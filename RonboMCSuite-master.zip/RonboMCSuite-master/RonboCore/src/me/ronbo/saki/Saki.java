package me.ronbo.saki;

public class Saki {
	
	//Saki Bloom the ultimate friend system
	
} 