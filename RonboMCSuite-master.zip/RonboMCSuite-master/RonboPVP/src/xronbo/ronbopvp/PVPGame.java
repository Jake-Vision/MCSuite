package xronbo.ronbopvp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.material.SpawnEgg;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.Potion;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.BlockIterator;
import org.bukkit.util.Vector;

import xronbo.common.effects.EffectCreator;
import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.ParticleDetails;
import xronbo.common.effects.ParticleType;
import xronbo.common.entitytypes.CustomZombie;
import xronbo.common.games.Game;
import xronbo.common.other.Values;
import xronbo.ronbopvp.RonboPVP.Stats;

public class PVPGame extends Game {

	public boolean checkEndCondition() {
		return false;
	}
	
	@Override
	protected double[] getSpawnLoc(Player p) {
		Location loc = world.getSpawnLocation();
		return new double[] {loc.getX(), loc.getY(), loc.getZ(), loc.getPitch(), loc.getYaw()};
	}
	
	public PVPGame(int id) {
		super(id);
	}
	
	@EventHandler
	public void onfire(BlockSpreadEvent event) {
		event.setCancelled(true);
	}

	protected int objectiveTask() {
		return -1;
	}

	
	@EventHandler
	public void quitlol(PlayerQuitEvent event) {
		killcount.remove(event.getPlayer().getName());
	}
	
	public HashMap<String, String> lastAttackedBy = new HashMap<String, String>();
	
	@EventHandler
	public void onPlayerAttack(EntityDamageByEntityEvent event) {
		if(event.getEntity() instanceof Player) {
			if(event.getDamager() instanceof Player) {
				lastAttackedBy.put(((Player)event.getEntity()).getName(), ((Player)event.getDamager()).getName());
			} else if(event.getDamager() instanceof Projectile && ((Projectile)event.getDamager()).getShooter() instanceof Player) {
				lastAttackedBy.put(((Player)event.getEntity()).getName(), ((Player)((Projectile)event.getDamager()).getShooter()).getName());
			}
		}
	}
	
	public HashMap<String, Integer> killcount = new HashMap<String, Integer>();

	public String top = null;
	public long lastCheck = 0;
	
	@Override
	protected void postEnter(Player p) {
		final Scoreboard board = plugin.getServer().getScoreboardManager().getNewScoreboard();
		final String name = p.getName();
		p.setScoreboard(board);
		killcount.put(p.getName(), 0);
		removeMetadata(p);
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public Objective side;
			public String getTop() {
				int max = -1;
				if(System.currentTimeMillis() - lastCheck > 2500 || top == null) {
					String s = "";
					lastCheck = System.currentTimeMillis();
					for(Entry<String, Integer> e : killcount.entrySet()) {
						if(e.getValue() > max) {
							s = e.getKey();
							max = e.getValue();
						}
					}
					return top = s;
				} else {
					return top;
				}
			}
			public void run() {
				if(plugin.getServer().getPlayerExact(name) == null)
					return;
				if(side != null)
					side.unregister();
				String top = getTop();
				String topdisplay = ChatColor.GOLD + top;
				if(topdisplay.length() > 16)
					topdisplay = topdisplay.substring(0, 16);
				side = board.registerNewObjective("info", "dummy");
				side.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Ronbattle");
				side.setDisplaySlot(DisplaySlot.SIDEBAR);
				int count = 14;
				side.getScore(ChatColor.GOLD + "Top Streak").setScore(count--);
				side.getScore(topdisplay).setScore(count--);
				side.getScore(ChatColor.GOLD + "" + (killcount.containsKey(top) ? killcount.get(top) + " Kills" : "")).setScore(count--);
				side.getScore(ChatColor.AQUA + "").setScore(count--);
				side.getScore(ChatColor.AQUA + "Players Online").setScore(count--);
				side.getScore(ChatColor.AQUA + "" + plugin.getServer().getOnlinePlayers().length).setScore(count--);
				side.getScore(ChatColor.BLACK + "").setScore(count--);
				side.getScore(ChatColor.GREEN + "Kill Streak").setScore(count--);
				side.getScore(ChatColor.GREEN + "" + (killcount.containsKey(name) ? killcount.get(name): 0) + " Kills").setScore(count--);
				side.getScore(ChatColor.BLUE + "").setScore(count--);
				side.getScore(ChatColor.LIGHT_PURPLE + "Battle Points").setScore(count--);
				side.getScore(ChatColor.LIGHT_PURPLE + "" + RonboPVP.stats.get(name).getTotalPoints() + " BP").setScore(count--);
				side.getScore(ChatColor.BOLD + "").setScore(count--);
				side.getScore(ChatColor.GOLD + "" + ChatColor.BOLD + "/stats").setScore(count--);
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
			}
		});
	}
	
	@EventHandler
	public void onrspn(PlayerRespawnEvent event) {
		if(event.getPlayer().hasMetadata("class")) {
			final String name = event.getPlayer().getName();
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					Player p = plugin.getServer().getPlayerExact(name);
					if(p != null)
						checkGiveKit(p, p.getMetadata("class").get(0).asString());
				}
			});
		}
	}
	
	@EventHandler
	public void leavewolfies(PlayerQuitEvent event) {
		if(world != null)
			for(Entity e : world.getEntities())
				if(e instanceof Wolf)
					if(((Wolf)e).getCustomName() != null && ((Wolf)e).getCustomName().contains(event.getPlayer().getName()))
						e.remove();
	}
	
	@EventHandler
	public void ondeath(final PlayerDeathEvent event) {
		event.getDrops().clear();
		event.getEntity().getInventory().clear();
		event.getEntity().getInventory().setArmorContents(null);
		String s = event.getEntity().getName();
		for(Entity e : world.getEntities())
			if(e instanceof Wolf)
				if(((Wolf)e).getCustomName() != null && ((Wolf)e).getCustomName().contains(event.getEntity().getName()))
					e.remove();
		for(PotionEffect pe : event.getEntity().getActivePotionEffects())
			event.getEntity().removePotionEffect(pe.getType());
		if(killcount.containsKey(s)) {
			int kills = killcount.get(s);
			if(kills >= 5) {
				if(lastAttackedBy.containsKey(s)) {
					message(ChatColor.RED + s + " was shut down by " + lastAttackedBy.get(s) + " after " + kills + " kills!");
				} else {
					message(ChatColor.RED + s + " was shut down after " + kills + " kills!");
				}
			}
		}
		if(lastAttackedBy.containsKey(s)) {
			event.getEntity().sendMessage(ChatColor.RED + "You were killed by " + lastAttackedBy.get(s) + ".");
		} else {
			event.getEntity().sendMessage(ChatColor.RED + "You were killed!");
		}
		removeMetadata(event.getEntity());
		if(lastAttackedBy.containsKey(s)) {
			String killer = lastAttackedBy.get(s);
			if(!killer.equals(s) && plugin.getServer().getPlayerExact(killer) != null) {
				giveKill(killer, s);
			}
		}
		lastAttackedBy.remove(s);
		killcount.put(s, 0);
		RonboPVP.stats.get(s).deaths++;
	}
	
	public void giveKill(String killer, String killed) {
		if(killcount.containsKey(killer))
			killcount.put(killer, killcount.get(killer) + 1);
		else
			killcount.put(killer, 1);
		checkKillStreak(killer);
		RonboPVP.stats.get(killer).kills++;
		int earned = 1;
		if(plugin.getServer().getPlayerExact(killer) != null && RankManager.checkEquals(plugin.getServer().getPlayerExact(killer), "noble")) {
			plugin.getServer().getPlayerExact(killer).sendMessage(ChatColor.GREEN + "As a Noble, you earn 2x BP!");
			earned = 2;
		} else if(plugin.getServer().getPlayerExact(killer) != null && RankManager.checkEquals(plugin.getServer().getPlayerExact(killer), "royal")) {
			plugin.getServer().getPlayerExact(killer).sendMessage(ChatColor.GREEN + "As a Royal, you earn 3x BP!");
			earned = 3;
		}
		RonboPVP.stats.get(killer).earnedPoints += earned;
		if(killcount.get(killer) % 3 == 0) {
			Potion potion = new Potion(PotionType.INSTANT_HEAL);
			potion.setLevel(2);
			plugin.getServer().getPlayerExact(killer).getInventory().addItem(potion.toItemStack(5));
			plugin.getServer().getPlayerExact(killer).getInventory().addItem(new ItemStack(Material.COOKED_BEEF));
			plugin.getServer().getPlayerExact(killer).sendMessage(ChatColor.GREEN + "You get 5 potions and 1 steak for getting 3 kills!");
		}
		plugin.getServer().getPlayerExact(killer).sendMessage(ChatColor.GREEN + "You get " + earned + " Battle Point" + (earned > 1 ? "s" : "") + " for killing " + killed + "! (Total: " + RonboPVP.stats.get(killer).getTotalPoints() + ")");
		if(killcount.get(killer) > RonboPVP.stats.get(killer).longest) {
			RonboPVP.stats.get(killer).longest = killcount.get(killer);
			plugin.getServer().getPlayerExact(killer).sendMessage(ChatColor.GREEN + "You reached a new longest killstreak of " + RonboPVP.stats.get(killer).longest + " kill" + (RonboPVP.stats.get(killer).longest > 1 ? "s" : "") + "!");
		}
		if(killcount.get(killer) % 5 == 0) {
			switch(killcount.get(killer)) {
				case 0:
					break;
				case 5:
					message(ChatColor.GOLD + killer + " is on a 5 kill streak!");
					break;
				case 10:
					message(ChatColor.GOLD + killer + " is on a 10 kill streak! So pro!");
					break;
				case 15:
					message(ChatColor.GOLD + killer + " is on a 15 kill streak! Better go kill'em!");
					break;
				case 20:
					message(ChatColor.GOLD + killer + " is on a 20 kill streak! So many kill streak rewards...");
					break;
				case 25:
					message(ChatColor.GOLD + killer + " is on a 25 kill streak! Watch out!");
					break;
				case 30:
					message(ChatColor.GOLD + killer + " is on a 30 kill streak! So OP!");
					break;
				case 35:
					message(ChatColor.GOLD + killer + " is on a 35 kill streak! Unstoppable??");
					break;
				case 40:
					message(ChatColor.GOLD + killer + " is on a 40 kill streak! Godly PVPer!");
					break;
				default:
					message(ChatColor.GOLD + killer + " is on a " + killcount.get(killer) + " kill streak! Goodness gracious!");
					break;
			}
		}
	}
	
	public void checkKillStreak(String s) {
		Potion potion = null;
		ItemStack item = null;
		ItemMeta im = null;
		if(killcount.containsKey(s) && plugin.getServer().getPlayerExact(s) != null) {
			final Player p = plugin.getServer().getPlayerExact(s);
			int ks = killcount.get(s);
			Stats stats = RonboPVP.stats.get(p.getName());
			switch(ks) {
				case 5:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Speed I");
					p.removePotionEffect(PotionEffectType.SPEED);
					p.addPotionEffect(PotionEffectType.SPEED.createEffect(Integer.MAX_VALUE, 0));
					break;
				case 10:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Jump I");
					p.removePotionEffect(PotionEffectType.JUMP);
					p.addPotionEffect(PotionEffectType.JUMP.createEffect(Integer.MAX_VALUE, 0));
					break;
				case 15:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Speed II");
					p.removePotionEffect(PotionEffectType.SPEED);
					p.addPotionEffect(PotionEffectType.SPEED.createEffect(Integer.MAX_VALUE, 1));
					if(!(p.hasMetadata("class") && p.getMetadata("class").get(0).asString().equals("tank"))) {
						p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Bonus Health");
						p.setMaxHealth(24.0);
						p.setHealth(24.0);
					}
					break;
				case 20:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Potion Set");
					potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					p.getInventory().addItem(potion.toItemStack(10));
					potion = new Potion(PotionType.FIRE_RESISTANCE);
					potion.setLevel(1);
					p.getInventory().addItem(potion.toItemStack(2));
					potion = new Potion(PotionType.WATER_BREATHING);
					potion.setLevel(1);
					p.getInventory().addItem(potion.toItemStack(2));
					potion = new Potion(PotionType.INSTANT_DAMAGE);
					potion.setLevel(1);
					potion.setSplash(true);
					p.getInventory().addItem(potion.toItemStack(2));
					break;
				case 25:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Speed III");
					p.removePotionEffect(PotionEffectType.SPEED);
					p.addPotionEffect(PotionEffectType.SPEED.createEffect(Integer.MAX_VALUE, 2));
					if(!(p.hasMetadata("class") && p.getMetadata("class").get(0).asString().equals("tank"))) {
						p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Bonus Health");
						p.setMaxHealth(30.0);
						p.setHealth(30.0);
					}
					break;
				case 30:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Strength I (Temporary)");
					p.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
					p.addPotionEffect(PotionEffectType.INCREASE_DAMAGE.createEffect(20 * 60, 0));
					break;
				case 35:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Strength I (Temporary)");
					p.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
					p.addPotionEffect(PotionEffectType.INCREASE_DAMAGE.createEffect(20 * 60, 0));
					break;
				case 40:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Strength II (Temporary)");
					p.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
					p.addPotionEffect(PotionEffectType.INCREASE_DAMAGE.createEffect(20 * 60, 1));
					break;
				case 45:
					p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Strength II (Temporary)");
					p.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
					p.addPotionEffect(PotionEffectType.INCREASE_DAMAGE.createEffect(20 * 60, 1));
					break;
				case 50:
					if(!(p.hasMetadata("class") && p.getMetadata("class").get(0).asString().equals("tank"))) {
						p.sendMessage(ChatColor.AQUA + "" +  ks + " Kill Streak Reward Earned: Bonus Health");
						p.setMaxHealth(40.0);
						p.setHealth(40.0);
					}
					break;
				default:
					break;
			}
			if(p.hasMetadata("class")) {
				switch(p.getMetadata("class").get(0).asString()) {
					case "mercenary":
						switch(ks) {
							case 2:
								p.sendMessage(ChatColor.AQUA + "Mercenary " +  ks + " Kill Streak Reward Earned: Well Supplied");
								potion = new Potion(PotionType.INSTANT_HEAL);
								potion.setLevel(2);
								p.getInventory().addItem(potion.toItemStack(20));
								break;
							case 5:
								item = new ItemStack(Material.BLAZE_ROD);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "Lightning Rod");
								im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Right click to summon lightning!",
										ChatColor.YELLOW + "Bolts Left: 10"}));
								item.setItemMeta(im);
								p.sendMessage(ChatColor.AQUA + "Mercenary " +  ks + " Kill Streak Reward Earned: Lightning Rod");
								p.getInventory().addItem(item);
								break;
							case 9:
								item = new ItemStack(Material.TNT);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.RED + "Explosive Rain Activator");
								im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Place this down to use it!",}));
								item.setItemMeta(im);
								p.sendMessage(ChatColor.AQUA + "Mercenary " +  ks + " Kill Streak Reward Earned: Explosive Rain");
								p.getInventory().addItem(item);
								break;
							case 13:
								if(stats.kitunlocks.contains("wolfpack")) {
									item = new ItemStack(Material.BONE);
									im = item.getItemMeta();
									im.setDisplayName(ChatColor.BLUE + "Wolf Pack Summoner");
									im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Call in the wolves!!!",}));
									item.setItemMeta(im);
									p.sendMessage(ChatColor.AQUA + "Mercenary " +  ks + " Kill Streak Reward Earned: Wolf Pack");
									p.getInventory().addItem(item);
								}
								break;
							case 40:
								if(stats.kitunlocks.contains("superwolfpack")) {
									item = new ItemStack(Material.BONE);
									im = item.getItemMeta();
									im.setDisplayName(ChatColor.BLUE + "Super Wolf Pack Summoner");
									im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Call in the Super Wolfies!!!",}));
									item.setItemMeta(im);
									p.sendMessage(ChatColor.AQUA + "Mercenary " +  ks + " Kill Streak Reward Earned: Super Wolf Pack");
									p.getInventory().addItem(item);
								}
								break;
							default:
								break;
						}
						break;
					case "archer":
						switch(ks) {
							case 5:
								p.sendMessage(ChatColor.AQUA + "Archer " +  ks + " Kill Streak Reward Earned: Fire Spirit");
								p.setMetadata("firespirit", new FixedMetadataValue(plugin, 0));
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
									public void run() {
										p.removeMetadata("firespirit", plugin);
									}
								}, 2 * 20 * 60);
								break;
							case 10:
								p.sendMessage(ChatColor.AQUA + "Archer " +  ks + " Kill Streak Reward Earned: Thunder Spirit");
								p.setMetadata("thunderspirit", new FixedMetadataValue(plugin, 0));
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
									public void run() {
										p.removeMetadata("thunderspirit", plugin);
									}
								}, 2 * 20 * 60);
								break;
							case 15:
								if(stats.kitunlocks.contains("earthspirit")) {
									p.sendMessage(ChatColor.AQUA + "Archer " +  ks + " Kill Streak Reward Earned: Earth Spirit");
									p.setMetadata("earthspirit", new FixedMetadataValue(plugin, 0));
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
										public void run() {
											p.removeMetadata("earthspirit", plugin);
										}
									}, 2 * 20 * 60);
								}
								break;
							case 25:
								if(stats.kitunlocks.contains("kastiaspirit")) {
									p.sendMessage(ChatColor.AQUA + "Archer " +  ks + " Kill Streak Reward Earned: Spirit of Kastia");
									p.setMetadata("kastiaspirit", new FixedMetadataValue(plugin, 0));
								}
								break;
							case 35:
								if(stats.kitunlocks.contains("windspirit")) {
									p.sendMessage(ChatColor.AQUA + "Archer " +  ks + " Kill Streak Reward Earned: Wind Spirit");
									p.setMetadata("windspirit", new FixedMetadataValue(plugin, 0));
								}
								break;
							default:
								break;
						}
						break;
					case "wizard":
						switch(ks) {
							case 3:
								p.sendMessage(ChatColor.AQUA + "Wizard " +  ks + " Kill Streak Reward Earned: Melee Wizard");
								p.getInventory().addItem(new ItemStack(Material.IRON_SWORD));
								break;
							case 7:
								p.sendMessage(ChatColor.AQUA + "Wizard " +  ks + " Kill Streak Reward Earned: Backup Plan");
								p.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, 10));
								break;
							case 13:
								p.sendMessage(ChatColor.AQUA + "Wizard " +  ks + " Kill Streak Reward Earned: Shockwave");
								item = new ItemStack(Material.STICK);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.LIGHT_PURPLE + "Shockwave");
								im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Right click to cast spell!",}));
								item.setItemMeta(im);
								item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 2);
								p.getInventory().addItem(item);
								break;
							case 25:
								if(stats.kitunlocks.contains("supercaster")) {
									p.sendMessage(ChatColor.AQUA + "Wizard " +  ks + " Kill Streak Reward Earned: Super Caster");
									p.setMetadata("supercaster", new FixedMetadataValue(plugin, 0));
								}
								break;
							default:
								break;
						}
						break;
					case "tank":
						switch(ks) {
							case 4:
								p.sendMessage(ChatColor.AQUA + "Tank " +  ks + " Kill Streak Reward Earned: Exercise");
								p.removePotionEffect(PotionEffectType.SLOW);
								p.addPotionEffect(PotionEffectType.SLOW.createEffect(200000, 0));
								break;
							case 9:
								p.sendMessage(ChatColor.AQUA + "Tank " +  ks + " Kill Streak Reward Earned: Beefy");
								p.setMaxHealth(60.0);
								p.setHealth(60.0);
								break;
							case 19:
								p.sendMessage(ChatColor.AQUA + "Tank " +  ks + " Kill Streak Reward Earned: Gravity");
								p.setMetadata("gravity", new FixedMetadataValue(plugin, 1));
								final String name = p.getName();
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
									public void run() {
										if(plugin.getServer().getPlayerExact(name) == null || !plugin.getServer().getPlayerExact(name).hasMetadata("gravity"))
											return;
										for(Entity e : plugin.getServer().getPlayerExact(name).getNearbyEntities(10, 5, 10))
											if(e instanceof Player)
												((Player) e).addPotionEffect(PotionEffectType.SLOW.createEffect(20 * 5, 1));
										plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20 * 2);
									}
								});
								break;
							case 25:
								if(stats.kitunlocks.contains("repulsion")) {
									p.sendMessage(ChatColor.AQUA + "Tank " +  ks + " Kill Streak Reward Earned: Repulsion");
									p.setMetadata("repulsion", new FixedMetadataValue(plugin, 0));
								}
								break;
							default:
								break;
						}
						break;
					case "gladiator":
						switch(ks) {
							case 3:
								p.sendMessage(ChatColor.AQUA + "Gladiator " +  ks + " Kill Streak Reward Earned: Relentless");
								p.setMetadata("relentless", new FixedMetadataValue(plugin, 0));
								break;
							case 7:
								p.sendMessage(ChatColor.AQUA + "Gladiator " +  ks + " Kill Streak Reward Earned: Bloodthirsty");
								item = new ItemStack(Material.COMPASS);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "The Hunter");
								im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Right click to cast spell!",}));
								item.setItemMeta(im);
								p.getInventory().addItem(item);
								break;
							case 15:
								p.sendMessage(ChatColor.AQUA + "Gladiator " +  ks + " Kill Streak Reward Earned: Unstoppable");
								p.setMetadata("relentless", new FixedMetadataValue(plugin, 0));
								break;
							case 25:
								if(stats.kitunlocks.contains("duelist")) {
									p.sendMessage(ChatColor.AQUA + "Gladiator " +  ks + " Kill Streak Reward Earned: Duelist");
									p.addPotionEffect(PotionEffectType.REGENERATION.createEffect(200000, 2));
								}
								break;
							default:
								break;
						}
						break;
					default:
						break;
				}
			}
		}
	}
	
	@EventHandler
	public void onInvOpenFurnace(PlayerInteractEvent event) {
		try {
			if(event.getClickedBlock().getType() == Material.FURNACE)
				event.setCancelled(true);
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onProjectileLaunch(ProjectileLaunchEvent event) {
		if(event.getEntity() instanceof Arrow) {
			if(event.getEntity().getShooter() == null)
				return;
			if(event.getEntity().getShooter().hasMetadata("firespirit"))
				event.getEntity().setFireTicks(20 * 20);
			if(event.getEntity().getShooter().hasMetadata("thunderspirit"))
				event.getEntity().setMetadata("thunderspirit", new FixedMetadataValue(plugin, 0));
			if(event.getEntity().getShooter().hasMetadata("earthspirit"))
				event.getEntity().setMetadata("earthspirit", new FixedMetadataValue(plugin, 0));
			if(event.getEntity().getShooter().hasMetadata("kastiaspirit")) {
				event.getEntity().setFireTicks(20 * 20);
				event.getEntity().setMetadata("earthspirit", new FixedMetadataValue(plugin, 0));
			}
		}
	}
	
	@EventHandler
	public void onProjHit(ProjectileHitEvent event) {
		if(event.getEntity() instanceof Arrow) {
			if(event.getEntity().hasMetadata("thunderspirit"))
				event.getEntity().getWorld().strikeLightning(event.getEntity().getLocation());
			if(event.getEntity().hasMetadata("earthspirit"))
				event.getEntity().getWorld().createExplosion(event.getEntity().getLocation().getX(), 
						event.getEntity().getLocation().getY(), event.getEntity().getLocation().getZ(), 1.3f, false, false);
		}
	}
	
	public void removeMetadata(Player p) {
		p.removeMetadata("exited", plugin);
		p.removeMetadata("arrowblock", plugin);
		p.removeMetadata("firespirit", plugin);
		p.removeMetadata("thunderspirit", plugin);
		p.removeMetadata("earthspirit", plugin);
		p.removeMetadata("kastiaspirit", plugin);
		p.removeMetadata("windspirit", plugin);
		p.removeMetadata("supercaster", plugin);
		p.removeMetadata("gravity", plugin);
		p.removeMetadata("repulsion", plugin);
		p.removeMetadata("relentless", plugin);
		p.removeMetadata("unstoppable", plugin);
	}
	
	@EventHandler
	public void ondmgnotexit(EntityDamageEvent event) {
		if(!event.getEntity().hasMetadata("exited"))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void ondmgbyexited(EntityDamageByEntityEvent event) {
		if(event.getDamager() instanceof Player && !event.getDamager().hasMetadata("exited"))
			event.setCancelled(true);
		if(event.getDamager() instanceof Projectile && !((Projectile)event.getDamager()).getShooter().hasMetadata("exited"))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onEntityExplode(EntityExplodeEvent event) {
		event.blockList().clear();
	}
	
	@EventHandler
	public void ondam124(EntityDamageByEntityEvent event) {
		if(event.getEntity().hasMetadata("repulsion"))
			event.getDamager().setVelocity(event.getEntity().getLocation().subtract(event.getDamager().getLocation()).toVector().normalize().multiply(-2.0));
		if(event.getDamager().hasMetadata("relentless") && event.getDamager() instanceof LivingEntity)
			((LivingEntity)event.getDamager()).addPotionEffect(PotionEffectType.SPEED.createEffect(20 * 2, 2));
		if(event.getEntity().hasMetadata("unstoppable"))
			if(Math.random() < 0.3)
				event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockPlace(final BlockPlaceEvent event) {
		if(event.getBlock().getType() == Material.TNT) {
			if(checkCanCast(event.getPlayer(), 1000)) {
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						int i = event.getPlayer().getInventory().first(Material.TNT);
						if(i >= 0) {
							ItemStack item = event.getPlayer().getInventory().getItem(i);
							if(item.getAmount() > 1)
								item.setAmount(item.getAmount() - 1);
							else
								event.getPlayer().getInventory().setItem(i, new ItemStack(Material.AIR));
							for(Entity e : event.getPlayer().getNearbyEntities(25, 50, 25)) {
								if(e instanceof Player) {
									((Player)e).sendMessage(ChatColor.RED + "WARNING! " + event.getPlayer().getName() + " just triggered an Explosive Rain near you!");
								}
							}
							event.getPlayer().sendMessage(ChatColor.RED + "You triggered an Explosive Rain. RUN. IT CAN HURT YOU TOO.");
							final Location loc = event.getPlayer().getLocation();
							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
								public int count = 25;
								public void run() {
									for(int dx = -7; dx <= 7; dx++) {
										for(int dz = -7; dz <= 7; dz++) {
											if(count <= 0)
												break;
											if(Math.random() < 0.05) {
												count--;
												Location temp = loc.clone().add(dx, (int)(Math.random() * 15 + 10), dz);
												TNTPrimed ptnt = (TNTPrimed)temp.getWorld().spawnEntity(temp, EntityType.PRIMED_TNT);
												ptnt.setFuseTicks((int)(Math.random() * 40 + 30));
											}
										}
										if(count <= 0)
											break;
									}
									if(count > 0)
										plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, (int)(Math.random() * 20 + 5));
								}
							}, 60);
						}
					}
				}, 5);
			}
		}
	}
	
	@EventHandler
	public void fixdurability(EntityDamageEvent event) {
		if(event.getEntity() instanceof Player) {
			Player p = (Player)event.getEntity();
			try {
				if(p.getItemInHand().getType() != Material.POTION && p.getItemInHand().getType() != Material.GLASS_BOTTLE)
					p.getItemInHand().setDurability((short)0);
				p.getEquipment().getHelmet().setDurability((short)0);
				p.getEquipment().getChestplate().setDurability((short)0);
				p.getEquipment().getLeggings().setDurability((short)0);
				p.getEquipment().getBoots().setDurability((short)0);
			} catch(Exception e) {
				
			}
		}
	}
	
	public HashMap<String, Long> doublejumpcd = new HashMap<String, Long>();
	@EventHandler
	public void onFlyToggle(PlayerToggleFlightEvent event) {
		if(event.getPlayer().hasMetadata("class") && event.getPlayer().getMetadata("class").get(0).asString().equals("archer")) {
			event.setCancelled(true);
			Location loc = event.getPlayer().getLocation();
			event.getPlayer().setVelocity(new Vector(0,0,0));
			event.getPlayer().setFlying(false);
			event.getPlayer().setVelocity(new Vector(0,0,0));
			if(doublejumpcd.containsKey(event.getPlayer().getName())) {
				if(System.currentTimeMillis() < doublejumpcd.get(event.getPlayer().getName())) {
					event.getPlayer().sendMessage(ChatColor.RED + "You can't Double Jump for " + String.format("%.1f", (doublejumpcd.get(event.getPlayer().getName()) - System.currentTimeMillis()) / 1000.0) + " more seconds.");
					event.getPlayer().setVelocity(new Vector(0,0,0));
					event.getPlayer().teleport(loc);
					return;
				}
			}
			if(event.getPlayer().hasMetadata("windspirit")) {
				doublejumpcd.put(event.getPlayer().getName(), System.currentTimeMillis() + 2500);
			} else {
				doublejumpcd.put(event.getPlayer().getName(), System.currentTimeMillis() + 5000);
			}
			event.getPlayer().setVelocity(event.getPlayer().getEyeLocation().getDirection().normalize().add(new Vector(0,0.2,0)));
		}
	}
	
	public void showKSRewards(String s, Player p) {
		Inventory inventory = null;
		try {
			inventory = plugin.getServer().createInventory(p, 6*9, ChatColor.BLACK + s + " Streak Rewards");
		} catch(Exception e) {
			return;
		}
		ItemStack item = null;
		ItemMeta im = null;
		Potion potion = null;
		Stats stats = RonboPVP.stats.get(p.getName());
		
		item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLACK.getData());
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.BLACK + "");
		item.setItemMeta(im);
		for(int k = 0; k < 9; k++)
			inventory.setItem(k, item);
		
		item = new ItemStack(Material.BOOK);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + s + " Kill Streak Rewards");
		im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "These Kill Streak rewards are only available when playing as a " + s + ".", "Unlock all the Kill Streak Rewards with Battle Points for maximum awesomeness!"));
		item.setItemMeta(im);
		inventory.setItem(4, item);
		
		item = new ItemStack(Material.IRON_FENCE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "vvv Locked vvv");
		im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Unlock the below Kill Streak Rewards with Battle Points!", "Once you unlock one, it will be available forever."));
		item.setItemMeta(im);
		for(int k = 27; k < 27 + 9; k++)
			inventory.setItem(k, item);
		ArrayList<ItemStack> unlocked = new ArrayList<ItemStack>();
		ArrayList<ItemStack> locked = new ArrayList<ItemStack>();
		switch(s) { //s should be the NPC name, not the metadata "class" name
			case "Mercenary":
				potion = new Potion(PotionType.INSTANT_HEAL);
				item = potion.toItemStack(1);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "2 Kills - Well Supplied");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Get 20 additional Health Potions!"));
				item.setItemMeta(im);
				unlocked.add(Values.removeAttributes(item));
				
				item = new ItemStack(Material.BLAZE_ROD);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "5 Kills - Lightning Rod");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Receive a Lightning Rod that can smite your enemies!"));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.TNT);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "9 Kills - Explosive Rain");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Place the TNT to call in an storm of Explosive Rain!", "Careful, you can hurt yourself!"));
				item.setItemMeta(im);
				unlocked.add(item);

				item = new ItemStack(Material.MONSTER_EGG);
				item.setData(new SpawnEgg(EntityType.WOLF));
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "13 Kills - Wolf Pack");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Summon a pack of loyal wolves!"));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("wolfpack")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 50 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}

				item = new ItemStack(Material.MONSTER_EGG);
				item.setData(new SpawnEgg(EntityType.WOLF));
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "40 Kills - Super Wolf Pack");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Summon a pack of Super Wolfies!"));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("superwolfpack")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 500 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				break;
			case "Archer":
				item = new ItemStack(Material.ARROW);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "5 Kills - Fire Spirit");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "You shoot fire arrows for 2 minutes."));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.BLAZE_ROD);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "10 Kills - Thunder Spirit");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "You shoot thunder arrows for 2 minutes."));
				item.setItemMeta(im);
				unlocked.add(item);

				item = new ItemStack(Material.TNT);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "15 Kills - Earth Spirit");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "You shoot explosive arrows for 2 minutes."));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("earthspirit")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 75 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}

				item = new ItemStack(Material.BLAZE_POWDER);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "25 Kills - Spirit of Kastia");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "You shoot explosive fire arrows until you die!"));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("kastiaspirit")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 300 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				
				item = new ItemStack(Material.FEATHER);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "35 Kills - Wind Spirit");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Double Jump cooldown halved!"));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("windspirit")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 850 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				break;
			case "Wizard":
				item = new ItemStack(Material.IRON_SWORD);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "3 Kills - Melee Wizard");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Who needs wands? Get a pro sword to fight with!"));
				item.setItemMeta(im);
				unlocked.add(Values.removeAttributes(item));
				
				item = new ItemStack(Material.ENDER_PEARL);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "7 Kills - Backup Plan");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Get 10 Ender Pearls to use in case your Teleporter isn't ready."));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.DIRT);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "13 Kills - Shockwave");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Get the powerful Shockwave wand."));
				item.setItemMeta(im);
				unlocked.add(item);

				item = new ItemStack(Material.STRING);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "25 Kills - Super Caster");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Your cooldowns are 5 seconds shorter."));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("supercaster")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 150 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				break;
			case "Tank":
				item = new ItemStack(Material.SUGAR);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "4 Kills - Exercise");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Wow you are not as slow anymore!"));
				item.setItemMeta(im);
				unlocked.add(item);

				item = new ItemStack(Material.COOKED_BEEF);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "9 Kills - Beefy");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Your maximum HP increases!"));
				item.setItemMeta(im);
				unlocked.add(item);

				item = new ItemStack(Material.WEB);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "19 Kills - Gravity");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Everyone around you is slowed!"));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.SLIME_BALL);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "25 Kills - Repulsion");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Whenever you are hit, the attacker will be knocked back."));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("repulsion")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 350 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				break;
			case "Gladiator":
				item = new ItemStack(Material.RAILS);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "3 Kills - Relentless");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Get a temporary speed boost whenever you hit an enemy!"));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.COMPASS);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "7 Kills - Bloodthirsty");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Get a magic compass to warp you to nearby players."));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.POWERED_RAIL);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "15 Kills - Unstoppable");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "You have a 30% chance to ignore damage!"));
				item.setItemMeta(im);
				unlocked.add(item);
				
				item = new ItemStack(Material.STRING);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "25 Kills - Duelist");
				im.setLore(Values.longStringToLoreList(ChatColor.YELLOW, "Regeneration! Yay!"));
				item.setItemMeta(im);
				if(stats.kitunlocks.contains("duelist")) {
					unlocked.add(item);
				} else {
					im.setDisplayName(ChatColor.RED + ChatColor.stripColor(im.getDisplayName()) + " (LOCKED)");
					List<String> lore = im.getLore();
					lore.add(0, ChatColor.GOLD + "Click to unlock for 275 BP!");
					im.setLore(lore);
					item.setItemMeta(im);
					locked.add(item);
				}
				break;
			default:
				return;
		}
		int count = 9;
		for(ItemStack i : unlocked)
			inventory.setItem(count++, i);
		count = 36;
		for(ItemStack i : locked)
			inventory.setItem(count++, i);
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void oniclick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().contains("Streak Rewards")) {
				String classname = ChatColor.stripColor(event.getInventory().getName());
				classname = classname.substring(0, classname.indexOf(" Streak Rewards"));
				event.setCancelled(true);
				ItemStack item = event.getCurrentItem();
				ItemMeta im = item.getItemMeta();
				if(im.getLore().get(0).contains("Click to unlock")) {
					int price = Integer.parseInt(ChatColor.stripColor(im.getLore().get(0)).replaceAll("[^0-9]", ""));
					Stats stats = RonboPVP.stats.get(event.getWhoClicked().getName());
					String tag = "";
					if(im.getDisplayName().toLowerCase().contains("wolf pack")) {
						tag = "wolfpack";
					}
					if(im.getDisplayName().toLowerCase().contains("super wolf pack")) {
						tag = "superwolfpack";
					}
					if(im.getDisplayName().toLowerCase().contains("earth spirit")) {
						tag = "earthspirit";
					}
					if(im.getDisplayName().toLowerCase().contains("spirit of kastia")) {
						tag = "kastiaspirit";
					}
					if(im.getDisplayName().toLowerCase().contains("super caster")) {
						tag = "supercaster";
					}
					if(im.getDisplayName().toLowerCase().contains("wind spirit")) {
						tag = "windspirit";
					}
					if(im.getDisplayName().toLowerCase().contains("repulsion")) {
						tag = "repulsion";
					}
					if(im.getDisplayName().toLowerCase().contains("duelist")) {
						tag = "duelist";
					}
					if(tag.length() > 0) {
						event.getWhoClicked().closeInventory();
						if(stats.getTotalPoints() >= price) {
							stats.kitunlocks.add(tag);
							stats.earnedPoints -= price;
							((Player)event.getWhoClicked()).sendMessage(ChatColor.GREEN + "You unlocked " + im.getDisplayName().substring(0, im.getDisplayName().indexOf("(LOCKED)") - 1) + ChatColor.GREEN + " for " + classname + "!");
							((Player)event.getWhoClicked()).sendMessage(ChatColor.GREEN + "You have " + stats.getTotalPoints() + " BP left.");
							stats.save();
						} else {
							((Player)event.getWhoClicked()).sendMessage(ChatColor.RED + "You need " + price + " BP to unlock that! You have " + stats.getTotalPoints() + " BP.");
						}
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onDropItem(PlayerDropItemEvent event) {
		event.setCancelled(true);
	}
	
	public HashMap<String, Long> cooldowns = new HashMap<String, Long>();
	
	@EventHandler
	public void oncombust(EntityCombustEvent event) {
		if(event.getEntity().hasMetadata("invincible")) {
			event.setDuration(0);
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onpie(PlayerInteractEvent event) {
		ItemStack item = event.getPlayer().getItemInHand();
		Player p = event.getPlayer();
		if(!p.hasMetadata("exited")) {
			p.sendMessage(ChatColor.RED + "You can't cast spells in spawn!");
			return;
		}
		if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Gravity Sword")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(checkCanCast(p, 20000)) {
						p.sendMessage(ChatColor.GOLD + "You use the Gravity Sword to draw enemies towards you.");
						for(Entity e : p.getNearbyEntities(12,5,12)) {
							if(e instanceof LivingEntity && !e.hasMetadata("invincible")) {
								if(e instanceof Player && !e.hasMetadata("exited"))
									continue;
								e.setVelocity(p.getLocation().subtract(e.getLocation()).toVector().normalize().multiply(1.5));
							}
					}
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Lightning Rod")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				BlockIterator bi = new BlockIterator(event.getPlayer(), 100);
				Block b = null;
				while(bi.hasNext()) {
					b = bi.next();
					if(b.getType() != Material.AIR)
						break;
				}
				if(b == null || b.getType() == Material.AIR) {
					event.getPlayer().sendMessage(ChatColor.RED + "There was no block in range (100), so your Lightning Rod didn't cast.");
				} else {
					if(checkCanCast(p, 2000)) {
						int shots = Integer.parseInt(ChatColor.stripColor(item.getItemMeta().getLore().toString()).replaceAll("[^0-9]", ""));
						if(--shots == 0) {
							event.getPlayer().sendMessage(ChatColor.RED + "Your Lightning Rod ran out of energy!");
							event.getPlayer().setItemInHand(new ItemStack(Material.AIR));
						} else {
							event.getPlayer().sendMessage(ChatColor.RED + "Your Lightning Rod can summon " + shots + " more lightning bolts!");
							ItemMeta im = item.getItemMeta();
							im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Right click to summon lightning!",
									ChatColor.YELLOW + "Bolts Left: " + shots}));
							item.setItemMeta(im);
						}
						Location loc = b.getLocation();
						loc.getWorld().strikeLightning(loc);
					}
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Wolf Pack") && !item.getItemMeta().getDisplayName().contains("Super")) {
			event.getPlayer().setItemInHand(new ItemStack(Material.AIR));
			Location loc = event.getPlayer().getLocation();
			int num = (int)(Math.random() * 2 + 3);
			for(int k = 0; k < num; k++) {
				Wolf w = (Wolf)event.getPlayer().getWorld().spawnEntity(loc.clone().add(Math.random() * 7 - 3, 0, Math.random() * 7 - 3), EntityType.WOLF);
				w.setOwner(event.getPlayer());
				w.setAdult();
				w.setCollarColor(DyeColor.ORANGE);
				w.setAngry(true);
				w.setCustomNameVisible(true);
				w.setCustomName(ChatColor.RED + event.getPlayer().getName() + "'s Wolfie");
				w.setMaxHealth(5.0);
				w.setHealth(5.0);
				w.addPotionEffect(PotionEffectType.SPEED.createEffect(200000, 0));
			}
			event.getPlayer().sendMessage(ChatColor.GREEN + "You summon your lovely wolf friends!");
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Super Wolf Pack")) {
			event.getPlayer().setItemInHand(new ItemStack(Material.AIR));
			Location loc = event.getPlayer().getLocation();
			int num = (int)(Math.random() * 1 + 2);
			for(int k = 0; k < num; k++) {
				Wolf w = (Wolf)event.getPlayer().getWorld().spawnEntity(loc.clone().add(Math.random() * 7 - 3, 0, Math.random() * 7 - 3), EntityType.WOLF);
				w.setOwner(event.getPlayer());
				w.setAdult();
				w.setCollarColor(DyeColor.ORANGE);
				w.setAngry(true);
				w.setCustomNameVisible(true);
				w.setCustomName(ChatColor.RED + "" + ChatColor.BOLD + event.getPlayer().getName() + "'s Super Wolfie");
				w.setMaxHealth(12.0);
				w.setHealth(12.0);
				w.addPotionEffect(PotionEffectType.SPEED.createEffect(200000, 1));
				w.addPotionEffect(PotionEffectType.INCREASE_DAMAGE.createEffect(200000, 0));
			}
			event.getPlayer().sendMessage(ChatColor.GREEN + "You summon your lovely wolf friends!");
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Bow of the Heavens")) {
			if(event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
				if(checkCanCast(event.getPlayer(), 10000)) {
					try {
						final Location loc = event.getPlayer().getTargetBlock(null, 0).getLocation();
						final Player shooter = event.getPlayer();
						shooter.sendMessage(ChatColor.GREEN + "A shower of arrows rains down from the heavens.");
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public int count = 30;
							public void run() {
								for(int x = -3; x <= 3; x++) {
									if(count <= 0)
										break;
									for(int z = -3; z <= 3; z++) {
										if(count <= 0)
											break;
										if(Math.random() < 0.05) {
											count--;
											Location currentLoc = loc.clone();
											currentLoc.setX(loc.getX() + x - 1);
											currentLoc.setZ(loc.getZ() + z);
											currentLoc.setY(loc.getY() + 6);
											Projectile proj = ((Projectile)(loc.getWorld().spawnEntity(currentLoc, EntityType.ARROW)));
											Location loc2 = loc.clone();
											loc2.setX(loc.getX() + x);
											loc2.setZ(loc.getZ() + z);
											Vector v = loc2.toVector().subtract(currentLoc.toVector()).normalize();
											proj.setVelocity(v);
											proj.setShooter(shooter);
										}
									}
								}
								if(count > 0)
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, (int)(Math.random() * 3 + 1));
							}
						});
					} catch(Exception e) {
						
					}
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Arrow Deflector")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(checkCanCast(event.getPlayer(), 20000)) {
					event.getPlayer().sendMessage(ChatColor.GREEN + "You activate your Arrow Deflector!");
					event.getPlayer().sendMessage(ChatColor.GREEN + "For 5 seconds, arrows cannot hit you.");
					event.getPlayer().setMetadata("arrowblock", new FixedMetadataValue(plugin, 1));
					final Player p2 = event.getPlayer();
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							p2.removeMetadata("arrowblock", plugin);
						}
					}, 20 * 5);
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Tornado")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				BlockIterator bi = new BlockIterator(event.getPlayer(), 20);
				Block b = null;
				while(bi.hasNext()) {
					b = bi.next();
					if(b.getType() != Material.AIR)
						break;
				}
				if(b == null || b.getType() == Material.AIR) {
					event.getPlayer().sendMessage(ChatColor.RED + "There was no block in range (20), so your Tornado didn't cast.");
				} else {
					if(checkCanCast(p, 25000)) {
						createTornado(b.getLocation().add(0,1,0), p);
					}
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Teleporter")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(p.hasMetadata("cantp")) {
					BlockIterator bi = new BlockIterator(event.getPlayer(), 40);
					Block b = null;
					while(bi.hasNext()) {
						b = bi.next();
						if(b.getType() != Material.AIR)
							break;
					}
					if(b == null || b.getType() == Material.AIR) {
						event.getPlayer().sendMessage(ChatColor.RED + "There was no block in range (40) so you didn't Teleport.");
					} else {
						HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
						particles.add(new ParticleDetails(ParticleType.RAINBOWSWIRL));
						EffectHolder holder = EffectCreator.createLocHolder(particles, p.getLocation());
						holder.setRunning(true);
						holder.update();
						holder.setRunning(false);
						p.removeMetadata("cantp", plugin);
						p.setFallDistance(0);
						Location loc = b.getLocation().add(0,1,0);
						loc.setPitch(p.getLocation().getPitch());
						loc.setYaw(p.getLocation().getYaw());
						p.teleport(loc);
						holder = EffectCreator.createLocHolder(particles, loc);
						holder.setRunning(true);
						holder.update();
						holder.setRunning(false);
					}
				} else {
					if(checkCanCast(p, 20000)) {
						p.setVelocity(new Vector(0,2,0));
						p.sendMessage(ChatColor.GOLD + "Right click a destination within 40 blocks to teleport!");
						p.setMetadata("cantp", new FixedMetadataValue(plugin, 1));
						p.setMetadata("nofall", new FixedMetadataValue(plugin, 1));
						HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
						particles.add(new ParticleDetails(ParticleType.MAGIC));
						EffectHolder holder = EffectCreator.createLocHolder(particles, p.getLocation());
						holder.setRunning(true);
						holder.update();
						holder.setRunning(false);
					}
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Shockwave")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(checkCanCast(p, 15000)) {
					p.sendMessage(ChatColor.GOLD + "Boom! A powerful shockwave ripples across the ground.");
					createShockwave(p);
				}
			}
		} else if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("The Hunter")) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(checkCanCast(p, 15000)) {
					Entity closest = null;
					double distance = Integer.MAX_VALUE;
					for(Entity e : p.getNearbyEntities(50, 20, 50)) {
						if(!(e instanceof Player))
							continue;
						if(e.getLocation().distanceSquared(p.getLocation()) < distance) {
							distance = e.getLocation().distanceSquared(p.getLocation());
							closest = e;
						}
					}
					if(closest != null) {
						p.sendMessage(ChatColor.GOLD + "Poof! You teleported to the closest nearby player.");
						HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
						particles.add(new ParticleDetails(ParticleType.MAGIC));
						EffectHolder holder = EffectCreator.createLocHolder(particles, p.getLocation());
						holder.setRunning(true);
						holder.update();
						holder.setRunning(false);
						p.teleport(closest.getLocation());
						holder = EffectCreator.createLocHolder(particles, closest.getLocation());
						holder.setRunning(true);
						holder.update();
						holder.setRunning(false);
					} else {
						p.sendMessage(ChatColor.RED + "There were no players within range, so your teleport failed.");
					}
						
				}
			}
		}
	}
	
	@EventHandler
	public void ond241(EntityDamageEvent event) {
		if(event.getCause() == DamageCause.FALL) {
			if(event.getEntity().hasMetadata("nofall")) {
				event.setCancelled(true);
				event.getEntity().removeMetadata("nofall", plugin);
			}
		}
	}
	
	public static final Material[] tornadoMats = {
		Material.DIRT,
		Material.GRASS,
		Material.STONE,
		Material.COBBLESTONE,
		Material.COAL_ORE,
		Material.COAL_BLOCK,
		Material.REDSTONE_ORE,
		Material.GOLD_ORE,
		Material.MOSSY_COBBLESTONE
	};
	
	public void createTornado(final Location l, Player p2) {
		final String name = p2.getName();
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int count = 16;
			public void run()  {
				for(int k = 0; k < 20; k++) {
					final Location loc = l.clone();
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							if(fb == null) {
								fb = loc.getWorld().spawnFallingBlock(loc, tornadoMats[(int)(Math.random() * tornadoMats.length)], (byte)0);
								fb.setDropItem(false);
							}
							if(Math.random() < 0.005) {
								HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
								particles.add(new ParticleDetails(ParticleType.CLOUD));
								EffectHolder holder = EffectCreator.createLocHolder(particles, fb.getLocation());
								holder.setRunning(true);
								holder.update();
								holder.setRunning(false);
							}
							if(Math.random() < 0.001) {
								HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
								particles.add(new ParticleDetails(ParticleType.SMOKE));
								EffectHolder holder = EffectCreator.createLocHolder(particles, fb.getLocation());
								holder.setRunning(true);
								holder.update();
								holder.setRunning(false);
							}
							double radius = Math.sin(verticalTicker()) * 2;
				            float horisontal = horisontalTicker();
				            Vector v = new Vector(radius * Math.cos(horisontal), 0.15D, radius * Math.sin(horisontal));
				            fb.setVelocity(v);
				            for(Entity e : fb.getNearbyEntities(0.5, 0.5, 0.5))
				            	if(e instanceof Player) {
				            		Player p = (Player)e;
				            		if(p.getName().equals(name))
				            			continue;
				            		lastAttackedBy.put(p.getName(), name);
				            		if(p.hasMetadata("exited")) {
					            		p.damage(1.5);
					            		p.setVelocity(p.getVelocity().setY(0.2));
					            		p.setFallDistance(0);
				            		}
				            	}
				            if(count-- > 0)
				            	plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 1);
				            else
				            	fb.remove();
						}
						public FallingBlock fb = null;
						public int count = 60;
				        private float ticker_vertical = 0.0f;
				        private float ticker_horisontal = (float) (Math.random() * 2 * Math.PI);
						public float horisontalTicker() {
							return (ticker_horisontal += 0.8f);
						}
						private float verticalTicker() {
				            if (ticker_vertical < 1.0f) {
				                ticker_vertical += 0.05f;
				            }
				            return ticker_vertical;
				        }
					}, k * (int)(Math.random() * 3));
				}
				if(count-- > 0)
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
			}
		});
	}
	
	public void createShockwave(Player p2) {
		final String name = p2.getName();
		final Location loc = p2.getLocation();
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int count = 2;
			public void run() {
				for(int dx = -count; dx <= count; dx++) {
					int dz = count;
					if(Math.random() < 0.5)
						continue;
					Location temp = loc.clone().add(dx,0,dz);
					Material m = Material.DIRT;
					if(temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType() != Material.AIR)
						m = temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType();
					final FallingBlock fb = loc.getWorld().spawnFallingBlock(temp, m, (byte)0);
					fb.setDropItem(false);
					fb.setVelocity(new Vector(0,Math.random() * 0.3 + 0.3,0));
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public int count = 7;
						public void run() {
							for(Entity e : fb.getNearbyEntities(0.5, 0.5, 0.5)) {
								if(e instanceof Player) {
				            		Player p = (Player)e;
				            		if(p.getName().equals(name))
				            			continue;
				            		lastAttackedBy.put(p.getName(), name);
				            		if(p.hasMetadata("exited")) {
					            		p.damage(4);
					            		p.setVelocity(new Vector(0,0.4,0));
				            		}
								}
							}
							if(count-- > 0)
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 2);
							else
								fb.remove();
						}
					});
				}
				for(int dx = -count; dx <= count; dx++) {
					int dz = -count;
					if(Math.random() < 0.5)
						continue;
					Location temp = loc.clone().add(dx,0,dz);
					Material m = Material.DIRT;
					if(temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType() != Material.AIR)
						m = temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType();
					final FallingBlock fb = loc.getWorld().spawnFallingBlock(temp, m, (byte)0);
					fb.setDropItem(false);
					fb.setVelocity(new Vector(0,Math.random() * 0.3 + 0.3,0));
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public int count = 7;
						public void run() {
							for(Entity e : fb.getNearbyEntities(0.5, 0.5, 0.5)) {
								if(e instanceof Player) {
				            		Player p = (Player)e;
				            		if(p.getName().equals(name))
				            			continue;
				            		lastAttackedBy.put(p.getName(), name);
				            		if(p.hasMetadata("exited")) {
					            		p.damage(2);
					            		p.setVelocity(new Vector(0,0.4,0));
				            		}
								}
							}
							if(count-- > 0)
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 2);
							else
								fb.remove();
						}
					});
				}
				for(int dz = -count + 1; dz <= count - 1; dz++) {
					int dx = -count;
					if(Math.random() < 0.5)
						continue;
					Location temp = loc.clone().add(dx,0,dz);
					Material m = Material.DIRT;
					if(temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType() != Material.AIR)
						m = temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType();
					final FallingBlock fb = loc.getWorld().spawnFallingBlock(temp, m, (byte)0);
					fb.setDropItem(false);
					fb.setVelocity(new Vector(0,Math.random() * 0.3 + 0.3,0));
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public int count = 7;
						public void run() {
							for(Entity e : fb.getNearbyEntities(0.5, 0.5, 0.5)) {
								if(e instanceof Player) {
				            		Player p = (Player)e;
				            		if(p.getName().equals(name))
				            			continue;
				            		lastAttackedBy.put(p.getName(), name);
				            		if(p.hasMetadata("exited")) {
					            		p.damage(2);
					            		p.setVelocity(new Vector(0,0.4,0));
				            		}
								}
							}
							if(count-- > 0)
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 2);
							else
								fb.remove();
						}
					});
				}
				for(int dz = -count + 1; dz <= count - 1; dz++) {
					int dx = count;
					if(Math.random() < 0.5)
						continue;
					Location temp = loc.clone().add(dx,0,dz);
					Material m = Material.DIRT;
					if(temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType() != Material.AIR)
						m = temp.getWorld().getBlockAt(temp.clone().add(0, -1, 0)).getType();
					final FallingBlock fb = loc.getWorld().spawnFallingBlock(temp, m, (byte)0);
					fb.setDropItem(false);
					fb.setVelocity(new Vector(0,Math.random() * 0.3 + 0.3,0));
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public int count = 7;
						public void run() {
							for(Entity e : fb.getNearbyEntities(0.5, 0.5, 0.5)) {
								if(e instanceof Player) {
				            		Player p = (Player)e;
				            		if(p.getName().equals(name))
				            			continue;
				            		lastAttackedBy.put(p.getName(), name);
				            		if(p.hasMetadata("exited")) {
					            		p.damage(2);
					            		p.setVelocity(new Vector(0,0.4,0));
				            		}
								}
							}
							if(count-- > 0)
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 2);
							else
								fb.remove();
						}
					});
				}
				if(count++ < 8)
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 3);
			}
		});
	}
	
	@EventHandler
	public void fallblock(EntityChangeBlockEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onarrowhit(EntityDamageByEntityEvent event) {
		if(event.getEntity().hasMetadata("arrowblock") && event.getDamager() instanceof Projectile) {
			final Entity e = event.getEntity();
			event.setCancelled(true);
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					e.removeMetadata("arrowblock", plugin);
				}
			}, 20 * 5);
		}
	}
	
	public boolean checkCanCast(Player p, long cooldown) {
		String s = p.getName();
		if(cooldowns.containsKey(s)) {
			if(System.currentTimeMillis() < cooldowns.get(s)) {
				p.sendMessage(ChatColor.RED + "You cannot cast any more spells for " + String.format("%.1f", (cooldowns.get(s) - System.currentTimeMillis())/1000.0) + " seconds.");
				return false;
			}
		}
		if(p.hasMetadata("supercaster"))
			cooldown -= 5000;
		cooldowns.put(s, System.currentTimeMillis() + cooldown);
		return true;
	}

	public static HashMap<String, ArrayList<ItemStack>> kits = new HashMap<String, ArrayList<ItemStack>>();
	
	public void giveKit(Player p, String s) {
		checkCanCast(p, 2500);
		removeMetadata(p);
		p.setMaxHealth(20.0);
		p.getInventory().clear();
		p.setAllowFlight(false);
		killcount.put(p.getName(), 0);
		for(PotionEffect pe : p.getActivePotionEffects())
			p.removePotionEffect(pe.getType());
		if(!kits.containsKey(s)) {
			ArrayList<ItemStack> kit = new ArrayList<ItemStack>();
			switch(s) {
				case "mercenary":
					ItemStack item;
					ItemMeta im;
					item = new ItemStack(Material.IRON_HELMET);
					kit.add(item);
					item = new ItemStack(Material.IRON_CHESTPLATE);
					kit.add(item);
					item = new ItemStack(Material.IRON_LEGGINGS);
					kit.add(item);
					item = new ItemStack(Material.IRON_BOOTS);
					kit.add(item);
					item = new ItemStack(Material.IRON_SWORD);
					item.addEnchantment(Enchantment.DAMAGE_ALL, 1);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.DARK_GREEN + "Gravity Sword");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Right click to cast spell!"));
					item.setItemMeta(im);
					kit.add(item);
					item = new ItemStack(Material.BOW);
					item.addEnchantment(Enchantment.ARROW_DAMAGE, 1);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Just Your Average Bow");
					item.setItemMeta(im);
					kit.add(item);
					Potion potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					kit.add(potion.toItemStack(5));
					item = new ItemStack(Material.COOKED_BEEF);
					item.setAmount(64);
					kit.add(item);
					item = new ItemStack(Material.ARROW);
					item.setAmount(64);
					kit.add(item);
					break;
				case "archer":
					item = new ItemStack(Material.LEATHER_HELMET);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_CHESTPLATE);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_LEGGINGS);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_BOOTS);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3);
					kit.add(item);
					item = new ItemStack(Material.BOW);
					im = item.getItemMeta();
					im.addEnchant(Enchantment.ARROW_INFINITE, 1, true);
					im.setDisplayName(ChatColor.RED + "Bow of the Heavens");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Left click to cast spell!"));
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.ARROW_DAMAGE, 3);
					kit.add(item);
					item = new ItemStack(Material.IRON_SWORD);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Arrow Deflector");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Right click to cast spell!"));
					item.setItemMeta(im);
					kit.add(item);
					potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					kit.add(potion.toItemStack(5));
					item = new ItemStack(Material.COOKED_BEEF);
					item.setAmount(64);
					kit.add(item);
					item = new ItemStack(Material.ARROW);
					item.setAmount(64);
					kit.add(item);
					kit.add(item);
					kit.add(item);
					kit.add(item);
					kit.add(item);
					break;
				case "wizard":
					item = new ItemStack(Material.LEATHER_HELMET);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.PURPLE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_CHESTPLATE);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.PURPLE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_LEGGINGS);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.PURPLE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_BOOTS);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.PURPLE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					kit.add(item);
					item = new ItemStack(Material.STICK);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.LIGHT_PURPLE + "Tornado");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Right click to cast spell!"));
					item.setItemMeta(im);
					item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 2);
					kit.add(item);
					item = new ItemStack(Material.STICK);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.LIGHT_PURPLE + "Teleporter");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Right click to cast spell!"));
					item.setItemMeta(im);
					item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 2);
					kit.add(item);
					potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					kit.add(potion.toItemStack(5));
					item = new ItemStack(Material.COOKED_BEEF);
					item.setAmount(64);
					kit.add(item);
					item = new ItemStack(Material.WOOD_SWORD);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.LIGHT_PURPLE + "Noob Sword");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Because you know.. yer a wizard."));
					item.setItemMeta(im);
					kit.add(item);
					break;
				case "tank":
					item = new ItemStack(Material.DIAMOND_HELMET);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_EXPLOSIONS, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_PROJECTILE, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FIRE, 2);
					kit.add(item);
					item = new ItemStack(Material.DIAMOND_CHESTPLATE);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_EXPLOSIONS, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_PROJECTILE, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FIRE, 2);
					kit.add(item);
					item = new ItemStack(Material.DIAMOND_LEGGINGS);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_EXPLOSIONS, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_PROJECTILE, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FIRE, 2);
					kit.add(item);
					item = new ItemStack(Material.DIAMOND_BOOTS);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_EXPLOSIONS, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_PROJECTILE, 2);
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FIRE, 2);
					kit.add(item);
					item = new ItemStack(Material.WOOD_SWORD);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Tank Sword");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Doesn't do much."));
					item.setItemMeta(im);
					kit.add(item);
					potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					kit.add(potion.toItemStack(5));
					item = new ItemStack(Material.COOKED_BEEF);
					item.setAmount(64);
					kit.add(item);
					break;
				case "gladiator":
					item = new ItemStack(Material.LEATHER_HELMET);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.ORANGE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_CHESTPLATE);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.ORANGE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_LEGGINGS);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.ORANGE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
					kit.add(item);
					item = new ItemStack(Material.LEATHER_BOOTS);
					im = item.getItemMeta();
					((LeatherArmorMeta)im).setColor(Color.ORANGE);
					item.setItemMeta(im);
					item.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
					kit.add(item);
					item = new ItemStack(Material.DIAMOND_SWORD);
					item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 3);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.GOLD + "Gladiator's Blade");
					im.setLore(Arrays.asList(ChatColor.YELLOW + "Real sharp!"));
					item.setItemMeta(im);
					kit.add(item);
					potion = new Potion(PotionType.INSTANT_HEAL);
					potion.setLevel(2);
					kit.add(potion.toItemStack(5));
					item = new ItemStack(Material.COOKED_BEEF);
					item.setAmount(64);
					kit.add(item);
					break;
			}
			kits.put(s, kit);
		}
		ArrayList<ItemStack> kit = kits.get(s);
		p.getInventory().setHelmet(kit.get(0));
		p.getInventory().setChestplate(kit.get(1));
		p.getInventory().setLeggings(kit.get(2));
		p.getInventory().setBoots(kit.get(3));
		p.removeMetadata("class", plugin);
		p.setMetadata("class", new FixedMetadataValue(plugin, s));
		for(int k = 4; k < kit.size(); k++)
			p.getInventory().addItem(kit.get(k));
		p.updateInventory();
	}
	
	@EventHandler
	public void onEntityInteract(PlayerInteractEntityEvent event) {
		Player p = event.getPlayer();
		Entity e = event.getRightClicked();
		if(e instanceof LivingEntity) {
			LivingEntity le = (LivingEntity)e;
			if(le.getCustomName() != null) {
				checkGiveKit(p, le.getCustomName().toLowerCase());
			}
		}
	}
	
	@EventHandler
	public void onConsume(PlayerItemConsumeEvent event) {
		if(event.getItem().getAmount() > 0) {
			if(event.getItem().getType() == Material.POTION || event.getItem().getType() == Material.GLASS_BOTTLE) {
				Potion potion = new Potion(PotionType.INSTANT_HEAL);
				potion.setLevel(2);
				event.getPlayer().getInventory().removeItem(event.getItem());
				event.getPlayer().getInventory().addItem(potion.toItemStack(event.getItem().getAmount()));
			}
		}
	}
	
	public void checkGiveKit(Player p, String s) {
		s = ChatColor.stripColor(s);
		String capitalized = Character.toUpperCase(s.charAt(0)) + s.substring(1);
		if(s.contains("mercenary")) {
			giveKit(p, "mercenary");
			p.sendMessage("");
			p.sendMessage(ChatColor.GREEN + "You are now a Mercenary!");
			p.sendMessage(ChatColor.GREEN + "Go out there and kill some noobs!");
			p.sendMessage(ChatColor.GREEN + "Left-click the " + ChatColor.AQUA + capitalized + ChatColor.GREEN + " to see your kill streak rewards!");
		} else if(s.contains("archer")) {
			giveKit(p, "archer");
			p.sendMessage("");
			p.setAllowFlight(true);
			p.sendMessage(ChatColor.GREEN + "You are now an Archer!");
			p.sendMessage(ChatColor.GREEN + "Double-tap space to double jump!");
			p.sendMessage(ChatColor.GREEN + "Left-click the " + ChatColor.AQUA + capitalized + ChatColor.GREEN + " to see your kill streak rewards!");
		} else if(s.contains("wizard")) {
			if(RonboPVP.stats.containsKey(p.getName())) {
				if(RonboPVP.stats.get(p.getName()).kitunlocks.contains("wizardclass") || RankManager.check(p, "helper")) {
					giveKit(p, "wizard");
					p.sendMessage("");
					p.sendMessage(ChatColor.GREEN + "You are now a Wizard!");
					p.sendMessage(ChatColor.GREEN + "Remember, right click to cast spells!");
					p.sendMessage(ChatColor.GREEN + "Left-click the " + ChatColor.AQUA + capitalized + ChatColor.GREEN + " to see your kill streak rewards!");
				} else {
					p.sendMessage(ChatColor.RED + "You haven't unlocked the Wizard class yet!");
					p.sendMessage(ChatColor.RED + "Use " + ChatColor.YELLOW + "/unlock wizard" + ChatColor.RED + " to unlock Wizard for 4000 BP!");
				}
			}
		} else if(s.contains("gladiator")) {
			giveKit(p, "gladiator");
			p.sendMessage("");
			p.sendMessage(ChatColor.GREEN + "You are now a Gladiator!");
			p.sendMessage(ChatColor.GREEN + "Everyone shall fear your blade!");
			p.sendMessage(ChatColor.GREEN + "Left-click the " + ChatColor.AQUA + capitalized + ChatColor.GREEN + " to see your kill streak rewards!");
		} else if(s.contains("tank")) {
			if(RonboPVP.stats.containsKey(p.getName())) {
				if(RonboPVP.stats.get(p.getName()).kitunlocks.contains("tankclass") || RankManager.check(p, "helper")) {
					giveKit(p, "tank");
					p.sendMessage("");
					p.addPotionEffect(PotionEffectType.SLOW.createEffect(200000, 1));
					p.addPotionEffect(PotionEffectType.WEAKNESS.createEffect(200000, 0));
					p.sendMessage(ChatColor.GREEN + "You are now a Tank!");
					p.sendMessage(ChatColor.GREEN + "Don't die, it'll be embarrassing!");
					p.sendMessage(ChatColor.GREEN + "Left-click the " + ChatColor.AQUA + capitalized + ChatColor.GREEN + " to see your kill streak rewards!");
				} else {
					p.sendMessage(ChatColor.RED + "You haven't unlocked the Tank class yet!");
					p.sendMessage(ChatColor.RED + "Use " + ChatColor.YELLOW + "/unlock tank" + ChatColor.RED + " to unlock Tank for 4000 BP!");
				}
			}
		}
	}
	
	@EventHandler
	public void onEntityDamageByPlayer(EntityDamageByEntityEvent event) {
		if(event.getDamager() instanceof Player && event.getEntity() instanceof LivingEntity && ((LivingEntity)event.getEntity()).getCustomName() != null) {
			showKSRewards(ChatColor.stripColor(((LivingEntity)event.getEntity()).getCustomName()), (Player)event.getDamager());
			event.getEntity().setFireTicks(0);
		}
	}
	
	@EventHandler
	public void onPlayerMoveEvent(PlayerMoveEvent event) {
		if(event.getTo().getWorld().equals(world)) {
			if(event.getTo().getX() >= -70 && event.getTo().getX() <= -24 && event.getTo().getZ() >= -9 && event.getTo().getZ() <= 39) {
				if(event.getPlayer().hasMetadata("exited")) {
					event.setCancelled(true);
					event.getPlayer().teleport(event.getFrom());
				}
			} else {
				if(!event.getPlayer().hasMetadata("exited")) {
					event.getPlayer().setMetadata("exited", new FixedMetadataValue(plugin, 0));
					event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "You are now in the Fight Zone!");
				}
			}
		}
	}
	
	@Override
	protected void postWorldLoad() {
		world.setGameRuleValue("doFireTick", "false");
		world.setGameRuleValue("doMobSpawning", "false");
		world.setGameRuleValue("randomTickSpeed", "0");
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				double[] d = {-62, 110, 29, -113.25128, 28.199963};
				Location loc = doubleArrayToLoc(d);
				LivingEntity le = plugin.createLivingEntityNoMove(CustomZombie.class, loc);
				le.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Mercenary");
				le.setCustomNameVisible(true);
				EntityEquipment ee = le.getEquipment();
				ItemStack helmet = new ItemStack(Material.IRON_HELMET);
				ItemStack chestplate = new ItemStack(Material.IRON_CHESTPLATE);
				ItemStack leggings = new ItemStack(Material.IRON_LEGGINGS);
				ItemStack boots = new ItemStack(Material.IRON_BOOTS);
				ItemStack weapon = new ItemStack(Material.IRON_SWORD);
				weapon.addEnchantment(Enchantment.DAMAGE_ALL, 1);
				ItemStack[] equips = {helmet, chestplate, leggings, boots};
				ee.setArmorContents(equips);
				ee.setItemInHand(weapon);
				ee.setItemInHandDropChance(0);
				ee.setHelmetDropChance(0);
				ee.setChestplateDropChance(0);
				ee.setLeggingsDropChance(0);
				ee.setBootsDropChance(0);
				le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
				
				d = new double[] {-62, 110, 26, -107.85126, 17.849958};
				loc = doubleArrayToLoc(d);
				le = plugin.createLivingEntityNoMove(CustomZombie.class, loc);
				le.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Archer");
				le.setCustomNameVisible(true);
				ee = le.getEquipment();
				helmet = new ItemStack(Material.LEATHER_HELMET);
				helmet.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				chestplate = new ItemStack(Material.LEATHER_CHESTPLATE);
				chestplate.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				leggings = new ItemStack(Material.LEATHER_LEGGINGS);
				leggings.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				boots = new ItemStack(Material.LEATHER_BOOTS);
				boots.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				weapon = new ItemStack(Material.BOW);
				weapon.addEnchantment(Enchantment.ARROW_DAMAGE, 1);
				equips = new ItemStack[] {helmet, chestplate, leggings, boots};
				ee.setArmorContents(equips);
				ee.setItemInHand(weapon);
				ee.setItemInHandDropChance(0);
				ee.setHelmetDropChance(0);
				ee.setChestplateDropChance(0);
				ee.setLeggingsDropChance(0);
				ee.setBootsDropChance(0);
				le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
				
				d = new double[] {-58, 110, 30, -142.20117, 8.84996};
				loc = doubleArrayToLoc(d);
				le = plugin.createLivingEntityNoMove(CustomZombie.class, loc);
				le.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Wizard");
				le.setCustomNameVisible(true);
				ee = le.getEquipment();
				helmet = new ItemStack(Material.LEATHER_HELMET);
				helmet.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				ItemMeta im = helmet.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.PURPLE);
				helmet.setItemMeta(im);
				chestplate = new ItemStack(Material.LEATHER_CHESTPLATE);
				chestplate.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				im = chestplate.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.PURPLE);
				chestplate.setItemMeta(im);
				leggings = new ItemStack(Material.LEATHER_LEGGINGS);
				leggings.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				im = leggings.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.PURPLE);
				leggings.setItemMeta(im);
				boots = new ItemStack(Material.LEATHER_BOOTS);
				boots.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				im = boots.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.PURPLE);
				boots.setItemMeta(im);
				weapon = new ItemStack(Material.STICK);
				weapon.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 2);
				equips = new ItemStack[] {helmet, chestplate, leggings, boots};
				ee.setArmorContents(equips);
				ee.setItemInHand(weapon);
				ee.setItemInHandDropChance(0);
				ee.setHelmetDropChance(0);
				ee.setChestplateDropChance(0);
				ee.setLeggingsDropChance(0);
				ee.setBootsDropChance(0);
				le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
				
				d = new double[] {-62, 110, 24, -108.15112, 17.849966};
				loc = doubleArrayToLoc(d);
				le = plugin.createLivingEntityNoMove(CustomZombie.class, loc);
				le.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Gladiator");
				le.setCustomNameVisible(true);
				ee = le.getEquipment();
				helmet = new ItemStack(Material.LEATHER_HELMET);
				im = helmet.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.ORANGE);
				helmet.setItemMeta(im);
				chestplate = new ItemStack(Material.LEATHER_CHESTPLATE);
				im = chestplate.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.ORANGE);
				chestplate.setItemMeta(im);
				leggings = new ItemStack(Material.LEATHER_LEGGINGS);
				im = leggings.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.ORANGE);
				leggings.setItemMeta(im);
				boots = new ItemStack(Material.LEATHER_BOOTS);
				im = boots.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.ORANGE);
				boots.setItemMeta(im);
				weapon = new ItemStack(Material.DIAMOND_SWORD);
				weapon.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 3);
				equips = new ItemStack[] {helmet, chestplate, leggings, boots};
				ee.setArmorContents(equips);
				ee.setItemInHand(weapon);
				ee.setItemInHandDropChance(0);
				ee.setHelmetDropChance(0);
				ee.setChestplateDropChance(0);
				ee.setLeggingsDropChance(0);
				ee.setBootsDropChance(0);
				le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
				
				d = new double[] {-55, 110, 30, -146.70111, -0.15004049};
				loc = doubleArrayToLoc(d);
				le = plugin.createLivingEntityNoMove(CustomZombie.class, loc);
				le.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Tank");
				le.setCustomNameVisible(true);
				ee = le.getEquipment();
				helmet = new ItemStack(Material.DIAMOND_HELMET);
				helmet.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				chestplate = new ItemStack(Material.DIAMOND_CHESTPLATE);
				chestplate.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				leggings = new ItemStack(Material.DIAMOND_LEGGINGS);
				leggings.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				boots = new ItemStack(Material.DIAMOND_BOOTS);
				boots.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
				weapon = new ItemStack(Material.WOOD_SWORD);
				equips = new ItemStack[] {helmet, chestplate, leggings, boots};
				ee.setArmorContents(equips);
				ee.setItemInHand(weapon);
				ee.setItemInHandDropChance(0);
				ee.setHelmetDropChance(0);
				ee.setChestplateDropChance(0);
				ee.setLeggingsDropChance(0);
				ee.setBootsDropChance(0);
				le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
			}
		}, 20);
	}

	@Override
	public void postAllEnter() {
		
	}

	@Override
	public String getGameName() {
		return "Ronbattle";
	}

	@Override
	public String[][] getWorldNames() {
		return new String[][] {
			{"battle", "Battleground"},
		};
	}

	@Override
	public int getPlayersToStart() {
		return 1;
	}

	@Override
	public int getCountdownLength() {
		return 0;
	}

	@Override
	public boolean getJoinableAfterStart() {
		return true;
	}

	@Override
	public int getGameCount() {
		return 1;
	}

	@Override
	public int getMaxPlayers() {
		return 100;
	}

	@Override
	public boolean getTerrainChangeable() {
		return false;
	}

	@Override
	public boolean getLeaveOnDeath() {
		return false;
	}

	@Override
	public boolean getShowDeathMessage() {
		return false;
	}

	@Override
	protected void postLeave(Player p) {
		
	}

	@Override
	protected void postRespawn(Player p) {
		
	}

	@Override
	protected void postJoin(Player p) {
		
	}

	@Override
	protected void preJoin(Player p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void postEnd() {
		// TODO Auto-generated method stub
		
	}
	
}
