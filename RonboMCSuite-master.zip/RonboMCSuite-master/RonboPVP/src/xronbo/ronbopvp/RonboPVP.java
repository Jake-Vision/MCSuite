package xronbo.ronbopvp;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import me.ronbo.core.SQLManager;
import me.ronbo.core.ranks.RankManager;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import xronbo.common.MinigamePlugin;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;

public class RonboPVP extends MinigamePlugin implements CommandExecutor, Listener {
	
	public void onEnable() {
		super.onEnable();
		for(String s : commands) {
			for(String s2 : defaultCommands) {
				if(s.equals(s2)) {
					System.out.println("FATAL ERROR: COMMAND CONFLICT \"" + s + "\" with default command \"" + s2 + "\"");
					plugin.getServer().shutdown();
					break;
				}
			}
			try {
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void init()  {
		plugin.getServer().broadcastMessage(ChatColor.RED + "Server reloading... Sending all players back to hub.");
		plugin.getServer().broadcastMessage(ChatColor.RED + "Sorry for any inconvenience.");
		for(Player p : plugin.getServer().getOnlinePlayers())
			GameManager.returnToHub(p);
	}

	public static ConcurrentHashMap<String, Stats> stats = new ConcurrentHashMap<String, Stats>();
	
	public static class Stats {
		public int kills = 0;
		public int deaths = 0;
		public int earnedPoints = 0;
		public int points = 0;
		public int longest = 0;
		public String joinDate = null;
		public final String uuid;
		public final String player;
		public boolean disabled = false;
		public HashSet<String> kitunlocks = new HashSet<String>();
		public boolean loaded = false;
		public void save() {
			save(false);
		}
		public int getTotalPoints() {
			return earnedPoints + points;
		}
		public static final SimpleDateFormat dateformatCST;
		static {
			dateformatCST = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss zzz");
			dateformatCST.setTimeZone(TimeZone.getTimeZone("CST"));
		}
		public void save(boolean forced) {
			if(!loaded)
				return;
			String date = dateformatCST.format(new Date());
			if(joinDate == null) {
				joinDate = date;
			}
			StringBuilder sb = new StringBuilder();
			for(String s : kitunlocks)
				sb.append(s + " ");
			SQLManager.execute("insert into playerdata(uuid, kitkills, kitdeaths, kitpoints, kitlongest,  kitunlocks) values ('" + uuid + "', " + kills + 
					", " + deaths + ", " + getTotalPoints() + ", " + longest + ", '" + sb.toString().trim() + "') on duplicate key update kitkills = " + kills + ", kitdeaths = " + deaths +
					", kitpoints = kitpoints + " + earnedPoints + ", kitlongest = " + longest + ", kitunlocks = '" + sb.toString().trim() + "'", forced);
			points = points + earnedPoints;
			earnedPoints = 0;
		}
		private void load() {
			plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
				public void run() {
					try {
						ResultSet rs = SQLManager.executeQuery("select kitkills, kitdeaths, kitpoints, kitlongest, joinDate, kitunlocks from playerdata where uuid = '" + uuid + "'");
						loaded = true;
						if(rs.next()) {
							kills = rs.getInt("kitkills");
							deaths = rs.getInt("kitdeaths");
							points = rs.getInt("kitpoints");
							longest = rs.getInt("kitlongest");
							joinDate = rs.getString("joinDate");
							if(rs.getString("kitunlocks") != null)
								kitunlocks.addAll(Arrays.asList(rs.getString("kitunlocks").split(" ")));
						} else {
							save();
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
		public Stats(String player, String uuid) {
			this.player = player;
			this.uuid = uuid;
			load();
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					if(disabled)
						return;
					save();
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20 * 120);
				}
			}, 20 * 120);
		}
	}
	
	@EventHandler
	public void quit(PlayerQuitEvent event) {
		if(stats.containsKey(event.getPlayer().getName())) {
			stats.get(event.getPlayer().getName()).save();
			stats.get(event.getPlayer().getName()).disabled = true;
			stats.remove(event.getPlayer());
		}
	}
	
	public void loadPlayer(final Player p) {
		super.loadPlayer(p);
		final String uuid = p.getUniqueId().toString();
		p.teleport(plugin.getServer().getWorld("world").getSpawnLocation().add((int)(Math.random() * 7 - 3), 0, (int)(Math.random() * 7 - 3)));
		p.getInventory().clear();
		p.setScoreboard(plugin.getServer().getScoreboardManager().getMainScoreboard());
		p.sendMessage(ChatColor.GREEN + "");
		stats.put(p.getName(), new Stats(p.getName(), uuid));
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		loadPlayer(event.getPlayer());
		event.setJoinMessage("");
	}
	
	@EventHandler
	public void onPlayerLeave(PlayerQuitEvent event) {
		event.setQuitMessage("");
	}
	
	public static String[] commands = {
		"db", "unlock", "stats"
	};
	
	public static ArrayList<String> switchedToVip = new ArrayList<String>();
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			super.onCommand(sender, cmd, label, args);
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("db")) {
					if(RankManager.check(p, "owner")) {
						if(args.length == 1) {
							if(args[0].equals("tornado")) {
								((PVPGame)GameManager.getGame(p)).createTornado(p.getLocation(), p);
							} else if(args[0].equals("wave")) {
								((PVPGame)GameManager.getGame(p)).createShockwave(p);
							} else {
								for(int k = 0; k < Integer.parseInt(args[0]); k++)
									((PVPGame)GameManager.getGame(p)).giveKill(p.getName(), "test");
							}
						} else {
							((PVPGame)GameManager.getGame(p)).giveKill(p.getName(), "test");
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("unlock")) {
					if(args.length == 1) {
						switch(args[0].toLowerCase()) {
							case "wizard":
								if(stats.get(p.getName()).kitunlocks.contains("wizardclass")) {
									p.sendMessage(ChatColor.RED + "You've already unlocked the Wizard class!");
								} else {
									int price = 4000;
									if(stats.get(p.getName()).getTotalPoints() >= price) {
										if(stats.get(p.getName()).earnedPoints >= price) {
											stats.get(p.getName()).earnedPoints -= price;
										} else {
											price -= stats.get(p.getName()).earnedPoints;
											stats.get(p.getName()).earnedPoints = 0;
											stats.get(p.getName()).points -= price;
										}
										stats.get(p.getName()).kitunlocks.add("wizardclass");
										p.sendMessage(ChatColor.GREEN + "You unlocked the Wizard class! Have fun!");
									} else {
										p.sendMessage(ChatColor.RED + "You need 4000 BP to unlock the Wizard class!");
									}
								}
								break;
							case "tank":
								if(stats.get(p.getName()).kitunlocks.contains("tankclass")) {
									p.sendMessage(ChatColor.RED + "You've already unlocked the Tank class!");
								} else {
									int price = 4000;
									if(stats.get(p.getName()).getTotalPoints() >= price) {
										if(stats.get(p.getName()).earnedPoints >= price) {
											stats.get(p.getName()).earnedPoints -= price;
										} else {
											price -= stats.get(p.getName()).earnedPoints;
											stats.get(p.getName()).earnedPoints = 0;
											stats.get(p.getName()).points -= price;
										}
										stats.get(p.getName()).kitunlocks.add("tankclass");
										p.sendMessage(ChatColor.GREEN + "You unlocked the Tank class! Have fun!");
									} else {
										p.sendMessage(ChatColor.RED + "You need 4000 BP to unlock the Wizard class!");
									}
								}
								break;
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("stats")) {
					Stats s = stats.get(p.getName());
					if(s != null) {
						String kdr = "";
						if(s.deaths == 0) {
							kdr = "N/A";
						} else {
							kdr = String.format("%.2f", ((double)s.kills) / s.deaths);
						}
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
            			p.sendMessage(ChatColor.GREEN + "Kills: " + s.kills + ChatColor.RED + "   Deaths: " + s.deaths + ChatColor.YELLOW + "   KDR: " + kdr);
            			p.sendMessage(ChatColor.GOLD + "Battle Points: " + s.getTotalPoints() + ChatColor.LIGHT_PURPLE + "   Longest Killstreak: " + s.longest);
            			p.sendMessage(ChatColor.AQUA + "Join Date: " + s.joinDate);
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void onDisable() {
		super.onDisable();
		for(Stats s : stats.values())
			s.save(true);
	}

	@Override
	public String[] getExtraInfo(Game g) {
		return new String[] {""};
	}

	@Override
	public Class<? extends Game> getGameClass() {
		return PVPGame.class;
	}
	
}
