package xronbo.ronbobuild;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import me.ronbo.core.ranks.ChatManager;

import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import xronbo.common.GeneralManager;

public class RonboBuild extends JavaPlugin implements CommandExecutor, Listener {
	
	public void onEnable() {
		plugin = this;
		ChatManager.chatCooldown = 10000;
		getServer().getPluginManager().registerEvents(this, this);
		getServer().getPluginManager().registerEvents(new GeneralManager(this), this);
		for(String s : commands)
			try {	
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				System.out.println("Error loading command " + s);
				e.printStackTrace();
			}
		getServer().createWorld(new WorldCreator("build"));
		init();
		getLogger().info("Loaded Ronbo Build");
	}
	
	public void init() {
		for(File f : new File("./").listFiles()) {
			if(f.isDirectory()) {
				boolean isWorld = false;
				for(File f2 : f.listFiles()) {
					if(f2.getPath().toString().contains("session.lock")) {
						isWorld = true;
						break;
					}
				}
				if(isWorld) {
					String worldName = f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1);
					System.out.println("Loading world " + worldName + "...");
					getServer().createWorld(new WorldCreator(worldName));
				}
			}
		}
		System.out.println("Loaded " + getServer().getWorlds().size() + " worlds.");
		for(World w : plugin.getServer().getWorlds()) {
			w.setGameRuleValue("doFireTick", "false");
			w.setGameRuleValue("doMobSpawning", "false");
			w.setGameRuleValue("randomTickSpeed", "0");
			for(Entity e : w.getEntities())
				if(e instanceof LivingEntity && !(e instanceof Player))
					e.remove();
		}
	}
	
	public static String[] commands = {
		"addloc", "outputlocs", "clearlocs"
	};
	
	public static ArrayList<String> locs = new ArrayList<String>();
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("db")) {
					
				}
				if(cmd.getName().equalsIgnoreCase("addloc")) {
					String s = (int)p.getLocation().getBlockX() + ", " + (int)p.getLocation().getBlockY() + ", " + (int)p.getLocation().getBlockZ() + ", " + p.getLocation().getYaw() + ", " + p.getLocation().getPitch();
					p.sendMessage("Added loc " + s);
					locs.add(s);
				}
				if(cmd.getName().equalsIgnoreCase("clearlocs")) {
					p.sendMessage("cleared");
					locs.clear();
				}
				if(cmd.getName().equalsIgnoreCase("outputlocs")) {
					p.sendMessage("Printing locs...");
					File dir = new File(plugin.getDataFolder().getPath());
					if(!dir.exists())
						dir.mkdir();
					File f = new File(dir.getPath() + File.separator + "locsoutput.txt");
					if(!f.exists())
						f.createNewFile();
					PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f)));
					try {
						boolean brackets = false;
						if(args.length == 1)
							brackets = true;
						for(String s : locs) {
							if(brackets)
								out.println("{" + s + "},");
							else
								out.println(s);
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					out.close();
					p.sendMessage("Output to locsoutput.txt");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void onDisable() {
		getLogger().info("Disabling Ronbo Build...");
	}
	
	public static RonboBuild plugin;
	
}
