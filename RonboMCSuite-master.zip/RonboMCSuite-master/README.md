# MCSuite
A suite of Java plugins for Minecraft servers. 

# Notable Plugins

- RonboCore - Core backend, required for majority of plugins.

- RonboMinigames - Required for majority of minigame plugins, includes match/round system and automatic lobbies.

- RonboMC - Original RPG plugin with numerous features.

# 

Most plugins are intended to run with Spigot version 1.7.x.

Plugins released for reference purposes.