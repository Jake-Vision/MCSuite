package xronbo.common.games;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import me.ronbo.core.ranks.RankManager;
import net.minecraft.util.org.apache.commons.io.FileUtils;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffectType;

import xronbo.common.MinigamePlugin;

public class GameManager implements Listener {
	
	private static Class<? extends Game> GAME_CLASS;
	
	private static int ID = 0;
	public static HashMap<Integer, Game> games;
	public static String gameName = null;
	
	private static void load() {
		if(games != null)
			games.clear();
		ID = 0;
		games = new HashMap<Integer, Game>();
		int cleaned = 0;
		for(File f : new File("./").listFiles()) {
			if(f.isDirectory() && !f.toPath().toString().contains("_template") && f.toPath().toString().matches(".+_[0-9]+.+")) {
				boolean isWorld = false;
				for(File f2 : f.listFiles()) {
					if(f2.getPath().toString().contains("region") && f2.isDirectory()) {
						isWorld = true;
						break;
					}
				}
				if(isWorld) {
					System.out.println("Deleting " + f.toPath().toString());
					FileUtils.deleteQuietly(f);
					cleaned++;
				}
			}
		}
		System.out.println("Cleaned " + cleaned + " worlds.");
		Game.plugin = plugin;
		GAME_CLASS = plugin.getGameClass();
		try {
			for(int k = 0; k < GAME_CLASS.getConstructor(int.class).newInstance(-1).getGameCount(); k++) {
				int id = ID++;
				Game g = GAME_CLASS.getConstructor(int.class).newInstance(id);
				plugin.getServer().getPluginManager().registerEvents(g, plugin);
				games.put(id, g);
				if(gameName == null)
					gameName = g.getGameName();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		plugin.getServer().getWorld("world").setTime(0);
		plugin.getServer().getWorld("world").setGameRuleValue("doDayNightCycle", "false");
		System.out.println("Loaded " + games.size() + " game instances.");
	}
	
	public static HashSet<String> spectators = new HashSet<String>();
	public static ItemStack spectate_compass;
	
	public static void spectate(Player p, int id) {
		p.removeMetadata("id", plugin);
		p.removeMetadata("spectate", plugin);
		p.setMetadata("id", new FixedMetadataValue(plugin, id));
		p.setMetadata("spectate", new FixedMetadataValue(plugin, id));
		spectators.add(p.getName());
		Game g = getGame(p);
		if(g.inProgress) {
			if(g.getRemainingPlayers() == 0) {
				g.end();
				returnToHub(p);
				p.sendMessage(ChatColor.RED + "Looks like this game just ended!");
			} else {
				g.spectators.add(p.getName());
				Player target = null;
				g.trimPlayers();
				Iterator<String> iter = g.players.iterator();
				while(iter.hasNext()) {
					target = plugin.getServer().getPlayerExact(iter.next());
					if(target != null)
						break;
				}
				p.addPotionEffect(PotionEffectType.INVISIBILITY.createEffect(200000, 1));
				p.setGameMode(GameMode.CREATIVE);
				p.setHealth(20.0);
				p.setFoodLevel(20);
				p.setAllowFlight(true);
				p.setFlying(true);
				p.teleport(target);
				p.sendMessage(ChatColor.GREEN + "You are now spectating " + ChatColor.AQUA + target.getName() + ChatColor.GREEN + "!");
				p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/hub " + ChatColor.GREEN + "to return to the Kastia Hub!");
				p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/spectate <name> " + ChatColor.GREEN + "to spectate a specific player!");
				p.setMetadata("currentspec", new FixedMetadataValue(plugin, target.getName()));
				p.getInventory().remove(Material.COMPASS);
				p.getInventory().clear();
				p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
				p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
				if(spectate_compass == null) {
					spectate_compass = new ItemStack(Material.COMPASS);
					ItemMeta im = spectate_compass.getItemMeta();
					im.setDisplayName(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Click to Spectate Someone Else");
					spectate_compass.setItemMeta(im);
				}
				for(Player p2 : plugin.getServer().getOnlinePlayers()) {
					p2.hidePlayer(p);
					p.hidePlayer(p2);
				}
				for(Player p2 : g.getPlayers()) {
					p2.hidePlayer(p);
					p.showPlayer(p2);
				}
				p.getInventory().addItem(spectate_compass);
			}
		}
	}
	
	@EventHandler
	public void onspecchange(PlayerInteractEvent event) {
		try {
			Player p = event.getPlayer();
			if(spectators.contains(p.getName())) {
				event.setCancelled(true);
				if(p.getItemInHand() != null && p.getItemInHand().hasItemMeta() && p.getItemInHand().getItemMeta().hasDisplayName() && 
						p.getItemInHand().getItemMeta().getDisplayName().contains("Click to Spectate")) {
					String current = p.getMetadata("currentspec").get(0).asString();
					GameManager.getGame(p).trimPlayers();
					ArrayList<String> players = new ArrayList<String>(GameManager.getGame(p).players);
					Collections.shuffle(players);
					for(int k = 0; k < players.size(); k++) {
						if(players.get(k).equals(current) || plugin.getServer().getPlayerExact(players.get(k)) == null ||
								!plugin.getServer().getPlayerExact(players.get(k)).getWorld().equals(GameManager.getGame(p).world))
							continue;
						p.teleport(plugin.getServer().getPlayerExact(players.get(k)).getLocation());
						p.sendMessage(ChatColor.GREEN + "You are now spectating " + ChatColor.AQUA + players.get(k) + ChatColor.GREEN + "!");
						p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/hub " + ChatColor.GREEN + "to return to the Kastia Hub!");
						p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/spectate <name> " + ChatColor.GREEN + "to spectate a specific player!");
						p.setMetadata("currentspec", new FixedMetadataValue(plugin, players.get(k)));
						break;
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler(priority = EventPriority.LOW)
	public void onEntityDamage(EntityDamageEvent event) {
		if(event.getEntity().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(event.getEntity().hasMetadata("invincible"))
			event.setCancelled(true);
	}

	@EventHandler
	public void onDropItemInWorld(PlayerDropItemEvent event) {
		if(event.getPlayer().getWorld().getName().equals("world") && !(event.getPlayer().getGameMode() == GameMode.CREATIVE && RankManager.check(event.getPlayer(), "owner")))
			event.setCancelled(true);
	}

	@EventHandler
	public void onPlayerInteractInWorld(PlayerInteractEvent event) {
		if(event.getPlayer().getWorld().getName().equals("world") && !(event.getPlayer().getGameMode() == GameMode.CREATIVE && RankManager.check(event.getPlayer(), "owner")))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onspecinv(InventoryClickEvent event) {
		if(spectators.contains(event.getWhoClicked().getName()))
			event.setCancelled(true);
	}

	@EventHandler(priority = EventPriority.LOW)
	public void onspecbreak(BlockBreakEvent event) {
		if(spectators.contains(event.getPlayer().getName())) {
			event.setCancelled(true);
			event.getPlayer().setFlying(true);
		}
		if(event.getBlock().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(event.getPlayer().getGameMode() == GameMode.CREATIVE && RankManager.check(event.getPlayer(), "admin"))
			event.setCancelled(false);
	}

	@EventHandler(priority = EventPriority.LOW)
	public void onspecplace(BlockPlaceEvent event) {
		if(spectators.contains(event.getPlayer().getName())) {
			event.setCancelled(true);
			event.getPlayer().setFlying(true);
		}
		if(event.getBlock().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(event.getPlayer().getGameMode() == GameMode.CREATIVE && RankManager.check(event.getPlayer(), "admin"))
			event.setCancelled(false);
	}

	@EventHandler
	public void onchangefood123(FoodLevelChangeEvent event) {
		if(event.getEntity().getWorld().getName().equals("world")) {
			((Player)event.getEntity()).setFoodLevel(19);
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void ondmgspec(EntityDamageEvent event) {
		if(event.getEntity() instanceof Player && spectators.contains(((Player)event.getEntity()).getName()))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onspecattack(EntityDamageByEntityEvent event) {
		if(event.getDamager() instanceof Player && spectators.contains(((Player)event.getDamager()).getName()))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onpickup(PlayerDropItemEvent event) {
		if(spectators.contains(event.getPlayer().getName()))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onpickup(PlayerPickupItemEvent event) {
		if(spectators.contains(event.getPlayer().getName()))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onquitspec(PlayerQuitEvent event) {
		spectators.remove(event.getPlayer().getName());
		event.getPlayer().setScoreboard(plugin.getServer().getScoreboardManager().getMainScoreboard());
	}
	
	public static void add(Player p, int id, boolean vip) {
		p.removeMetadata("id", plugin);
		p.removeMetadata("spectate", plugin);
		p.setMetadata("id", new FixedMetadataValue(plugin, id));
		p.getInventory().clear();
		p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		Game g = getGame(p);
		spectators.remove(p.getName());
		g.spectators.remove(p.getName());
		if(g.joinable) {
			g.trimPlayers();
			if(g.players.size() < g.getMaxPlayers()) {
				g.join(p);
				return;
			} else {
				if(vip && !g.inProgress) {
					ArrayList<Player> players = g.getPlayers();
					String kicked = null;
					for(int k = players.size() - 1; k >= 0; k--) {
						if(!RankManager.check(players.get(k), "knight")) {
							kicked = players.get(k).getName();
							g.leave(players.get(k));
							returnToHub(players.get(k));
							players.get(k).sendMessage(ChatColor.RED + "A VIP player just took your place in the lobby. Sorry!");
							break;
						}
					}
					if(kicked != null && g.players.size() < g.getMaxPlayers()) {
						p.sendMessage(ChatColor.GREEN + kicked + " was removed to make room for you!");
						g.join(p);
					} else {
						returnToHub(p);
						p.sendMessage(ChatColor.RED + "Sorry! Everyone in the lobby was a VIP, so you couldn't join.");
					}
				} else {
					returnToHub(p);
					p.sendMessage(ChatColor.RED + "Sorry, this game is now full!");
				}
			}
		}
	}
	
	public static Game getGame(Player p) {
		int id = getGameId(p);
		if(id > -1 && games.containsKey(id))
			return games.get(id);
		return null;
	}

	private static void sendToHub(Player p) {
		p.sendMessage(ChatColor.GREEN + "Returning to the Kastia Lobby now!");
		ByteArrayOutputStream b = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(b);
		try {
			out.writeUTF("Connect");
			out.writeUTF("hub");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		p.sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
	}
	
	public static HashSet<String> returning = new HashSet<String>();
	public static void returnToHub(Player p) {
		if(returning.contains(p.getName())) 
			return;
		p.removeMetadata("id", plugin);
		returning.add(p.getName());
		p.sendMessage("");
		p.sendMessage(ChatColor.RED + "Returning to the Kastia Lobby in 5 seconds...");
		final String name = p.getName();
		p.setScoreboard(plugin.getServer().getScoreboardManager().getMainScoreboard());
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				try {
					Player p = plugin.getServer().getPlayerExact(name);
					if(p != null) {
						sendToHub(p);
					}
				} catch(Exception e) {
					
				}
				returning.remove(name);
			}
		}, 5 * 20);
	}
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		event.getPlayer().getInventory().clear();
		event.getPlayer().getInventory().setContents(new ItemStack[event.getPlayer().getInventory().getSize()]);
		event.getPlayer().getInventory().setArmorContents(new ItemStack[event.getPlayer().getInventory().getArmorContents().length]);
	}
	
	public static int getGameId(Player p) {
		if(p == null)
			return -1;
		if(p.hasMetadata("id"))
			return p.getMetadata("id").get(0).asInt();
		return -1;
	}
	
	public static HashMap<String, Integer> joinedGames = new HashMap<String, Integer>();
	
	
	public static MinigamePlugin plugin;
	public GameManager(MinigamePlugin plugin) {
		GameManager.plugin = plugin;
		load();
	}
	
}
