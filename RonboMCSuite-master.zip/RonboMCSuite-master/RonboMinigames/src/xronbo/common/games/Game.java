package xronbo.common.games;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

import net.minecraft.util.org.apache.commons.io.FileUtils;

import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import xronbo.common.MinigamePlugin;

public abstract class Game implements Listener {
	
	public static final boolean DEBUG = false;

	private static int worldId = (int)(Math.random() * 1000);
	
	public final int id;
	public Scoreboard board;
	public Objective side;
	public HashSet<String> players = new HashSet<String>();
	public HashSet<String> spectators = new HashSet<String>();
	public volatile boolean inProgress = false;
	public volatile boolean joinable = true;
	public volatile World world = null;
	public volatile boolean counting = false;
	public volatile String currentMapDisplayName = "";
	public volatile String currentMapWorldTemplateName = "";
	public volatile int currentId = 0;	
	public volatile boolean beginning = false;

	public abstract String getGameName();
	public abstract String[][] getWorldNames();
	public abstract int getPlayersToStart();
	public abstract int getCountdownLength();
	public abstract boolean getJoinableAfterStart();
	public abstract int getGameCount();
	public abstract int getMaxPlayers();
	public abstract boolean getTerrainChangeable();
	public abstract boolean getLeaveOnDeath();
	public abstract boolean getShowDeathMessage();
	
	public ArrayList<Player> getPlayers() {
		ArrayList<Player> p = new ArrayList<Player>();
		for(String s : players) {
			if(plugin.getServer().getPlayerExact(s) != null && GameManager.getGame(plugin.getServer().getPlayerExact(s)) == this)
				p.add(plugin.getServer().getPlayerExact(s));
		}
		return p;
	}
	
	public ArrayList<Player> getSpectators() {
		ArrayList<Player> p = new ArrayList<Player>();
		for(String s : spectators) {
			if(plugin.getServer().getPlayerExact(s) != null && GameManager.getGame(plugin.getServer().getPlayerExact(s)) == this)
				p.add(plugin.getServer().getPlayerExact(s));
		}
		return p;
	}
	
	private synchronized void createNewWorld() { //must be called within async thread!
		currentId = worldId += (int)(Math.random() * 33);
		System.out.println("Creating world with ID " + currentId);
		File from = new File(currentMapWorldTemplateName + "_template");
		File to = new File(currentMapWorldTemplateName + "_" + currentId);
		try {
			FileUtils.copyDirectory(from, to);
			for(File f : to.listFiles())
				if(f.getName().contains("uid.dat"))
					f.delete();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteWorld(final boolean forced) {
		if(world == null) {
			return;
		}
		boolean foundPlayers = false;
		for(Entity e : world.getEntities()) {
			if(e instanceof Player) {
				e.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
				foundPlayers = true;
			}
		}
		if(foundPlayers && !forced) {
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					for(Chunk c : world.getLoadedChunks())
						c.unload(false, false);
					plugin.getServer().unloadWorld(world, false);
					world = null;
					final File toDelete = new File(currentMapWorldTemplateName + "_" + currentId);
					if(forced) {
						FileUtils.deleteQuietly(toDelete);
					} else {
						plugin.getServer().getScheduler().runTaskLaterAsynchronously(plugin, new Runnable() {
							public void run() {
								FileUtils.deleteQuietly(toDelete);
							}
						}, 20 * 10);
					}
				}
			}, 5);
		} else {
			for(Chunk c : world.getLoadedChunks())
				c.unload(false, false);
			plugin.getServer().unloadWorld(world, false);
			world = null;
			final File toDelete = new File(currentMapWorldTemplateName + "_" + currentId);
			if(forced) {
				FileUtils.deleteQuietly(toDelete);
			} else {
				plugin.getServer().getScheduler().runTaskLaterAsynchronously(plugin, new Runnable() {
					public void run() {
						FileUtils.deleteQuietly(toDelete);
					}
				}, 20 * 10);
			}
		}
	}
	
	public int getRemainingPlayers() {
		int count = 0;
		for(String s : players) {
			Player p = plugin.getServer().getPlayerExact(s);
			if(p == null || !p.isOnline())
				continue;
			if(inProgress && !getJoinableAfterStart() && world != null && !p.getWorld().equals(world))
				continue;
			if(spectators.contains(p.getName()) || GameManager.spectators.contains(p.getName()))
				continue;
			count++;
		}
		return count;
	}
	
	protected void trimPlayers() {
		HashSet<String> toKeep = new HashSet<String>();
		toKeep.addAll(players);
		for(String s : players) {
			try {
				if(DEBUG)
					System.out.println("Checking " + s);
				Player p = plugin.getServer().getPlayerExact(s);
				if(p == null || !p.isOnline()) {
					toKeep.remove(s);
					continue;
				}
				if(inProgress && !getJoinableAfterStart() && world != null && !p.getWorld().equals(world)) {
					toKeep.remove(s);
					continue;
				}
				if(DEBUG)
					System.out.println(p.getWorld());
				if(!inProgress && p.getWorld() != null && !p.getWorld().getName().equals("world")) {
					toKeep.remove(s);
					continue;
				}
				if(spectators.contains(p.getName()) || GameManager.spectators.contains(p.getName())) {
					toKeep.remove(s);
					continue;
				}
				if(DEBUG)
					System.out.println(s + " is in game.");
			} catch(Exception e) {
				if(DEBUG)
					System.out.println("Error caught for " + s + "!");
				e.printStackTrace();
			}
		}
		players.retainAll(toKeep);
		if(DEBUG)
			System.out.println("players for id (" + id + "): " + players);
	}
	
	protected Location doubleArrayToLoc(double[] d) {
		return new Location(world, d[0], d[1] + 0.2, d[2], (float)d[3], (float)d[4]);
	}
	
	protected double[] locToDoubleArray(Location loc) {
		return new double[] {loc.getX(), loc.getY() + 0.2, loc.getZ(), loc.getPitch(), loc.getYaw()};
	}
	
	public String secondsToTimeString(int sec) {
		StringBuilder sb = new StringBuilder("");
		sb.append((sec / 60) + "m ");
		sb.append(sec - (sec / 60) * 60 + "s");
		return sb.toString();
	}

	protected void join(Player p) {
		trimPlayers();
		players.add(p.getName());
		for(Player p2 : getPlayers()) {
			p2.showPlayer(p);
			p.showPlayer(p2);
		}
		for(Player p2 : plugin.getServer().getOnlinePlayers()) {
			p2.hidePlayer(p);
			p.hidePlayer(p2);
		}
		for(Player p2 : getPlayers()) {
			p2.showPlayer(p);
			p.showPlayer(p2);
		}
		p.setScoreboard(board);
		p.getInventory().clear();
		p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		for(PotionEffect pe : p.getActivePotionEffects())
			p.removePotionEffect(pe.getType());
		p.setGameMode(GameMode.SURVIVAL);
		p.setAllowFlight(false);
		p.setHealth(20.0);
		p.setFoodLevel(19);
		preJoin(p);
		if(!inProgress) {
			if(players.size() >= getPlayersToStart()) {
				scheduleStart();
			} else {
				int needed = (getPlayersToStart() - players.size());
				message(ChatColor.YELLOW + "Waiting for " + needed  + " more player" + (needed > 1 ? "s" : "") + " to begin " + ChatColor.BOLD + getGameName() + ChatColor.YELLOW + "...");
			}
		} else {
			enterGame(p);
		}
		postJoin(p);
	}
	
	protected void scheduleStart() {
		if(counting || inProgress || beginning)
			return;
		counting = true;
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int countdown = getCountdownLength();
			public void run() {
				if(countdown <= 0) {
					if(getPlayers().size() >= getPlayersToStart()) {
						begin();
						counting = false;
					} else {
						int needed = (getPlayersToStart() - getPlayers().size()) ;
						counting = false;
						message(ChatColor.RED + "Countdown canceled. " + needed + " more player" + (needed > 1 ? "s are" : " is") + " needed to begin!");
					}
				} else {
					if(getPlayers().size() >= getPlayersToStart()) {
						if(countdown == 60 || countdown == 30 || countdown == 10 || countdown <= 5)
							message(ChatColor.GREEN + getGameName() + " is starting in " + countdown + " seconds!");
						if(countdown == 5) {
							for(Player p : getPlayers())
								p.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
						}
						countdown--;
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20);
					} else {
						int needed = (getPlayersToStart() - getPlayers().size()) ;
						counting = false;
						message(ChatColor.RED + "Countdown canceled. " + needed + " more player" + (needed > 1 ? "s are" : " is") + " needed to begin!");
					}
				}
			}
		});
	}
	
	public static int gamesPlayed = 0;
	
	public int objectiveTaskId = -1;
	protected void begin() {
		if(beginning || inProgress)
			return;
		beginning = true;
		deleteWorld(false);
		gamesPlayed++;
		message(ChatColor.GREEN + "Preparing game world...");
		System.out.println("Game " + id + " is beginning.");
		joinable = getJoinableAfterStart();
		final Game me = this;
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				createNewWorld();
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						world = plugin.getServer().createWorld(new WorldCreator(currentMapWorldTemplateName + "_" + currentId));
						world.setAutoSave(false);
						world.setKeepSpawnInMemory(false);
						world.setTime(0);
						System.out.println("Loaded world " + world.getName() + " for Game " + id + ".");
						for(Entity e : world.getEntities())
							if(e instanceof Item || (e instanceof LivingEntity && !(e instanceof Player)))
								e.remove();
						postWorldLoad();
						inProgress = true;
						joinable = getJoinableAfterStart();
						ArrayList<String> temp = new ArrayList<String>(players);
						Collections.shuffle(temp);
						for(String s : temp) {
							if(plugin.getServer().getPlayerExact(s) != null && GameManager.getGame(plugin.getServer().getPlayerExact(s)) == me)
								enterGame(plugin.getServer().getPlayerExact(s));
						}
						for(String s : players) {
							Player temp1 = plugin.getServer().getPlayerExact(s);
							if(temp1 != null && temp1.isOnline()) {
								for(String s2 : players) {
									Player temp2 = plugin.getServer().getPlayerExact(s2);
									if(temp1 != null && temp1.isOnline()) {
										temp1.showPlayer(temp2);
										temp2.showPlayer(temp1);
									}
								}
							}
						}
						if(objectiveTaskId != -1)
							plugin.getServer().getScheduler().cancelTask(objectiveTaskId);
						objectiveTaskId = objectiveTask();
						postAllEnter();
						beginning = false;
					}
				});
			}
		});
	}
	
	protected void enterGame(Player p) {
		Location loc = doubleArrayToLoc(getSpawnLoc(p));
		p.setFallDistance(0);
		p.getInventory().clear();
		p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		for(PotionEffect pe : p.getActivePotionEffects())
			p.removePotionEffect(pe.getType());
		p.setGameMode(GameMode.SURVIVAL);
		p.setAllowFlight(false);
		p.setFlying(false);
		p.setHealth(20.0);
		p.setMaxHealth(20.0);
		p.setFoodLevel(19);
		p.teleport(loc);
		postEnter(p);
	}

	private HashMap<String, Long> lastleave = new HashMap<String, Long>();
	protected void leave(Player p) {
		trimPlayers();
		players.remove(p.getName());
		spectators.remove(p.getName());
		p.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
		p.getInventory().clear();
		p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		boolean postLeave = true;
		for(Player p2 : getPlayers())
			p2.hidePlayer(p);
		if(lastleave.containsKey(p.getName())) {
			if(System.currentTimeMillis() - lastleave.get(p.getName()) < 2000) {
				postLeave = false;
			}
		}
		if(postLeave) {
			lastleave.put(p.getName(), System.currentTimeMillis());
			postLeave(p);
		}
		if(inProgress && checkEndCondition()) {
			end();
		}
	}
	
	public void end() {
		joinable = true;
		inProgress = false;
		players.clear();
		spectators.clear();
		if(board != null) {
			for(Objective o : board.getObjectives()) {
				o.unregister();
			}
		}
		if(world != null) {
			for(Entity e : world.getEntities()) {
				if(e instanceof Player) {
					Player p = (Player)e;
					if(players.contains(p.getName()))
						leave(p);
					p.getInventory().clear();
					p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
					p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
					p.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
					GameManager.returnToHub(p);
				} else {
					e.remove();
				}
			}
		}
		world = null;
		deleteWorld(false);
		randomWorld();
		postEnd();
	}
	
	protected void randomWorld() {
		String[] s = getWorldNames()[(int)(Math.random() * getWorldNames().length)];
		currentMapWorldTemplateName = s[0];
		currentMapDisplayName = s[1];
	}
	
	public void message(String s) {
		for(Player p : getPlayers()) {
			p.sendMessage(s);
		}
		for(String s2 : spectators) {
			if(plugin.getServer().getPlayerExact(s2) != null) {
				plugin.getServer().getPlayerExact(s2).sendMessage(s);
			}
		}
	}

	@EventHandler
	public void onPlayerQuit123(PlayerQuitEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld()) || (!inProgress && event.getPlayer().getWorld().getName().equals("world"))) {
			leave(event.getPlayer());
		}
		event.getPlayer().removeMetadata("id", plugin);
	}
	
	@EventHandler
	public void onPlayerDeath123(PlayerDeathEvent event) {
		if(world != null && world.equals(event.getEntity().getWorld())) {
			Game real = GameManager.getGame(event.getEntity());
			if(real != null) {
				justDiedGame.put(event.getEntity().getName(), real);
			} else {
				System.out.println("Warning: Player died while not in a game!");
			}
			if(getShowDeathMessage()) {
				if(GameManager.getGame(event.getEntity()) != null) {
					GameManager.getGame(event.getEntity()).message(event.getDeathMessage());
				}
			}
			if(getLeaveOnDeath()) {
				if(real != null)
					real.leave(event.getEntity());
				for(Game g : GameManager.games.values())
					if(g.getPlayers().contains(event.getEntity()))
						g.leave(event.getEntity());
				event.getEntity().removeMetadata("id", plugin);
				event.getEntity().removeMetadata("spectate", plugin);
			}
			event.setDeathMessage("");
		}
	}
	private HashMap<String, Game> justDiedGame = new HashMap<String, Game>();
	
	@EventHandler
	public void onRespawn123(PlayerRespawnEvent event) {
		if(justDiedGame.containsKey(event.getPlayer().getName()) && justDiedGame.get(event.getPlayer().getName()) == this) {
			Game g = justDiedGame.get(event.getPlayer().getName());
			if(inProgress && (GameManager.spectators.contains(event.getPlayer().getName()) || !getLeaveOnDeath())) {
				Location loc = doubleArrayToLoc(g.getSpawnLoc(event.getPlayer()));
				event.setRespawnLocation(loc);
			} else {
				event.setRespawnLocation(plugin.getServer().getWorld("world").getSpawnLocation());
			}
			postRespawn(event.getPlayer());
		}
	}
	
	@EventHandler(priority = EventPriority.LOWEST)
	public void onBlockBreak123(BlockBreakEvent event) {
		if(!getTerrainChangeable())
			event.setCancelled(true);
	}
	
	@EventHandler(priority = EventPriority.LOWEST)
	public void onEntityExplode123(EntityExplodeEvent event) {
		if(!getTerrainChangeable()) {
			event.blockList().clear();
			event.setCancelled(true);
		}
	}
	
	@EventHandler(priority = EventPriority.LOWEST)
	public void onBlockPlace123(BlockPlaceEvent event) {
		if(!getTerrainChangeable())
			event.setCancelled(true);
	}

	protected abstract double[] getSpawnLoc(Player p);
	protected abstract void postWorldLoad();
	protected abstract void postAllEnter();
	protected abstract void postEnter(Player p);
	protected abstract boolean checkEndCondition();
	protected abstract int objectiveTask();
	protected abstract void postLeave(Player p);
	protected abstract void postRespawn(Player p);
	protected abstract void preJoin(Player p);
	protected abstract void postJoin(Player p);
	protected abstract void postEnd();
	
	protected static MinigamePlugin plugin;
	public Game(int id) {
		this.id = id;
		board = plugin.getServer().getScoreboardManager().getNewScoreboard();
		randomWorld();
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public void run() {
				trimPlayers();
				if(inProgress && (checkEndCondition() || getRemainingPlayers() == 0 || getPlayers().size() == 0 || players.size() == 0))
					end();
			}
		}, 20 * 20, 20 * 20);
	}
	
}
