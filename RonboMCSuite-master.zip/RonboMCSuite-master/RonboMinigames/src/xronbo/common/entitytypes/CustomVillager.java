package xronbo.common.entitytypes;

import java.lang.reflect.Field;

import net.minecraft.server.v1_7_R4.Entity;
import net.minecraft.server.v1_7_R4.EntityHuman;
import net.minecraft.server.v1_7_R4.EntityVillager;
import net.minecraft.server.v1_7_R4.GenericAttributes;
import net.minecraft.server.v1_7_R4.PathfinderGoalFloat;
import net.minecraft.server.v1_7_R4.PathfinderGoalLookAtPlayer;
import net.minecraft.server.v1_7_R4.PathfinderGoalRandomLookaround;
import net.minecraft.server.v1_7_R4.PathfinderGoalRandomStroll;
import net.minecraft.server.v1_7_R4.PathfinderGoalSelector;
import net.minecraft.server.v1_7_R4.World;

import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_7_R4.util.UnsafeList;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import xronbo.common.games.GameManager;

public class CustomVillager extends EntityVillager {

	@Override
	protected void aD() {
	    super.aD();
	    getAttributeInstance(GenericAttributes.b).setValue(100000.0D);
	}
	
	public CustomVillager(World world) {
		super(world);
		try {
			Field gsa = PathfinderGoalSelector.class.getDeclaredField("b");
			gsa.setAccessible(true);
			gsa.set(this.goalSelector, new UnsafeList<Object>());
			gsa.set(this.targetSelector, new UnsafeList<Object>());
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.goalSelector.a(0, new PathfinderGoalFloat(this));
		this.goalSelector.a(1, new PathfinderGoalRandomLookaround(this));
		this.goalSelector.a(2, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
	}
	
	public String toString() {
		return this.getCustomName() + " " + this.getUniqueID();
	}
	
	public void allowWalk() {
	    this.goalSelector.a(3, new PathfinderGoalRandomStroll(this, 0.6D));
	}
	
	@Override
	public void collide(Entity entity) {
		
	}
	
	@Override
	public void g(double d0, double d1, double d2) {
		
	}
	
	public boolean a(EntityHuman entityhuman) {
        if (this.isAlive()) {
            if (!this.world.isStatic) {
                this.a_(entityhuman);
                if(((LivingEntity)this.getBukkitEntity()).getCustomName() != null) {
                	String name = ((LivingEntity)this.getBukkitEntity()).getCustomName();
                    Player p = (Player)(entityhuman.getBukkitEntity());
                	if(name.contains("King")) {
                		p.sendMessage(ChatColor.GOLD + "King Ronbo" + ChatColor.WHITE + ": Welcome to " + (GameManager.gameName == null ? "Kastia!" : GameManager.gameName + "!"));
                	}
                }
            }
            return true;
        } else {
            return super.a(entityhuman);
        }
    }
	
}