package xronbo.common.entitytypes;

import java.lang.reflect.Field;

import net.minecraft.server.v1_7_R4.Block;
import net.minecraft.server.v1_7_R4.Entity;
import net.minecraft.server.v1_7_R4.EntityFireball;
import net.minecraft.server.v1_7_R4.EntityHuman;
import net.minecraft.server.v1_7_R4.EntityLiving;
import net.minecraft.server.v1_7_R4.EntitySkeleton;
import net.minecraft.server.v1_7_R4.EntitySmallFireball;
import net.minecraft.server.v1_7_R4.MathHelper;
import net.minecraft.server.v1_7_R4.PathfinderGoalArrowAttack;
import net.minecraft.server.v1_7_R4.PathfinderGoalFloat;
import net.minecraft.server.v1_7_R4.PathfinderGoalHurtByTarget;
import net.minecraft.server.v1_7_R4.PathfinderGoalLookAtPlayer;
import net.minecraft.server.v1_7_R4.PathfinderGoalNearestAttackableTarget;
import net.minecraft.server.v1_7_R4.PathfinderGoalRandomLookaround;
import net.minecraft.server.v1_7_R4.PathfinderGoalRandomStroll;
import net.minecraft.server.v1_7_R4.PathfinderGoalSelector;
import net.minecraft.server.v1_7_R4.World;

import org.bukkit.craftbukkit.v1_7_R4.util.UnsafeList;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.potion.PotionEffectType;


public class CustomFireballSkeleton extends EntitySkeleton {
    
	public CustomFireballSkeleton(World world) {
		super(world);
        if (world != null && !world.isStatic) {
            setFightStyle();
        }
	}
	
	@Override
	public void a(EntityLiving entityliving, float f) {
		EntityFireball entity = null;
    	double d0 = entityliving.locX - this.locX;
     	double d1 = entityliving.boundingBox.b + entityliving.length / 2.0F - (this.locY + this.length / 2.0F);
     	double d2 = entityliving.locZ - this.locZ;
     	float f1 = MathHelper.c(f) * 0.5F;
		entity = new EntitySmallFireball(this.world, this, d0 + this.random.nextGaussian() * f1, d1, d2 + this.random.nextGaussian() * f1);
        entity.locY = (this.locY + this.length / 2.0F + 0.5D);
        this.world.addEntity(entity, SpawnReason.CUSTOM);
	}
	
	private PathfinderGoalArrowAttack rangedLong = new PathfinderGoalArrowAttack(this, 1.2D, 20, 60, 30.0F);
	  
	public void setFightStyle() {
		try {
			Field gsa = PathfinderGoalSelector.class.getDeclaredField("b");
			gsa.setAccessible(true);
			gsa.set(this.goalSelector, new UnsafeList<Object>());
			gsa.set(this.targetSelector, new UnsafeList<Object>());
		} catch (Exception e) {
			e.printStackTrace();
		}
        this.goalSelector.a(1, new PathfinderGoalFloat(this));
        this.goalSelector.a(5, new PathfinderGoalRandomStroll(this, 1.0D));
        this.goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
        this.goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
        this.targetSelector.a(1, new PathfinderGoalHurtByTarget(this, false));
        this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityHuman.class, 0, true));
		this.goalSelector.a(4, this.rangedLong);
	}
	
	@Override
	public boolean n(Entity entity) {
		boolean r = super.n(entity);
        if (this.getSkeletonType() == 1 && entity instanceof EntityLiving) {
        	if(entity.getBukkitEntity() instanceof Player) {
        		((Player)(entity.getBukkitEntity())).removePotionEffect(PotionEffectType.WITHER);
        	}
        }
		return r;
	}
	
	public void makeWither() {
		setSkeletonType(1);
	}
	
	@Override
	protected String t() {
		return "";
	}
	
	@Override
	protected String aT() {
		return "game.player.hurt";
	}
	
	@Override
	protected String aU() {
		return "mob.villager.death";
	}
	
	@Override
	protected void a(int i, int j, int k, Block block) {
	    //makeSound("mob.skeleton.step", 0.15F, 1.0F);
	}
	
}