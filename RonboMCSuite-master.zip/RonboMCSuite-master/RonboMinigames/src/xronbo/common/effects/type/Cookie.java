package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Cookie extends PacketEffect {

    public Cookie(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.COOKIE);
    }

    @Override
    public String getNmsName() {
        return "angryVillager";
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 15;
    }
}