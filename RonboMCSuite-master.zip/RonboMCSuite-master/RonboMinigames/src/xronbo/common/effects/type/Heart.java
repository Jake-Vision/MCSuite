package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Heart extends PacketEffect {

    public Heart(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.HEART);
    }

    @Override
    public String getNmsName() {
        return "heart";
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 10;
    }
}