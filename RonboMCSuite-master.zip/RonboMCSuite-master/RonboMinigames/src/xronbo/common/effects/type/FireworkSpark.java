package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class FireworkSpark extends PacketEffect {

    public FireworkSpark(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.FIREWORKSPARK);
    }

    @Override
    public String getNmsName() {
        return "fireworksSpark";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 5;
    }
}