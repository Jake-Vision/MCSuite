package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Runes extends PacketEffect {

    public Runes(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.RUNES);
    }

    @Override
    public String getNmsName() {
        return "enchantmenttable";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 100;
    }
}