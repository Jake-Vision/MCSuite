package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Fire extends PacketEffect {

    public Fire(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.FIRE);
    }

    @Override
    public String getNmsName() {
        return "flame";
    }

    @Override
    public float getSpeed() {
        return 0.05F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}