package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Dust extends PacketEffect {

    public int idValue;
    public int metaValue;

    public Dust(EffectHolder effectHolder, int idValue, int metaValue) {
        super(effectHolder, ParticleType.DUST);
        this.idValue = idValue;
        this.metaValue = metaValue;
    }

    @Override
    public String getNmsName() {
        return "blockdust_" + idValue + "_" + metaValue;
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 100;
    }
}