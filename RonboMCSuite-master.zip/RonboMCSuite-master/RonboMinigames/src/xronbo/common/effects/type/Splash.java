package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Splash extends PacketEffect {

    public Splash(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SPLASH);
    }

    @Override
    public String getNmsName() {
        return "splash";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}