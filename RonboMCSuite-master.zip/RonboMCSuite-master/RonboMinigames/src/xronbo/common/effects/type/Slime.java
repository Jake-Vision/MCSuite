package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Slime extends PacketEffect {

    public Slime(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SLIME);
    }

    @Override
    public String getNmsName() {
        return "slime";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 20;
    }
}