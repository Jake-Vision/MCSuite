package xronbo.common.effects.type;

import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.PacketEffect;
import xronbo.common.effects.ParticleType;


public class Ember extends PacketEffect {

    public Ember(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.EMBER);
    }

    @Override
    public String getNmsName() {
        return "lava";
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 25;
    }
}