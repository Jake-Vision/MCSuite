package xronbo.common;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;

import me.ronbo.core.SQLManager;
import me.ronbo.core.ranks.RankManager;
import net.minecraft.server.v1_7_R4.EntityLiving;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;

import xronbo.common.entitytypes.CustomEntityType;
import xronbo.common.entitytypes.CustomVillager;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;
import xronbo.common.hpbar.HPBar;
import xronbo.common.other.GeneralManager;

public abstract class MinigamePlugin extends JavaPlugin implements CommandExecutor, Listener {
	
	public void onEnable() {
		plugin = this;
		CustomEntityType.registerEntities();
		getServer().getPluginManager().registerEvents(this, this);
		getServer().getPluginManager().registerEvents(new HPBar(this), this);
		getServer().getPluginManager().registerEvents(new GeneralManager(this), this);
		getServer().getPluginManager().registerEvents(new GameManager(this), this);
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		for(String s : defaultCommands) {
			try {
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				System.out.println("Error with command: " + s);
				e.printStackTrace();
			}
		}
		for(Entity e : plugin.getServer().getWorld("world").getEntities())
			if(!(e instanceof Player))
				e.remove();
		try {
			loadServerName();
			init();
			infoTask();
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					LivingEntity le = createLivingEntity(CustomVillager.class, new Location(plugin.getServer().getWorld("world"),1535.5,62,-792.5));
					le.setCustomName(ChatColor.GOLD + "King Ronbo");
					le.setCustomNameVisible(true);
				}
			}, 20);
			getLogger().info("Loaded!");
		} catch(Exception e) {
			e.printStackTrace();
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					getLogger().info("FAILED TO LOAD!");
					plugin.getServer().shutdown();
				}
			}, 20);
		}
	}
	
	public String serverName;
	
	public void loadServerName() throws Exception {
		boolean found = false;
		for(File f : new File("./plugins/").listFiles()) {
			if(f.getName().startsWith("server_")) {
				serverName = f.getName().substring("server_".length());
				System.out.println("This server is " + serverName);
				found = true;
				break;
			}
		}
		if(!found)
			throw new Exception("ERROR: COULD NOT FIND BUNGEE SERVER NAME IN ./plugins/. SHUTTING DOWN NOW!");
	}
	
	public long startTime;
	
	public abstract void init();
	public abstract String[] getExtraInfo(Game g);
	public abstract Class<? extends Game> getGameClass();
	
	public String convertInfo(String [] s) {
		StringBuilder sb = new StringBuilder("");
		for(String s2 : s)
			sb.append(s2 + "!@!");
		return sb.toString().trim();
	}
	
	public static final int GAMES_TO_PLAY = (int)(Math.random() * 20 + 35);

	public static int lastUpdate = 0;
	public static boolean restarting = false;
	public void infoTask() {
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public void run() {
				int count = 0;
				int update = lastUpdate++;
				ArrayList<String> vals = new ArrayList<String>();
				StringBuilder sb = new StringBuilder("");
				for(Game g : GameManager.games.values()) {
					int id = count++;
					String[] extra = null;
					String[] strings = new String[] {
						serverName + id,
						g.getRemainingPlayers() + "",
						update + "",
						(g.joinable ? "1" : "0"),
						(g.inProgress ? "1" : "0"),
						(Game.gamesPlayed < GAMES_TO_PLAY ? ((extra = getExtraInfo(g)) != null ? convertInfo(extra) : "") : "RESTARTING"),
					};
					if(Game.gamesPlayed >= GAMES_TO_PLAY && !restarting) {
						restarting = true;
						plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
							public void run() {
								if(plugin.getServer().getOnlinePlayers().length == 0) {
									System.out.println("Found no players online. Shutting down now.");
									plugin.getServer().shutdown();
								} else {
									boolean allempty = true;
									for(Game g : GameManager.games.values())
										if(g.players.size() == 0 && !g.inProgress)
											allempty = false;
									for(Player p : plugin.getServer().getOnlinePlayers())
										if(!p.getWorld().getName().equalsIgnoreCase("world"))
											allempty = false;
									if(plugin.getServer().getOnlinePlayers().length <= 1)
										allempty = true;
									if(allempty) {
										System.out.println("Found no players in-game. Shutting down now.");
										plugin.getServer().shutdown();
									}
								}
							}
						}, 20, 20);
					}
					for(String s : strings)
						vals.add(s);
					sb.append("(?,?,?,?,?,?),");
				}
				String questions = sb.toString();
				if(questions.endsWith(",")) {
					questions = questions.substring(0, questions.length() - 1);
				}
				String[] strings = vals.toArray(new String[vals.size()]);
				SQLManager.executePrepared("replace into bungee (name, players, lastupdate, joinable, inProgress, extra) "
						+ "VALUES " + questions
				, false, strings);
			}
		}, 20 * 1, 20 * 3);
	}
	
	public void loadWorlds() {
		for(File f : new File("./").listFiles()) {
			if(f.isDirectory()) {
				boolean isWorld = false;
				for(File f2 : f.listFiles()) {
					if(f2.getPath().toString().contains("session.lock")) {
						isWorld = true;
						break;
					}
				}
				if(isWorld) {
					getServer().createWorld(new WorldCreator(f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1)));
				}
			}
		}
		System.out.println("Loaded " + getServer().getWorlds().size() + " worlds.");
	}
	
	public void loadPlayer(Player p) {
		final String uuid = p.getUniqueId().toString();
		final String name = p.getName();
		for(Player p2 : plugin.getServer().getOnlinePlayers()) {
			p2.showPlayer(p);
			p.showPlayer(p2);
		}
		p.sendMessage(ChatColor.GREEN + "Loading player data...");
		p.teleport(plugin.getServer().getWorld("world").getSpawnLocation().add((int)(Math.random() * 7 - 3), 0, (int)(Math.random() * 7 - 3)));
		p.getInventory().clear();
		p.setScoreboard(plugin.getServer().getScoreboardManager().getMainScoreboard());
		final PermissionAttachment pa = p.addAttachment(plugin);
		pa.unsetPermission("bukkit.command.tell");
		pa.setPermission("bukkit.command.tell", false);
		pa.unsetPermission("minecraft.command.tell");
		pa.setPermission("minecraft.command.tell", false);
		pa.unsetPermission("bukkit.command.me");
		pa.setPermission("bukkit.command.me", false);
		pa.unsetPermission("minecraft.command.me");
		pa.setPermission("minecraft.command.me", false);
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				try {
					final ResultSet rs = SQLManager.executeQuery("select rankString, transfer, spectate from playerdata where uuid = '" + uuid + "'");
					if(rs.next()) {
						final int transfer = rs.getInt("transfer");
						final boolean spectate = rs.getBoolean("spectate");
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public void run() {
								Player p = plugin.getServer().getPlayerExact(name);
								if(p != null && p.isOnline() && p.isValid()) {
									for(int k = 0; k < 20; k++)
										p.sendMessage("");
									p.setGameMode(GameMode.SURVIVAL);
									p.setAllowFlight(false);
									if(!RankManager.check(p, "owner")) {
										p.setOp(false);
									} else {
										pa.unsetPermission("bukkit.command.tell");
										pa.setPermission("bukkit.command.tell", true);
										pa.unsetPermission("minecraft.command.tell");
										pa.setPermission("minecraft.command.tell", true);
										pa.unsetPermission("bukkit.command.me");
										pa.setPermission("bukkit.command.me", true);
										pa.unsetPermission("minecraft.command.me");
										pa.setPermission("minecraft.command.me", true);
									}
									if(spectate)
										GameManager.spectate(p, transfer);
									else
										GameManager.add(p, transfer, RankManager.check(p, "knight"));
									GameManager.joinedGames.put(p.getName(), transfer);
								}
							}
						});
					} else {
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public void run() {
								Player p = plugin.getServer().getPlayerExact(name);
								if(p != null && p.isOnline() && p.isValid()) {
									p.sendMessage(ChatColor.RED + "FATAL ERROR: Could not load your player data!");
									GameManager.returnToHub(p);
								}
							}
						});
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		loadPlayer(event.getPlayer());
		event.setJoinMessage("");
	}
	
	@EventHandler
	public void onPlayerLeave(PlayerQuitEvent event) {
		event.setQuitMessage("");
	}
	
	public LivingEntity createLivingEntity(Class<?> type, Location loc) {
		net.minecraft.server.v1_7_R4.World world = ((CraftWorld)(loc.getWorld())).getHandle();
		net.minecraft.server.v1_7_R4.EntityLiving e = null;
		try {
			e = (EntityLiving) (type.getDeclaredConstructor(net.minecraft.server.v1_7_R4.World.class).newInstance(world));
		} catch(Exception e2) {
			e2.printStackTrace();
		}
		e.setPosition(loc.getX(), loc.getY(), loc.getZ());
		world.addEntity(e, SpawnReason.CUSTOM);
		LivingEntity le = (LivingEntity)(((net.minecraft.server.v1_7_R4.Entity)e).getBukkitEntity());
		le.setRemoveWhenFarAway(false);
		return le;
	}

	
	public LivingEntity createLivingEntityNoMove(Class<?> type, Location loc) {
		net.minecraft.server.v1_7_R4.World world = ((CraftWorld)(loc.getWorld())).getHandle();
		net.minecraft.server.v1_7_R4.EntityLiving e = null;
		try {
			e = (EntityLiving) (type.getDeclaredConstructor(net.minecraft.server.v1_7_R4.World.class, boolean.class).newInstance(world, false));
		} catch(Exception e2) {
			e2.printStackTrace();
		}
		e.setPosition(loc.getX(), loc.getY(), loc.getZ());
		world.addEntity(e, SpawnReason.CUSTOM);
		LivingEntity le = (LivingEntity)(((net.minecraft.server.v1_7_R4.Entity)e).getBukkitEntity());
		le.setRemoveWhenFarAway(false);
		return le;
	}
	
	public String[] defaultCommands = {
			"changeworld", "hub", "killall", "checkworld", "spectate"
		};
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("spectate")) {
					if(GameManager.spectators.contains(p.getName())) {
						if(args.length == 1) {
							Player spec = plugin.getServer().getPlayerExact(args[0]);
							if(GameManager.getGame(spec) == GameManager.getGame(p)) {
								p.teleport(spec.getLocation());
								p.sendMessage(ChatColor.GREEN + "You are now spectating " + ChatColor.AQUA + spec.getName() + ChatColor.GREEN + "!");
								p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/hub " + ChatColor.GREEN + "to return to the Kastia Hub!");
								p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/spectate <name> " + ChatColor.GREEN + "to spectate a specific player!");
							} else {
								p.sendMessage(ChatColor.RED + "Player " + args[0] + " is not in this game!");
							}
						} else {
							p.sendMessage(ChatColor.RED + "Player " + args[0] + " is not in this game!");
						}
					} else {
						p.sendMessage(ChatColor.RED + "You are not in spectator mode right now!");
					}
				}
				if(cmd.getName().equalsIgnoreCase("killall")) {
					if(RankManager.check(p, "admin")) {
						for(Entity e : p.getWorld().getEntities())
							if(!(e instanceof Player))
								e.remove();
					}
				}
				if(cmd.getName().equalsIgnoreCase("changeworld")) {
					if(RankManager.check(p, "mod")) {
						if(args.length > 0) {
							World w = null;
							StringBuilder worldName = new StringBuilder("");
							for(String s : args)
								worldName.append(s + " ");
							worldName = new StringBuilder(worldName.substring(0, worldName.length() - 1));
							for(World w2 : plugin.getServer().getWorlds()) {
								if(w2.getName().equalsIgnoreCase(worldName.toString()))
									w = w2;
							}
							if(w == null) {
								p.sendMessage(ChatColor.RED + "Invalid world name! (" + worldName.toString() + ")");
								StringBuilder sb = new StringBuilder("Valid world names: ");
								for(World w2 : plugin.getServer().getWorlds())
									if(!w2.getName().contains("+di+"))
										sb.append(w2.getName() + ", ");
								p.sendMessage(sb.substring(0, sb.length() - 2));
								return true;
							}
							p.teleport(w.getSpawnLocation());
						} else {
							StringBuilder sb = new StringBuilder("Valid world names: ");
							for(World w2 : plugin.getServer().getWorlds())
									sb.append(w2.getName() + ", ");
							p.sendMessage(sb.substring(0, sb.length() - 2));
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("hub")) {
					GameManager.returnToHub(p);
				}
				if(cmd.getName().equalsIgnoreCase("checkworld")) {
					if(RankManager.check(p, "admin")) {
						p.sendMessage(p.getWorld().getName());
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		for(String s : defaultCommands) {
			if(cmd.getName().equalsIgnoreCase(s))
				return true;
		}
		return false;
	}
	
	public void onDisable() {
		getLogger().info("Disabling...");
		CustomEntityType.unregisterEntities();
		plugin.getServer().getScheduler().cancelAllTasks();
		for(World w : plugin.getServer().getWorlds())
			if(!w.getName().equals("world"))
				plugin.getServer().unloadWorld(w, false);
		for(Game g : GameManager.games.values())
			g.deleteWorld(true);
		getLogger().info("Disabled.");
	}
	
	public static MinigamePlugin plugin;
	
}
