package me.ronbo.ronborunners;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import xronbo.common.MinigamePlugin;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;

public class RonboRunners extends MinigamePlugin implements CommandExecutor, Listener {

	@Override
	public Class<? extends Game> getGameClass() {
		return RunnersGame.class;
	}
	
	public void onEnable() {
		super.onEnable();
		for(String s : commands) {
			try {
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		loadWorlds();
	}
	
	public void init() {
		plugin.getServer().broadcastMessage(ChatColor.RED + "Server reloading... Sending all players back to hub.");
		plugin.getServer().broadcastMessage(ChatColor.RED + "Sorry for any inconvenience.");
		for(Player p : plugin.getServer().getOnlinePlayers()) {
			loadPlayer(p);
			GameManager.add(p, 1, true);
		}
//			GameManager.returnToHub(p);
	}
	
	public String[] commands = {
		"db", 
	};
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(super.onCommand(sender, cmd, label, args)) //default commands
				return true;
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("db")) {
					p.sendMessage("Team ID: " + p.getMetadata("team").get(0).asInt());
					((RunnersGame)GameManager.getGame(p)).spawnGriever(p.getLocation());
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public String[] getExtraInfo(Game g) {
		return null;
	}
	
}
