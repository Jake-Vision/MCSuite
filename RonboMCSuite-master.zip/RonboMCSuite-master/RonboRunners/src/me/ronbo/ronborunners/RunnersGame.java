package me.ronbo.ronborunners;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

import xronbo.common.entitytypes.CustomZombie;
import xronbo.common.games.Game;
import xronbo.common.other.Values;

public class RunnersGame extends Game {
	
	@Override
	public String getGameName() {
		return "Maze Ronners";
	}
	
	@Override
	public String[][] getWorldNames() {
		return new String[][] {
			{"test", "Blip blop"},
		};
	}
	
	@Override
	public int getPlayersToStart() {
		return 1;
	}

	@Override
	public int getCountdownLength() {
		return 10;
	}

	@Override
	public boolean getJoinableAfterStart() {
		return false;
	}

	@Override
	public int getGameCount() {
		return 3;
	}

	@Override
	public int getMaxPlayers() {
		return 48;
	}

	@Override
	public boolean getTerrainChangeable() {
		return true;
	}
	
	@Override
	public boolean getLeaveOnDeath() {
		return true;
	}

	@Override
	public boolean getShowDeathMessage() {
		return true;
	}
	
	@EventHandler
	public void ondielol(PlayerDeathEvent event) {
		
	}
	

	public boolean checkEndCondition() {
		return false;
	}
	
	@Override
	protected double[] getSpawnLoc(Player p) {
		try {
			switch(p.getMetadata("team").get(0).asInt()) {
				case 0:
					return new double[] {205, 66, -215, 40.94, -2.85};
				case 1:
					return new double[] {196, 66, -215, -48, -6.75};
				case 2:
					return new double[] {196, 66, -206, -139.5, -1.95};
				case 3:
					return new double[] {205, 66, -207, -229.95, -5.85};
				default:
					return locToDoubleArray(world.getSpawnLocation());
			}
		} catch(Exception e) {
			e.printStackTrace();
			return locToDoubleArray(world.getSpawnLocation());
		}
	}
	
	@SuppressWarnings("unchecked")
	public HashSet<String>[] teams = new HashSet[4];
	
	public int index = 0;
	
	@Override
	public void preJoin(Player p) {
		if(index >= teams.length)
			index = 0;
		if(teams[index] == null)
			teams[index] = new HashSet<String>();
		teams[index].add(p.getName());
		p.setMetadata("team", new FixedMetadataValue(plugin, index));
		index++;
	}
	
	@Override
	public void postJoin(Player p) {
		
	}
	
	public RunnersGame(int id) {
		super(id);
	}
	
	protected int objectiveTask() {
		return -1;
	}

	@Override
	protected void postWorldLoad() {
		
	}

	@Override
	public void postLeave(Player p) {
		p.removeMetadata("class", plugin);
	}

	@Override
	public void postRespawn(Player p) {
		
	}
	
	@Override
	public void postEnd() {
		
	}
	
	public void spawnGriever(Location loc) {
//		world.spawnEntity(loc, EntityType.SKELETON);
		//Skeleton le = (Skeleton)
				plugin.createLivingEntity(CustomZombie.class, loc);
//		le.setSkeletonType(SkeletonType.WITHER);
//		le.getEquipment().setHelmet(new ItemStack(Material.IRON_HELMET));
//		le.getEquipment().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
//		le.getEquipment().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
//		le.getEquipment().setBoots(new ItemStack(Material.IRON_BOOTS));
//		le.addPotionEffect(PotionEffectType.SLOW.createEffect(200000, 0));
	}

	public Set<int[]> mosses = Collections.newSetFromMap(new ConcurrentHashMap<int[], Boolean>());
	public ArrayList<Integer> taskIds = new ArrayList<Integer>();
	
	public volatile int count = 0;
	@Override
	protected void postAllEnter() {
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				count = 0;
				message(ChatColor.RED + "Walls will go down in 30 seconds!");
				final ArrayList<ChunkSnapshot> snaps = new ArrayList<ChunkSnapshot>();
				for(Chunk c : world.getLoadedChunks()) {
					snaps.add(c.getChunkSnapshot());
				}
				plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
					public void run() {
						for(final ChunkSnapshot cs : snaps) {
							for(int x = 0; x < 16; x++) {
								for(int z = 0; z < 16; z++) {
									for(int y = 0; y < 128; y++) {
										int id = cs.getBlockTypeId(x, y, z);
										if(id == Material.MOSSY_COBBLESTONE.getId())
											mosses.add(new int[] {cs.getX() * 16 + x, y, cs.getZ() * 16 + z});
									}
								}
							}
						}
						System.out.println("Done searching loaded snapshots. Total of " + mosses.size() + " blocks found in " + snaps.size() + " snapshots.");
						System.out.println("Edited a total of " + count + " highest blocks.");
					}
				});
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						message(ChatColor.RED + "The walls disappear with a bang!");
						for(int[] i : mosses) {
							Block b = world.getBlockAt(i[0], i[1], i[2]);
							if(b.getType() == Material.MOSSY_COBBLESTONE) {
								b.setType(Material.AIR);
								world.createExplosion(b.getX(), b.getY(), b.getZ(), 0.5f, false, false);
							}
						}
					}
				}, 20 * 30);
			}
		}, 20 * 5);
		
	}
	
	public static ItemStack clock = null;
	
	@EventHandler
	public void onClassMenuClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().contains("Choose your Class!")) {
				event.setCancelled(true);
				ItemStack item = event.getCurrentItem();
				Player p = (Player)event.getWhoClicked();
				String className = ChatColor.stripColor(item.getItemMeta().getDisplayName()).toLowerCase();
				if(item.getItemMeta().getLore().toString().contains("Click to Play")) {
					p.setMetadata("class", new FixedMetadataValue(plugin, className));
				} else if(item.getItemMeta().getLore().toString().contains("Click to Buy")) {
					
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public void openClassMenu(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "Choose your Class!");
		ItemStack item;
		ItemMeta im;
		ArrayList<String> lore;
		
		item = new ItemStack(Material.STONE_AXE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Noobo");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Play");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Axe");
		lore.add("");
		lore.add(ChatColor.YELLOW + "Just your standard stone axer.");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(0, item);
		
		item = new ItemStack(Material.STONE_SWORD);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Barbarian");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Sword");
		lore.add(ChatColor.RED + " - 2x STR Pot");
		lore.add("");
		lore.add(ChatColor.YELLOW + "MUST DESTROY ALL!!!");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(2, Values.removeAttributes(item));
		
		item = new ItemStack(Material.SUGAR);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Maze Ronner");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Permanent Night Vision");
		lore.add(ChatColor.RED + " - Permanent Speed I");
		lore.add(ChatColor.RED + " - 3x Speed Sugar");
		lore.add("");
		lore.add(ChatColor.YELLOW + "Run run run!");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(3, item);
		
		item = new ItemStack(Material.DIAMOND_SPADE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Smasher");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Sharpness III Diamond Shovel");
		lore.add(ChatColor.RED + "   - Smash Ability (Right-Click)");
		lore.add("");
		lore.add(ChatColor.YELLOW + "It's time to get physical!");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(4, item);
		
		item = new ItemStack(Material.REDSTONE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Vampire");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Sword");
		lore.add(ChatColor.RED + " - 25% chance of inflicting Nausea");
		lore.add(ChatColor.RED + " - 10% chance of inflicting Blindness");
		lore.add("");
		lore.add(ChatColor.YELLOW + "Beware the darkness...");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(5, item);
		
		item = new ItemStack(Material.MONSTER_EGG);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Beastmaster");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Axe");
		lore.add(ChatColor.RED + " - 3 Wolf Eggs");
		lore.add(ChatColor.RED + " - 10 Bones");
		lore.add("");
		lore.add(ChatColor.YELLOW + "The wolfpack is back!");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(6, item);
		
		item = new ItemStack(Material.WATCH);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Magician");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Sword");
		lore.add(ChatColor.RED + " - Invisibility Clock");
		lore.add(ChatColor.RED + "   - 5 second duration");
		lore.add(ChatColor.RED + "   - 30 second cooldown");
		lore.add("");
		lore.add(ChatColor.YELLOW + "And for my next trick... die!");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(7, item);
		
		item = new ItemStack(Material.COMPASS);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Hunter");
		lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Click to Buy (Permanent)");
		lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "500 Blops");
		lore.add("");
		lore.add(ChatColor.BLUE + "" + ChatColor.UNDERLINE + "Kit");
		lore.add(ChatColor.RED + " - Stone Sword");
		lore.add(ChatColor.RED + " - Tracking Device (Compass)");
		lore.add("");
		lore.add(ChatColor.YELLOW + "Why escape when you can kill?");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(8, item);
		
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void onChooseClass(PlayerInteractEvent event) {
		try {
			if(event.getItem().getItemMeta().getDisplayName().contains("Choose your Class!")) {
				openClassMenu(event.getPlayer());
				event.setCancelled(true);
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onDropClock(PlayerDropItemEvent event) {
		try {
			if(event.getItemDrop().getItemStack().getItemMeta().getDisplayName().contains("Choose your Class!")) {
				openClassMenu(event.getPlayer());
				event.setCancelled(true);
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onClickClock(InventoryClickEvent event) {
		try {
			if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Choose your Class!")) {
				openClassMenu((Player)event.getWhoClicked());
				event.setCancelled(true);
			}
		} catch(Exception e) {
			
		}
	}
	
	@Override
	protected void postEnter(Player p) {
		p.sendMessage(ChatColor.GOLD + "Choose your class with your " + ChatColor.YELLOW + ChatColor.BOLD + "clock" + ChatColor.GOLD + "! Just click while holding it!");
		if(clock == null) {
			clock = new ItemStack(Material.WATCH);
			ItemMeta im = clock.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Choose your Class!");
			im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Click to choose your class!"}));
			clock.setItemMeta(im);
		}
		p.setItemInHand(clock);
	}
	
}
