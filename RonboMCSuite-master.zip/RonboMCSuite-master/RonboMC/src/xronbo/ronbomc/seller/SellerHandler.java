package xronbo.ronbomc.seller;

import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;

public class SellerHandler implements Listener {

	public static Inventory inventory;
	
	public static void load() {
		inventory = Bukkit.createInventory(null, 9, ChatColor.BLACK + "Sell your junk!");
		ItemStack item = new ItemStack(Material.GOLD_BLOCK);
		ItemMeta im = item.getItemMeta();
		im.setDisplayName("Sell your stuff now!");
		im.setLore(Arrays.asList(new String[] {
				"Sell your equipment here!",
				"Tier 1 - 15g",
				"Tier 2 - 50g",
				"Tier 3 - 4000g",
				"Tier 4 - 30000g",
				"Tier 5 - 60000g",
				"",
				"Just click an item in your inventory to sell it!",
				"Warning: There is no confirmation, it's sold immediately!"
		}));
		item.setItemMeta(im);
		inventory.setItem(0, item);
		item = new ItemStack(Material.POTION);
		im = item.getItemMeta();
		im.setDisplayName("Sell your potions!");
		im.setLore(Arrays.asList(new String[] {
				"Sell your potions here!",
				"Click this button to sell ALL potions in your inventory",
				"All potions are sold for 10g each!",
				"Warning: There is no confirmation, it's sold immediately!"
		}));
		item.setItemMeta(im);
		inventory.setItem(1, item);
	}
	
	public static void show(Player p) {
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		Player p = (Player)event.getWhoClicked();
		try {
			 if(event.getInventory().getName().equals(ChatColor.BLACK + "Sell your junk!")) {
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				 event.setCancelled(true);
				 ItemStack item = event.getCurrentItem();
				 try {
					 if(item.getItemMeta().getDisplayName().contains("Sell your stuff now!"))
						 return;
				 } catch(Exception e) {
					 
				 }
				 if(item.getItemMeta().getDisplayName().contains("Sell your potions!")) {
					 int potionCount = 0;
					 for(ItemStack i : p.getInventory()) {
						 if(i != null && i.getType() == Material.POTION && i.hasItemMeta() && i.getItemMeta().hasDisplayName() &&
								 i.getItemMeta().getDisplayName().contains("Healing Potion")) {
							 p.getInventory().removeItem(i);
							 potionCount++;
						 }
					 }
					 if(potionCount == 0) {
						 p.sendMessage(ChatColor.RED + "You don't have any healing potions with you!");
						 p.closeInventory();
					 } else {
						 plugin.getPD(p).wallet += potionCount * 10;
						 p.sendMessage(ChatColor.GREEN + "You sold all your potions for " + ChatColor.GOLD + (potionCount * 10) + "g" + ChatColor.GREEN + ". The gold has been added to your wallet.");
						 p.closeInventory();
					 }
				 } else {
					 ItemHandler.loadItem(item);
					 ItemData id = ItemHandler.items.get(item);
					 int tier = id.tier;
					 int worth = 0;
					 switch(tier) {
						 case 1:
							 worth = 15;
							 break;
						 case 2:
							 worth = 50;
							 break;
						 case 3:
							 worth = 4000;
							 break;
						 case 4:
							 worth = 30000;
							 break;
						 case 5:
							 worth = 60000;
							 break;
					 }
					 if(worth == 0) {
						 p.sendMessage("This item does not appear to have a tier, and cannot be sold!");
						 return;
					 }
					 plugin.getPD(p).wallet += worth;
					 p.getInventory().removeItem(item);
					 p.sendMessage(ChatColor.GREEN + "You sold your " + (id.name.length() > 0 ? id.name : "item") + " for " + ChatColor.GOLD + worth + "g" + ChatColor.GREEN + ". The gold has been added to your wallet.");
				 }
			 }
		} catch(Exception e) {
			
		}
	}
	
	public static RonboMC plugin;
	
	public SellerHandler(RonboMC plugin) {
		SellerHandler.plugin = plugin;
		load();
	}
	
}
