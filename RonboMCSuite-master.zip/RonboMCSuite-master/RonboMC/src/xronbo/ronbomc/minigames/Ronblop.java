package xronbo.ronbomc.minigames;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import xronbo.ronbomc.RonboMC;

public class Ronblop implements Listener {
	
	public static RonboMC plugin;
	public static Inventory ronblopTemplate;
	@SuppressWarnings("static-access")
	public Ronblop(RonboMC plugin) {
		ronblopTemplate = Bukkit.createInventory(null, 9 * 3, ChatColor.GOLD + "" + ChatColor.MAGIC + "|" + ChatColor.RESET + "The Ronblop Machine" + ChatColor.GOLD + "" + ChatColor.MAGIC + "|");
		this.plugin = plugin;
	}
	
	public static void openRonblop(final Player p) {
//		final Inventory ronblop = Bukkit.createInventory(null, 9 * 3, ChatColor.GOLD + "" + ChatColor.MAGIC + "|" + ChatColor.RESET + "The Ronblop Machine" + ChatColor.GOLD + "" + ChatColor.MAGIC + "|");
//		p.openInventory(ronblop);
//		final int ronblopTask = SuperDebugger.scheduleSyncRepeatingTask(plugin, new Runnable() {
//			public void run() {
//				//if(p.get)
//			}
//		}, 0, 3);
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getTitle().equals(ronblopTemplate.getTitle())) {
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				event.setCancelled(true);
				switch(ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName().trim()).toLowerCase()) {
					case "ronblop":
	//					Ronblop.openRonblop((Player)(event.getWhoClicked()));
						break;
				}
			}
		} catch(Exception e) {
			
		}
	}
	
//	@EventHandler
//	public void login(PlayerLoginEvent event) {
//		Player p = event.getPlayer();
//		plugin.loadPlayer(p);
//	}
	
}