package xronbo.ronbomc.minigames;

import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;

public class MinigameHandler implements Listener {
	
	public static RonboMC plugin;
	public static Inventory minigameSelector;
	
	public static void openMinigames(Player p) {
		if(minigameSelector == null)
			createMinigameSelector();
		p.openInventory(minigameSelector);
	}
	
	public static void createMinigameSelector() {
		minigameSelector = Bukkit.createInventory(null, 9*1, "Kastia Minigames");
		ItemStack i = new ItemStack(Material.SLIME_BALL);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.DARK_GREEN + "Ronblop");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Challenge your reflexes!", 
				ChatColor.LIGHT_PURPLE + "Try to stop the Ronblop machine when there",
				ChatColor.LIGHT_PURPLE + "are at least 5 Red Ronblops on the machine!",
				ChatColor.LIGHT_PURPLE + "The more Red Ronblops, the bigger your reward!"
		}));
		i.setItemMeta(im);
		minigameSelector.setItem(0, i);
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getTitle().equals(minigameSelector.getTitle())) {
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				event.setCancelled(true);
				switch(ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName().trim()).toLowerCase()) {
					case "ronblop":
	//					Ronblop.openRonblop((Player)(event.getWhoClicked()));
						break;
				}
			} 
		} catch(Exception e) {
			
		}
	}

	@SuppressWarnings("static-access")
	public MinigameHandler(RonboMC plugin) {
		this.plugin = plugin;
	}
}