package xronbo.ronbomc.travel;

import java.util.ArrayList;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.parties.Party;
import xronbo.ronbomc.warps.WarpHandler;

public class TravelHandler implements Listener {

	public static RonboMC plugin;
	
	@EventHandler
	public void onCompassUse(PlayerInteractEvent event) {
		Player p = event.getPlayer();
		PlayerData pd = plugin.getPD(p);
		try {
			if(event.getItem().getItemMeta().getDisplayName().contains("The Navigator")) {
				switch(event.getAction()) {
					case LEFT_CLICK_BLOCK:
					case LEFT_CLICK_AIR:
						if(pd.party == null) {
							p.sendMessage(ChatColor.RED + "You are not in a party!");
							return;
						}
						openPartyTeleportInterface(pd.party, p);
						break;
					case RIGHT_CLICK_BLOCK:
					case RIGHT_CLICK_AIR:
						openQuickTravelInterface(p);
						break;
					case PHYSICAL:
						break;
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onPartyMenuClick(InventoryClickEvent event) {
		try {
			Player p = (Player) event.getWhoClicked();
			PlayerData pd = plugin.getPD(p);
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Warp to your partymates!")) {
				event.setCancelled(true);
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				p.closeInventory();
				String name = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
				Player tpto = plugin.getServer().getPlayerExact(name);
				if(tpto == null) {
					p.sendMessage("Could not find player " + name + "!");
				} else {
					Location loc = tpto.getLocation();
					boolean canTP = loc.getWorld().getName().equals("world") && p.getLocation().getWorld().getName().equals("world");
					if(canTP) {
						int price = getPrice(p.getLocation().distance(loc), plugin.getPD(p));
						if(pd.bankGold >= price) {
							p.sendMessage(ChatColor.GREEN + "Teleporting you to " + name + "! The price will be " + ChatColor.GOLD + price + "g" + ChatColor.GREEN + ".");
							tpto.sendMessage(ChatColor.GREEN + "Your party member " + p.getName() + " is warping to your current location in 10 seconds!");
							WarpHandler.warp(p, name, loc, 10, price);
						} else {
							p.sendMessage(ChatColor.RED + "You need to have " + ChatColor.GOLD + price + "g" + ChatColor.RED + " in your bank to use this!");
						}
					} else {
						p.sendMessage(ChatColor.RED + tpto.getName() + " is in a location that you can't teleport to!");
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onQuickTravelMenuClick(InventoryClickEvent event) {
		try {
			Player p = (Player) event.getWhoClicked();
			PlayerData pd = plugin.getPD(p);
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Kastia Quick Travel")) {
				event.setCancelled(true);
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				p.closeInventory();
				String name = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
				if(name.startsWith("QT Slot ")) {
					int slot = Integer.parseInt(name.substring("QT Slot ".length()));
					if(pd.QTLocs.get(slot - 1).name.equals("$temp")) {
						p.sendMessage(ChatColor.RED + "There is no location linked to that QT Slot!");
					} else {
						Location loc = pd.QTLocs.get(slot - 1).loc;
						boolean canTP = p.getLocation().getWorld().getName().equals("world");
						if(canTP) {
							int price = getPrice(p.getLocation().distance(loc), plugin.getPD(p));
							if(pd.bankGold >= price) {
								p.sendMessage(ChatColor.GREEN + "Warping you to " + name + "! The price will be " + ChatColor.GOLD + price + "g" + ChatColor.GREEN + ".");
								WarpHandler.warp(p, pd.QTLocs.get(slot - 1).name, loc, 10, price);
							} else {
								p.sendMessage(ChatColor.RED + "You need to have " + ChatColor.GOLD + price + "g" + ChatColor.RED + " in your bank to use this!");
							}
						} else {
							p.sendMessage(ChatColor.RED + "You can't teleport right now!");
						}
					}
				} else if(name.startsWith("Buy 1 more QT Slot!")) {
					int price = getExpandQTSlotPrice(pd.maxQT, pd);
					if(pd.bankGold >= price) {
						pd.maxQT += 1;
						pd.bankGold -= price;
						pd.QTLocs.add(new QTDestination());
						p.sendMessage(ChatColor.GREEN + "You expanded your QT Slots by 1! You now have " + pd.maxQT + " slots.");
					} else {
						p.sendMessage(ChatColor.RED + "You need to have " + ChatColor.GOLD + price + "g" + ChatColor.RED + " in your bank to use this!");
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public static class QTDestination {
		public String name;
		public Location loc;
		public QTDestination() {
			this.name = "$temp";
			this.loc = WarpHandler.warps.get("mainspawn");
		}
		public QTDestination(String name, Location loc) {
			this.name = name;
			this.loc = loc;
		}
	}
	
	public static void openQuickTravelInterface(Player p) {
		PlayerData pd = plugin.getPD(p);
		Inventory inventory = Bukkit.createInventory(p, (int)Math.ceil((pd.maxQT + 1) / 9.0) * 9, ChatColor.BLACK + "Kastia Quick Travel");
		for(int k = 0; k < pd.maxQT; k++) {
			ItemStack item = new ItemStack(Material.COMPASS);
			ItemMeta im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "QT Slot " + (k+1));
			ArrayList<String> lore = new ArrayList<String>();
			QTDestination qtd = pd.QTLocs.get(k);
			if(qtd.name.equals("$temp")) {
				lore.add(ChatColor.RED + "This QT Slot has not been set!");
				lore.add("");
				lore.add(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/setqt " + (k+1) + " <Slot Nickname>" + ChatColor.GREEN + " to set this");
				lore.add(ChatColor.GREEN + "QT Slot to your current location.");
			} else {
				Location loc = qtd.loc;
				lore.add(ChatColor.GREEN + qtd.name + ChatColor.WHITE + " - " + ChatColor.YELLOW + "" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
				lore.add("");
				lore.add(ChatColor.GREEN + "Click on this compass to teleport to " + qtd.name + ".");
				lore.add("");
				int price = 5000;
				if(loc.getWorld() != null && p.getLocation().getWorld() == loc.getWorld())
					price = getPrice(p.getLocation().distance(loc), plugin.getPD(p));
				lore.add(ChatColor.GREEN + "The cost of this teleport is " + ChatColor.GOLD + price + "g.");
				lore.add(ChatColor.GREEN + "The price will be deducted from your bank account.");
				lore.add("");
				lore.add(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/setqt " + (k+1) + " <Slot Nickname>" + ChatColor.GREEN + " to set this");
				lore.add(ChatColor.GREEN + "QT Slot to your current location.");
			}
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(k, item);
		}
		ItemStack item = new ItemStack(Material.WATCH);
		ItemMeta im = item.getItemMeta();
		int price = getExpandQTSlotPrice(pd.maxQT, pd);
		im.setDisplayName(ChatColor.GREEN + "Buy 1 more QT Slot!");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add(ChatColor.LIGHT_PURPLE + "Buy 1 more QT Slot for " + ChatColor.GOLD + price + "g" + ChatColor.LIGHT_PURPLE + ".");
		lore.add("");
		lore.add(ChatColor.LIGHT_PURPLE + "Click on this icon to buy one more QT Slot.");
		lore.add(ChatColor.LIGHT_PURPLE + "The cost will be taken from your bank account.");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(inventory.getSize() - 1, item);
		p.openInventory(inventory);
	}
	
	private static int getExpandQTSlotPrice(int maxQT, PlayerData pd) {
		int value = 500000;
		switch(maxQT) {
			case 3:
				value = 1000;
			case 4:
				value = 5000;
			case 5:
				value = 10000;
			case 6:
				value = 50000;
			case 7:
				value = 100000;
			case 8:
				value = 200000;
			case 9:
				value = 300000;
			case 10:
				value = 400000;
			default:
				value = 500000;
		}
		if(RankManager.check(pd.player, "knight"))
			value /= 2;
		return value;
	}

	public static int getPrice(double distance, PlayerData pd) {
		int value = 1000;
		if(distance < 200) {
			value = 25;
		} else if(distance < 500) {
			value = 75;
		} else if(distance < 1500) {
			value = 150;
		} else if(distance < 4000){
			value = 250;
		} else if(distance < 10000){
			value = 400;
		} else {
			value = 1000;
		}
		if(RankManager.check(pd.player, "knight"))
			value /= 2;
		return value;
	}
	
	public static void openPartyTeleportInterface(Party party, Player p) {
		if(party == null) {
			p.sendMessage(ChatColor.RED + "You are not in a party! You can only teleport your partymates.");
			return;
		}
		Inventory inventory = Bukkit.createInventory(p, (int)Math.ceil(party.members.size() / 9.0) * 9, ChatColor.BLACK + "Warp to your partymates!");
		for(String name : party.members) {
			Player pmem = plugin.getServer().getPlayer(name);
			if(pmem == p) {
				continue;
			}
			ItemStack item = new ItemStack(Material.COMPASS);
			ItemMeta im = item.getItemMeta();
			Location loc = pmem.getLocation();
			boolean canTP = loc.getWorld().getName().equals("world") && p.getLocation().getWorld().getName().equals("world");
			im.setDisplayName((canTP ? ChatColor.GREEN : ChatColor.RED) + pmem.getName());
			ArrayList<String> lore = new ArrayList<String>();
			if(canTP) {
				lore.add(ChatColor.GREEN + pmem.getName() + "'s Coords:");
				lore.add(ChatColor.GREEN + "" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
				lore.add("");
				lore.add(ChatColor.GREEN + "Click on this compass to teleport to " + pmem.getName() + ".");
				lore.add("");
				lore.add(ChatColor.GREEN + "The cost of this teleport is " + ChatColor.GOLD + getPrice(p.getLocation().distance(loc), plugin.getPD(p)) + "g.");
				lore.add(ChatColor.GREEN + "The price will be deducted from your bank account.");
			} else {
				lore.add(ChatColor.RED + pmem.getName() + " is in a location that you can't teleport to!");
			}
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.addItem(item);
		}
		p.openInventory(inventory);
	}
	
	public TravelHandler(RonboMC plugin) {
		TravelHandler.plugin = plugin;
	}
	
}
