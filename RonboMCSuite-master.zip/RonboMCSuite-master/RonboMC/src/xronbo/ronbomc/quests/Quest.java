package xronbo.ronbomc.quests;

import java.util.ArrayList;
import java.util.TreeMap;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;


public class Quest {
	
	public static RonboMC plugin;
	public ArrayList<Stage> stages;
	public String name, description;
	public int reqQuest, reqLevel;
	public int id;
	public boolean noInfo = false;
	
	public Quest(int id, String name, String description, int reqQuest, int reqLevel) {
		this.id = id;
		if(name.trim().endsWith("(noinfo)")) {
			noInfo = true;
			name = name.substring(0, name.lastIndexOf("(noinfo)")).trim();
		}
		this.name = name;
		this.description = description;
		this.reqQuest = reqQuest;
		this.reqLevel = reqLevel;
		stages = new ArrayList<Stage>();
	}
	
	public int stagecount = 0;
	
	public void addObjective(String s) {
		boolean objective = false;
		String[] data = s.trim().split(" ");
		Stage stage = null;
		if(data[0].endsWith(":")) {
			stage = new Stage(this, s, "talk", Integer.parseInt(data[0].substring(0, data[0].indexOf(":"))), s.substring(s.indexOf(": ") + ": ".length()), "");
		} else if(data[0].equalsIgnoreCase("new")) {
			stage = new Stage(this, s, data[1], Integer.parseInt(data[5]), data[2], data[3]);
		} else if(data[0].equalsIgnoreCase("rewarditem")) {
			stage = new Stage(this, s, data[0], 0, data[1], data[2]);
		} else if(data[0].equalsIgnoreCase("rewardexp")) {
			stage = new Stage(this, s, data[0], 0, data[1], "");
		} else if(data[0].equalsIgnoreCase("rewardgold")) {
			stage = new Stage(this, s, data[0], 0, data[1], "");
		} else if(data[0].equalsIgnoreCase("objective")) {
			objective = true;
			addObjective(stagecount, s.substring("objective ".length()));
		} else {
			System.out.println("INVALID STAGE DATA " + s);
		}
		if(stage != null)
			stages.add(stage);
		if(!objective)
			stagecount++;
	}

	public TreeMap<Integer, String> objectives = new TreeMap<Integer, String>();
	
	public void addObjective(int index, String obj) {
		objectives.put(index, obj);
	}
	
	public String getObjective(PlayerData pd) {
		int current = 0;
		if(pd.inProgressQuests.keySet().contains(this)) {
			current = pd.inProgressQuests.get(this);
		} else if(pd.completedQuests.contains(this)) {
			return "Complete!";
		} else if(pd.level < this.reqLevel || (this.reqQuest > 0 && !pd.completedQuests.contains(QuestHandler.quests.get(this.reqQuest)))) {
			return "Requirements not met.";
		}
		int last = -1;
		for(int i : objectives.keySet()) {
			if(i <= current && i > last) {
				last = i;
			}
		}
		if(last == -1)
			return "No info.";
		return objectives.get(last);
	}
	
	public String toString() {
		return this.name;
	}
	
}