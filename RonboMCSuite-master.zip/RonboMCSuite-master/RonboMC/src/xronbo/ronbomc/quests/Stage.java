package xronbo.ronbomc.quests;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobDrop;
import xronbo.ronbomc.entities.VillagerData;
import xronbo.ronbomc.items.EtcItem;


public class Stage {
	
	public static RonboMC plugin;
	public String type;
	public String phrase;
	public int npcID;
	public EtcItem collectItem;
	public ItemStack[] rewardItem;
	public String mobToHunt;
	public int count;
	public Quest quest;
	public String original;
	
	public Stage(Quest q, String original, String type, int npcID, String val1, String val2) {
		this.type = type;
		this.npcID = npcID;
		this.quest = q;
		this.original = original;
		switch(type.toLowerCase()) {
			case "talk":
				this.phrase = val1;
				break;
			case "collect":
				count = Integer.parseInt(val1);
				collectItem = EtcItem.getEtcItem(val2);
				break;
			case "kill":
				count = Integer.parseInt(val1);
				mobToHunt = val2;
				break;
			case "rewarditem":
				count = Integer.parseInt(val1);
				if(val2.contains("||")) {
					String[] data = val2.split("\\|\\|");
					rewardItem = new ItemStack[data.length];
					for(int k = 0; k < data.length; k++)
						rewardItem[k] = MobDrop.getDrop(data[k]);
				} else {
					rewardItem = new ItemStack[]{MobDrop.getDrop(val2)};
				}
				break;
			case "rewardgold":
				count = Integer.parseInt(val1);
				break;
			case "rewardexp":
				count = Integer.parseInt(val1);
				break;
		}
	}
	
	public boolean checkComplete(Player p, VillagerData v) {
		plugin.getPD(p).lastStage = this;
		plugin.getPD(p).lastVillager = v;
		int id = 0;
		if(v != null)
			id = v.questNpcID;
		switch(type.toLowerCase()) {
			case "talk":
				if(id == npcID) {
					if(plugin.getPD(p).alreadyTalked.contains(this))
						return true;
					v.sendMessage(p, phrase);
					advanceStage(p, v);
					plugin.getPD(p).alreadyTalked.add(this);
					return true;
				}
				break;
			case "collect":
				if(id == npcID) {
					if(collectItem.checkInventory(p, count)) {
						advanceStage(p, v);
					} else {
						v.sendMessage(p, "Are you here to give me something? It doesn't look like you have everything with you!");
					}
					return true;
				}
				break;
			case "kill":
				if(id == npcID) {
					if(mobToHunt != null) {
						if(plugin.getPD(p).mobKillTracker.get(mobToHunt) != null) {
							if(plugin.getPD(p).mobKillTracker.get(mobToHunt).get(quest) != null) {
								if(plugin.getPD(p).mobKillTracker.get(mobToHunt).get(quest) >= count) {
									plugin.getPD(p).mobKillTracker.get(mobToHunt).remove(quest);
									advanceStage(p, v);
								} else {
									v.sendMessage(p, "You've killed " + plugin.getPD(p).mobKillTracker.get(mobToHunt).get(quest) + "/" + count + " " + Values.capitalize(mobToHunt).replaceAll("-", " ") + ".");
								}
							} else {
								plugin.getPD(p).mobKillTracker.get(mobToHunt).put(quest, 0);
								v.sendMessage(p, "You've killed " + plugin.getPD(p).mobKillTracker.get(mobToHunt).get(quest) + "/" + count + " " + Values.capitalize(mobToHunt).replaceAll("-", " ") + ".");
							}
						} else {
							plugin.getPD(p).mobKillTracker.put(mobToHunt, new HashMap<Quest, Integer>());
							plugin.getPD(p).mobKillTracker.get(mobToHunt).put(quest, 0);
							v.sendMessage(p, "You've killed " + plugin.getPD(p).mobKillTracker.get(mobToHunt).get(quest) + "/" + count + " " + Values.capitalize(mobToHunt).replaceAll("-", " ") + ".");
						}
					}
					return true;
				}
				break;
			case "rewarditem":
				if(giveReward(p, v)) {
					advanceStage(p, v);
				}
				return true;
			case "rewardgold":
				plugin.getPD(p).wallet += count;
				advanceStage(p, v);
				return true;
			case "rewardexp":
				plugin.getPD(p).addExp(count);
				advanceStage(p, v);
				return true;
		}
		return false;
	}
	
	public boolean giveReward(Player p, VillagerData v) {
		ArrayList<ItemStack> list = new ArrayList<ItemStack>();
		int amount = count;
		while(amount > 0) {
			ItemStack i = rewardItem[(int)(Math.random() * rewardItem.length)].clone();
			i.setAmount(amount > i.getMaxStackSize() ? i.getMaxStackSize() : amount);
			amount -= i.getAmount();
			list.add(i);
		}
		int empty = 0;
		for(int k = 0; k < p.getInventory().getContents().length; k++)
			if(p.getInventory().getContents()[k] == null || p.getInventory().getContents()[k].getType() == Material.AIR)
				empty++;
		if(empty < list.size()) {
			v.sendMessage(p, "Empty up " + list.size() + " inventory slots, I want to give you a reward for your help.");
			return false;
		}
		p.getInventory().addItem(list.toArray(new ItemStack[list.size()]));
		return true;
	}

	public void advanceStage(final Player p, final VillagerData v) {
		final PlayerData pd = plugin.getPD(p);
		try {
			pd.inProgressQuests.put(quest, pd.inProgressQuests.get(quest) + 1);
		} catch(Exception e) {
			pd.inProgressQuests.put(quest, 1);
		}
		int newStage = pd.inProgressQuests.get(quest);
		if(newStage >= quest.stages.size()) {
			p.sendMessage(ChatColor.GOLD + "Congratulations! You have completed " + quest.name + "!");
			pd.inProgressQuests.remove(quest);
			pd.completedQuests.add(quest);
			pd.addGuildPoints(quest.stages.size() * 3);
		} else {
			final Stage s = quest.stages.get(newStage);
			if(s.type.startsWith("kill")) {
				if(pd.mobKillTracker.get(s.mobToHunt) == null)
					pd.mobKillTracker.put(s.mobToHunt, new HashMap<Quest, Integer>());
				pd.mobKillTracker.get(s.mobToHunt).put(quest, 0);
			}
			if(s.type.startsWith("collect")) {
				s.checkComplete(p, v);
			}
			if(s.type.startsWith("reward") || (!this.type.startsWith("talk") && s.type.equalsIgnoreCase("talk"))) {
				s.checkComplete(p, v);
			}
			if(this.type.startsWith("talk") && s.type.equals("talk")) {
				Runnable r = new Runnable() {
					public void run() {
						try {
							if(plugin.getPD(p).alreadyTalked.contains(s)) {
								return;
							}
							s.checkComplete(p, v);
						} catch(Exception e) {
							
						}
					}
				};
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, r, Values.SECONDS_BETWEEN_QUEST_NPC_CHAT * 20);
			}
		}
		pd.updateRonbook();
	}
	
}