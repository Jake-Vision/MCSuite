package xronbo.ronbomc.quests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import xronbo.ronbomc.RonboMC;

public class QuestHandler {
	
	public static RonboMC plugin;
	public static HashMap<Integer, Quest> quests = new HashMap<Integer, Quest>();
	
	public static void load() {
		try {
			BufferedReader scan = new BufferedReader(new FileReader(new File(plugin.getDataFolder()+ File.separator + "quests.dat")));
			String s = "";
			s = scan.readLine();
			while(s != null) {
				int id = Integer.parseInt(s.substring("ID: ".length()));
				Quest q = null;
				if(quests.containsKey(id)) {
					q = quests.get(id);
				}
				s = scan.readLine();
				String name = s.substring("Name: ".length());
				s = scan.readLine();
				String description = s.substring("Description: ".length());
				s = scan.readLine();
				int reqQuest = Integer.parseInt(s.substring("Prerequisite Quest: ".length()));
				s = scan.readLine();
				int reqLevel = Integer.parseInt(s.substring("Prerequisite Level: ".length()));
				s = scan.readLine();
				if(q == null) {
					q = new Quest(id, name, description, reqQuest, reqLevel);
					QuestHandler.quests.put(id, q);
				} else {
					q.name = name;
					q.description = description;
					q.reqQuest = reqQuest;
					q.reqLevel = reqLevel;
					q.stages.clear();
					q.stagecount = 0;
					q.objectives.clear();
				}
				while((s = scan.readLine()) != null) {
					if(!s.equals("") && !s.startsWith("ID: ")) {
						q.addObjective(s);
					}
					if(s.startsWith("ID: ")) {
						break;
					}
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Loaded " + quests.size() + " quests.");
	}
	
	private QuestHandler() {
		
	}
	
}