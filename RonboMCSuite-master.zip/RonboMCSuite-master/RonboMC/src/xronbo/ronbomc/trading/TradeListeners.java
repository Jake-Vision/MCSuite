package xronbo.ronbomc.trading;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;

public class TradeListeners implements Listener {
	
	public RonboMC plugin;
	
	public TradeListeners(RonboMC plugin) {
		this.plugin = plugin;
	}

	@EventHandler
	public void onPickupItem(PlayerPickupItemEvent event) {
		if(plugin.getPD(event.getPlayer()).intrade)
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onTradeClick(InventoryClickEvent event) {
		for(TradeInventory ti : TradeHandler.trades.values()) {
			if(ti.inventory.getName().equalsIgnoreCase(event.getInventory().getName())) {
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				event.setCancelled(true);
				if(event.getCurrentItem() != null) {
					Player p = (Player)(event.getWhoClicked());
					if(event.getRawSlot() < 45) {
						if(ti.getOfferedItems(p).contains(event.getCurrentItem())) {
							ti.removeItem(p, event.getCurrentItem());
						} else {
							ItemStack i = event.getCurrentItem();
							if(i.getType() == Material.STAINED_GLASS_PANE) {
								ItemMeta im = i.getItemMeta();
								if(im.hasDisplayName()) {
									if(im.getDisplayName().contains(p.getName()) && im.getDisplayName().contains(ChatColor.RED + "")) {
										if(p == ti.p1) {
											ti.p1Accepted = true;
										} else if(p == ti.p2) {
											ti.p2Accepted = true;
										}
									} else if(im.getDisplayName().contains(p.getName()) && im.getDisplayName().contains(ChatColor.GREEN + "")) {
										if(p == ti.p1) {
											ti.p1Accepted = false;
										} else if(p == ti.p2) {
											ti.p2Accepted = false;
										}
									}
								}
							}
						}
					} else {
						ti.updateTrade(p, event.getCurrentItem());
					}
					ti.reopenInventory();
				}
				break;
			}
		}
	}
	
	@EventHandler
	public void checkTradeClose(InventoryCloseEvent event) {
		for(TradeInventory ti : TradeHandler.trades.values()) {
			if(ti.inventory.getName().equalsIgnoreCase(event.getInventory().getName())) {
				if(!ti.reopen) {
					ti.cancelTrade();
					Player p = (Player)event.getPlayer();
					if(p == ti.p1)
						ti.p2.closeInventory();
					else if(p == ti.p2)
						ti.p1.closeInventory();
				}
				break;
			}
		}
	}
	
}