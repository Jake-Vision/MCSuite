package xronbo.ronbomc.trading;

import java.util.HashMap;

import org.bukkit.entity.Player;

import xronbo.ronbomc.RonboMC;

public class TradeHandler {
	
	public static int tradeID = 0;
	
	public static HashMap<Integer, TradeInventory> trades = new HashMap<Integer, TradeInventory>();
	public static RonboMC plugin;
	
	public static void newTrade(Player p1, Player p2) {
		TradeInventory ti = new TradeInventory(tradeID, p1, p2);
		ti.openTrade();
		trades.put(ti.id, ti);
		tradeID++;
	}
	
	private TradeHandler() {
		
	}
}