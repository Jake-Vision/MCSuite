package xronbo.ronbomc.trading;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.items.ItemHandler;

public class TradeInventory {
	
	public int id;
	public Player p1, p2;
	public boolean p1Accepted, p2Accepted;
	public ArrayList<ItemStack> p1OfferedItems, p2OfferedItems;
	public Inventory inventory;
	public boolean reopen;
	
	public TradeInventory(int id, Player p1, Player p2) {
		this.id = id;
		this.p1 = p1;
		this.p2 = p2;
		this.p1OfferedItems = new ArrayList<ItemStack>();
		this.p2OfferedItems = new ArrayList<ItemStack>();
	}
	
	public String getTitle() {
		StringBuilder sb = new StringBuilder("");
		sb.append(p1.getName());
		for(int k = 0; k < (32 - p1.getName().length() - p2.getName().length()); k++)
			sb.append(" ");
		sb.append(p2.getName());
		return sb.toString();
	}
	
	public ArrayList<ItemStack> getOfferedItems(Player p) {
		if(p == p1)
			return p1OfferedItems;
		else if(p == p2)
			return p2OfferedItems;
		else
			return null;
	}
	
	public void removeItem(Player p, ItemStack i) {
		int count = 0;
		for(ItemStack item : p.getInventory().getContents()) 
			if(item != null && item.getType() != Material.AIR)
				count++;
		if(count < p.getInventory().getSize()) { //prevents a possible loss of items
			getOfferedItems(p).remove(i);
			if(inventory.removeItem(i) != null) //prevents a possible dupe
				p.getInventory().addItem(i);
		} else {
			p.sendMessage(ChatColor.RED + "Your inventory has become full while you were trading!");
		}
		p1Accepted = false;
		p2Accepted = false;
	}
	
	public static final int[] TRADER1_SLOTS = {1,2,3,  9,10,11,12, 18,19,20,21, 27,28,29,30, 36,37,38,39};
	public static final int[] TRADER2_SLOTS = {5,6,7, 14,15,16,17, 23,24,25,26, 32,33,34,35, 41,42,43,44};
	
	public void updateTrade(Player p, ItemStack i) {
		try {
			if(i.getItemMeta().getDisplayName().equals(ChatColor.RESET + "" + ChatColor.AQUA + "The Ronbook")) {
				p.sendMessage(ChatColor.RED + "You can't trade the Ronbook!");
				return;
			}
			if(!ItemHandler.isTradeable(i)) {
				p.sendMessage(ChatColor.RED + "That item is untradeable!");
				return;
			}
		} catch(Exception e) {
			
		}
		boolean putInTrade = false;
		for(int slot : p == p1 ? TRADER1_SLOTS : TRADER2_SLOTS) {
			if(inventory.getItem(slot) == null || inventory.getItem(slot).getType() == Material.AIR) {
				inventory.setItem(slot, i);
				putInTrade = true;
				break;
			}
		}
		if(putInTrade) {
			p.getInventory().removeItem(i);
			getOfferedItems(p).add(i);
		} else {
			p.sendMessage(ChatColor.RED + "You can only trade 19 items at a time.");
		}
		p1Accepted = false;
		p2Accepted = false;
	}
	
	public void reopenInventory() {
		if(p1Accepted && p2Accepted) {
			int p1empty = 0;
			for(int k = 0; k < p1.getInventory().getContents().length; k++)
				if(p1.getInventory().getContents()[k] == null || p1.getInventory().getContents()[k].getType() == Material.AIR)
					p1empty++;
			int p2empty = 0;
			for(int k = 0; k < p2.getInventory().getContents().length; k++)
				if(p2.getInventory().getContents()[k] == null || p2.getInventory().getContents()[k].getType() == Material.AIR)
					p2empty++;
			if(p1empty < p2OfferedItems.size()) {
				p1.sendMessage(ChatColor.RED + "You need to have " + p2OfferedItems.size() + " open inventory slots to accept that trade!");
				p2.sendMessage(ChatColor.RED + p1.getName() + " doesn't have enough open slots to accept the trade!");
				for(ItemStack i : p1OfferedItems)
					p1.getInventory().addItem(i);
				for(ItemStack i : p2OfferedItems)
					p2.getInventory().addItem(i);
			} else if(p2empty < p1OfferedItems.size()) {
				p2.sendMessage(ChatColor.RED + "You need to have " + p1OfferedItems.size() + " open inventory slots to accept that trade!");
				p1.sendMessage(ChatColor.RED + p2.getName() + " doesn't have enough open slots to accept the trade!");
				for(ItemStack i : p1OfferedItems)
					p1.getInventory().addItem(i);
				for(ItemStack i : p2OfferedItems)
					p2.getInventory().addItem(i);
			} else {
				for(ItemStack i : p1OfferedItems)
					p2.getInventory().addItem(i);
				for(ItemStack i : p2OfferedItems)
					p1.getInventory().addItem(i);
				SoundHandler.playSound(p1, Sound.LEVEL_UP);
				SoundHandler.playSound(p2, Sound.LEVEL_UP);
				p1.sendMessage("Your trade with " + p2.getName() + " was successful!");
				p2.sendMessage("Your trade with " + p1.getName() + " was successful!");
			}
			p1OfferedItems = new ArrayList<ItemStack>();
			p2OfferedItems = new ArrayList<ItemStack>();
			reopen = true; //reopen doesn't actually reopen, it just prevents the cancelTrade() in the InvenotryCloseListener
			p1.closeInventory();
			p2.closeInventory();
			TradeHandler.plugin.getPD(p1).intrade = false;
			TradeHandler.plugin.getPD(p2).intrade = false;
			TradeHandler.plugin.getPD(p1).toTrade = "";
			TradeHandler.plugin.getPD(p2).toTrade = "";
			inventory = null;
			TradeHandler.trades.remove(this.id);
		} else {
			reopen = true;
			p1.closeInventory();
			p2.closeInventory();
			inventory.setItem(0, getAcceptButton(p1));
			inventory.setItem(8, getAcceptButton(p2));
			p1.openInventory(inventory);
			p2.openInventory(inventory);
			reopen = false;
		}
	}
	
	public void cancelTrade() {
		reopen = false;
		for(ItemStack i : p1OfferedItems)
			p1.getInventory().addItem(i);
		for(ItemStack i : p2OfferedItems)
			p2.getInventory().addItem(i);
		p1OfferedItems = new ArrayList<ItemStack>();
		p2OfferedItems = new ArrayList<ItemStack>();
		p1.sendMessage("Your trade with " + p2.getName() + " was cancelled.");
		p2.sendMessage("Your trade with " + p1.getName() + " was cancelled.");
		TradeHandler.plugin.getPD(p1).toTrade = "";
		TradeHandler.plugin.getPD(p2).toTrade = "";
		inventory = null;
		TradeHandler.trades.remove(this.id);
		p1.updateInventory();
		p2.updateInventory();
		TradeHandler.plugin.getPD(p1).intrade = false;
		TradeHandler.plugin.getPD(p2).intrade = false;
	}
	
	public void openTrade() {
		Inventory i = Bukkit.createInventory(null, 9 * 5, getTitle());
		updateTradeInventory(i);
		p1.openInventory(inventory);
		p2.openInventory(inventory);
		TradeHandler.plugin.getPD(p1).intrade = true;
		TradeHandler.plugin.getPD(p2).intrade = true;
	}
	
	public void updateTradeInventory(Inventory i) {
		for(int k = 4; k < i.getSize(); k += 9) {
			i.setItem(k, getDivider());
		}
		i.setItem(0, getAcceptButton(p1));
		i.setItem(8, getAcceptButton(p2));
		inventory = i;
	}
	
	public ItemStack getAcceptButton(Player p) {
		ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, (p == p1 ? p1Accepted ? DyeColor.LIME.getData() : DyeColor.RED.getData() :  p2Accepted ? DyeColor.LIME.getData() : DyeColor.RED.getData()));
		ItemMeta im = i.getItemMeta();
		if(p == p1 ? p1Accepted : p2Accepted) {
			im.setDisplayName(ChatColor.GREEN + p.getName() + " has accepted the trade.");
			im.setLore(Arrays.asList(new String[] {ChatColor.GOLD + p.getName() + ", click here to un-accept the current trade."}));
		} else {
			im.setDisplayName(ChatColor.RED + p.getName() + " has not accepted the trade yet.");
			im.setLore(Arrays.asList(new String[] {ChatColor.GOLD + p.getName() + ", click here to accept the current trade."}));
		}
		i.setItemMeta(im);
		return i;
	}
	
	public ItemStack getDivider() {
		ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLACK.getData());
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + p1.getName() + "\'s items are on the left.");
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + p2.getName() + "\'s items are on the right."}));
		i.setItemMeta(im);
		return i;
	}
}