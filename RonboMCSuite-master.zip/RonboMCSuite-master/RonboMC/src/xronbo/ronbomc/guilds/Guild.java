package xronbo.ronbomc.guilds;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.json.FancyMessage;

public class Guild implements Comparable<Guild> {
	
	public int id = -1;
	public String leader;
	public String leaderUUID;
	public String guildName;
	public String abbreviation;
	public String rank1,rank2,rank3,rank4,rank5;
	public String motd;
	public int size;
	public volatile ArrayList<String> applicants = new ArrayList<String>();
	public volatile HashMap<String, Member> members = new HashMap<String, Member>(); //maps uuid to member
	
	public void sendGuildMessage(String message, String sender) {
		FancyMessage fm = new FancyMessage("");
		if(sender == null || plugin.getPD(sender) == null) {
			fm.then(ChatColor.GREEN + "[" + ChatColor.WHITE + abbreviation + ChatColor.GREEN + "] Guild Message: ");
			fm.then(message);
			receivedGuildMessage(fm);
		} else {
			PlayerData pd = plugin.getPD(sender);
			fm.then(ChatColor.GREEN + "[" + ChatColor.WHITE + abbreviation + ChatColor.GREEN + "] /gc: ");
			fm.then("[" + ChannelManager.thisChannel.abbreviation + "] ")
				.color(ChatColor.GRAY)
				.tooltip(ChatColor.WHITE + "This player is on " + ChannelManager.thisChannel.name + ". Use " + ChatColor.YELLOW + "/cc" + ChatColor.WHITE + " to join them!");
			fm.then("[" + pd.level + "] ")
	        .color(ChatColor.GRAY)
	        .tooltip(ChatColor.YELLOW + pd.classType + ChatColor.AQUA + " | " + ChatColor.YELLOW + "Spirit Points: " + (pd.spiritPoints > 0 ? ChatColor.GREEN + "" + pd.spiritPoints : ChatColor.RED + "" + pd.spiritPoints));
			fm.then(ChatColor.WHITE + pd.player.getName() + ": ");
			fm.then(message);
			ChannelManager.broadcastGuild(fm.toJSONString(), id);
		}
	}
	
	public void saveRank(int i, String s) {
		plugin.executePrepared("update guilds set rank" + i + " = ? where id = ?", s, id + "");
	}
	
	public void receivedGuildMessage(FancyMessage fm) {
		for(Player p : getOnlinePlayers())
			fm.send(p);
	}
	
	public void broadcastSound(Sound s) {
		for(Player p : getOnlinePlayers())
			SoundHandler.playSound(p, s);
	}
	
	public List<Player> getOnlinePlayers() {
		List<Player> eda = new ArrayList<Player>();
		if(members.size() < plugin.players.size()) {
			for(Member m : members.values()) {
				if(plugin.getPD(m.name) != null)
					eda.add(plugin.getPD(m.name).player);
			}
		} else {
			for(PlayerData pd : plugin.players.values()) {
				if(members.containsKey(pd.uuid))
					eda.add(pd.player);
			}
		}
		return eda;
	}
	
	public boolean addApplicant(final Player p) {
		if(members.size() >= size || applicants.contains(plugin.getPD(p).uuid))
			return false;
		plugin.execute("update guilds set applicants = concat(applicants, '@" + plugin.getPD(p).uuid + "') where id = " + id);
		applicants.add(plugin.getPD(p).uuid);
		return true;
	}
	
	public void removeApplicant(final String name) {
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select uuid from rpg where name = '" + name + "'");
				try {
					if(rs.next()) {
						String uuid = rs.getString("uuid");
						plugin.execute("update guilds set applicants = replace(applicants, '@" + uuid + "', '') where id = " + id);
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void acceptApplicant(final Player p, final String name) {
		p.sendMessage(ChatColor.GREEN + "Checking to see if " + name + " is currently waiting to join your guild...");
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select uuid from rpg where name = '" + name + "'");
				String uuid2 = null;
				try {
					if(rs.next())
						uuid2 = rs.getString("uuid");
				} catch(Exception e) {
					e.printStackTrace();
				}
				final String uuid = uuid2;
				if(updateApplicants().contains(uuid2)) {
					rs = plugin.executeQuery("select guildId from rpg where name = '" + name + "'");
					try {
						if(rs.next()) {
							if(rs.getInt("guildId") > 0 && rs.getInt("guildId") != id) {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										removeApplicant(name);
										p.sendMessage(ChatColor.RED +name + " has already joined another guild!");
									}
								});
							} else {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										removeApplicant(name);
										addMember(plugin.getServer().getPlayerExact(name), uuid);
										sendGuildMessage(name + " has joined the guild!", null);
									}
								});
							}
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
				} else {
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							p.sendMessage(ChatColor.RED + name + " is not an applicant to your guild!");
							p.sendMessage(ChatColor.RED + "They must first use " + ChatColor.YELLOW + "/g apply " + abbreviation + ChatColor.RED + " for you to accept them.");
						}
					});
				}
			}
		});
	}
	
	public void rejectApplicant(final Player p, final String name) {
		p.sendMessage(ChatColor.GREEN + name + "'s application to join the guild was rejected.");
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select uuid from rpg where name = '" + name + "'");
				String uuid = null;
				try {
					if(rs.next())
						uuid = rs.getString("uuid");
				} catch(Exception e) {
					e.printStackTrace();
				}
				plugin.execute("update guilds set applicants = replace(applicants, '@" + uuid + "', '') where id = " + id);
				applicants.remove(uuid);
			}
		});
	}
	
	public void promote(final String toPromote, final Player promoter, final int promoterRank) {
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select guildId, guildRank from rpg where name='" + toPromote + "'");
				try {
					if(rs.next()) {
						final int guildId = rs.getInt("guildId");
						final int guildRank = rs.getInt("guildRank");
						if(guildId == id) {
							if(guildRank < GuildHandler.GUILD_MEMBER3 && promoterRank >= GuildHandler.GUILD_JRMASTER || guildRank == GuildHandler.GUILD_MEMBER3 && promoterRank == GuildHandler.GUILD_MASTER) {
								plugin.execute("update rpg set guildRank = guildRank + 1 where name = '" + toPromote + "'");
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										sendGuildMessage(ChatColor.GREEN + toPromote + " has been promoted to " + getRankDisplay(guildRank + 1) + ChatColor.GREEN + " by " + promoter.getName() + "!",null);
										for(Member m : members.values()) {
											if(m.name.equals(toPromote)) {
												m.rank++;
												break;
											}
										}
									}
								});
							} else if(guildRank >= GuildHandler.GUILD_JRMASTER) {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										promoter.sendMessage(ChatColor.RED + "You can't promote " + toPromote + " any higher than " + getRankDisplay(guildRank) + ChatColor.RED + "!");
									}
								});
							} else {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										promoter.sendMessage(ChatColor.RED + "You can't promote someone to the same rank as you!");
									}
								});
							}
						} else {
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									promoter.sendMessage(ChatColor.RED + "That player is not in your guild!");
								}
							});
						}
					} else {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								promoter.sendMessage(ChatColor.RED + toPromote + " is not in your guild - you can't promote them!");
							}
						});
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void demote(final String toDemote, final Player demoter, final int demoterRank) {
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select guildId, guildRank from rpg where name='" + toDemote + "'");
				try {
					if(rs.next()) {
						final int guildId = rs.getInt("guildId");
						final int guildRank = rs.getInt("guildRank");
						if(guildId == id) {
							if(guildRank > GuildHandler.GUILD_MEMBER1 && guildRank < GuildHandler.GUILD_JRMASTER && demoterRank >= GuildHandler.GUILD_JRMASTER || guildRank == GuildHandler.GUILD_JRMASTER && demoterRank == GuildHandler.GUILD_MASTER) {
								plugin.execute("update rpg set guildRank = guildRank - 1 where name = '" + toDemote + "'");
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										sendGuildMessage(ChatColor.GREEN + toDemote + " has been demoted to " + getRankDisplay(guildRank + 1) + ChatColor.GREEN + " by " + demoter.getName() + " !",null);
										for(Member m : members.values()) {
											if(m.name.equals(toDemote)) {
												m.rank--;
												break;
											}
										}
									}
								});
							} else if(guildRank == GuildHandler.GUILD_MEMBER1) {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										demoter.sendMessage(ChatColor.RED + "You can't demote " + toDemote + " any lower than " + getRankDisplay(guildRank) + ChatColor.RED + "!");
									}
								});
							}
						} else {
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									demoter.sendMessage(ChatColor.RED + "That player is not in your guild!");
								}
							});
						}
					} else {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								demoter.sendMessage(ChatColor.RED + toDemote + " is not in your guild - you can't demote them!");
							}
						});
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void expel(final String toKick, final Player kicker, final int kickerRank) {
		final String kickerName = kicker.getName();
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				ResultSet rs = plugin.executeQuery("select guildId, guildRank from rpg where name='" + toKick + "'");
				try {
					if(rs.next()) {
						final int guildId = rs.getInt("guildId");
						final int guildRank = rs.getInt("guildRank");
						if(guildId == id) {
							if(guildRank < GuildHandler.GUILD_JRMASTER && kickerRank >= GuildHandler.GUILD_JRMASTER || guildRank == GuildHandler.GUILD_JRMASTER && kickerRank == GuildHandler.GUILD_MASTER) {
								removeMember(toKick, kickerName);
							} else if(guildRank == GuildHandler.GUILD_MEMBER1) {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										kicker.sendMessage(ChatColor.RED + "You can only expel players lower ranked than you!");
									}
								});
							}
						} else {
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									kicker.sendMessage(ChatColor.RED + "That player is not in your guild!");
								}
							});
						}
					} else {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								kicker.sendMessage(ChatColor.RED + toKick + " is not in your guild, so you can't expel them from it!");
							}
						});
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void setMotd(final String message, final Player setter) {
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				plugin.executePrepared("update guilds set motd = ? where id = ?", true, message, id + "");
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						setter.sendMessage(ChatColor.GREEN + "Guild MOTD set to: " + message);
						motd = message;
					}
				});
			}
		});
	}
	
	public boolean addMember(Player p, String uuid) {
		if(members.size() >= size)
			return false;
		plugin.execute("update guilds set members = concat(members, '@" + uuid + "') where id = " + id);
		plugin.execute("update rpg set guildId = " + id + ", guildRank = 1 where uuid = '" + uuid + "'");
		if(p != null) {
			plugin.getPD(p).guildId = id;
			p.sendMessage(ChatColor.GREEN + "You have been accepted to the guild " + guildName + "!");
		}
		return true;
	}
	
	public String getBracketColor(Player p) {
		Member m = getMember(p);
		if(m == null)
			return ChatColor.GREEN + "";
		if(m.rank == GuildHandler.GUILD_MASTER)
			return ChatColor.GOLD + "";
		if(m.rank == GuildHandler.GUILD_JRMASTER)
			return ChatColor.LIGHT_PURPLE + "";
		return ChatColor.GREEN + "";
	}
	
	public void removeMember(final String name, final String kicker) {
		if(kicker == null)
			sendGuildMessage(ChatColor.RED + name + " has left the guild.", null);
		else
			sendGuildMessage(ChatColor.RED + name + " has been expelled from the guild by " + kicker + ".", null);
		if(plugin.getPD(name) != null) {
			plugin.getPD(name).guildId = 0;
			if(kicker == null)
				plugin.getPD(name).player.sendMessage(ChatColor.RED + "You have left your guild.");
			else
				plugin.getPD(name).player.sendMessage(ChatColor.RED + "You have been expelled from your guild by " + kicker + ".");
		}
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				try {
					final ResultSet rs = plugin.executeQuery("select uuid from rpg where name='" + name + "'");
					if(rs.next()) {
						String uuid = rs.getString("uuid");
						plugin.execute("update guilds set members = replace(members,'@" + uuid + "','') where id = " + id);
						plugin.execute("update rpg set guildId = 0, guildRank = 1 where uuid = '" + uuid + "'");
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Member getMember(Player p) {
		return members.get(plugin.getPD(p).uuid);
	}
	
	public int compareTo(Guild other) {
		if(other.getGuildPoints() != this.getGuildPoints())
			return other.getGuildPoints() - this.getGuildPoints();
		if(other.members.size() != this.members.size())
			return other.members.size() - this.members.size();
		return other.size - this.size;
	}
	
	public int guildPointsTotal = 0;
	public long lastUpdatedGP = 0;
	
	public int getGuildPoints() {
		if(System.currentTimeMillis() - lastUpdatedGP < 3 * 60 * 1000 && guildPointsTotal > 0) {
			return guildPointsTotal;
		} else {
			guildPointsTotal = 0;
			for(Member m : members.values())
				guildPointsTotal += m.guildPoints;
			return guildPointsTotal;
		}
	}
	
	public String getRankDisplay(int rank) {
		switch(rank) {
			case 5:
				return ChatColor.GOLD + rank1;
			case 4:
				return ChatColor.LIGHT_PURPLE + rank2;
			case 3:
				return ChatColor.GREEN + rank3;
			case 2:
				return ChatColor.GREEN + rank4;
			case 1:
				return ChatColor.GREEN + rank5;
		}
		return ChatColor.GREEN + rank5;
	}
	
	public void showPendingApplicants(final Player p) {
		p.sendMessage(ChatColor.GREEN + "Updating applicants list...");
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				List<String> applicants = updateApplicants();
				StringBuilder sb = new StringBuilder("");
				for(String s : applicants)
					sb.append("'" + s + "' ");
				String set = sb.toString().trim().replace(' ', ',');
				ResultSet rs = plugin.executeQuery("select name,level,classType from rpg where uuid in (" + set + ")");
				final List<Applicant> eda = new ArrayList<Applicant>();
				try {
					while(rs.next()) {
						String name = rs.getString("name");
						int level = rs.getInt("level");
						String classType = rs.getString("classType");
						if(classType.length() == 0)
							classType = "None";
						eda.add(new Applicant(name,level,classType));
					}
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							Collections.sort(eda);
							boolean aqua = true;
							p.sendMessage("");
							p.sendMessage(ChatColor.GOLD + "Applicants to Guild");
							for(Applicant a : eda) {
								p.sendMessage(((aqua = !aqua) ? ChatColor.AQUA : ChatColor.GREEN) + a.name + " - Lv. " + a.level + " - Class: " + a.classType);
							}
							p.sendMessage(ChatColor.YELLOW + "To accept any of these applicants, use /g accept <name>");
						}
					});
				} catch(Exception e) {
					
				}
			}
		});
	}
	
	public void upgradeSize(String upgrader) {
		plugin.execute("update guilds set size = size + 5 where id = " + id);
		sendGuildMessage(ChatColor.GOLD + upgrader + " just paid for a Guild Expansion! The guild max size is now " + size + ".", null);
	}
	
	public int getExpansionCost() {
		if(size < 10)
			return 250000;
		if(size < 20)
			return 350000;
		if(size < 30)
			return 400000;
		if(size < 40)
			return 500000;
		if(size < 50)
			return 600000;
		if(size < 60)
			return 700000;
		if(size < 70)
			return 800000;
		if(size < 80)
			return 1000000;
		if(size < 90)
			return 2000000;
		return 10000000;
	}
	
	public static class Applicant implements Comparable<Applicant> {
		public String name,classType;
		public int level;
		public Applicant(String name, int level, String classType) {
			this.name = name;
			this.classType = classType;
			this.level = level;
		}
		public int compareTo(Applicant other) {
			return other.level - this.level;
		}
	}
	
	public List<String> updateApplicants() { //must always be called ASYNC
		final ResultSet rs = plugin.executeQuery("SELECT applicants from rpg_guilds WHERE id = " + id + "");
		try {
			if(rs.next()) {
				String eda = rs.getString("applicants");
				ArrayList<String> eda2 = new ArrayList<String>();
				eda2.addAll(Arrays.asList(eda.split("@")));
				return eda2;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateMembers() { //must always be called ASYNC
		final ResultSet rs = plugin.executeQuery("SELECT members from rpg_guilds where id=" + id + "");
		try {
			if(rs.next()) {
				String membersString = rs.getString("members");
				StringBuilder sb = new StringBuilder("");
				for(String s : membersString.split("@")) {
					sb.append("'" + s + "' ");
				}
				String set = sb.toString().trim().replace(' ', ',');
				final ResultSet rs2 = plugin.executeQuery("select name,uuid,level,guildRank,guildPoints from rpg where uuid in (" + set + ")");
				final HashMap<String, Member> membersMap = new HashMap<String, Member>();
				while(rs2.next()) {
					String name = rs2.getString("name");
					String uuid = rs2.getString("uuid");
					int level = rs2.getInt("level");
					int guildRank = rs2.getInt("guildRank");
					if(guildRank == 0)
						guildRank = 1;
					int guildPoints = rs2.getInt("guildPoints");
					Member m = new Member(name,uuid,guildRank,level,guildPoints);
					membersMap.put(uuid, m);
				}
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						members.clear();
						members.putAll(membersMap);
						getGuildPoints();
					}
				});
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void saveNewGuild() {
		System.out.println("Creating new guild \"" + guildName + "\" owned by " + leader);
		final Guild eda = this;
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				plugin.executePrepared("insert into guilds (id, name, leader, leaderName, members, abbreviation, rank1, rank2, rank3, rank4, rank5, motd, size, applicants) "
						+ "values (NULL, "
						+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", true, guildName, leaderUUID, leader, "@" + leaderUUID, abbreviation, "Master", "Jr. Master", "Member", "Member", "Member", "Welcome to " + guildName + "!", 10 + "", "");
				ResultSet rs = plugin.executeQuery("select id from rpg_guilds where name = '" + guildName + "'");
				try {
					if(rs.next()) {
						final int myId = rs.getInt("id");
						plugin.execute("update rpg set guildId = " + myId + " where uuid = '" + leaderUUID + "'");
						eda.id = myId;
					}
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							if(plugin.getPD(leader) != null) {
								PlayerData pd = plugin.getPD(leader);
								pd.guildId = eda.id;
								pd.player.sendMessage(ChatColor.GREEN + "Your new guild has been registered! /g to view the Guild Menu.");
								GuildHandler.showMenu(null);
							}
						}
					});
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public String serializeMembers() {
		StringBuilder sb = new StringBuilder("");
		for(Member m : members.values())
			sb.append("@" + m.uuid);
		return sb.toString().trim();
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		for(Member m : members.values())
			sb.append(m.name + "(GP:" + m.guildPoints + "R:" + m.rank + ") ");
		return id + ": " + guildName + ", " + leader + ", " + abbreviation + ", MEMBERS: " + sb.toString().trim().replace(' ', ',');
	}

	public Guild(String guildName, String leader, String leaderUUID, String abbreviation, int leaderLevel) {
		/* New Guild Constructor*/
		this.guildName = guildName;
		this.leader = leader;
		this.leaderUUID = leaderUUID;
		this.abbreviation = abbreviation;
		this.rank1 = "Master";
		this.rank2 = "Jr. Master";
		this.rank3 = "Member";
		this.rank4 = "Member";
		this.rank5 = "Member";
		this.motd = "Welcome to " + guildName + "!";
		this.size = 10;
		Member m = new Member(leader, leaderUUID, GuildHandler.GUILD_MASTER, leaderLevel, 0);
		members.put(leaderUUID, m);
		m.updateAllStats();
	}
	
	public Guild(int id, String guildName, String leader, String leaderUUID, String abbreviation, String rank1, String rank2, String rank3, String rank4, String rank5, String motd, int size) {
		/* Existing Guild Constructor */
		this.guildName = guildName;
		this.leader = leader;
		this.leaderUUID = leaderUUID;
		this.abbreviation = abbreviation;
		this.rank1 = rank1;
		this.rank2 = rank2;
		this.rank3 = rank3;
		this.rank4 = rank4;
		this.rank5 = rank5;
		this.id = id;
		this.motd = motd;
		this.size = size;
	}
	
	public static RonboMC plugin;
	
}