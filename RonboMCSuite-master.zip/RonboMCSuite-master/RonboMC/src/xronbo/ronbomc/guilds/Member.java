package xronbo.ronbomc.guilds;

import xronbo.ronbomc.debug.SuperDebugger;

public class Member implements Comparable<Member> {
	public String uuid;
	public String name;
	public int rank;
	public int level;
	public int guildPoints;
	
	public Member(String name, String uuid, int rank, int level, int guildPoints) {
		this.name = name;
		this.uuid = uuid;
		this.rank = rank;
		this.level = level;
		this.guildPoints = guildPoints;
	}
	
	public String toString() {
		return "[" + level + "] " + name;
	}
	
	public void updateAllStats() {
		SuperDebugger.runTaskAsynchronously(this.getClass(), Guild.plugin, new Runnable() {
			public void run() {
				Guild.plugin.executePrepared("update rpg set guildPoints = ?, guildrank = ? where uuid = ?", guildPoints + "", rank + "", uuid);
			}
		});
	}
	
	public int compareTo(Member other) { //other - this for descending
		if(other.guildPoints != this.guildPoints)
			return other.guildPoints - this.guildPoints;
		if(other.level != this.level)
			return other.level - this.level;
		return other.rank - this.rank;
	}
	
}