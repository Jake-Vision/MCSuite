package xronbo.ronbomc.guilds;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.listeners.ChatListeners;

public class GuildHandler implements Listener {
	
	public static final int GUILD_MASTER = 5;
	public static final int GUILD_JRMASTER = 4;
	public static final int GUILD_MEMBER3 = 3;
	public static final int GUILD_MEMBER2 = 2;
	public static final int GUILD_MEMBER1 = 1;

	public static volatile ConcurrentHashMap<Integer, Guild> guilds = new ConcurrentHashMap<Integer, Guild>();
	public static ConcurrentHashMap<Integer, ArrayList<String>> guildBuffs = new ConcurrentHashMap<Integer, ArrayList<String>>();
	
	public static Guild getGuild(PlayerData pd) {
		return guilds.get(pd.guildId);
	}
	
	public static Guild getGuild(Player p) {
		return guilds.get(plugin.getPD(p).guildId);
	}
	
	public static void attemptApply(Player p, String prefix) {
		for(Guild g : guilds.values()) {
			if(g.abbreviation.equalsIgnoreCase(prefix)) {
				if(g.addApplicant(p)) 
					p.sendMessage(ChatColor.GREEN + "You have applied to join " + g.guildName + " owned by " + g.leader + ".");
				else
					p.sendMessage(ChatColor.RED + g.guildName + " is currently full, or you have already applied to it."); 
			}
		}
	}
	
	public static boolean checkBuff(Player p, String buff) {
		if(plugin.getPD(p).guildId > 0) {
			try {
				return guildBuffs.get(plugin.getPD(p).guildId).contains(buff);
			} catch(Exception e) {
				return false;
			}
		}
		return false;
	}
	
	public static void showMenu(final Player p) {
		if(p != null)
			p.sendMessage(ChatColor.GREEN + "Fetching latest guild data...");
		SuperDebugger.runTaskAsynchronously(GuildHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				final ResultSet rs = plugin.executeQuery("SELECT * from rpg_guilds");
				final HashMap<Integer, Guild> temp = new HashMap<Integer, Guild>();
				try {
					while(rs.next()) {
						int id = rs.getInt("id");
						String name = rs.getString("name");
						String leaderUUID = rs.getString("leaderUUID");
						String leaderName = rs.getString("leaderName");
						String abbreviation = rs.getString("abbreviation");
						String rank1 = rs.getString("rank1");
						String rank2 = rs.getString("rank2");
						String rank3 = rs.getString("rank3");
						String rank4 = rs.getString("rank4");
						String rank5 = rs.getString("rank5");
						String motd = rs.getString("motd");
						int size = rs.getInt("size");
						Guild guild = new Guild(id,name,leaderName,leaderUUID,abbreviation,rank1,rank2,rank3,rank4,rank5,motd,size);
						guild.updateMembers();
						guild.updateApplicants();
						temp.put(id, guild);
						if(!guildBuffs.containsKey(id))
							guildBuffs.put(id, new ArrayList<String>());
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
				SuperDebugger.scheduleSyncDelayedTask(GuildHandler.class.getClass(), plugin, new Runnable() {
					public void run() {
						if(p != null)
						p.sendMessage(ChatColor.GREEN + "Guild data updated!");
						guilds.clear();
						guilds.putAll(temp);
						if(p == null)
							return;
						Inventory inventory = null;
						ItemStack item;
						ItemMeta im;
						ArrayList<String> lore;
						if(getGuild(p) == null) {
							
							if(plugin.getPD(p).justBoughtGuild) {
								p.sendMessage(ChatColor.RED + "Your new guild is still being registered. Please wait a bit longer.");
								return;
							}
							
							inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "Guild Menu");
							
							item = new ItemStack(Material.FIRE);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.RED + "Guild Guide 1/4");
							lore = new ArrayList<String>();
							lore.addAll(Values.longStringToLoreList(ChatColor.YELLOW, "There are two ways to be in a guild.", "1. Join someone's guild.", "2. Make your own guild."));
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(0, item);
							
							item = new ItemStack(Material.FIRE);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.RED + "Guild Guide 2/4");
							lore = new ArrayList<String>();
							lore.addAll(Values.longStringToLoreList(ChatColor.YELLOW, "We can't really help you with joining guilds, that's up to the guild owners to decide.", "What we can help with is making guilds!"));
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(1, item);
							
							item = new ItemStack(Material.FIRE);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.RED + "Guild Guide 3/4");
							lore = new ArrayList<String>();
							lore.addAll(Values.longStringToLoreList(ChatColor.YELLOW, "To make your guild, hover over the Diamond to the right.", "Guilds are quite expensive, but they're super awesome, so save up!"));
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(2, item);
							
							item = new ItemStack(Material.FIRE);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.RED + "Guild Guide 4/4");
							lore = new ArrayList<String>();
							lore.addAll(Values.longStringToLoreList(ChatColor.YELLOW, "Guilds are a community experience. If you join a guild, expect to make new friends!", "Guild members gain many perks from each other, and can even chat across channels whenever they want!"));
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(3, item);
							
							item = new ItemStack(Material.DIAMOND);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.GOLD + "Create a Guild (1,000,000g)");
							lore = new ArrayList<String>();
							lore.addAll(Values.longStringToLoreList(ChatColor.LIGHT_PURPLE, "You must have 1,000,000 gold in your wallet to create a new guild.", "Click this diamond to begin the process of making a guild."));
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(4, item);

							
							item = new ItemStack(Material.PAPER);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.GOLD + "Click to view Guild Commands");
							lore = new ArrayList<String>();
							lore.add(ChatColor.GREEN + "You can also use " + ChatColor.YELLOW + "/g help");
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(6, item);

							item = new ItemStack(Material.PAPER);
							im = item.getItemMeta();
							im.setDisplayName(ChatColor.GOLD + "Guild Rankings");
							lore = new ArrayList<String>();
							ArrayList<Guild> guildstemp = new ArrayList<Guild>();
							guildstemp.addAll(guilds.values());
							Collections.sort(guildstemp);
							lore.add(ChatColor.YELLOW + "Rankings are based on Guild Points.");
							lore.add("");
							lore.add(ChatColor.LIGHT_PURPLE + "Click to view the top 10 guilds in Kastia.");
							im.setLore(lore);
							item.setItemMeta(im);
							inventory.setItem(8, item);
							
						} else {
							inventory = Bukkit.createInventory(p, 9 * 2, ChatColor.BLACK + "Guild Menu");
							Guild guild = getGuild(p);
							Member member = guild.getMember(p);
							if(member == null) {
								p.sendMessage(ChatColor.RED + "Could not locate your guild member data. Please try /g again.");
							} else {
								p.sendMessage(ChatColor.GOLD + "Guild MOTD: " + guild.motd);
								item = new ItemStack(Material.BOOK);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Guild Info");
								lore = new ArrayList<String>();
								lore.add(ChatColor.AQUA + "Name: " + ChatColor.GREEN + guild.guildName);
								lore.add(ChatColor.AQUA + "Leader: " + ChatColor.GREEN + guild.leader);
								lore.add("");
								lore.add(ChatColor.AQUA + "Prefix: " + ChatColor.GREEN + "[" + ChatColor.WHITE + guild.abbreviation + ChatColor.GREEN + "]");
								lore.add(ChatColor.AQUA + "Size: " + ChatColor.GREEN + guild.members.size() + " member" + (guild.members.size() > 1 ? "s" : ""));
								lore.add(ChatColor.AQUA + "Max Size: " + ChatColor.GREEN + guild.size);
								lore.add("");
								lore.add(ChatColor.YELLOW + "" + ChatColor.BOLD + "Guild Ranks");
								lore.add(ChatColor.AQUA + "1. " + ChatColor.GOLD + (guild.rank1 == null ? "Master" : guild.rank1));
								lore.add(ChatColor.AQUA + "2. " + ChatColor.LIGHT_PURPLE + (guild.rank2 == null ? "Jr. Master" : guild.rank2));
								lore.add(ChatColor.AQUA + "3. " + ChatColor.GREEN + (guild.rank3 == null ? "Member" : guild.rank3));
								lore.add(ChatColor.AQUA + "4. " + ChatColor.GREEN + (guild.rank4 == null ? "Member" : guild.rank4));
								lore.add(ChatColor.AQUA + "5. " + ChatColor.GREEN + (guild.rank5 == null ? "Member" : guild.rank5));
								lore.add("");
								lore.add(ChatColor.GOLD + "MOTD:");
								lore.addAll(Arrays.asList(Values.stringToLore(guild.motd, ChatColor.GOLD)));
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(0, item);
								
								item = new ItemStack(Material.BOOK);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Your Info");
								lore = new ArrayList<String>();
								lore.add(ChatColor.AQUA + "Name: " + ChatColor.GOLD + p.getName());
								lore.add(ChatColor.AQUA + "Rank: " + guild.getRankDisplay(member.rank));
								lore.add("");
								lore.add(ChatColor.AQUA + "Guild Points: " + member.guildPoints);
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(1, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "Member Rankings");
								lore = new ArrayList<String>();
								ArrayList<Member> members = new ArrayList<Member>();
								members.addAll(getGuild(p).members.values());
								Collections.sort(members);
								lore.add(ChatColor.YELLOW + "Your member ranking: " + (members.indexOf(member) + 1));
								lore.add("");
								lore.add(ChatColor.YELLOW + "Rankings are based on Guild Points.");
								lore.add("");
								lore.add(ChatColor.LIGHT_PURPLE + "Click to view the top 10 in your guild.");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(2, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "Guild Rankings");
								lore = new ArrayList<String>();
								ArrayList<Guild> guildstemp = new ArrayList<Guild>();
								guildstemp.addAll(guilds.values());
								Collections.sort(guildstemp);
								lore.add(ChatColor.YELLOW + "Your guild's ranking: " + (guildstemp.indexOf(guild) + 1));
								lore.add("");
								lore.add(ChatColor.YELLOW + "Rankings are based on Guild Points.");
								lore.add("");
								lore.add(ChatColor.LIGHT_PURPLE + "Click to view the top 10 guilds in Kastia.");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(3, item);
								
								item = new ItemStack(Material.NAME_TAG);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "Rank Name Commands");
								lore = new ArrayList<String>();
								lore.add(ChatColor.YELLOW + "You can change the names of Guild Ranks!");
								lore.add("");
								lore.add(ChatColor.YELLOW + "/g rankname1 <name> " + ChatColor.GREEN + " to change " + guild.rank1);
								lore.add(ChatColor.YELLOW + "/g rankname2 <name> " + ChatColor.GREEN + " to change " + guild.rank2);
								lore.add(ChatColor.YELLOW + "/g rankname3 <name> " + ChatColor.GREEN + " to change " + guild.rank3);
								lore.add(ChatColor.YELLOW + "/g rankname4 <name> " + ChatColor.GREEN + " to change " + guild.rank4);
								lore.add(ChatColor.YELLOW + "/g rankname5 <name> " + ChatColor.GREEN + " to change " + guild.rank5);
								lore.add("");
								lore.add(ChatColor.YELLOW + "<name> can be up to 15 characters long.");
								lore.add(ChatColor.YELLOW + "Rank names should be appropriate.");
								lore.add("");
								lore.add(ChatColor.YELLOW + "These commands are available to " + guild.getRankDisplay(GuildHandler.GUILD_JRMASTER) + ChatColor.YELLOW + ".");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(4, item);
								
								item = new ItemStack(Material.BOOK_AND_QUILL);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "Guild Management Commands");
								lore = new ArrayList<String>();
								lore.add(ChatColor.YELLOW + "/g promote <name>");
								lore.add(ChatColor.GREEN + "  - Raises the guild rank of <name>");
								lore.add(ChatColor.YELLOW + "/g demote <name>");
								lore.add(ChatColor.GREEN + "  - Decreases the guild rank of <name>");
								lore.add(ChatColor.YELLOW + "/g accept <name>");
								lore.add(ChatColor.GREEN + "  - Adds <name> to your guild");
								lore.add(ChatColor.YELLOW + "/g reject <name>");
								lore.add(ChatColor.GREEN + "  - Reject <name>'s application to join");
								lore.add(ChatColor.YELLOW + "/g pending");
								lore.add(ChatColor.GREEN + "  - View all pending applications");
								lore.add(ChatColor.YELLOW + "/g expel <name>");
								lore.add(ChatColor.GREEN + "  - Remove <name> from your guild");
								lore.add(ChatColor.YELLOW + "/g motd <message>");
								lore.add(ChatColor.GREEN + "  - Set your guild MOTD");
								lore.add("");
								lore.add(ChatColor.YELLOW + "These commands are available to " + guild.getRankDisplay(GuildHandler.GUILD_JRMASTER) + ChatColor.YELLOW + ".");
								lore.add(ChatColor.YELLOW + "However, they can only use these commands on");
								lore.add(ChatColor.YELLOW + "normal guild members, and not on each other.");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(5, item);
								
								item = new ItemStack(Material.CAKE);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GREEN + "Expand Guild Capacity");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GOLD + "Price: " + guild.getExpansionCost() + "g");
								lore.add(ChatColor.YELLOW + "Increases your guild's Max Size by 5.");
								lore.add("");
								lore.add(ChatColor.YELLOW + "There will be a confirmation message");
								lore.add(ChatColor.YELLOW + "before you pay for the expansion.");
								lore.add("");
								lore.add(ChatColor.YELLOW + "Any guild member can buy an expansion!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(6, item);
								
								item = new ItemStack(Material.SUGAR);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GREEN + "Open Guild Buff Shop");
								lore = new ArrayList<String>();
								lore.addAll(Values.longStringToLoreList(ChatColor.AQUA, "Guild buffs are buffs that can be purchased with Guild Points.", "When a player buys a Guild Buff, the buff is given to all guild members on all channels.", "", "Click here to view the Guild Buff Shop."));
								lore.add("");
								lore.add(ChatColor.YELLOW + "" + ChatColor.BOLD + "Currently Active Buffs");
								boolean added = false;
								for(String s : guildBuffs.get(guild.id)) {
									added = true;
									lore.add(ChatColor.GREEN + getBuffDisplay(s));
								}
								if(!added)
									lore.add(ChatColor.RED + "None!");
								lore.add("");
								lore.add(ChatColor.YELLOW + "Buffs that are currently active will");
								lore.add(ChatColor.YELLOW + "not show up in the Guild Buff Shop.");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(7, item);
								
								item = new ItemStack(Material.CHEST);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.GOLD + "Guild Bank");
								lore = new ArrayList<String>();
								lore.add(ChatColor.RED + "Coming soon!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(8, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "All Members (Level, Asc.)");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GREEN + "Click to view all guild members.");
								lore.add(ChatColor.GREEN + "Order will be ascending by level.");
								lore.add("");
								lore.add(ChatColor.RED + "Warning: This can fill most of your chat!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(9, item);

								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "All Members (Level, Desc.)");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GREEN + "Click to view all guild members.");
								lore.add(ChatColor.GREEN + "Order will be descending by level.");
								lore.add("");
								lore.add(ChatColor.RED + "Warning: This can fill most of your chat!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(10, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "All Members (GP, Asc.)");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GREEN + "Click to view all guild members.");
								lore.add(ChatColor.GREEN + "Order will be ascending by Guild Points.");
								lore.add("");
								lore.add(ChatColor.RED + "Warning: This can fill most of your chat!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(11, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "All Members (GP, Desc.)");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GREEN + "Click to view all guild members.");
								lore.add(ChatColor.GREEN + "Order will be descending by Guild Points.");
								lore.add("");
								lore.add(ChatColor.RED + "Warning: This can fill most of your chat!");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(12, item);
								
								item = new ItemStack(Material.PAPER);
								im = item.getItemMeta();
								im.setDisplayName(ChatColor.AQUA + "Online Players");
								lore = new ArrayList<String>();
								lore.add(ChatColor.GREEN + "Click to view all guild members currently");
								lore.add(ChatColor.GREEN + "on this channel.");
								im.setLore(lore);
								item.setItemMeta(im);
								inventory.setItem(13, item);
							}
						}
						p.openInventory(inventory);
					}
				});
			}
		});
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Guild Menu")) {
				event.setCancelled(true);
				ItemStack item = event.getCurrentItem();
				Player p = (CraftPlayer)event.getWhoClicked();
				PlayerData pd = plugin.getPD(p);
				if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Create a Guild (1,000,000g)")) {
					if(pd.wallet >= 1000000) {
						pd.waitingOnGuildName = true;
						p.closeInventory();
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type the name of the guild you want to make.");
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Type 'cancel' to cancel your guild creation.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Guild names may only have letters and spaces.");
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Guild names can be up to 25 characters long.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "No obscene or vulgar guild names!");
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
					} else {
						p.sendMessage(ChatColor.RED + "You do not have 1,000,000g with you!");
					}
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Member Rankings")) {
					if(getGuild(p) != null) {
						ArrayList<Member> members = new ArrayList<Member>();
						members.addAll(getGuild(p).members.values());
						Collections.sort(members);
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Top 10 Members");
						p.sendMessage("");
						for(int k = 0; k < 10 && k < members.size(); k++) {
							p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GRAY + "[" + members.get(k).level + "] " + ChatColor.WHITE + members.get(k).name + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + members.get(k).guildPoints + ChatColor.GREEN + " - " + getGuild(p).getRankDisplay(members.get(k).rank));
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Guild Rankings")) {
					ArrayList<Guild> guildstemp = new ArrayList<Guild>();
					guildstemp.addAll(guilds.values());
					Collections.sort(guildstemp);
					p.sendMessage("");
					p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + "Top 10 Guilds of Kastia");
					p.sendMessage("");
					for(int k = 0; k < 10 && k < guildstemp.size(); k++) {
						p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GREEN + "[" + ChatColor.WHITE + guildstemp.get(k).abbreviation + ChatColor.GREEN + "] " + ChatColor.WHITE + guildstemp.get(k).guildName + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + guildstemp.get(k).getGuildPoints());
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Expand Guild Capacity")) {
					if(getGuild(p) != null) {
						int cost = getGuild(p).getExpansionCost();
						if(pd.wallet >= cost) {
							pd.waitingOnGuildExpansionConfirmation = true;
							pd.guildExpansionPrice = cost;
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "  Type 'confirm' to increase the maximum size");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "  of the guild you are currently in by 5!");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "  The price is " + ChatColor.GOLD + pd.guildExpansionPrice + "g" + ChatColor.AQUA + ".");
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
						} else {
							p.sendMessage(ChatColor.RED + "You need " + cost+  "g in your wallet to buy an expansion!");
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Open Guild Buff Shop")) {
					if(getGuild(p) != null) {
						showBuffsMenu(p);
					} else {
						p.closeInventory();
					}
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("All Members (Level, Asc.)")) {
					if(getGuild(p) != null) {
						ArrayList<Member> members = new ArrayList<Member>();
						members.addAll(getGuild(p).members.values());
						Collections.sort(members, new Comparator<Member>() {
							public int compare(Member one, Member two) {
								return one.level - two.level;
							}
						});
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Member List");
						p.sendMessage("");
						for(int k = 0; k < members.size(); k++) {
							p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GRAY + "[" + members.get(k).level + "] " + ChatColor.WHITE + members.get(k).name + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + members.get(k).guildPoints + ChatColor.GREEN + " - " + getGuild(p).getRankDisplay(members.get(k).rank));
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("All Members (Level, Desc.)")) {
					if(getGuild(p) != null) {
						ArrayList<Member> members = new ArrayList<Member>();
						members.addAll(getGuild(p).members.values());
						Collections.sort(members, new Comparator<Member>() {
							public int compare(Member one, Member two) {
								return two.level - one.level;
							}
						});
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Member List");
						p.sendMessage("");
						for(int k = 0; k < members.size(); k++) {
							p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GRAY + "[" + members.get(k).level + "] " + ChatColor.WHITE + members.get(k).name + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + members.get(k).guildPoints + ChatColor.GREEN + " - " + getGuild(p).getRankDisplay(members.get(k).rank));
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("All Members (GP, Asc.)")) {
					if(getGuild(p) != null) {
						ArrayList<Member> members = new ArrayList<Member>();
						members.addAll(getGuild(p).members.values());
						Collections.sort(members, new Comparator<Member>() {
							public int compare(Member one, Member two) {
								return one.guildPoints - two.guildPoints;
							}
						});
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Member List");
						p.sendMessage("");
						for(int k = 0; k < members.size(); k++) {
							p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GRAY + "[" + members.get(k).level + "] " + ChatColor.WHITE + members.get(k).name + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + members.get(k).guildPoints + ChatColor.GREEN + " - " + getGuild(p).getRankDisplay(members.get(k).rank));
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("All Members (GP, Desc.)")) {
					if(getGuild(p) != null) {
						
						ArrayList<Member> members = new ArrayList<Member>();
						members.addAll(getGuild(p).members.values());
						Collections.sort(members, new Comparator<Member>() {
							public int compare(Member one, Member two) {
								return two.guildPoints - one.guildPoints;
							}
						});
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Member List");
						p.sendMessage("");
						for(int k = 0; k < members.size(); k++) {
							p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GRAY + "[" + members.get(k).level + "] " + ChatColor.WHITE + members.get(k).name + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + members.get(k).guildPoints + ChatColor.GREEN + " - " + getGuild(p).getRankDisplay(members.get(k).rank));
						}
					}
					p.closeInventory();
				} else if(ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Online Players")) {
					if(getGuild(p) != null) {
						p.sendMessage("");
						p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + getGuild(p).guildName + " Players on " + ChannelManager.thisChannel.name);
						p.sendMessage("");
						StringBuilder sb = new StringBuilder("");
						for(Player p2 : getGuild(p).getOnlinePlayers()) {
							sb.append(p2.getName() + " ");
						}
						p.sendMessage(ChatColor.GREEN + sb.toString().trim().replace(" ", ", "));
					}
					p.closeInventory();
				}
			}
		} catch(Exception e) {
		
		}
	}
	
	public static String getBuffDisplay(String s2) {
		for(String[] s : buffs)
			if(s[0].equals(s2))
				return s[1];
		return "NULL";
	}
	
	public static String[][] buffs = new String[][] {
		{"exp", "+10% EXP Bonus", "30 minutes", "20"},
		{"damage", "+10% Damage Bonus", "30 minutes", "40"},
		{"drop", "+10% Drop Rate Bonus", "30 minutes", "100"},
		{"damagereduction", "+10% Damage Reduction", "10 minutes", "50"},
	};
	
	public void showBuffsMenu(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9 * 1, ChatColor.BLACK + "Guild Buff Shop");
		ItemStack item;
		ItemMeta im;
		ArrayList<String> lore;
		Guild guild = getGuild(p);
		int displayed = 0;
		for(String[] s : buffs) {
			if(!guildBuffs.get(guild.id).contains(s[0])) {
				item = new ItemStack(Material.APPLE);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GREEN + s[1]);
				lore = new ArrayList<String>();
				lore.add(ChatColor.YELLOW + "Duration: " + ChatColor.AQUA + s[2]);
				lore.add(ChatColor.YELLOW + "Price: " + ChatColor.AQUA + s[3] + " Guild Points");
				lore.add(ChatColor.YELLOW + "");
				lore.add(ChatColor.GOLD + "Click to buy this buff for your guild!");
				im.setLore(lore);
				item.setItemMeta(im);
				inventory.setItem(displayed++, item);
			}
		}
		
		if(displayed == 0) {
			item = new ItemStack(Material.APPLE);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.RED + "No buffs available!");
			lore = new ArrayList<String>();
			lore.add(ChatColor.RED + "All available guild buffs are currently active.");
			lore.add(ChatColor.RED + "");
			lore.add(ChatColor.RED + "Check back when one runs out to buy it again.");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(0, item);
		}
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void onBuffMenuClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Guild Buff Shop")) {
				event.setCancelled(true);
				ItemStack item = event.getCurrentItem();
				Player p = (CraftPlayer)event.getWhoClicked();
				PlayerData pd = plugin.getPD(p);
				String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());
				String[] info = null;
				for(String[] s : buffs) {
					if(s[1].equals(name)) {
						info = s;
						break;
					}
				}
				if(info != null) {
					Guild guild = getGuild(p);
					if(pd.getGuildPoints() > Integer.parseInt(info[3])) {
						final int guildId = pd.guildId;
						final String buffName = info[0];
						if(guildBuffs.get(guildId).contains(buffName)) {
							p.sendMessage(ChatColor.RED + "Looks like someone just bought that buff for you!");
						} else {
							p.sendMessage(ChatColor.GREEN + "Bought " + info[1] + " for " + info[3] + " Guild Points.");
							guild.sendGuildMessage(ChatColor.GREEN + p.getName() + " just bought a Guild Buff, " + info[1] + "!", null);
							pd.spendGuildPoints(Integer.parseInt(info[3]));
							guildBuffs.get(guild.id).add(buffName);
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									guilds.get(guildId).sendGuildMessage(ChatColor.RED + "Guild Buff " + buffName + " has expired!", null);
									guildBuffs.get(guildId).remove(buffName);
									guilds.get(guildId).broadcastSound(Sound.NOTE_PIANO);
								}
							}, Integer.parseInt(info[2].substring(0, info[2].indexOf(" "))) * 20 * 60);
						}
					} else {
						p.sendMessage(ChatColor.RED + "You don't have enough Guild Points to buy that buff!");
					}
					p.closeInventory();
				}
			}
		} catch(Exception e) {
		
		}
	}
	
	@EventHandler
	public void onChatEvent(final AsyncPlayerChatEvent event) {
		if(plugin.getPD(event.getPlayer()).waitingOnGuildName) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnGuildName = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String s = event.getMessage();
					Player p = event.getPlayer();
					if(s.trim().replaceAll("[^a-zA-Z]", "").toLowerCase().contains("cancel")) {
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else if(s.length() > 25) {
						p.sendMessage(ChatColor.RED + "Not a valid guild name! Max guild name length is 25 characters, yours was " + s.length() + ".");
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else if(s.replaceAll("[a-zA-Z]|\\s", "").length() > 0) {
						p.sendMessage(ChatColor.RED + "Not a valid guild name! Invalid characters: " + s.replaceAll("[a-zA-Z]|\\s", ""));
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else {
						plugin.getPD(p).desiredGuildName = s;
						plugin.getPD(p).waitingOnGuildAbbreviation = true;
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Your guild will be named: " + s);
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Type 'cancel' to cancel your guild creation.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Now, type your guild prefix - up to 5 characters long.");
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Guild prefixes may only have letters and numbers.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "No obscene or vulgar guild prefixes!");
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
					}
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnGuildAbbreviation) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnGuildAbbreviation = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String s = event.getMessage();
					Player p = event.getPlayer();
					if(s.trim().replaceAll("[^a-zA-Z]", "").toLowerCase().contains("cancel")) {
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else if(s.length() > 5) {
						p.sendMessage(ChatColor.RED + "Not a valid guild prefix! Max prefix length is 5 characters, yours was " + s.length() + ".");
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else if(s.replaceAll("[a-zA-Z0-9]", "").length() > 0) {
						p.sendMessage(ChatColor.RED + "Not a valid guild prefix! Invalid characters: " + s.replaceAll("[a-zA-Z0-9]", ""));
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					} else {
						plugin.getPD(p).desiredGuildPrefix = s;
						plugin.getPD(p).waitingOnGuildPurchaseConfirmation = true;
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type 'cancel' to cancel your guild creation.");
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Type 'confirm' to create your guild for 1,000,000g.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Your guild will be named: " + plugin.getPD(p).desiredGuildName);
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Your guild prefix will be : [" + s + "]");
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
					}
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnGuildPurchaseConfirmation) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnGuildPurchaseConfirmation = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String s = event.getMessage();
					final Player p = event.getPlayer();
					if(s.trim().replaceAll("[^a-zA-Z]", "").toLowerCase().contains("confirm")) {
						p.sendMessage(ChatColor.GREEN + "Checking to see if your guild name and prefix are available...");
						SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
							public void run() {
								ResultSet rs = plugin.executeQuery("select * from rpg_guilds where name = '" + plugin.getPD(p).desiredGuildName + "'");
								try {
									if(rs.next()) {
										SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
											public void run() {
												p.sendMessage(ChatColor.RED + "Your desired guild name " + plugin.getPD(p).desiredGuildName + " is already taken, sorry!");
												p.sendMessage(ChatColor.RED + "Please try a different guild name.");
											}
										});
									} else {
										rs = plugin.executeQuery("select * from rpg_guilds where abbreviation = '" + plugin.getPD(p).desiredGuildPrefix + "'");
										if(rs.next()) {
											SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
												public void run() {
													p.sendMessage(ChatColor.RED + "Your desired guild prefix " + plugin.getPD(p).desiredGuildPrefix + " is already taken, sorry!");
													p.sendMessage(ChatColor.RED + "Please try a different guild prefix.");
												}
											});
										} else {
											SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
												public void run() {
													String name = plugin.getPD(p).desiredGuildName;
													String prefix = plugin.getPD(p).desiredGuildPrefix;
													if(name.contains("staff") || ChatListeners.filter(name).contains("@") || name.contains("admin") ||
															name.contains("moderator") || name.contains("owner")) {
														p.sendMessage(ChatColor.RED + "Your desired guild name " + plugin.getPD(p).desiredGuildName + " is already taken, sorry!");
														p.sendMessage(ChatColor.RED + "Please try a different guild name.");
													} else if(prefix.contains("staff") || ChatListeners.filter(prefix).contains("@") || prefix.contains("admin") ||
															prefix.contains("moderator") || prefix.contains("owner")) {
														p.sendMessage(ChatColor.RED + "Your desired guild prefix " + plugin.getPD(p).desiredGuildPrefix + " is already taken, sorry!");
														p.sendMessage(ChatColor.RED + "Please try a different guild prefix.");
													} else {
														if(plugin.getPD(p).wallet >= 1000000) {
															p.sendMessage(ChatColor.GREEN + "Success! Guild name and prefix are available!");
															plugin.getPD(p).wallet -= 1000000;
															plugin.getPD(p).save(false);
															createGuild(p, name, prefix);
														} else {
															p.sendMessage(ChatColor.RED + "You don't have 1m with you, silly!");
														}
													}
												}
											});
										}
									}
								} catch(Exception e) {
									
								}
							}
						});
					} else {
						p.sendMessage(ChatColor.RED + "Guild creation request cancelled.");
					}
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnGuildExpansionConfirmation) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnGuildExpansionConfirmation = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String s = event.getMessage();
					Player p = event.getPlayer();
					if(s.trim().replaceAll("[^a-zA-Z]", "").toLowerCase().contains("confirm")) {
						PlayerData pd = plugin.getPD(p);
						if(pd.wallet >= pd.guildExpansionPrice) {
							Guild guild = GuildHandler.getGuild(p);
							if(guild != null) {
								pd.wallet -= pd.guildExpansionPrice;
								guild.size += 5;
								guild.upgradeSize(p.getName());
							} else {
								p.sendMessage(ChatColor.RED + "You are not in a guild!");
							}
						} else {
							p.sendMessage(ChatColor.RED + "You don't have enough money in your wallet to buy an expansion!");
						}
					} else {
						p.sendMessage(ChatColor.RED + "Guild expansion request cancelled.");
					}
				}
			});
		} 
	}
	
	public static void createGuild(Player owner, String name, String abbreviation) {
		Guild guild = new Guild(name, owner.getName(), plugin.getPD(owner).uuid, abbreviation, plugin.getPD(owner).level);
		guild.saveNewGuild();
		plugin.getPD(owner).justBoughtGuild = true;
		plugin.getPD(owner).addGuildPoints(1000);
		owner.sendMessage(ChatColor.GOLD + "New guild created! It can take up to a minute for it to be fully registered.");
		owner.sendMessage(ChatColor.GOLD + "Don't accidentally buy another guild! The one you just bought will be created soon!");
	}
	
	public static RonboMC plugin;
	
	public GuildHandler(RonboMC plugin) {
		GuildHandler.plugin = plugin;
	}
	
}