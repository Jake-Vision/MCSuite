package xronbo.ronbomc.pets;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.pets.powers.FireBlastPetPower;
import xronbo.ronbomc.pets.powers.GravityPetPower;
import xronbo.ronbomc.pets.powers.HealPetPower;
import xronbo.ronbomc.pets.powers.LightningPetPower;
import xronbo.ronbomc.pets.powers.PetPower;
import xronbo.ronbomc.pets.powers.SmashPetPower;


public class PetPowerHandler {
	
	public static PetPower[] powers = {
		new SmashPetPower(),
		new FireBlastPetPower(),
		new HealPetPower(),
		new LightningPetPower(),
		new GravityPetPower(),
	};
	
	public HashMap<Integer, PetPowerActivator> myPowers = new HashMap<Integer, PetPowerActivator>();
	
	public static class PetPowerActivator {
		public long cooldown = -1;
		public void activate(Pet pet) {
			if(cooldown == -1)
				cooldown = power.getCooldownMillis(pet.getPowerTier());
			power.activate(pet, pet.getPowerTier());
		}
		public PetPower power;
		public PetPowerActivator(PetPower power) {
			this.power = power;
			this.cooldown = -1;
		}
	}
	
	public void showMenu(Player p, Pet pet) {
		Inventory inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "Pet Powers");
		ItemStack item;
		ItemMeta im;
		for(int k = 0; k < powers.length; k++) {
			if(myPowers.keySet().contains(k)) {
				item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.AQUA + powers[k].name);
				ArrayList<String> lore = new ArrayList<String>();
				lore.add(ChatColor.GREEN + "" + ChatColor.BOLD + "ACTIVE");
				lore.add("");
				lore.addAll(powers[k].getDescription(pet.getPowerTier()));
				lore.add("");
				lore.add(ChatColor.YELLOW + "Cooldown: " + String.format("%.1f", powers[k].getCooldownMillis(pet.getPowerTier()) / 1000.0) + "s");
				lore.add("");
				lore.add(ChatColor.RED + "Click to deactivate this power.");
				lore.add(ChatColor.RED + "Pets can have 3 active powers.");
				im.setLore(lore);
				item.setItemMeta(im);
				inventory.setItem(k, item);
			} else {
				item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLUE.getData());
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.AQUA + powers[k].name);
				ArrayList<String> lore = new ArrayList<String>();
				lore.add(ChatColor.RED + "" + ChatColor.BOLD + "INACTIVE");
				lore.add("");
				lore.addAll(powers[k].getDescription(pet.getPowerTier()));
				lore.add("");
				lore.add(ChatColor.YELLOW + "Cooldown: " + String.format("%.1f", powers[k].getCooldownMillis(pet.getPowerTier()) / 1000.0) + "s");
				lore.add("");
				lore.add(ChatColor.GREEN + "Click to activate this power.");
				lore.add(ChatColor.GREEN + "Pets can have 3 active powers.");
				im.setLore(lore);
				item.setItemMeta(im);
				inventory.setItem(k, item);
			}
		}
		for(int k = powers.length; k < 9; k++) {
			item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.RED.getData());
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.RED + "More pet powers coming soon!");
			ArrayList<String> lore = new ArrayList<String>();
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(k, item);
		}
		p.openInventory(inventory);
	}
	
	public void parseActives(String s) {
		for(String s2 : s.split(" ")) {
			if(s2.length() < 1)
				continue;
			int i = Integer.parseInt(s2);
			myPowers.put(i, new PetPowerActivator(powers[i]));
		}
	}
	
	public static RonboMC plugin;
	
	public PetPowerHandler() {
		
	}
	
}