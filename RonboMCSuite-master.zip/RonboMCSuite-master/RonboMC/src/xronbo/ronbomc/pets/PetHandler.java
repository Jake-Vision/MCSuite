package xronbo.ronbomc.pets;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.pets.PetPowerHandler.PetPowerActivator;

public class PetHandler implements Listener {
	
	public static String[] petCommands = {
		"", 
		ChatColor.LIGHT_PURPLE + "      *****************************************************", 
		ChatColor.LIGHT_PURPLE + "      |                  Kastia Pet Commands                    |",
		ChatColor.LIGHT_PURPLE + "      *****************************************************", 
		"", 
		ChatColor.GREEN + "  /pet OR /pet menu",
		ChatColor.GOLD + "   - open the main menu for managing pets",
		ChatColor.GREEN + "  /pet call OR /pet here",
		ChatColor.GOLD + "   - make your pet teleport directly to you",
		ChatColor.GREEN + "  /pet hide OR /pet despawn",
		ChatColor.GOLD + "   - make your pet disappear. Respawn it with /pet call",
		ChatColor.GREEN + "  /pet ride",
		ChatColor.GOLD + "   - ride on your pet and control it with WASD + Space Bar!",
		ChatColor.GREEN + "  /pet unride",
		ChatColor.GOLD + "   - get off of your pet when you are riding it",
		ChatColor.GREEN + "  /pet hat",
		ChatColor.GOLD + "   - have your pet ride on your head",
		ChatColor.GREEN + "  /pet unhat",
		ChatColor.GOLD + "   - get your pet to come down from your head", 
		"",
	};
	
	@EventHandler
	public void onPetsMenuClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Kastia Pets Menu")) {
				event.setCancelled(true);
				Player p = (Player)(event.getWhoClicked());
				ItemStack i = event.getCurrentItem();
				if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Chicken") ||
						ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Pig") ||
						ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Cow")) {
					if(plugin.getPD(p).wallet >= 1000) {
						plugin.getPD(p).wallet -= 1000;
						p.sendMessage(ChatColor.GREEN + "You purchased a pet for " + ChatColor.GOLD + "1000g" + ChatColor.GREEN + "!");
						p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/pet" + ChatColor.GREEN + " to begin checking out its features!");
						if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Chicken")) {
							givePet(p, "chicken");
						} else if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Pig")) {
							givePet(p, "pig");
						} else if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Buy a Cow")) {
							givePet(p, "cow");
						}
					} else {
						p.sendMessage(ChatColor.RED + "You don't have 1000g in your wallet!");
					}
					p.closeInventory();
				} else {
					Pet pet = getPet(p);
					if(pet == null) {
						p.sendMessage(ChatColor.RED + "Error! Could not find your pet.");
					} else {
						if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Pet Powers Menu")) {
							showActivesMenu(p);
						} else if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Change Pet Type")) {
							pet.showPetTypes(p);
						} else if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Pet Commands")) {
							p.closeInventory();
							for(String s : petCommands)
								p.sendMessage(s);
						} else if(ChatColor.stripColor(i.getItemMeta().getDisplayName()).equals("Spawn your pet!")) {
							if(pet.spawned)
								pet.despawn();
							pet.spawn(p);
							p.closeInventory();
						}
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onPetTypesMenuClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Owned Pet Types")) {
				event.setCancelled(true);
				if(event.getRawSlot() < 9*6) {
					Player p = (Player)(event.getWhoClicked());
					ItemStack i = event.getCurrentItem();
					Pet pet = getPet(p);
					String clicked = ChatColor.stripColor(i.getItemMeta().getDisplayName());
					if(pet.spawned)
						pet.despawn();
					String reference = pet.getReferenceType(clicked);
					if(reference.equals(pet.type)) {
						p.sendMessage(ChatColor.RED + "Your pet is already a " + clicked + ", silly!");
					} else {
						p.sendMessage(ChatColor.GREEN + "You switched your pet to be a " + clicked + "!");
						pet.type = reference;
						pet.spawn(p);
					}
					p.closeInventory();
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onPetPowersMenuClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Pet Powers")) {
				event.setCancelled(true);
				Player p = (Player)(event.getWhoClicked());
				if(event.getRawSlot() < 9) {
					Pet pet = getPet(p);
					if(pet != null) {
						int clicked = event.getRawSlot();
						if(clicked < PetPowerHandler.powers.length) {
							if(pet.pph.myPowers.keySet().contains(clicked)) {
								p.sendMessage(ChatColor.GREEN + "Deactivated pet power " + pet.pph.myPowers.get(clicked).power.name + ".");
								pet.pph.myPowers.remove(clicked);
								pet.pph.showMenu(p, pet);
							} else {
								if(pet.pph.myPowers.size() < 3) {
									pet.pph.myPowers.put(clicked, new PetPowerActivator(PetPowerHandler.powers[clicked]));
									p.sendMessage(ChatColor.GREEN + "Activated pet power " + PetPowerHandler.powers[clicked].name + ".");
									pet.pph.showMenu(p, pet);
								} else {
									p.sendMessage(ChatColor.RED + "You have already selected the maximum of 3 Pet Powers to be active. Deactivate one, then try again.");
									p.closeInventory();
								}
							}
						}
					} else {
						p.sendMessage(ChatColor.RED + "Error! Could not find your pet.");
						p.closeInventory();
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public static void showMainMenu(Player p) {
		Pet pet = getPet(p);
		if(pet == null) {
			Inventory inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "Kastia Pets Menu");
			
			ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.RED.getData());
			ItemMeta im = item.getItemMeta();
			im.setDisplayName(ChatColor.RED + "You do not have a pet yet!");
			ArrayList<String> lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "To buy your first pet, read everything in this menu.");
			lore.add("");
			lore.add(ChatColor.YELLOW + "The beginner pets are Chicken, Pig, and Cow.");
			lore.add(ChatColor.YELLOW + "The differences between them are in appearance only.");
			lore.add("");
			lore.add(ChatColor.YELLOW + "All pets have the same powers and damage!");
			lore.add(ChatColor.YELLOW + "The beginner pets are obtainable in other ways too.");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(0, item);
			
			item = new ItemStack(Material.PAPER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.LIGHT_PURPLE + "Pet Info 1/4");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "In Kastia, you can have your very own pet!");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Your pet is a mysterious being that can");
			lore.add(ChatColor.YELLOW + "even change its own appearance!");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "All players start with the \"Chicken\".");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Different types can be purchased at");
			lore.add(ChatColor.YELLOW + "the store on our website.");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(1, item);
			
			item = new ItemStack(Material.PAPER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.LIGHT_PURPLE + "Pet Info 2/4");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "All pets have the same Pet Powers.");
			lore.add(ChatColor.YELLOW + "Your pet can have 3 Pet Powers");
			lore.add(ChatColor.YELLOW + "activate at once.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Once you own a pet, the new Pet Menu");
			lore.add(ChatColor.YELLOW + "will have a portion for selecting");
			lore.add(ChatColor.YELLOW + "which Pet Powers you want active.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "And, yes, Pet Powers are for combat!");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(2, item);
			
			item = new ItemStack(Material.PAPER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.LIGHT_PURPLE + "Pet Info 3/4");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "Pets gain experience from playtime.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "In other words, for every minute");
			lore.add(ChatColor.YELLOW + "you play, your pet gains 1 EXP!");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Your pet will level up with EXP.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Higher level pets deal more damage");
			lore.add(ChatColor.YELLOW + "and have stronger Pet Powers.");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(3, item);
			
			item = new ItemStack(Material.PAPER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.LIGHT_PURPLE + "Pet Info 4/4");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "Your pet will follow you around");
			lore.add(ChatColor.YELLOW + "and aid you in combat against mobs.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "However, it will not be attacked.");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "If your pet strays too far from you");
			lore.add(ChatColor.YELLOW + "it will be teleported to your side!");
			lore.add(ChatColor.YELLOW + "");
			lore.add(ChatColor.YELLOW + "Have fun with your pet!");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(4, item);
			
			item = new ItemStack(Material.RAW_CHICKEN);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Buy a Chicken");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
			lore.add("");
			lore.add(ChatColor.YELLOW + "Buy a cute chicken as your first pet!");
			lore.add("");
			lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
			lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(6, item);
			
			item = new ItemStack(Material.PORK);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Buy a Pig");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
			lore.add("");
			lore.add(ChatColor.YELLOW + "Buy a plump pig!");
			lore.add("");
			lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
			lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(7, item);
			
			item = new ItemStack(Material.LEATHER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Buy a Cow");
			lore = new ArrayList<String>();
			lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
			lore.add("");
			lore.add(ChatColor.YELLOW + "Buy a cool cow!");
			lore.add("");
			lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
			lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(8, item);
			
			p.openInventory(inventory);
		} else {
			Inventory inventory = Bukkit.createInventory(p, 9 * 1, ChatColor.BLACK + "Kastia Pets Menu");
			
			ItemStack item = new ItemStack(Material.BOOK_AND_QUILL);
			ItemMeta im = item.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "Pet Stats");
			ArrayList<String> lore = new ArrayList<String>();
			lore.add(ChatColor.AQUA + "Name: " + ChatColor.GREEN + pet.name);
			lore.add(ChatColor.AQUA + "Level: " + ChatColor.GREEN + pet.level);
			lore.add(ChatColor.AQUA + "Type: " + ChatColor.GREEN + pet.getDisplayType());
			lore.add(ChatColor.AQUA + "EXP: " + ChatColor.GREEN + pet.exp + "/" + pet.expToNextLevel());
			im.setLore(lore);
			item.setItemMeta(im);
			inventory.setItem(0, item);

			item = new ItemStack(Material.PAPER);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Pet Commands");
			im.setLore(Arrays.asList(Values.stringToLore("Click here to view all pet commands!", ChatColor.YELLOW)));
			item.setItemMeta(im);
			inventory.setItem(2, item);

			item = new ItemStack(Material.MONSTER_EGG);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Change Pet Type");
			im.setLore(Arrays.asList(Values.stringToLore("Change to a different pet type that you own.", ChatColor.YELLOW)));
			item.setItemMeta(im);
			inventory.setItem(3, item);

			item = new ItemStack(Material.IRON_SWORD);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.AQUA + "Pet Powers Menu");
			im.setLore(Arrays.asList(Values.stringToLore("Choose your Pet Powers. You can use up to 3 Pet Powers at once.", ChatColor.YELLOW)));
			item.setItemMeta(im);
			inventory.setItem(4, ItemHandler.removeAttributes(item));

			if(pet.ownedTypes.contains("pig") && pet.ownedTypes.contains("cow") && pet.ownedTypes.contains("chicken")) {
				item = new ItemStack(Material.FIRE);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GREEN + "Spawn your pet!");
				im.setLore(Arrays.asList(Values.stringToLore("Make sure to check out the Pet Commands.", ChatColor.YELLOW)));
				item.setItemMeta(im);
				inventory.setItem(6, ItemHandler.removeAttributes(item));
			} else {
				item = new ItemStack(Material.FIRE);
				im = item.getItemMeta();
				im.setDisplayName(ChatColor.GREEN + "Spawn your pet!");
				im.setLore(Arrays.asList(Values.stringToLore("Make sure to check out the Pet Commands.", ChatColor.YELLOW)));
				item.setItemMeta(im);
				inventory.setItem(5, ItemHandler.removeAttributes(item));
				int tempindex = 6;
				if(!pet.ownedTypes.contains("chicken")) {
					item = new ItemStack(Material.RAW_CHICKEN);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Buy a Chicken");
					lore = new ArrayList<String>();
					lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
					lore.add("");
					lore.add(ChatColor.YELLOW + "Buy a cute chicken as your first pet!");
					lore.add("");
					lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
					lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
					im.setLore(lore);
					item.setItemMeta(im);
					inventory.setItem(tempindex++, item);
				}
				if(!pet.ownedTypes.contains("pig")) {
					item = new ItemStack(Material.PORK);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Buy a Pig");
					lore = new ArrayList<String>();
					lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
					lore.add("");
					lore.add(ChatColor.YELLOW + "Buy a plump pig as your first pet!");
					lore.add("");
					lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
					lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
					im.setLore(lore);
					item.setItemMeta(im);
					inventory.setItem(tempindex++, item);
				}
				if(!pet.ownedTypes.contains("cow")) {
					item = new ItemStack(Material.LEATHER);
					im = item.getItemMeta();
					im.setDisplayName(ChatColor.AQUA + "Buy a Cow");
					lore = new ArrayList<String>();
					lore.add(ChatColor.YELLOW + "Price: " + ChatColor.GOLD + "1000g");
					lore.add("");
					lore.add(ChatColor.YELLOW + "Buy a cool cow as your first pet!");
					lore.add("");
					lore.add(ChatColor.YELLOW + "As you begin to get different pet types, you");
					lore.add(ChatColor.YELLOW + "will be able to switch between them freely!");
					im.setLore(lore);
					item.setItemMeta(im);
					inventory.setItem(tempindex++, item);
				}
			}

			item = new ItemStack(Material.GOLD_NUGGET);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "Buy new pets!");
			ArrayList<String> lore2 = new ArrayList<String>();
			lore2.addAll(Arrays.asList(Values.stringToLore("You can buy more cool pet types at store.kastia.net!")));
			lore2.add("");
			lore2.addAll(Arrays.asList(Values.stringToLore("Your purchases are greatly appreciated!", ChatColor.YELLOW)));
			im.setLore(lore2);
			item.setItemMeta(im);
			inventory.setItem(8, ItemHandler.removeAttributes(item));
			
			p.openInventory(inventory);
		}
	}
	
	public static void showActivesMenu(Player p) {
		Pet pet = getPet(p);
		if(pet == null) {
			p.sendMessage(ChatColor.RED + "Error: You do not have a pet!");
			return;
		}
		pet.pph.showMenu(p, pet);
	}
	
	public static Pet getPet(Player p) {
		return plugin.getPD(p).pet;
	}
	
	public static Pet givePet(Player p, String type) {
		if(getPet(p) == null) {
			String[] strings = {
					plugin.getPD(p).uuid + "",
					p.getName() + "'s Pet",
					"1",
					"0",
					"",
					type,
					type
			};
			plugin.executePrepared("INSERT INTO rpg_pets (id, uuid, name, level, exp, activePowers, type, ownedTypes) "
					+ "VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);", strings);
			Pet pet = new Pet(-1, plugin.getPD(p).uuid, p.getName() + "'s Pet", 1, 0, "", type, type);
			plugin.getPD(p).pet = pet;
			return pet;
		} else {
			if(!getPet(p).ownedTypes.contains(type))
				getPet(p).ownedTypes.add(type);
			plugin.execute("UPDATE rpg_pets set ownedTypes = concat(ownedTypes, ' " + type + "') where uuid = '" + plugin.getPD(p).uuid + "'");
			return getPet(p);
		}
	}
	
	public static void spawnPet(final Player p) {
		Pet pet = getPet(p);
		if(pet == null) {
			p.sendMessage(ChatColor.RED + "You don't have a pet yet! Use " + ChatColor.YELLOW + "/pet" + ChatColor.RED + " to buy one!");
			return;
		}
		pet.spawn(p);
	}
	
	public static RonboMC plugin;
	public PetHandler(RonboMC plugin) {
		PetHandler.plugin = plugin;
	}
	
}