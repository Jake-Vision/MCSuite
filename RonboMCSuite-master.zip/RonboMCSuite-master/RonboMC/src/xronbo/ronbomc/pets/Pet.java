package xronbo.ronbomc.pets;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import net.minecraft.server.v1_8_R1.EntityLiving;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.craftbukkit.v1_8_R1.CraftWorld;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.entitytypes.CustomCaveSpider;
import xronbo.ronbomc.entities.entitytypes.CustomChicken;
import xronbo.ronbomc.entities.entitytypes.CustomCow;
import xronbo.ronbomc.entities.entitytypes.CustomCreeper;
import xronbo.ronbomc.entities.entitytypes.CustomIronGolem;
import xronbo.ronbomc.entities.entitytypes.CustomMushroomCow;
import xronbo.ronbomc.entities.entitytypes.CustomOcelot;
import xronbo.ronbomc.entities.entitytypes.CustomPig;
import xronbo.ronbomc.entities.entitytypes.CustomPigZombie;
import xronbo.ronbomc.entities.entitytypes.CustomSheep;
import xronbo.ronbomc.entities.entitytypes.CustomSkeleton;
import xronbo.ronbomc.entities.entitytypes.CustomSpider;
import xronbo.ronbomc.entities.entitytypes.CustomWolf;
import xronbo.ronbomc.entities.entitytypes.CustomZombie;

public class Pet {
	
	public int id;
	public String uuid;
	public String name;
	public int level;
	public long exp;
	public PetPowerHandler pph;
	public PetBehaviorTask pbt;
	public String type;
	public List<String> ownedTypes;
	public Player owner;
	public LivingEntity entity;
	public MobData target;
	public boolean spawned = false;
	
	public static HashMap<String, Object[]> petTypes = new HashMap<String, Object[]>();
	public static final Object[][] petTypesPre = {
		{"chicken", new Object[]{"Chicken", "Cluck cluck! Just your everyday chicken.", Material.EGG, CustomChicken.class}},
		{"babychicken", new Object[]{"Baby Chicken", "Cheep cheep! Aww, so cute!!!", Material.FEATHER, CustomChicken.class}},
		{"pig", new Object[]{"Pig", "Oink oink! Hungry hungry!", Material.PORK, CustomPig.class}},
		{"babypig", new Object[]{"Baby Pig", "This piglet was born to do great things!", Material.APPLE, CustomPig.class}},
		{"cow", new Object[]{"Cow", "Mooooooooooooooooooo....", Material.LEATHER, CustomCow.class}},
		{"babycow", new Object[]{"Baby Cow", "Moo. Moo moo?", Material.MILK_BUCKET, CustomCow.class}},
		{"sheep", new Object[]{"Sheep", "Baa, baa, white sheep, have you any wool?", Material.SHEARS, CustomSheep.class}},
		{"babysheep", new Object[]{"Baby Sheep", "Yes, sir, yes, sir, three bags full!", Material.WOOL, CustomSheep.class}},
		{"spider", new Object[]{"Spider", "I guess you don't have arachnophobia.", Material.WEB, CustomSpider.class}},
		{"cavespider", new Object[]{"Cave Spider", "Watch out for that poison!", Material.SPIDER_EYE, CustomCaveSpider.class}},
		{"irongolem", new Object[]{"Iron Golem", "Defender of Villagers!", Material.IRON_BLOCK, CustomIronGolem.class}},
		{"mushroomcow", new Object[]{"Mooshroom", "What an intriguing animal.", Material.BROWN_MUSHROOM, CustomMushroomCow.class}},
		{"babymushroomcow", new Object[]{"Baby Mooshroom", "Mushrooms + Baby + Cow = Ultimate Awesomeness!", Material.RED_MUSHROOM, CustomMushroomCow.class}},
		{"pigzombie", new Object[]{"Zombie Pigman", "Ew that looks so ugly.", Material.GOLD_SWORD, CustomPigZombie.class}},
		{"babypigzombie", new Object[]{"Zombie Pigbaby", "Not quite as ugly as the adult version.", Material.GOLD_INGOT, CustomPigZombie.class}},
		{"skeleton", new Object[]{"Skeleton", "The nightmare of children around the world.", Material.SKULL_ITEM, CustomSkeleton.class}},
		{"wolf", new Object[]{"Wolf", "A Minecrafter's best friend!", Material.RAW_BEEF, CustomWolf.class}},
		{"angrywolf", new Object[]{"Angry Wolf", "Grrrr.... Uh oh. It's angry!", Material.REDSTONE, CustomWolf.class}},
		{"zombie", new Object[]{"Zombie", "A horror movie antagonist come to life.", Material.ROTTEN_FLESH, CustomZombie.class}},
		{"babyzombie", new Object[]{"Baby Zombie", "It's a tragedy when you think about it.", Material.SKULL_ITEM, CustomZombie.class}},
		{"creeper", new Object[]{"Creeper", "A Minecraft classic!", Material.SKULL_ITEM, CustomCreeper.class}},
		{"ocelot", new Object[]{"Ocelot", "Meeowww!", Material.RAW_FISH, CustomOcelot.class}},
		{"babyocelot", new Object[]{"Baby Ocelot", "Mew, mew.", Material.COOKED_FISH, CustomOcelot.class}},
		{"babywolf", new Object[]{"Baby Wolf", "Woof! Woof! What a cutie.", Material.BONE, CustomWolf.class}},
		{"witherskeleton", new Object[]{"Wither Skeleton", "It's like a skeleton but bigger and scarier.", Material.SKULL_ITEM, CustomSkeleton.class}},
	};
	
	static {
		for(Object[] o : petTypesPre) {
			petTypes.put(o[0] + "", (Object[])o[1]);
		}
	}
	
	public static String getDisplayTypeStatic(String type) throws NullPointerException {
		return ((Object[])petTypes.get(type.toLowerCase()))[0] + "";
	}
	
	public String getDisplayType() {
		try {
			return getDisplayTypeStatic(type);
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("Error: Pet type " + type + " no longer exists?");
			type = ownedTypes.get((int)(Math.random() * ownedTypes.size()));
			return ((Object[])petTypes.get(type.toLowerCase()))[0] + "";
		}
	}
	
	public String getReferenceType(String displayType) {
		for(Object[] o : petTypesPre) {
			if(((String)((Object[])o[1])[0]).equals(displayType))
				return o[0] + "";
		}
		return "";
	}
	
	public static ItemStack getItemStackDisplay(String s) {
		String name = "";
		String description = "";
		Material material = null;
		Object[] o = petTypes.get(s.toLowerCase());
		if(o == null) {
			System.out.println("COULD NOT FIND PET TYPE " + s);
			return null;
		}
		name = o[0] + "";
		description = o[1] + "";
		material = (Material)o[2];
		ItemStack item = new ItemStack(material);
		if(s.toLowerCase().equals("skeleton")) {
			item = new ItemStack(Material.SKULL_ITEM, 1, (short)(SkullType.SKELETON.ordinal()));
		} else if(s.toLowerCase().equals("babyzombie")) {
			item = new ItemStack(Material.SKULL_ITEM, 1, (short)(SkullType.ZOMBIE.ordinal()));
		} else if(s.toLowerCase().equals("creeper")) {
			item = new ItemStack(Material.SKULL_ITEM, 1, (short)(SkullType.CREEPER.ordinal()));
		} else if(s.toLowerCase().equals("witherskeleton")) {
			item = new ItemStack(Material.SKULL_ITEM, 1, (short)(SkullType.WITHER.ordinal()));
		}
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + name);
		im.setLore(Arrays.asList(Values.stringToLore(description, ChatColor.YELLOW)));
		item.setItemMeta(im);
		return item;
	}
	
	public static Class<?> getClass(String type) {
		return (Class<?>)((Object[])petTypes.get(type.toLowerCase()))[3];
	}
	
	public static EntityLiving getEntity(String type, net.minecraft.server.v1_8_R1.World world) {
		EntityLiving e = null;
		try {
			e = (EntityLiving) (getClass(type).getDeclaredConstructor(net.minecraft.server.v1_8_R1.World.class, boolean.class).newInstance(world, true));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		switch(type) {
			case "babychicken":
			case "babypig":
			case "babycow":
			case "babysheep":
			case "babymushroomcow":
			case "babywolf":
			case "babyocelot":
				Ageable a = (Ageable) e.getBukkitEntity();
				a.setBaby();
				a.setAgeLock(true);
				break;
			case "babypigzombie":
			case "babyzombie":
				((CustomZombie)e).setBaby(true);
				break;
			case "angrywolf":
				((CustomWolf)e).makeRedEyes(true);
				break;
			case "witherskeleton":
				((CustomSkeleton)e).makeWither();
				break;
		}
		return e;
	}
	
	public String activePowersToString() {
		StringBuilder sb = new StringBuilder("");
		for(int i : pph.myPowers.keySet())
			sb.append(i + " ");
		return sb.toString().trim();
	}
	
	public static long[] expReqs = {
		10, //2
		11, //3
		12, //4
		13, //5
		14, //6
		15, //7
		20, //8
		21, //9
		22, //10
		23, //11
		24, //12
		25, //13
		30, //14
		31, //15
		32, //16
		33, //17
		34, //18
		35, //19
		40, //20
		41, //21
		42, //22
		43, //23
		44, //24
		45, //25
		50, //26
		51, //27
		52, //28
		53, //29
		54, //30
		55, //31
		60, //32
		61, //33
		62, //34
		63, //35
		65, //36
		70, //37
		75, //38
		80, //39
		85, //40
		90, //41
		95, //42
		100, //43
		120, //44
		140, //45
		160, //46
		180, //47
		200, //48
		220, //49
		240, //50
	};
	
	public long expToNextLevel() {
		if(level - 1 < expReqs.length)
			return expReqs[level - 1];
		else
			return 10000;
	}
	
	public void save(boolean forced) {
		String[][] data = new String[][] {
				{"name", "" + name},
				{"level", "" + level},
				{"exp", "" + exp},
				{"activePowers", activePowersToString()},
				{"type", type},
		};
		StringBuilder statement = new StringBuilder("UPDATE rpg_pets SET ");
		String[] stringsOnly = new String[data.length];
		int count = 0;
		for(String[] s : data) {
			statement.append(s[0] + " = ?, ");
			stringsOnly[count++] = s[1];
		}
		if(statement.toString().endsWith(", "))
			statement = new StringBuilder(statement.substring(0, statement.length() - 2));
		statement.append(" WHERE uuid='" + uuid + "'");
		plugin.executePrepared(statement.toString(), forced, stringsOnly);
	}
	
	public int rollDamage() {
		int damage = (int)(Values.randInt(level / 3 + 3, level / 2 + 5) * 2 * (Math.ceil(level / 6) + 1) * (Math.random() * 0.7 + .5));
		return damage;
	}
	
	public void showPetTypes(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9 * 6, ChatColor.BLACK + "Owned Pet Types");
		int count = 0;
		for(String s : ownedTypes) {
			ItemStack item = getItemStackDisplay(s);
			if(item == null)
				continue;
			inventory.setItem(count++, item);
		}
		p.openInventory(inventory);
	}
	
	public void spawn(Player p) {
		if(p.getVehicle() != null)
			p.getVehicle().eject();
		spawned = true;
		Location loc = p.getLocation();
		final net.minecraft.server.v1_8_R1.World world = ((CraftWorld)(loc.getWorld())).getHandle();
		net.minecraft.server.v1_8_R1.EntityLiving e = null;
		try {
			e = getEntity(type, world);
		} catch(Exception e2) {
			e2.printStackTrace();
		}
		e.setPosition(loc.getX(), loc.getY(), loc.getZ());
		world.addEntity(e, SpawnReason.CUSTOM);
		final LivingEntity le = (LivingEntity)(((net.minecraft.server.v1_8_R1.Entity)e).getBukkitEntity());
		le.setCustomName(name);
		if(p.getName().equals("xRonbo"))
			le.setCustomName(ChatColor.GOLD + name);
		le.setCustomNameVisible(true);
		this.owner = p;
		this.entity = le;
		this.pbt = new PetBehaviorTask(this);
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this.pbt);
	}
	
	public void despawn() {
		if(entity != null)
			entity.remove();
		entity = null;
		spawned = false;
		pbt = null;
	}

	public int getPowerTier() {
		if(level < 10)
			return 1;
		else if(level < 20)
			return 2;
		else if(level < 30)
			return 3;
		else if(level < 40)
			return 4;
		else
			return 5;
	}
	
	public String toString() {
		return name + " [ID: " + id + "]" + " Type: " + type + " OwnedTypes: " + ownedTypes;
	}
	
	public Pet(int id, String uuid, String name, int level, long exp, String activePowersString, String type, String ownedTypes) {
		this.id = id;
		this.uuid = uuid;
		this.name = name;
		this.level = level;
		this.exp = exp;
		this.pph = new PetPowerHandler();
		this.pph.parseActives(activePowersString);
		this.type = type.toLowerCase();
		this.ownedTypes = new ArrayList<String>();
		for(String s : ownedTypes.split(" ")) {
			if(s.length() > 0)
				this.ownedTypes.add(s);
		}
		if(!this.ownedTypes.contains(this.type))
			this.ownedTypes.add(this.type);
	}
	
	public static RonboMC plugin;

	public void addExp(int i) {
		exp += i;
		if(exp >= expToNextLevel() && owner != null && owner.isOnline() && owner.isValid()) {
			level++;
			exp = 0;
			owner.sendMessage(ChatColor.GOLD + "Your pet just leveled up!");
		}
	}
	
}