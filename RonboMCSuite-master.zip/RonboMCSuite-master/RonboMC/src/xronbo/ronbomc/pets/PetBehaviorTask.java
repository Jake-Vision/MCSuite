package xronbo.ronbomc.pets;

import java.util.UUID;

import net.minecraft.server.v1_8_R1.EntityInsentient;

import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftLivingEntity;
import org.bukkit.entity.Entity;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.pets.PetPowerHandler.PetPowerActivator;
import xronbo.ronbomc.regions.RegionHandler;



public class PetBehaviorTask implements Runnable {
	
	public void run() {
		if(pet.owner == null || !pet.owner.isOnline() || !pet.owner.isValid()) {
			pet.owner = null;
			if(pet.entity != null)
				pet.entity.remove();
			pet.entity = null;
			return;
		}
		if(!pet.spawned || pet.entity == null || !pet.entity.isValid())
			return;
		if(!pet.entity.getUniqueId().equals(uniqueID))
			return;
		try {
			if(!RegionHandler.getRegion(pet.entity.getLocation()).type.equals("secure")) {
				if(count % 6 == 0) {
					boolean fired = false;
					for(PetPowerActivator ppa : pet.pph.myPowers.values()) {
						ppa.cooldown -= 1500;
						if(!fired && ppa.cooldown <= 0 && pet.entity.getPassenger() == null) {
							fired = true;
							ppa.activate(pet);
							ppa.cooldown = ppa.power.getCooldownMillis(pet.getPowerTier());
						}
					}
				}
				if(count % 16 == 0) {
					if(Math.random() < 0.3) {
						pet.target = null;
					}
				}
				if(pet.target != null) {
					if(pet.target.dead) {
						pet.target = null;
					} else {
						Location loc = pet.target.entity.getLocation();
						if(loc.distanceSquared(pet.entity.getLocation()) > 15*15)
							pet.target = null;
						else
							((EntityInsentient) ((CraftLivingEntity) pet.entity).getHandle()).getNavigation().a(loc.getX(), loc.getY(), loc.getZ(), 1.4D);	
					}
				} else if(count % 8 == 0) {
					for(Entity e : pet.entity.getNearbyEntities(8, 8, 8)) {
						if(MobHandler.spawnedMobs.get(e.getUniqueId()) != null) {
							pet.target = MobHandler.spawnedMobs.get(e.getUniqueId());
							break;
						}
					}
				}
			}
			if(count % 8 == 0 && (pet.entity.getLocation().distanceSquared(pet.owner.getLocation()) > 15*15 || Math.abs(pet.entity.getLocation().getY() - pet.owner.getLocation().getY()) > 7))
				pet.entity.teleport(pet.owner.getLocation());
			Location loc = pet.owner.getLocation();
			if(pet.target == null)
				((EntityInsentient) ((CraftLivingEntity) pet.entity).getHandle()).getNavigation().a(loc.getX(), loc.getY(), loc.getZ(), 1.4D);
			count++;
		} catch(Exception e) {
			pet.despawn();
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					if(pet.owner != null && pet.owner.isOnline() && pet.owner.isValid())
						pet.spawn(pet.owner);
				}
			}, 1);
		}
		if(pet.owner != null && pet.owner.isValid() && pet.entity != null && pet.entity.isValid() && !pet.entity.isDead())
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 3);
	}
	
	public int count = 0;
	public UUID uniqueID;
	public Pet pet;
	
	public static RonboMC plugin;
	
	public PetBehaviorTask(Pet pet) {
		this.pet = pet;
		this.uniqueID = pet.entity.getUniqueId();
	}
	
}