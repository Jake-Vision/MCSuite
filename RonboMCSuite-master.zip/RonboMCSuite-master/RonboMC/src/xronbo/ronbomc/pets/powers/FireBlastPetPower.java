package xronbo.ronbomc.pets.powers;

import java.util.HashSet;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.pets.Pet;

public class FireBlastPetPower extends PetPower {
	
	public FireBlastPetPower() {
		this.name = "Fire Blast";
		this.description = "Explode in a burst of fire, burning nearby mobs for %MULTIPLIER% pet damage.";
	}
	
	@Override
	public void activate(final Pet pet, final int level) {
		Location loc = pet.entity.getEyeLocation();
		HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
		particles.add(new ParticleDetails(ParticleType.FIRE));
		EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
		holder.setRunning(true);
		holder.update();
		holder.setRunning(false);
		for(Entity e2 : pet.entity.getNearbyEntities(2,2,2)) {
			if(MobHandler.spawnedMobs.get(e2.getUniqueId()) != null) {
				int damage = getDamage(pet);
				MobHandler.spawnedMobs.get(e2.getUniqueId()).damage(damage, pet.owner, true);
			}
		}
	}
	
	@Override
	public double getMultiplier(int level) {
		return level * 1.2;
	}

	@Override
	public int getCooldownMillis(int level) {
		return 7000 - level*400;
	}
	
}