package xronbo.ronbomc.pets.powers;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;

import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.pets.Pet;

public class SmashPetPower extends PetPower {
	
	public SmashPetPower() {
		this.name = "Smash";
		this.description = "Leap into the air and smash the ground, damaging nearby mobs for %MULTIPLIER% pet damage.";
	}
	
	@Override
	public void activate(final Pet pet, final int level) {
		final Entity e = pet.entity;
		e.setVelocity(e.getVelocity().normalize().add(new Vector(0,1.0,0)));
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(e == null || e.isDead() || !e.isValid() || pet.owner == null || !pet.owner.isOnline())
					return;
				Location loc = e.getLocation();
				loc.getWorld().createExplosion(loc.getX(),loc.getY(),loc.getZ(),1.0f,false,false);
				for(Entity e2 : e.getNearbyEntities(3, 3, 3)) {
					if(MobHandler.spawnedMobs.get(e2.getUniqueId()) != null) {
						int damage = getDamage(pet);
						MobHandler.spawnedMobs.get(e2.getUniqueId()).damage(damage, pet.owner, true);
					}
				}
			}
		}, 15);
	}
	
	@Override
	public double getMultiplier(int level) {
		return level + 0.2 * level;
	}

	@Override
	public int getCooldownMillis(int level) {
		return 10000 - level*1000;
	}
	
}