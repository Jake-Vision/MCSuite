package xronbo.ronbomc.pets.powers;

import org.bukkit.entity.Entity;

import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.pets.Pet;

public class GravityPetPower extends PetPower {
	
	public GravityPetPower() {
		this.name = "Gravity";
		this.description = "Draw in all nearby mobs towards the pet.";
	}
	
	@Override
	public void activate(final Pet pet, final int level) {
		for(Entity e : pet.entity.getNearbyEntities(level*4, 3,level*4)) {
			if(MobHandler.spawnedMobs.containsKey(e.getUniqueId())) {
				e.setVelocity(pet.entity.getLocation().subtract(e.getLocation()).toVector().normalize());
			}
		}
	}
	
	@Override
	public double getMultiplier(int level) {
		return 0;
	}

	@Override
	public int getCooldownMillis(int level) {
		return 8000 - level*500;
	}
	
}