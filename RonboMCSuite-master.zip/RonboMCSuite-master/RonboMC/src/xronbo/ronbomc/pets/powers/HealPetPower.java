package xronbo.ronbomc.pets.powers;

import java.util.HashSet;

import org.bukkit.Location;

import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.pets.Pet;

public class HealPetPower extends PetPower {
	
	public HealPetPower() {
		this.name = "Heal";
		this.description = "Heal the pet owner for %MULTIPLIER% of normal pet damage, up to 30% of max HP.";
	}
	
	@Override
	public void activate(final Pet pet, final int level) {
		Location loc = pet.entity.getEyeLocation();
		HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
		particles.add(new ParticleDetails(ParticleType.HEART));
		EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
		holder.setRunning(true);
		holder.update();
		holder.setRunning(false);
		int heal = getDamage(pet);
		if(heal > (plugin.getPD(pet.owner).maxHP + plugin.getPD(pet.owner).maxHP_temp) * 0.3)
			heal = (int)((plugin.getPD(pet.owner).maxHP + plugin.getPD(pet.owner).maxHP_temp) * 0.3);
		plugin.getPD(pet.owner).heal(heal);
	}
	
	@Override
	public double getMultiplier(int level) {
		return level * 1.5;
	}

	@Override
	public int getCooldownMillis(int level) {
		return 15000 - level*1000;
	}
	
}