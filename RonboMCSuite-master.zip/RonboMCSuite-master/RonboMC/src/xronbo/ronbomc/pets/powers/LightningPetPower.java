package xronbo.ronbomc.pets.powers;

import java.util.HashSet;

import org.bukkit.Location;

import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.pets.Pet;

public class LightningPetPower extends PetPower {
	
	public LightningPetPower() {
		this.name = "Lightning Strike";
		this.description = "Call down a powerful bolt of lighting, striking a target mob for %MULTIPLIER% of pet damage.";
	}
	
	@Override
	public void activate(final Pet pet, final int level) {
		if(pet.target == null || pet.target.entity == null || !pet.target.entity.isValid() || pet.target.dead)
			return;
		pet.entity.getLocation().getWorld().strikeLightningEffect(pet.target.entity.getLocation());
		Location loc = pet.entity.getEyeLocation();
		HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
		particles.add(new ParticleDetails(ParticleType.EXPLOSION));
		EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
		holder.setRunning(true);
		holder.update();
		holder.setRunning(false);
		pet.target.damage(getDamage(pet), pet.owner, true);
	}
	
	@Override
	public double getMultiplier(int level) {
		return level * 2;
	}

	@Override
	public int getCooldownMillis(int level) {
		return 30000 - 2500*level;
	}
	
}