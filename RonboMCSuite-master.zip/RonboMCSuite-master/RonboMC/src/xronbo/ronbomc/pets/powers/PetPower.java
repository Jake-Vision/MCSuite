package xronbo.ronbomc.pets.powers;

import java.util.Arrays;
import java.util.List;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.pets.Pet;

public abstract class PetPower {

	public String name = "placeholder_name";
	public String description = "placeholder_desc";
	
	public abstract void activate(Pet pet, int level);
	
	public abstract int getCooldownMillis(int level);
	
	public List<String> getDescription(int level) {
		String s = description;
		s = s.replaceAll("%MULTIPLIER%", (int)((getMultiplier(level) * 100)) + "%");
		return Arrays.asList(Values.stringToLore(s));
	}
	
	public int getDamage(Pet pet) {
		return (int)(pet.rollDamage() * getMultiplier(pet.getPowerTier()));
	}
	
	public abstract double getMultiplier(int level);
	
	public static RonboMC plugin;
	
}