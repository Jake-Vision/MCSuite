package xronbo.ronbomc;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import me.ronbo.core.RonboCore;
import me.ronbo.core.SQLManager;
import net.minecraft.server.v1_8_R1.PlayerList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.Recipe;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scheduler.BukkitWorker;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;

import xronbo.ronbomc.bounty.BountyHandler;
import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.chests.ChestHandler;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.combat.SpellHandler;
import xronbo.ronbomc.combat.spells.Spell;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.Dungeon;
import xronbo.ronbomc.dungeons.DungeonHandler;
import xronbo.ronbomc.enchants.EnchantHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.entities.MobStats;
import xronbo.ronbomc.entities.NPCHandler;
import xronbo.ronbomc.entities.VillagerData;
import xronbo.ronbomc.entities.entityspells.EntitySpell;
import xronbo.ronbomc.entities.entityspells.EntitySpellHandler;
import xronbo.ronbomc.entities.entitytypes.CustomEntityType;
import xronbo.ronbomc.entities.entitytypes.CustomVillager;
import xronbo.ronbomc.guilds.Guild;
import xronbo.ronbomc.guilds.GuildHandler;
import xronbo.ronbomc.horses.HorseHandler;
import xronbo.ronbomc.items.EtcItemListeners;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.listeners.BankListeners;
import xronbo.ronbomc.listeners.ChatListeners;
import xronbo.ronbomc.listeners.CombatListeners;
import xronbo.ronbomc.listeners.GeneralListeners;
import xronbo.ronbomc.listeners.MenuListeners;
import xronbo.ronbomc.listeners.RegionListeners;
import xronbo.ronbomc.listeners.ShopListeners;
import xronbo.ronbomc.listeners.SkillsListeners;
import xronbo.ronbomc.listeners.SpellListeners;
import xronbo.ronbomc.minigames.MinigameHandler;
import xronbo.ronbomc.minigames.Ronblop;
import xronbo.ronbomc.options.OptionsHandler;
import xronbo.ronbomc.parties.Party;
import xronbo.ronbomc.pets.Pet;
import xronbo.ronbomc.pets.PetBehaviorTask;
import xronbo.ronbomc.pets.PetHandler;
import xronbo.ronbomc.pets.PetPowerHandler;
import xronbo.ronbomc.pets.powers.PetPower;
import xronbo.ronbomc.quests.Quest;
import xronbo.ronbomc.quests.QuestHandler;
import xronbo.ronbomc.quests.Stage;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;
import xronbo.ronbomc.regions.Spawn;
import xronbo.ronbomc.seller.SellerHandler;
import xronbo.ronbomc.shops.ShopHandler;
import xronbo.ronbomc.skills.harvesting.HarvestingHandler;
import xronbo.ronbomc.trading.TradeHandler;
import xronbo.ronbomc.trading.TradeListeners;
import xronbo.ronbomc.travel.TravelHandler;
import xronbo.ronbomc.votes.VoteHandler;
import xronbo.ronbomc.warps.WarpHandler;


public class RonboMC extends JavaPlugin {
	
	public static final boolean DEBUG = true;
	public static final boolean TESTING_INVENTORY_CANCELS = false;
	public static final boolean BUILD_MODE_ACTIVE = true;
	public static final int MAX_PLAYERS = 200;
	
	public static boolean DEV_MODE_ACTIVE = false;
	
	public static ChannelManager cm = null;
	
	public ConcurrentHashMap<String, PlayerData> players;
	public Scoreboard hpBoard;
	
	public static RonboMC plugin;

	public String serverName = "";
	public void loadServerName() throws Exception {
		boolean found = false;
		for(File f : new File("./plugins/").listFiles()) {
			if(f.getName().startsWith("server_")) {
				serverName = f.getName().substring("server_".length());
				System.out.println("This server is " + serverName);
				found = true;
				break;
			}
		}
		if(!found)
			throw new Exception("ERROR: COULD NOT FIND BUNGEE SERVER NAME IN ./plugins/. SHUTTING DOWN NOW!");
	}
	
	public void onEnable() {
		RonboMC.plugin = this;
		try {
			loadServerName();
		} catch(Exception e) {
			e.printStackTrace();
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					plugin.getServer().shutdown();
				}
			}, 20);
		}
		RonboCore.overrideChat();
		if(new File(plugin.getDataFolder() + File.separator + "dev").isFile()) {
			SuperDebugger.scheduleSyncDelayedTask(RonboMC.class.getClass(), plugin, new Runnable() {
				public void run() {
					System.out.println("DEV MODE ACTIVE!");	
				}
			}, 20);
			DEV_MODE_ACTIVE = true;
		}
		for(World w : plugin.getServer().getWorlds()) {
			if(w.getName().contains("+di+"))
				plugin.getServer().unloadWorld(w, false);
		}
		try {
			Field field = getServer().getClass().getDeclaredField("playerList");
			field.setAccessible(true);
			Object playerList = field.get(getServer());
			Field field2 = PlayerList.class.getDeclaredField("maxPlayers");
			field2.setAccessible(true);
			field2.set(playerList, MAX_PLAYERS);
			field.set(getServer(), playerList);
			System.out.println("Max player count set to " + MAX_PLAYERS + ".");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		long startTimeNano = System.nanoTime();
		loadWorlds();
    	for(World w : getServer().getWorlds()) {
			w.setWeatherDuration(0);
			w.setStorm(false);
			w.setThunderDuration(0);
			w.setThundering(false);
    	}
		players = new ConcurrentHashMap<String, PlayerData>();
		hpBoard = getServer().getScoreboardManager().getNewScoreboard();
		Objective objective = hpBoard.registerNewObjective("hpdisplay", "dummy");
		objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
		objective.setDisplayName(ChatColor.RED + "\u2764");
		
		getServer().getPluginManager().registerEvents(new GeneralListeners(this), this);
		getServer().getPluginManager().registerEvents(new BankListeners(this), this);
		getServer().getPluginManager().registerEvents(new RegionListeners(this), this);
		getServer().getPluginManager().registerEvents(new CombatListeners(this), this);
		getServer().getPluginManager().registerEvents(new ChatListeners(this), this);
		getServer().getPluginManager().registerEvents(new ShopListeners(this), this);
		getServer().getPluginManager().registerEvents(new MenuListeners(this), this);
		getServer().getPluginManager().registerEvents(new SpellListeners(this), this);
		getServer().getPluginManager().registerEvents(new TradeListeners(this), this);
		getServer().getPluginManager().registerEvents(new EtcItemListeners(this), this);
		getServer().getPluginManager().registerEvents(new ChestHandler(this), this);
		getServer().getPluginManager().registerEvents(new OptionsHandler(this), this);
		getServer().getPluginManager().registerEvents(new EnchantHandler(this), this);
		getServer().getPluginManager().registerEvents(new HorseHandler(this), this);
		getServer().getPluginManager().registerEvents(new TravelHandler(this), this);
		getServer().getPluginManager().registerEvents(new SkillsListeners(this), this);
//		getServer().getPluginManager().registerEvents(hpbar = new HPBar(this), this);
		getServer().getPluginManager().registerEvents(new SellerHandler(this), this);
		getServer().getPluginManager().registerEvents(new VoteHandler(this), this);
		getServer().getPluginManager().registerEvents(new MinigameHandler(this), this);
		getServer().getPluginManager().registerEvents(new Ronblop(this), this);
		getServer().getPluginManager().registerEvents(new ShopHandler(this), this);
		getServer().getPluginManager().registerEvents(new PetHandler(this), this);
		getServer().getPluginManager().registerEvents(new GuildHandler(this), this);
		getServer().getPluginManager().registerEvents(cm = new ChannelManager(this), this);
		getServer().getPluginManager().registerEvents(new GrappleManager(this), this);
		getServer().getPluginManager().registerEvents(new BountyHandler(this), this);
		
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		
		RonboMCCommandExecutor commandExecutor = new RonboMCCommandExecutor(this);
		for(final String s : RonboMCCommandExecutor.commands) {
			try {
				getCommand(s).setExecutor(commandExecutor);
				getCommand(s).setPermission("");
			} catch(Exception e) {
				System.out.println("Could not load command \"" + s + "\"");
			}
		}
		
		loadGlobalTasks();
		PlayerData.plugin = this;
		CombatHandler.plugin = this;
		ItemHandler.plugin = this;
		MobHandler.plugin = this;
		TipHandler.plugin = this;
		MobData.plugin = this;
		RegionHandler.plugin = this;
		NPCHandler.plugin = this;
		SpellHandler.plugin = this;
		Spell.plugin = this;
		Party.plugin = this;
		ClassHandler.plugin = this;
		WarpHandler.plugin = this;
		TradeHandler.plugin = this;
		QuestHandler.plugin = this;
		Quest.plugin = this;
		Stage.plugin = this;
		Dungeon.plugin = this;
		CustomVillager.plugin = this;
		DungeonHandler.plugin = this;
		HarvestingHandler.plugin = this;
		VillagerData.plugin = this;
		EntitySpellHandler.plugin = this;
		EntitySpell.plugin = this;
		MobStats.plugin = this;
		PetPower.plugin = this;
		Pet.plugin = this;
		PetPowerHandler.plugin = this;
		PetBehaviorTask.plugin = this;
		Guild.plugin = this;
		
		ItemHandler.load();
		MobHandler.load();
		RegionHandler.load();
		CustomEntityType.registerEntities();
		NPCHandler.load();
		WarpHandler.load();
		QuestHandler.load();
		ChestHandler.load();
		DungeonHandler.load();
		ShopHandler.load();
		
		for(Player player : plugin.getServer().getOnlinePlayers()) {
			loadPlayer(player);
		}
		Iterator<Recipe> iter = plugin.getServer().recipeIterator();
		while(iter.hasNext()) {
			iter.next();
			iter.remove();
		}
		
		System.out.println("RonboMC loaded in " + ((int)(((System.nanoTime() - startTimeNano))/1000000.0)) + "ms");
	}

	public void loadWorlds() {
		for(File f : new File("./").listFiles()) {
			if(f.isDirectory()) {
				boolean isWorld = false;
				for(File f2 : f.listFiles()) {
					if(f2.getPath().toString().contains("session.lock")) {
						isWorld = true;
						break;
					}
				}
				if(isWorld) {
					getServer().createWorld(new WorldCreator(f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1)));
				}
			}
		}
		System.out.println("Loaded " + getServer().getWorlds().size() + " worlds.");
	}
	
	public static int latency;

	public static volatile int lastupdate = 0;
	public static class TPSChecker implements Runnable {
		public void run() {
			started = System.currentTimeMillis();
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public int runCount = 0;
				public void run() {
					long now = System.currentTimeMillis();
					runCount++;
					if(runCount > 20) {
						if(p != null && p.isOnline() && plugin.getPD(p) != null) {
							p.sendMessage("Ran 20 ticks in " + (now - started) + "ms.");
							p.sendMessage("Latency of " + (latency = Math.abs((int)(now - started) - 1000)) + "ms.");
							plugin.getPD(p).checkLagTaskId = -1;
						} else {
							latency = Math.abs((int)(now - started) - 1000);
						}
					} else {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 1);
					}
					final String serverName = plugin.serverName;
					final int players = plugin.getServer().getOnlinePlayers().length;
					final int latency = RonboMC.latency;
					SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
						public void run() {
							plugin.execute("replace into bungee values('" + "channel_" + serverName + "', " + players + ", " + lastupdate++ + ", 1, 0, '" + latency + "')");
						}
					});
				}
			});
		}
		long started = 0;
		Player p = null;
		public TPSChecker(Player p) {
			this.p = p;
		}
	}
	
	public void loadGlobalTasks() {
		getServer().getScheduler().scheduleSyncDelayedTask(this, new Runnable() {
			public void run() {
				SuperDebugger.scheduleSyncRepeatingTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new TPSChecker(null));
					}
				}, 1 * 20, 3 * 20);
				ChannelManager.loadChannels();
				DungeonHandler.forceCleanup();
				GuildHandler.showMenu(null);
				for(World w: getServer().getWorlds()) {
					for(Entity e : w.getEntities()) {
						if(e instanceof LivingEntity && !(e instanceof Player))
							e.remove();
					}
				}
				SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
					public int restartCountdown = 60 * 4 + (int)(Math.random() * 30);
				    public void run() {
				    	MobHandler.tick();
						for(World w : plugin.getServer().getWorlds())
							for(Entity e : w.getEntities())
									if(e instanceof Villager)
										e.remove();
						NPCHandler.load(false);
						restartCountdown--;
						switch(restartCountdown) {
							case 60*4:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 4 hours.");
								break;
							case 60*3:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 3 hours.");
								break;
							case 60*2:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 2 hours.");
								break;
							case 60*1:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 1 hour.");
								break;
							case 45:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 45 minutes.");
								break;
							case 30:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 30 minutes.");
								break;
							case 15:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 15 minutes.");
								break;
							case 10:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 10 minutes.");
								break;
							case 5:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 5 minutes.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "Use /cc to switch channels now!");
								break;
							case 4:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 4 minutes.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "Use /cc to switch channels now!");
								break;
							case 3:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 3 minutes.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "Use /cc to switch channels now!");
								break;
							case 2:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 2 minutes.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "Use /cc to switch channels now!");
								break;
							case 1:
								plugin.getServer().broadcastMessage(ChatColor.RED + "This channel will be restarting in 1 minute.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "" + ChatColor.BOLD + "There will be no further restart warnings.");
								plugin.getServer().broadcastMessage(ChatColor.RED + "Use /cc to switch channels now!");
								break;
							default:
								break;
						}
						if(restartCountdown == 0) {
							plugin.getServer().broadcastMessage(ChatColor.RED + "This channel is restarting NOW.");
							for(Player p : plugin.getServer().getOnlinePlayers()) {
								plugin.getPD(p).save(true);
							}
							plugin.getServer().shutdown();
						}
				    }
			    }, 20*60, 20 * 60);
				SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	NPCHandler.fixLocations();
				    }
			    }, 20 * 60 * 10, 20 * 60 * 10);
				SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	if(last) {
				    		double rand = Math.random();
				    		if(rand < 0.25)
				    			plugin.getServer().broadcastMessage(ChatColor.GOLD + "Want a cool pet? Get one at store.kastia.net!");
				    		else if(rand < 0.5) {
					    		plugin.getServer().broadcastMessage(ChatColor.GOLD + "Check out the awesome Vote Point rewards with /vp!");
					    		plugin.getServer().broadcastMessage(ChatColor.GOLD + "Use /vote to earn your daily Vote Points - it only takes a minute!");
				    		} else if(rand < 0.75)
				    			plugin.getServer().broadcastMessage(ChatColor.GOLD + "Sign up on our website at www.kastia.net to stay up to date on Kastia news!");
				    		else
				    			plugin.getServer().broadcastMessage(ChatColor.GOLD + "Kastia is a friendly environment - be nice to others!");
				    	} else {
				    		plugin.getServer().broadcastMessage(ChatColor.GOLD + "Check out the awesome Vote Point rewards with /vp!");
				    		plugin.getServer().broadcastMessage(ChatColor.GOLD + "Use /vote to earn your daily Vote Points - it only takes a minute!");
				    	}
				    	last = !last;
				    }
				    public boolean last = true;
			    }, 20 * 60 * 5, 20 * 60 * 5);
				SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	for(Region region : RegionHandler.regions) {
							for(Spawn s : region.spawns) {
								s.available = s.count;
							}
				    	}
				    	if(getServer().getOnlinePlayers().length > 0) {
					    	getServer().broadcastMessage(ChatColor.RED + "Saving all players...");
					    	for(Player p : getServer().getOnlinePlayers()) {
					    		if(getPD(p) != null) {
					    			getPD(p).save(false);
					    			getPD(p).updateArmorStats();
					    		}
					    	}
					    	getServer().broadcastMessage(ChatColor.DARK_GREEN + "Save complete!");
				    	}
				    	for(World w : getServer().getWorlds()) {
				    		w.setTime(0);
							w.setWeatherDuration(0);
							w.setStorm(false);
							w.setThunderDuration(0);
							w.setThundering(false);
				    	}
				    }
			    }, 0, 20*60*3);
				SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	TipHandler.send();
				    }
			    }, 20 * 60 * (int)(Math.random() * 10 + 1), 20 * 60 * (int)(Math.random() * 10 + 1));
			}
		}, 5);
	}
	
	public ArrayList<String> loading = new ArrayList<String>();
	
	public void loadPlayer(final Player player) {
		if(!player.isOnline() || players.containsKey(player.getName()))
			return;
		if(!loading.contains(player.getName())) {
			player.getInventory().clear();
			player.getInventory().setArmorContents(new ItemStack[player.getInventory().getArmorContents().length]);
			player.updateInventory();
			loading.add(player.getName());
		}
		getServer().getScheduler().scheduleSyncDelayedTask(this, new Runnable() {
			public void run() {
				if(players.containsKey(player.getName()))
					return;
				PlayerData pd = new PlayerData(player);
				players.put(player.getName(), pd);
				Score score = hpBoard.getObjective("hpdisplay").getScore(player);
				score.setScore(getPD(player).hp);
				player.setScoreboard(hpBoard);
				PlayerInventory i = player.getInventory();
				ItemHandler.loadItem(i.getHelmet());
				ItemHandler.loadItem(i.getChestplate());
				ItemHandler.loadItem(i.getLeggings());
				ItemHandler.loadItem(i.getBoots());
				ItemHandler.loadItem(i.getItemInHand());
				pd.region = RegionHandler.getRegion(player.getLocation());
				
				/*
				 * Repeating Tasks
				 */
				
				getPD(player).taskIds.add(SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    @SuppressWarnings("deprecation")
					public void run() {
				    	if(!player.isDead()) {
				    		getPD(player).updateHealth();
				    	}
				    }
			    }, 0, 5)); 
				
				getPD(player).taskIds.add(SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	if(!player.isDead())
				    		getPD(player).recoverHealth();
				    }
			    }, 0, 20));

				getPD(player).taskIds.add(SuperDebugger.scheduleSyncRepeatingTask(RonboMC.class.getClass(), plugin, new Runnable() {
				    public void run() {
				    	for(Party party : Party.parties) {
				    		Player p = player;
				    		if(party == plugin.getPD(p).party) {
								Score score1 = party.partyBoard.getObjective("party").getScore(p);
						    	if(!p.isDead())
						    		score1.setScore(plugin.getPD(p).hp);
						    	else
						    		score1.setScore(0);
				    		}
							Score score2 = party.partyBoard.getObjective("hpdisplay").getScore(p);
					    	if(!p.isDead())
					    		score2.setScore(plugin.getPD(p).hp);
					    	else
					    		score2.setScore(0);
				    	}
						Score score = hpBoard.getObjective("hpdisplay").getScore(player);
				    	if(!player.isDead())
				    		score.setScore(getPD(player).hp);
				    	else
				    		score.setScore(0);
				    }
			    }, 6, 5));
				
			}
		}, 5);
	}
	
	public synchronized CachedRowSet executeSynchronizedQuery(String s) {
		return SQLManager.executeQuery(s);
	}
	
	public int querycount = 0;
	
	public CachedRowSet executeQuery(String s) {
		return SQLManager.executeQuery(s);
	}
	
	public void executePrepared(final String input, final String... values) {
		executePrepared(input, false, values);
	}
	
	public void executePrepared(final String input, final boolean forced, final boolean channelChange, final Player toChange, final String channelName, final String... values) {
		if(forced) {
			SQLManager.executePrepared(input, forced, values);
		} else {
			SuperDebugger.runTaskAsynchronously(RonboMC.class.getClass(), plugin, new Runnable() {
				public void run() {
					SQLManager.executePrepared(input, forced, values);
					if(channelChange) {
						ChannelManager.sendChannelChange(toChange, channelName);
					}
				}
			});
		}
	}
	
	public void executePrepared(final String input, final boolean forced, final String... values) {
		executePrepared(input,forced,false,null,null,values);
	}
	
	public void execute(final String input) {
		SQLManager.execute(input);
	}
	
	public PlayerData getPD(Player p) {
		if(p == null || p.getName() == null)
			return null;
		PlayerData pd = players.get(p.getName());
		if(pd != null)
			return pd;
		loadPlayer(p);
		pd = players.get(p.getName());
		return pd;
	}

	public PlayerData getPD(String pName) {
		return getPD(getServer().getPlayerExact(pName));
	}
	
	public void db(Player p, Object o) {
		if(plugin.getPD(p).options.checkOption("debug")) {
			String s = o.toString();
			if(s.equals(ChatColor.stripColor(o.toString()))) {
				p.sendMessage("       > " + ChatColor.YELLOW + ChatColor.stripColor(s));
			} else {
				p.sendMessage("       > " + s);
			}
		} else {
			if(plugin.getPD(p).options.checkOption("damage")) {
				String s = o.toString();
				if(s.contains(ChatColor.BOLD + "")) {
					if(s.equals(ChatColor.stripColor(o.toString()))) {
						p.sendMessage("       > " + ChatColor.YELLOW + ChatColor.stripColor(s));
					} else {
						p.sendMessage("       > " + s);
					}
				}
			}
		}
	}
    
	public void onDisable() {
		for(Entry<Block, Material> e : GeneralListeners.rebuildBlocksMaterial.entrySet()) {
			if(GeneralListeners.rebuildBlocksData.containsKey(e.getKey())) {
				e.getKey().setType(e.getValue());
				e.getKey().setData(GeneralListeners.rebuildBlocksData.get(e.getKey()));
			}
		}
		GeneralListeners.rebuildBlocksMaterial.clear();
		GeneralListeners.rebuildBlocksData.clear();
		DungeonHandler.forceCleanup();
		for(Player p : getServer().getOnlinePlayers()) {
			getPD(p).save(true);
			players.remove(p);
		}
		for(World w: getServer().getWorlds()) {
			for(Entity e : w.getEntities()) {
				if(e instanceof LivingEntity && !(e instanceof Player))
					e.remove();
			}
		}
		getServer().getScheduler().cancelAllTasks();
		for(int k = 0; k < getServer().getScheduler().getActiveWorkers().size(); k++) {
			BukkitWorker bw = getServer().getScheduler().getActiveWorkers().get(k);
			getServer().getScheduler().cancelTask(bw.getTaskId());
		}
		for(int k = 0; k < getServer().getScheduler().getPendingTasks().size(); k++) {
			BukkitTask bw = getServer().getScheduler().getPendingTasks().get(k);
			getServer().getScheduler().cancelTask(bw.getTaskId());
		}
		getServer().getScheduler().cancelTasks(this);
		CustomEntityType.unregisterEntities();
		players = null;
		getLogger().info("Disabling...");
	}
	
}
