package xronbo.ronbomc.dungeons;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobDrop;

public class DungeonHandler {
	
	public static RonboMC plugin;
	public static HashMap<String, Dungeon> loadedDungeons = new HashMap<String, Dungeon>(); 
	
	public static void enterInstance(Player p, String instanceName) {
		PlayerData pd = plugin.getPD(p);
		p.sendMessage(ChatColor.GREEN + "Preparing new instance... You will be warped in automatically.");
		if(pd.inDungeon) {
			p.sendMessage(ChatColor.RED + "You are already in a dungeon!");
			return;
		}
		plugin.getPD(p).waitingForDungeonEnter = false;
		Dungeon d = loadedDungeons.get(instanceName);
		d.createInstance(p);
	}
	
	public static void leaveInstance(Player p) {
		leaveInstance(p, false, false);
	}
	
	public static void leaveInstance(final Player p, boolean completed, boolean forced) {
		Dungeon d;
		try {
			d = loadedDungeons.get(plugin.getPD(p).dungeon);
		} catch(Exception e) {
			return;
		}
		if(d == null)
			return;
		final World w = p.getWorld();
		final String dungeonFile = plugin.getPD(p).dungeonFile;
		if(!completed)
			p.sendMessage("You have left " + d.worldName + ".");
		plugin.getPD(p).dungeon = "";
		plugin.getPD(p).inDungeon = false;
		plugin.getPD(p).dungeonFile = "";
		p.teleport(d.originalLocations.get(p.getName()));
		SuperDebugger.scheduleSyncDelayedTask(DungeonHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				if(w.getPlayers().size() == 0 || (w.getPlayers().size() == 1 && w.getPlayers().get(0) == p)) {
					w.setKeepSpawnInMemory(false);
					plugin.getServer().unloadWorld(w, false);
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							System.out.println("Deleting dungeon " + dungeonFile);
							Dungeon.deleteFiles(new File(dungeonFile), false);
						}
					}, 5);
				}
			}
		}, 5);
	}

	public static void forceCleanup() {
		for(Player p : plugin.getServer().getOnlinePlayers()) {
			leaveInstance(p, false, true);
		}
		for(File f : new File("./").listFiles()) { 
			if(f.toPath().toString().contains("+di+")) {
				FileUtils.deleteQuietly(f);
			}
		}
	}
	
	public static boolean checkIsDungeon(Location loc) {
		World w = loc.getWorld();
		for(Dungeon d : loadedDungeons.values()) {
			if(d.worldName.contains(w.getName()) || w.getName().contains(d.worldName)) 
				return true;
		}
		return false;
	}
	
	public static void loadMobSpawns() {
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "dungeonspawns.dat"));
			while(scan.hasNextLine()) {
				ArrayList<String> spawns = new ArrayList<String>();
				String s = scan.nextLine();
				Dungeon d = loadedDungeons.get(s.trim());
				if(d != null) {
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.length() == 0 || !Character.isDigit(s.charAt(0)))
							break;
						spawns.add(s);
					}
					d.spawns = spawns;
				} else {
					System.out.println("UH OH! COULDN'T FIND DUNGEON " + s + " when loading spawns!");
					break;
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void loadRewards() {
		int total = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "dungeonrewards.dat"));
			while(scan.hasNextLine()) {
				String s = scan.nextLine();
				Dungeon d = loadedDungeons.get(s.trim());
				if(d != null) {
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.length() == 0 || s.split(" ").length != 2)
							break;
						total++;
						if(s.split(" ")[0].equalsIgnoreCase("exp")) {
							d.rewardExp = Integer.parseInt(s.split(" ")[1]);
						} else {
							int count = Integer.parseInt(s.split(" ")[1]);
							for(int k = 0; k < count; k++)
								d.rewards.add(MobDrop.getDrop(s.split(" ")[0]));
						}
					}
				} else {
					System.out.println("UH OH! COULDN'T FIND DUNGEON " + s + " when loading rewards!");
					break;
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Loaded " + total + " dungeon rewards.");
	}
	
	public static void load() {
		for(File f : new File("./").listFiles()) {
			if(f.toPath().toString().endsWith("_template")) {
				String dungeonName = f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1, f.toPath().toString().indexOf("_template"));
				loadedDungeons.put(dungeonName, new Dungeon(dungeonName, f));
				plugin.getServer().createWorld(new WorldCreator(f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1)));
			}
		}
		loadMobSpawns();
		loadRewards();
		System.out.println("Loaded " + loadedDungeons.values().size() + " dungeons.");
	}
	
}