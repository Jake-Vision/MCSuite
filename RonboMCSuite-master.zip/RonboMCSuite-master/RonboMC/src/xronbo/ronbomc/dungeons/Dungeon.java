package xronbo.ronbomc.dungeons;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.regions.RegionHandler;

public class Dungeon {
	public static RonboMC plugin;
	
	public String worldName = "";
	public File originalPath;
	public File newPath;
	public HashMap<String, String> instanceIDs;
	public HashMap<String, Location> originalLocations;
	public ArrayList<ItemStack> rewards;
	public ArrayList<String> spawns;
	public int rewardExp;
	
	public Dungeon(String worldName, File path) {
		this.worldName = worldName;
		this.originalPath = path;
		this.originalLocations = new HashMap<String, Location>();
		this.instanceIDs = new HashMap<String, String>();
		this.rewards = new ArrayList<ItemStack>();
		this.spawns = new ArrayList<String>();
		this.worldName = originalPath.toPath().toString().substring(originalPath.toPath().toString().lastIndexOf(File.separator) + 1, originalPath.toPath().toString().indexOf("_template"));
		this.newPath = new File(originalPath.toPath().toString().substring(0, originalPath.toPath().toString().indexOf("_template")));
	}
	
	public HashMap<String, Long> lastenter = new HashMap<String, Long>();
	
	public void createInstance(final Player p) {
		if(lastenter.containsKey(p.getName())) {
			if(System.currentTimeMillis() - lastenter.get(p.getName()) < 5 * 1000 * 60) {
				p.sendMessage(ChatColor.RED + "You can only enter the same dungeon once every 5 minutes!");
				return;
			}
		}
		lastenter.put(p.getName(), System.currentTimeMillis());
		instanceIDs.put(p.getName(), p.getUniqueId().toString() + String.format("%.5f", Math.random()));
		final File f = new File(newPath.toString() + "_" + instanceIDs.get(p.getName()) + "+di+");
		final String fileName = newPath.toString() + "_" + instanceIDs.get(p.getName()) + "+di+";
		SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
			public void run() {
				copyFiles(originalPath, f);
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						if(p == null || !p.isValid() || !p.isOnline())
							return;
						String worldToLoad = worldName + "_" + instanceIDs.get(p.getName()) + "+di+";
						World w = plugin.getServer().createWorld(new WorldCreator(worldToLoad));
						for(Entity e : w.getEntities()) {
							if(e instanceof LivingEntity && !(e instanceof Player))
								e.remove();
						}
						populateDungeon(w, worldToLoad);
						PlayerData pd = plugin.getPD(p);
						ArrayList<Player> players = new ArrayList<Player>();
						players.add(p);
						if(pd.party != null && pd.party.leader.equalsIgnoreCase(p.getName())) {
							for(Player partyMember : pd.party.getMembers()) {
								if(partyMember != p) {
									try {
										if(partyMember.getLocation().distance(p.getLocation()) > 15) {
											partyMember.sendMessage(ChatColor.RED + "Your party leader entered the dungeon " + worldName + " but you were too far away to join in.");
										} else {
											players.add(partyMember);
										}
									} catch(Exception e) {
										partyMember.sendMessage(ChatColor.RED + "Your party leader entered the dungeon " + worldName + " but you were too far away to join in.");
									}
								}
							}
						}
						for(Player p_temp : players) {
							PlayerData pd_temp = plugin.getPD(p_temp);
							originalLocations.put(p_temp.getName(), p_temp.getLocation());
							p_temp.teleport(w.getSpawnLocation());
							p_temp.sendMessage("");
							p_temp.sendMessage(ChatColor.GREEN + "Welcome to " + worldName + "!");
							p_temp.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/leavedungeon" + ChatColor.GREEN + " at any time to leave this dungeon.");
							pd_temp.dungeon = worldName;
							pd_temp.dungeonFullName = worldToLoad;
							pd_temp.inDungeon = true;
							pd_temp.waitingForDungeonEnter = false;
							pd_temp.dungeonFile = fileName;
							pd_temp.makeVisible();
						}
					}
				});
			}
		});
	}
	
	public int bossLevel = 0;
	
	public void populateDungeon(World w, String dungeonFullName) {
		if(spawns == null) {
			System.out.println("Error: Found no spawns for dungeon " + worldName);
			return;
		}
		for(Entity e : w.getEntities())
			if(e instanceof LivingEntity && !(e instanceof Player))
				e.remove();
		for(String s : spawns) {
			String[] data = s.split(" ");
			boolean boss = data.length == 5 && data[4].equalsIgnoreCase("boss");
			int id = Integer.parseInt(data[0]);
			int x = Integer.parseInt(data[1]);
			int y = Integer.parseInt(data[2]);
			int z = Integer.parseInt(data[3]);
			MobData md = MobHandler.createDungeonMob(id, new Location(w, x, y, z), RegionHandler.wholeWorld);
			if(boss) {
				md.isDungeonBoss = true;
				md.dungeon = this;
				bossLevel = md.mobType.level;
			}
			md.dungeonFullName = dungeonFullName;
			md.isDungeonMob = true;
		}
		for(Entity e : w.getEntities())
			if(e instanceof LivingEntity && !(e instanceof Player))
				e.remove();
	}
	
	public void complete(Player p) {
		p.sendMessage(ChatColor.GOLD + "Congratulations, you have cleared " + worldName + "!");
		for(ItemStack i : rewards) {
			p.getInventory().addItem(i);
		}
		plugin.getPD(p).addExp(rewardExp);
		plugin.getPD(p).addGuildPoints(bossLevel * 4);
		DungeonHandler.leaveInstance(p, true, false);
	}
	
	public static void deleteFiles(final File f, final boolean forced) {
		if(!forced) {
			SuperDebugger.runTaskAsynchronously(Dungeon.class.getClass(), plugin, new Runnable() {
				public void run() {
					FileUtils.deleteQuietly(f);
				}
			});
		} else {
			FileUtils.deleteQuietly(f);
		}
	}
	
	public synchronized void copyFiles(File orig, File destFolder) {
		destFolder.mkdirs();
		for(File f : orig.listFiles()) {
			try {
				File destination = new File(destFolder.toString() + f.toString().substring(originalPath.toPath().toString().length()));
				if(destination.isDirectory())
					destination.mkdirs();
				else if(destination.isFile())
					destination.createNewFile();
				if(!f.toPath().toString().contains("uid.dat"))
					Files.copy(f.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		for(File f : orig.listFiles()) {
			if(f.isDirectory()) {
				copyFiles(f, destFolder);
			}
		}
	}
	
	public boolean equals(Object other) {
		return ((Dungeon)other).worldName.equals(this.worldName);
	}
}