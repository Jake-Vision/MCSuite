package xronbo.ronbomc.rewards;



public class RewardHandler {
	
//	public static RonboMC plugin;
//	
//	public static void registerReward(String player, int id) {
//		Player p = plugin.getServer().getPlayerExact(player);
//		if(p != null) {
//			if(!reward(p, id)) {
//				storeReward(player, id);
//			}
//		} else {
//			storeReward(player, id);
//		}
//	}
//	
//	public static void storeReward(String player, int id) {
//		plugin.execute("UPDATE rpg SET rewards = " + "concat(rewards, '" + id + " ')" + " WHERE name='" + player + "'");
//		System.out.println("Stored reward ID " + id + " for player " + player);
//	}
//	
//	public static void giveVipDays(Player p, int days) {
//		PlayerData pd = plugin.getPD(p);
//		if(pd.rank < Values.RANK_KNIGHT) {
//			pd.rank = Values.RANK_VIP;
//			pd.rankString = "vip";
//			p.sendMessage("Congratulations! You are now a VIP player!");
//		}
//		if(pd.vipExpiryDate == null) {
//			pd.vipExpiryDate = new Date();
//		}
//		Calendar c = Calendar.getInstance();
//		c.setTime(pd.vipExpiryDate);
//		c.add(Calendar.DATE, days);
//		pd.vipExpiryDate = c.getTime();
//		p.sendMessage(ChatColor.GOLD + "You have received " + days + " days of VIP.");
//		p.sendMessage(ChatColor.GOLD + "Your VIP will last until " + PlayerData.dateformat.format(pd.vipExpiryDate) + ".");
//	}
//	
//	public static boolean reward(Player p, int id) {
//		ArrayList<ItemStack> reward = new ArrayList<ItemStack>();
//		PlayerData pd = plugin.getPD(p);
//		String name = "";
//		String note = "";
//		int vip = 0;
//		String[] contents = null;
//		boolean silent = false;
//		String petType = "";
//		switch(id) {
//			case 1:
//				name = "VIP Membership (30 days)";
//				contents = new String[] {
//						"30 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 30;
//				break;
//			case 2:
//				name = "VIP Membership (60 days)";
//				contents = new String[] {
//						"60 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 60;
//				break;
//			case 3:
//				name = "VIP Membership (120 days)";
//				contents = new String[] {
//						"120 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 120;
//				break;
//			case 4:
//				name = "VIP Enchant Scroll 100% (+10)";
//				reward.addAll(Arrays.asList(ItemHandler.makeUntradeable(EtcItem.VIPENCHANTSCROLL_100_10.makeItems(1)[0])));
//				contents = new String[] {
//						"VIP Enchant Scroll 100% (+10)",
//						"10 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 10;
//				break;
//			case 5:
//				name = "VIP Enchant Scroll 100% (+20)";
//				reward.addAll(Arrays.asList(ItemHandler.makeUntradeable(EtcItem.VIPENCHANTSCROLL_100_20.makeItems(1)[0])));
//				contents = new String[] {
//						"VIP Enchant Scroll 100% (+20)",
//						"10 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 10;
//				break;
//			case 6:
//				name = "VIP Enchant Scroll 100% (+30)";
//				reward.addAll(Arrays.asList(ItemHandler.makeUntradeable(EtcItem.VIPENCHANTSCROLL_100_30.makeItems(1)[0])));
//				contents = new String[] {
//						"VIP Enchant Scroll 100% (+30)",
//						"10 days of VIP",
//				};
//				note = "Thank you for your purchase! Players like you keep the server alive!";
//				vip = 10;
//				break;
//			case 7:
//				name = "Name an NPC";
//				contents = new String[] {
//						"One permanent NPC with user-defined name, dialogue, and location.",
//						"10 days of VIP",
//				};
//				note = "Please wait up to 1 week for your NPC. If it still hasn't been added, please contact Ronbo directly on the forums.";
//				vip = 10;
//				break;
//			case 8:
//				name = "VIP Membership (Permanent)";
//				contents = new String[] {
//						"VIP forever! Thanks for your support!",
//				};
//				note = "Have fun with that permanent VIP, buddy.";
//				vip = 10950;
//				break;
//			case 9:
//				name = "Pegasus";
//				contents = new String[] {
//						"Pegasus, the flying horse. Use /flyhorse or /pegasus!",
//						"30 days of VIP",
//				};
//				note = "Yeah it's time to fly!";
//				pd.flyhorse = true;
//				vip = 30;
//				break;
//			case 10:
//				silent = true;
//				name = "Vote Reward";
//				contents = new String[] {
//						"One Vote Point for usage in /votepoints",
//				};
//				break;
//			case 11:
//				petType = "babychicken";
//				break;
//			case 12:
//				petType = "babypig";
//				break;
//			case 13:
//				petType = "babycow";
//				break;
//			case 14:
//				petType = "sheep";
//				break;
//			case 15:
//				petType = "babysheep";
//				break;
//			case 16:
//				petType = "spider";
//				break;
//			case 17:
//				petType = "cavespider";
//				break;
//			case 18:
//				petType = "irongolem";
//				break;
//			case 19:
//				petType = "mushroomcow";
//				break;
//			case 20:
//				petType = "babymushroomcow";
//				break;
//			case 21:
//				petType = "pigzombie";
//				break;
//			case 22:
//				petType = "babypigzombie";
//				break;
//			case 23:
//				petType = "skeleton";
//				break;
//			case 24:
//				petType = "wolf";
//				break;
//			case 25:
//				petType = "angrywolf";
//				break;
//			case 26:
//				petType = "zombie";
//				break;
//			case 27:
//				petType = "babyzombie";
//				break;
//			case 28:
//				petType = "creeper";
//				break;
//			case 30:
//				petType = "ocelot";
//				break;
//			case 31:
//				petType = "babyocelot";
//				break;
//			case 32:
//				petType = "babywolf";
//				break;
//			case 33:
//				petType = "witherskeleton";
//				break;
//			case 34:
//				name = "Pet Name Change";
//				reward.add(ItemHandler.makeUntradeable(EtcItem.PET_NAME_CHANGE.makeItems(1)[0]));
//				contents = new String[] {
//						"Pet Name Change Item",
//						"10 days of VIP",
//				};
//				note = "Thanks for your purchase! Hover over your Pet Name Change to see how to use it.";
//				vip = 10;
//				break;
//			case 0:
//				return false;
//			default:
//				note = "Please report this to Ronbo. You were somehow given an invalid reward ID. The reward ID was " + id + ". Thanks for your help, your inconvenience will be compensated! MAKE SURE YOU TAKE A SCREENSHOT OF THIS.";
//				System.out.println("Player " + p.getName() + " was given an invalid reward ID (" + id + ")");
//				return false;
//		}
//		if(petType.length() > 0) {
//			name = Pet.getDisplayTypeStatic(petType);
//			contents = new String[] {
//					Pet.getDisplayTypeStatic(petType) + " Pet Type",
//					"10 days of VIP",
//			};
//			note = "Thank you for your support! Switch to your new pet type in /pet.";
//			PetHandler.givePet(p, petType);
//			vip = 10;
//		}
//		int empty = 0;
//		for(int k = 0; k < p.getInventory().getContents().length; k++)
//			if(p.getInventory().getContents()[k] == null || p.getInventory().getContents()[k].getType() == Material.AIR)
//				empty++;
//		if(empty < reward.size() && !silent) {
//			p.sendMessage(ChatColor.GOLD + "There is a reward waiting for you, but you need " + reward.size() + " inventory slots to get it!");
//			p.sendMessage(ChatColor.GOLD + "Relog when you are ready to receive your reward!");
//			return false;
//		} else {
//			if(reward.size() > 0)
//				p.getInventory().addItem(reward.toArray(new ItemStack[reward.size()]));
//			if(!silent)
//				p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Congratulations! You have received a reward!");
//			if(name.length() > 0 && !silent)
//				p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Reward Name: " + ChatColor.GOLD + name);
//			if(contents != null && !silent) {
//				p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Contents: ");
//				for(String s : contents)
//					p.sendMessage(ChatColor.GOLD + "- " + s);
//			}
//			if(note.length() > 0 && !silent) {
//				p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Note: ");
//				p.sendMessage("" + ChatColor.GOLD + note);
//			}
//			if(vip > 0)
//				giveVipDays(p, vip);
//			System.out.println("Distributed reward ID " + id + " to " + p.getName());
//			p.updateInventory();
//			if(pd.rewards.contains(id))
//				pd.receivedRewards.add(id);
//			if(id == 10)
//				pd.voted();
//			else 
//				plugin.getServer().broadcastMessage(ChatColor.GOLD + p.getName() + " has just purchased " + name + "! Thanks for your support!");
//			if(petType.length() > 0)
//				plugin.getServer().broadcastMessage(ChatColor.GOLD + "Get your own pet types at store.kastia.net !");
//			return true;
//		}
//	}
//	
//	private RewardHandler() {
//		
//	}
	
}