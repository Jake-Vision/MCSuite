package xronbo.ronbomc.chests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import net.minecraft.server.v1_8_R1.TileEntityChest;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.craftbukkit.v1_8_R1.block.CraftChest;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemHandler;


public class ChestHandler implements Listener {
	
	public static RonboMC plugin;
	public static ArrayList<LootChest> chests;
	
	public static void load() {
		chests = new ArrayList<LootChest>();
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "chests.dat"));
			while(scan.hasNextLine()) {
				LootChest c = new LootChest(scan.nextLine());
				if(c.loaded) {
					chests.add(c);
					c.spawn();
				}
			}
			scan.close();
			System.out.println("Loaded " + chests.size() + " loot chests.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean addNewChest(Block b, int tier) {
		if(b.getType() != Material.CHEST)
			return false;
		LootChest c = new LootChest(b, tier);
		for(LootChest c2 : chests)
			if(c.equals(c2))
				return false;
		chests.add(c);
		c.spawn();
		save();
		return true;
	}
	
	public static boolean removeChest(Block b) {
		LootChest toRemove = null;
		for(LootChest c : chests) {
			if(c.b.getLocation().equals(b.getLocation())) {
				toRemove = c;
				break;
			}
		}
		if(toRemove == null)
			return false;
		chests.remove(toRemove);
		b.setType(Material.AIR);
		save();
		return true;
	}

	public static void save() {
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(plugin.getDataFolder() + File.separator + "chests.dat"))));
			for(LootChest c : chests)
				out.println(c.toString());
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@EventHandler
	public void onChestOpen(PlayerInteractEvent event) {
		try {
			Block b = event.getClickedBlock();
			if(b.getType() == Material.CHEST || b.getType() == Material.TRAPPED_CHEST) {
				boolean foundLootChest = false;
				for(LootChest lc : chests) {
					if(lc.b.equals(b)) {
						foundLootChest = true;
						Chest c = (Chest)b.getState();
						if(lc.firstOpen) {
							c.getInventory().clear();
							c.getBlockInventory().clear();
							c.getBlockInventory().addItem(LootChest.generateContents(lc.tier));
							lc.firstOpen = false;
						}
						break;
					}
				}
				if(!foundLootChest && event.getPlayer().getGameMode() != GameMode.CREATIVE) {
					event.getPlayer().sendMessage(ChatColor.RED + "The chest is firmly locked.");
					event.setCancelled(true);
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void onChestClose(InventoryCloseEvent event) {
		if(event.getInventory().getType() == InventoryType.CHEST) {
			boolean isEmpty = true;
			for(ItemStack i : event.getInventory().getContents()) {
				if(i != null && i.getType() != Material.AIR) {
					isEmpty = false;
					break;
				}
			}
			if(isEmpty) {
				for(final LootChest lc : chests) {
					if(lc.b.getType() == Material.CHEST) {
						boolean lcEmpty = true;
						if(LootChest.getName(lc.tier).equals(event.getInventory().getName())) {
							try {
								for(ItemStack i : ((Chest)(lc.b.getState())).getBlockInventory().getContents()) {
									if(i != null && i.getType() != Material.AIR) {
										lcEmpty = false;
										break;
									}
								}
							} catch(Exception e2) {
								
							}
							if(lcEmpty) {
								lc.b.setType(Material.AIR);
								lc.b.getLocation().getWorld().playSound(lc.b.getLocation(), Sound.STEP_WOOD, 1, 1);
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										lc.spawn();
									}
								}, (int)(Math.random() * 20 * 120 + 20 * 90));
							}
						}
					}
				}
			}
		}
	}
	
	public ChestHandler(RonboMC p) {
		ChestHandler.plugin = p;
	}
	
	public static class LootChest {
		public int x, y, z, tier;
		public Block b;
		public World world;
		public boolean loaded = false;
		public boolean firstOpen = true;
		
		public LootChest(Block b, int tier) {
			this.x = b.getLocation().getBlockX();
			this.y = b.getLocation().getBlockY();
			this.z = b.getLocation().getBlockZ();
			this.world = b.getLocation().getWorld();
			this.tier = tier;
			this.b = b;
			loaded = true;
		}
		
		public LootChest(String s) {
			try {
				String data[] = s.split(" ");
				this.x = Integer.parseInt(data[0]);
				this.y = Integer.parseInt(data[1]);
				this.z = Integer.parseInt(data[2]);
				this.world = plugin.getServer().getWorld(data[3]);
				this.tier = Integer.parseInt(data[4]);
				this.b = world.getBlockAt(x, y, z);
				loaded = true;
			} catch(Exception e) {
				System.out.println("WARNING: CHEST \"" + s + "\" IS BROKEN!");
				e.printStackTrace();
			}
		}

		public boolean equals(Object other) {
			LootChest lc = (LootChest)other;
			return lc.x == x && lc.y == y && lc.z == z && lc.world.getName().equalsIgnoreCase(world.getName());
		}
		
		public String toString() {
			return x + " " + y + " " + z + " " + world.getName() + " " + tier;
		}
		
		public void spawn() {
			firstOpen = true;
			if(tier < 1)
				tier = 1;
			if(tier > 5)
				tier = 6;
			b.setType(Material.CHEST);
			if(!b.getChunk().isLoaded()) {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						spawn();
					}
				}, (int)(Math.random() * 20 * 120 + 20 * 90));
				return;
			}
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					try {
						if(b.getState() instanceof Chest) {
							Chest c = (Chest)(b.getState());
							CraftChest cc = (CraftChest)(b.getState());
							try {
								Field inventoryField = cc.getClass().getDeclaredField("chest");
								inventoryField.setAccessible(true);
								TileEntityChest teChest = ((TileEntityChest)(inventoryField.get(cc)));
								teChest.a(getName(tier));
							} catch(Exception e) {
//								e.printStackTrace();
							}
							c.getBlockInventory().clear();
							c.getBlockInventory().setContents(new ItemStack[0]);
							c.update();
						} else {
							System.out.println("Error loading loot chest " + this);
						}
					} catch(Exception e) {
//						e.printStackTrace();
						System.out.println(this.toString() + " LOOT CHEST AT " + x + "," + y + "," + z + " IS BROKEN.");
					}
				}
			}, 1);
		}
		
		public static String getName(int tier) {
			String prefix = "";
			switch(tier) {
				default:
				case 1:
					prefix = ChatColor.BLACK + "Standard";
					break;
				case 2:
					prefix = ChatColor.BLUE + "Fancy";
					break;
				case 3:
					prefix = ChatColor.DARK_BLUE + "Glowing";
					break;
				case 4:
					prefix = ChatColor.DARK_PURPLE + "War Era";
					break;
				case 5:
					prefix = ChatColor.GOLD + "Heavenly";
					break;
				case 6:
					prefix = ChatColor.DARK_RED + "Mysterious";
					break;
			}
			return prefix + " Loot Chest";
		}
		
		public static Object[][][] lootTable = new Object[][][] {
			{ //Tier 1 Loot
				{0.5, EtcItem.HP_POTION_1, 3},
				{0.5, EtcItem.HP_POTION_1, 2},
				{0.5, EtcItem.HP_POTION_1, 3},
				{0.5, 1, 1},
				{0.3, 1, 2},
			},
			{ //Tier 2 Loot
				{0.75, EtcItem.HP_POTION_1, 5},
				{0.5, EtcItem.HP_POTION_2, 3},
				{0.75, EtcItem.HP_POTION_1, 5},
				{0.5, EtcItem.HP_POTION_2, 3},
				{0.4, 1, 2},
				{0.1, 2, 1},
			},
			{ //Tier 3 Loot
				{0.5, EtcItem.HP_POTION_2, 5},
				{0.2, EtcItem.HP_POTION_3, 3},
				{0.5, EtcItem.HP_POTION_2, 5},
				{0.2, EtcItem.HP_POTION_3, 3},
				{0.2, 2, 1},
				{0.15, 2, 2},
			},
			{ //Tier 4 Loot
				{0.7, EtcItem.HP_POTION_2, 3},
				{0.3, EtcItem.HP_POTION_3, 5},
				{0.2, EtcItem.HP_POTION_4, 2},
				{0.7, EtcItem.HP_POTION_2, 3},
				{0.3, EtcItem.HP_POTION_3, 5},
				{0.2, EtcItem.HP_POTION_4, 2},
				{0.1, 3, 1},
				{0.2, 2, 2},
			},
			{ //Tier 5 Loot
				{0.8, EtcItem.HP_POTION_3, 3},
				{0.4, EtcItem.HP_POTION_4, 5},
				{0.1, EtcItem.HP_POTION_5, 2},
				{0.15, 3, 1},
				{0.25, 2, 2},
				{0.25, 2, 2},
			},
			{ //Tier 6 Loot
				{0.7, EtcItem.HP_POTION_4, 5},
				{0.3, EtcItem.HP_POTION_5, 3},
				{0.1, EtcItem.HP_POTION_6, 1},
				{0.1, EtcItem.HP_POTION_6, 1},
				{0.1, EtcItem.HP_POTION_6, 1},
				{0.03, 4, 2},
				{0.2, 3, 2},
				{0.2, 3, 2},
			},
		};
		
		public static ItemStack[] generateContents(int tier) {
			ArrayList<ItemStack> items = new ArrayList<ItemStack>();
			while(items.size() == 0) {
				for(Object[] o : lootTable[tier - 1]) {
					if(Math.random() < (double)o[0]) {
						int count = (int)(Math.random() * (int)o[2]);
						if(count == 0)
							count = 1;
						if(o[1] instanceof EtcItem)
							items.addAll(Arrays.asList(((EtcItem)o[1]).makeItems(count)));
						else if(o[1] instanceof Integer) {
							for(int k = 0; k < count; k++)
								items.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), (int)(o[1])));
						}
					}
				}
			}
			return items.toArray(new ItemStack[items.size()]);
		}
	}
	
}