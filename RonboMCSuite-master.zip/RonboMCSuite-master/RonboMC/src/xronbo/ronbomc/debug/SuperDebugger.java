package xronbo.ronbomc.debug;

import java.util.concurrent.ConcurrentHashMap;

import xronbo.ronbomc.RonboMC;

public class SuperDebugger {
	
	public static final boolean ACTIVE_PRINTLN = false;
	
	public static ConcurrentHashMap<Integer, String> createdSyncTasks = new ConcurrentHashMap<Integer, String>();
	public static ConcurrentHashMap<Integer, String> createdSyncRepeatingTasks = new ConcurrentHashMap<Integer, String>();
//	public static HashMap<Integer, String> createdAsyncTasks = new HashMap<Integer, String>();
	
	public static String getTask(int i) {
		if(createdSyncTasks.containsKey(i)) {
			return createdSyncTasks.get(i) + "  <- Sync Task";
		} else if(createdSyncRepeatingTasks.containsKey(i)) {
			return createdSyncTasks.get(i) + "  <- Sync Repeating Task";
//		} else if(createdAsyncTasks.containsKey(i)) {
//			return createdSyncTasks.get(i) + "  <- Async Task";
		}
		return "";
	}
	
	public static int scheduleSyncDelayedTask(Class<?> eda, RonboMC plugin, Runnable runnable) {
		if(ACTIVE_PRINTLN)
			System.out.println("Scheduling sync task from class " + eda.getName());
		int i = plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, runnable);
		String s = eda.getName();
		createdSyncTasks.put(i, s);
		return i;
	}
	
	public static int scheduleSyncDelayedTask(Class<?> eda, RonboMC plugin, Runnable runnable, int delayTicks) {
		if(ACTIVE_PRINTLN)
			System.out.println("Scheduling sync delayed task from class " + eda.getName());
		int i = plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, runnable, delayTicks);
		String s = eda.getName();
		createdSyncTasks.put(i, s);
		return i;
	}
	
	public static int scheduleSyncRepeatingTask(Class<?> eda, RonboMC plugin, Runnable runnable, int delayTicks, int runAfter) {
		if(ACTIVE_PRINTLN)
			System.out.println("Scheduling sync repeating task from class " + eda.getName());
		int i = plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, runnable, delayTicks, runAfter);
		String s = eda.getName();
		createdSyncRepeatingTasks.put(i, s);
		return i;
	}
	
	public static int runTaskAsynchronously(Class<?> eda, RonboMC plugin, Runnable runnable) {
		if(ACTIVE_PRINTLN)
			System.out.println("Scheduling async task from class " + eda.getName());
		int i = plugin.getServer().getScheduler().runTaskAsynchronously(plugin, runnable).getTaskId();
//		createdAsyncTasks.put(i, eda.getName());
		return i;
	}
	
	public static int runTaskAsynchronouslyLater(Class<?> eda, RonboMC plugin, Runnable runnable, int delayTicks) {
		if(ACTIVE_PRINTLN)
			System.out.println("Scheduling sync delayed task from class " + eda.getName());
		int i = plugin.getServer().getScheduler().runTaskLaterAsynchronously(plugin, runnable, delayTicks).getTaskId();
//		createdAsyncTasks.put(i, eda.getName());
		return i;
	}
	
	private SuperDebugger() {
		
	}
	
}