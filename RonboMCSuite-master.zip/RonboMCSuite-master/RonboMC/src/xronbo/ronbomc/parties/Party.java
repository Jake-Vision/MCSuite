package xronbo.ronbomc.parties;

import java.util.ArrayList;
import java.util.List;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;

import xronbo.ronbomc.RonboMC;

public class Party {

	public static final int MAX_PARTY_SIZE = 10;
	public static RonboMC plugin;
	public static int currentPartyId = 1;
	public static List<Party> parties = new ArrayList<Party>();
	
	public Scoreboard partyBoard;
	
	public int partyId;
	
	public ArrayList<String> members;
	public ArrayList<String> pendingRequests;
	public String leader;
	public boolean joinRequestsOff;
	
	public Party(Player p) {
		members = new ArrayList<String>();
		pendingRequests = new ArrayList<String>();
		leader = p.getName();
		joinRequestsOff = false;
		partyId = currentPartyId;
		currentPartyId++;
		createBoard();
		joinParty(p);
		updateBelowHealth();
		parties.add(this);
	}
	
	public void updateBelowHealth() {
    	for(Player p : plugin.getServer().getOnlinePlayers()) {
			Score score2 = partyBoard.getObjective("hpdisplay").getScore(p);
	    	if(!p.isDead())
	    		score2.setScore(plugin.getPD(p).hp);
	    	else
	    		score2.setScore(0);
    	}
	}
	
	public void partyChat(Player talker, String message) {
		announce(RankManager.getPrefix(talker.getName()) + talker.getName() + ChatColor.RESET + ": " + message);
	}
	
	public void announce(String message) {
		for(Player p : getMembers())
			p.sendMessage(ChatColor.GRAY + "" + ChatColor.ITALIC + "(Party)" + ChatColor.RESET + " " + message);
	}
	
	public void createBoard() {
		partyBoard = plugin.getServer().getScoreboardManager().getNewScoreboard();
		Objective objective1 = partyBoard.registerNewObjective("hpdisplay", "dummy");
		objective1.setDisplaySlot(DisplaySlot.BELOW_NAME);
		objective1.setDisplayName(ChatColor.RED + "\u2764");
		Objective objective2 = partyBoard.registerNewObjective("party", "dummy");
		objective2.setDisplaySlot(DisplaySlot.SIDEBAR);
		objective2.setDisplayName("Party Member  HP");
	}
	
	public double getExpMultiplier() {
		return members.size() > 1 ? 0.05 * members.size() : 0;
	}
	
	public void changeLeader(String s) {
		try {
			Player p = plugin.getServer().getPlayer(s);
			if(plugin.getPD(p).party == this) {
				announce(leader + " has given leadership of the party to " + p.getName());
				leader = p.getName();
			}
		} catch(Exception e) {
			announce("Failed to make " + s + " the party leader.");
		}
	}
	
	public void kick(String s) {
		try {
			Player p = plugin.getServer().getPlayer(s);
			announce(p.getName() + " was kicked from the party!");
			p.setScoreboard(plugin.hpBoard);
			partyBoard.resetScores(p);
			plugin.getPD(p).party = null;
			members.remove(p.getName());
		} catch(Exception e) {
			announce("Failed to kick " + s + ".");
		}
	}
	
	public boolean disbanding = false;
	public void disband() {
		disbanding = true;
		Party.parties.remove(this);
		announce("The party was disbanded by the leader, " + leader +".");
		for(Player p : getMembers())
			leaveParty(p);
		members = null;
	}
	
	public void joinParty(Player p) {
		if(members.size() >= MAX_PARTY_SIZE) {
			p.sendMessage("The party you are trying to join is full!");
			return;
		}
		plugin.getPD(p).party = this;
		members.add(p.getName());
		p.setScoreboard(partyBoard);
		announce(p.getName() + " has joined the party!");
		if(members.size() >= MAX_PARTY_SIZE)
			announce("The party is now full.");
	}
	
	public void leaveParty(Player p) {
		announce(p.getName() + " has left the party!");
		p.setScoreboard(plugin.hpBoard);
		partyBoard.resetScores(p);
		plugin.getPD(p).party = null;
		members.remove(p.getName());
		if((p.getName().equalsIgnoreCase(leader) && !disbanding) || members.size() == 0) {
			disband();
		}
	}
	
	public List<Player> getMembers() {
		List<Player> l = new ArrayList<Player>();
		for(String s : members) {
			l.add(plugin.getServer().getPlayer(s));
		}
		return l;
	}

	public void acceptPlayer(String s) {
		try {
			for(String s2 : pendingRequests) {
				if(s2.equalsIgnoreCase(s)) {
					Player p = plugin.getServer().getPlayer(s);
					if(plugin.getPD(p).party == null) {
						p.sendMessage("Your request to join the party has been accepted!");
						joinParty(p);
					} else {
						p.sendMessage("You were accepted to join " + leader +"'s party but are now in a different party.");
						announce("Tried to add " + p.getName() + " to the party, but that player is in another party now.");
					}
					return;
				}
			}
			announce(s + " has not made a request to join the party!");
		} catch(Exception e) {
			announce("Could not find player " + s + " to accept.");
		}
	}
	
	
	public void joinRequest(Player p) {
		if(joinRequestsOff) {
			p.sendMessage("Join requests for " + leader + "'s party are currently turned off.");
			return;
		}
		if(pendingRequests.contains(p.getName())) {
			p.sendMessage("You have already requested to join this party. Message the party leader if they missed your request.");
			return;
		}
		pendingRequests.add(p.getName());
		announce(p.getName() + " [Lv. " + plugin.getPD(p).level + "] has asked to join the party!");
		announce("Use " + ChatColor.YELLOW + "/p acceptrequest " + p.getName() + ChatColor.RESET + " to accept the request.");
		p.sendMessage("You requested to join " + leader +"'s party.");
	}

	public void info(Player p) {
		StringBuilder sb = new StringBuilder("");
		for(String s : members)
			sb = sb.append(s + ", ");
		String members = sb.toString();
		members = members.substring(0, members.lastIndexOf(", "));
		p.sendMessage("");
		p.sendMessage("Party members: " + members);
		p.sendMessage("Party leader: " + leader);
		p.sendMessage("Bonus EXP Rate: +" + (int)(getExpMultiplier() * 100) + "%");
		p.sendMessage("Average party level: " + String.format("%.2f", averagePartyLevel()));
	}
	
	public double averagePartyLevel() {
		int total = 0;
		for(Player p : getMembers())
			total += plugin.getPD(p).level;
		return ((double)total)/members.size();
	}
	
	public void toggleRequests() {
		joinRequestsOff = !joinRequestsOff;
		announce("Join requests for the party have been toggled " + (joinRequestsOff ? "OFF" : "ON"));
	}

	public void invite(String s, Player inviter) {
		try {
			Player p = plugin.getServer().getPlayer(s);
			if(plugin.getPD(p).options.checkOption("partyinvites")) {
				plugin.getPD(p).invitedTo = this;
				p.sendMessage("You were invited to join " + leader + "'s party by " + inviter.getName() + ".");
				p.sendMessage("Use " + ChatColor.YELLOW + "/party acceptinvite " + ChatColor.RESET + "to join!");
				inviter.sendMessage("You invited " + p.getName() + " to the party.");
			} else {
				inviter.sendMessage(ChatColor.RED + s + " has party invites disabled.");
			}
		} catch(Exception e) {
			announce("Could not find player " + s + " to invite.");
		}
	}
	
}