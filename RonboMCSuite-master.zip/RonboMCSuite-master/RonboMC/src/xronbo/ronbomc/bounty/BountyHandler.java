package xronbo.ronbomc.bounty;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;

public class BountyHandler implements Listener {

	public static class Bounty {
		public String target;
		public String asker;
		public int value;
		public Bounty(String a, String b, int c) {
			target = a;
			asker = b;
			value = c;
		}
	}
	
	public static ArrayList<Bounty> bounties = new ArrayList<Bounty>();
	
	public static void newBounty(Player target, Player asker, int value) {
		Bounty toRemove = null;
		for(Bounty b2 : bounties) {
			if(b2.target.equals(target.getName()) && asker.getName().equals(b2.asker)) {
				toRemove = b2;
				break;
			}
		}
		if(toRemove != null) {
			bounties.remove(toRemove);
			asker.sendMessage(ChatColor.GREEN + "Your existing bounty on " + target.getName() + " was removed.");
		}
		PlayerData pd = plugin.getPD(asker);
		pd.wallet -= value;
		Bounty b = new Bounty(target.getName(), asker.getName(), value);
		bounties.add(b);
		plugin.getServer().broadcastMessage(ChatColor.AQUA + asker.getName() + ChatColor.RED + " just set a bounty on " + ChatColor.AQUA + target.getName() + " for " + ChatColor.GOLD + value + "g" + ChatColor.RED + ".");
		plugin.getServer().broadcastMessage(ChatColor.RED + "The first person to kill " + ChatColor.AQUA + target.getName() + " in a non-arena zone will receive the bounty!");
		plugin.getServer().broadcastMessage(ChatColor.RED + "Use " + ChatColor.YELLOW + "/checkbounties" + ChatColor.RED + " to see all current bounties.");
		asker.sendMessage(ChatColor.GREEN + "Your bounty has been placed. Use " + ChatColor.YELLOW + "/unbounty" + ChatColor.GREEN + " to remove the bounty and get your money back!");
		asker.sendMessage(ChatColor.GREEN + "You have " + ChatColor.GOLD + value + "g" + ChatColor.GREEN + " left in your wallet.");
	}
	
	public static RonboMC plugin;
	public BountyHandler(RonboMC plugin) {
		BountyHandler.plugin = plugin;
	}
	
}
