package xronbo.ronbomc.regions;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

import org.bukkit.Location;
import org.bukkit.World;

import xronbo.ronbomc.RonboMC;

public class RegionHandler {
	
	public static ArrayList<Region> regions;
	public static HashMap<Integer, Region> regionIds;
	public static RonboMC plugin;
	
	public static ArrayList<Region> tempregions = new ArrayList<Region>();	
	
	public static Region wholeWorld;
	
	private RegionHandler() {
		
	}
	
	public static void load() {
		regions = new ArrayList<Region>();
		regionIds = new HashMap<Integer, Region>();
		wholeWorld = new Region(Arrays.asList(new Cube[] {new Cube(Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE , Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE)}));
		wholeWorld.type = "dangerous";
		wholeWorld.name = "The Realms of Kastia";
		wholeWorld.welcome = true;
		wholeWorld.id = 0;
		regionIds.put(0, wholeWorld);
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "regions.dat"));
			String s = "";
			if(scan.hasNextLine()) {
				s = scan.nextLine();
			}
			while(scan.hasNextLine()) {
				if(s.contains("Region: ")) {
					String name = s.substring("Region: ".length());
					
					int id = Integer.parseInt(scan.nextLine().substring("ID: ".length()));
					
					String world = scan.nextLine().substring("World: ".length());
					World w = plugin.getServer().getWorld(world);
					
					String type = scan.nextLine().substring("Type: ".length()).toLowerCase();
					boolean sendWelcome = Boolean.parseBoolean(scan.nextLine().substring("Welcome: ".length()).toLowerCase());

					/* Boundaries of the Region */
					ArrayList<Cube> regionLimits = new ArrayList<Cube>();
					s = scan.nextLine();
					while(scan.hasNextLine() && !s.startsWith("Spawns:")) {
						String[] data = s.split(" ");
						double x1 = 0, y1 = 0, z1 = 0, x2 = 0, y2 = 0, z2 = 0;
						if(data.length == 2) {
							if(data[0].split(",").length == 3) {
								x1 = Double.parseDouble(data[0].split(",")[0]);
								y1 = Double.parseDouble(data[0].split(",")[1]);
								z1 = Double.parseDouble(data[0].split(",")[2]);
								x2 = Double.parseDouble(data[1].split(",")[0]);
								y2 = Double.parseDouble(data[1].split(",")[1]);
								z2 = Double.parseDouble(data[1].split(",")[2]);
							} else {
								x1 = Double.parseDouble(data[0].split(",")[0]);
								y1 = 0;
								z1 = Double.parseDouble(data[0].split(",")[1]);
								x2 = Double.parseDouble(data[1].split(",")[0]);
								y2 = 300;
								z2 = Double.parseDouble(data[1].split(",")[1]);
							}
						} else if(data.length == 1) {
							x1 = Double.parseDouble(data[0].split(",")[0]);
							y1 = Double.parseDouble(data[0].split(",")[1]);
							z1 = Double.parseDouble(data[0].split(",")[2]);
							x2 = x1;
							y2 = y1;
							z2 = z1;
						} else {
							System.out.println("Error: Invalid region definition " + s);
							break;
						}
						if(x1 > x2) {
							double temp = x2;
							x2 = x1;
							x1 = temp;
						}
						if(y1 > y2) {
							double temp = y2;
							y2 = y1;
							y1 = temp;
						}
						if(z1 > z2) {
							double temp = z2;
							z2 = z1;
							z1 = temp;
						}
						regionLimits.add(new Cube(x1, y1, z1, x2, y2, z2));
						s = scan.nextLine();
					}
					Region r = new Region(regionLimits);
					r.id = id;
					r.type = type;
					r.welcome = sendWelcome;
					r.name = name;
					r.world = w;
					r.checkRestrictive();

					while(scan.hasNextLine() && !s.startsWith("Region:")) {
						s = scan.nextLine();
						try {
							String[] data = s.split(" ");
							int spawnId = Integer.parseInt(data[0]);
							int count = Integer.parseInt(data[1]);
							r.addSpawn(new Spawn(spawnId, count, r));
						} catch(Exception e2) {
							break;
						}
					}
					if(scan.hasNextLine())
						s = scan.nextLine();
					regionIds.put(r.id, r);
					regions.add(r);
				} else {
					scan.nextLine();
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Loaded " + (regionIds.size() - 1) + " regions");
	}
	
	public static void save() {
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(plugin.getDataFolder() + File.separator + "regions.dat"))));
			for(Region r : regions) {
				out.println("Region: " + r.name);
				out.println("ID: " + r.id);
				out.println("World: " + r.world.getName());
				out.println("Type: " + r.type);
				out.println("Welcome: " + r.welcome);
				for(Cube c : r.cubes) {
					out.println(c.x1 + "," + c.y1 + "," + c.z1 + " " + c.x2 + "," + c.y2 + "," + c.z2);
				}
				out.println("Spawns: [Format: \"<ID> <Count>\"]");
				for(Spawn s : r.spawns) {
					out.println(s.id + " " + s.count);
				}
				out.println();
			}
			out.flush();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static Region getWelcomeRegion(Location loc) {
		ArrayList<Region> possibleRegions = getPossibleRegions(loc);
		if(possibleRegions.size() == 0) {
			return wholeWorld;
		}
		long smallest = wholeWorld.getSize();
		Region r = wholeWorld;
		for(Region r2 : possibleRegions) {
			if(r2.welcome) {
				if(r2.getSize() < smallest) {
					smallest = r2.getSize();
					r = r2;
				}
			}
		}
		return r;
	}
	
	public static Region getRegion(Location loc) {
		ArrayList<Region> possibleRegions = getPossibleRegions(loc);
		if(possibleRegions.size() == 0) {
			return wholeWorld;
		}
		long smallest = possibleRegions.get(0).getSize();
		Region r = possibleRegions.get(0);
		for(Region r2 : possibleRegions) {
			if(r2.getSize() < smallest) {
				smallest = r2.getSize();
				r = r2;
			}
		}
		return r;
	}
	
	public static ArrayList<Region> getPossibleRegions(Location loc) {
		ArrayList<Region> possibleRegions = new ArrayList<Region>();
		for(Region r : regions) {
			if(checkRegion(r, loc))
				possibleRegions.add(r);
		}
		return possibleRegions;
	}

	public static ArrayList<Region> getNearbyRegions(Location loc) {
		ArrayList<Region> possibleRegions = new ArrayList<Region>();
		for(Region r : regions) {
			if(checkRegion(r, loc))
				possibleRegions.add(r);
			else if(regionDistance(r, loc) < 32)
				possibleRegions.add(r);
		}
		return possibleRegions;
	}
	
	public static int regionDistance(Region r, Location loc) {
		double minDist = Integer.MAX_VALUE;
		double x = loc.getX();
		double z = loc.getZ();
		for(Cube c : r.cubes) {
			if(x > c.x1 && x < c.x2) {
				if(Math.abs(larger(x - c.y1, x - c.y2)) < minDist) {
					minDist = Math.abs(larger(x - c.y1, x - c.y2));
				}
			}
			if(z > c.x1 && z < c.x2) {
				if(Math.abs(larger(z - c.y1, z - c.y2)) < minDist) {
					minDist = Math.abs(larger(z - c.y1, z - c.y2));
				}
			}
			if(x > c.z1 && x < c.z2) {
				if(Math.abs(larger(x - c.y1, x - c.y2)) < minDist) {
					minDist = Math.abs(larger(x - c.y1, x - c.y2));
				}
			}
			if(z > c.z1 && z < c.z2) {
				if(Math.abs(larger(z - c.y1, z - c.y2)) < minDist) {
					minDist = Math.abs(larger(z - c.y1, z - c.y2));
				}
			}
			if(Math.sqrt((x - c.x1) * (x - c.x1) + (z - c.z1) * (z - c.z1)) < minDist) {
				minDist = Math.sqrt((x - c.x1) * (x - c.x1) + (z - c.z1) * (z - c.z1));
			}
			if(Math.sqrt((x - c.x1) * (x - c.x1) + (z - c.z2) * (z - c.z2)) < minDist) {
				minDist = Math.sqrt((x - c.x1) * (x - c.x1) + (z - c.z2) * (z - c.z2));
			}
			if(Math.sqrt((x - c.x2) * (x - c.x2) + (z - c.z1) * (z - c.z1)) < minDist) {
				minDist = Math.sqrt((x - c.x2) * (x - c.x2) + (z - c.z1) * (z - c.z1));
			}
			if(Math.sqrt((x - c.x2) * (x - c.x2) + (z - c.z2) * (z - c.z2)) < minDist) {
				minDist = Math.sqrt((x - c.x2) * (x - c.x2) + (z - c.z2) * (z - c.z2));
			}
		}
		return (int)minDist;
	}
	
	public static double larger(double x, double y) {
		if(x > y)
			return x;
		return y;
	}
	
	public static ArrayList<Cube> checkRegionXZ(Region r, double x, double z) {
		ArrayList<Cube> cubes = new ArrayList<Cube>();
		for(Cube c : r.cubes) {
			if(x >= c.x1 && x <= c.x2 + 1.0 && z >= c.z1 && z <= c.z2 + 1.0) {
				cubes.add(c);
			}
		}
		return cubes;
	}
	
	public static boolean checkRegion(Region r, double x, double y, double z, String world) {
		for(Cube c : r.cubes) {
			if(x >= c.x1 && x <= c.x2 + 1.0 && y >= c.y1 && y <= c.y2 + 1.0 && z >= c.z1 && z <= c.z2 + 1.0) {
				if(world.equals(r.world.getName()))
					return true;
			}
		}
		if(r == wholeWorld)
			return true;
		return false;
	}
	
	public static boolean checkRegion(Region r, Location loc) {
		double x = loc.getX();
		double y = loc.getY();
		double z = loc.getZ();
		for(Cube c : r.cubes) {
			if(x >= c.x1 && x <= c.x2 + 1.0 && y >= c.y1 && y <= c.y2 + 1.0 && z >= c.z1 && z <= c.z2 + 1.0) {
				if(loc.getWorld() == r.world)
					return true;
			}
		}
		if(r == wholeWorld)
			return true;
		return false;
	}
	
}