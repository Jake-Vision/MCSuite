package xronbo.ronbomc.regions;

public class Spawn {
	public int id;
	public int count;
	public volatile int available;
	public Region region;
//	public HashMap<String, Integer> spawnsForPlayer = new HashMap<String, Integer>();
	
	public Spawn(int i, int c, Region r) {
		id = i;
		count = c;
		region = r;
		available = count;
	}
	
	public String toString() {
		return "ID-" + id + " Count-" + count;
	}
	
}