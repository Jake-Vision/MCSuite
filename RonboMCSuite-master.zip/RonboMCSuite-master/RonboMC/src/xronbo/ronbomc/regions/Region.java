package xronbo.ronbomc.regions;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class Region {
	
	public ArrayList<Cube> cubes;
	public World world;
	public ArrayList<Spawn> spawns;
	
	public boolean restrictive = false;
	public boolean arena = false;
	
	public int id;
	public String name;
	public String type; //secure, dangerous, perilous
	public boolean welcome;
	
	public Region(List<Cube> r) {
		name = "";
		type = "";
		spawns = new ArrayList<Spawn>();
		cubes = new ArrayList<Cube>();
		if(r != null)
			cubes.addAll(r);
	}
	
	public void checkRestrictive() {
		if(name.endsWith("_spawn")) {
			name = name.substring(0, name.lastIndexOf("_spawn"));
			restrictive = true;
		}
		if(name.endsWith("_arena")) {
			name = name.substring(0, name.lastIndexOf("_arena"));
			restrictive = true;
			arena = true;
		}
	}
	
	public void addSpawn(Spawn s) {
		for(Spawn s2 : spawns)
			if(s2.id == s.id) {
				s2.count += s.count;
				s2.available += s.available;
				return;
			}
		spawns.add(s);
	}
	
	public long getSize() {
		long sum = 0;
		for(Cube c : cubes) {
			sum += Math.abs((c.x1 - c.x2) * (c.y1 - c.y2) * (c.z1 - c.z2));
		}
		return sum;
	}
	
	public void sendWelcome(Player p, boolean force) {
		if(!welcome || (!force && this == RegionHandler.plugin.getPD(p).preUnwelcomedRegion)) {
			return;
		}
		RegionHandler.plugin.getPD(p).preUnwelcomedRegion = null;
		p.sendMessage("");
		p.sendMessage(ChatColor.YELLOW + "You are now in " + ChatColor.YELLOW + name + "! " + ChatColor.ITALIC);
		p.sendMessage(ChatColor.YELLOW + "This region is " + getTypeColor() + type + ChatColor.YELLOW + ".");
		if(type.equals("perilous")) {
			p.sendMessage(ChatColor.RED + "You can be attacked here by both players and mobs!");
		} else if(type.equals("dangerous")) {
			p.sendMessage(ChatColor.YELLOW + "You can be attacked here by mobs but not by players.");
		} else if(type.equals("secure")) {
			p.sendMessage(ChatColor.YELLOW + "You cannot be attacked at all here.");
		}
		if(arena) {
			p.sendMessage(ChatColor.GREEN + "This region is an Arena. You will not lose Spirit Points.");
		}
		p.sendMessage("");
	}
	
	public ChatColor getTypeColor() {
		switch(type.toLowerCase()) {
			case "secure":
				return ChatColor.GREEN;
			case "dangerous":
				return ChatColor.AQUA;
			case "perilous":
				return ChatColor.RED;
		}
		return ChatColor.RESET;
	}
	
	public String toString() {
		return "Region " + name; 
	}
	
}