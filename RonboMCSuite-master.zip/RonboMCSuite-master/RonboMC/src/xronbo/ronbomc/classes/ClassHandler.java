package xronbo.ronbomc.classes;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;


public class ClassHandler {
	
	public static RonboMC plugin;

	public enum ClassType {
		CRUSADER("Crusader",  new String[][][] {
				//Tier 1
				{
					{"Sword Prowess", "Deal 3 bonus damage with Swords"},
					{"Regeneration", "Regenerate 3 HP per second"},
				},
				//Tier 2
				{
					{"Sword Mastery", "Deal 10 bonus damage with Swords"},
					{"Self Recovery", "Regenerate 1% of max HP per second"},
					{"Time Warp", "1% chance of not activating a spell cooldown"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Sword Champion", "Deal 10% bonus damage with Swords"},
					{"Power Stance", "Reduces damage taken by 5%"},
					{"Time Stasis", "3% chance of not activating a spell cooldown"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Stalwart", "Reduces damage taken by 8%"},
					{"Knight's Legacy", "Deal 20% bonus damage with Swords"},
					{"Combat Prowess", "Reduces damage taken by 5% and deals 10% bonus damage with Swords"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Combat Master", "Reduces damage taken by 10% and deals 15% bonus damage with Swords"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Hero's Will", "Reduces damage taken by 15%"},
				},
		}),
		BERSERKER("Berserker",  new String[][][] {
				//Tier 1
				{
					{"Axe Prowess", "Deal 4 bonus damage with Axes"},
					{"Savage", "Gain 5% Lifesteal"},
				},
				//Tier 2
				{
					{"Axe Mastery", "Deal 13 bonus damage with Axes"},
					{"Rage", "Increases damage dealt with Axes and damage received by 10%"},
					{"Blood Lust", "Gain 10% Lifesteal"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Axe Champion", "Deal 15% bonus damage with Axes"},
					{"Reckless", "Increases damage dealt with Axes and damage received by 15%"},
					{"Vicious Strikes", "Deal 3% of the enemies current HP as bonus damage with Axes, up to 5000 bonus damage"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Desperation", "Gain 50% Lifesteal when under 40% Health"},
					{"Berserk", "Increases damage dealt with Axes by 20% and damage received by 15%"},
					{"Undying Rage", "Reduces damage taken by 35% when under 40% Health"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Dangerous Game", "Increases damage dealt with Axes by 30% and damage received by 20%"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Survival Instinct", "Reduces damage taken by 50% when under 50% Health"},
				},
		}),
		PALADIN("Paladin",  new String[][][] {
				//Tier 1
				{
					{"Mace Prowess", "Deal 2 bonus damage with Maces"},
					{"Block", "5% chance to block all damage from an attack"},
				},
				//Tier 2
				{
					{"Mace Mastery", "Deal 8 bonus damage with Maces"},
					{"Barricade", "Reduces damage taken by 7%"},
					{"Valiant", "Reduces damage taken by 4% and deals 5% bonus damage with Maces"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Mace Champion", "Deal 10% bonus damage with Maces"},
					{"Holy Mastery", "Reduces damage taken by 12% and deals 10% bonus damage with Maces"},
					{"Divine Shield", "10% chance to block all damage from an attack"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Heaven's Hammer", "Deal 20% increased damage with Maces"},
					{"Divine Protection", "15% chance to block all damage from an attack"},
					{"Transcendent", "Reduces damage taken by 15% and deals 15% bonus damage with Maces"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Sanctuary", "20% chance to block all damage from an attack"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Citadel", "Reduces damage taken by 18% and deals 20% bonus damage with Maces"},
				},
		}),
		CLERIC("Cleric", new String[][][] {
				//Tier 1
				{
					{"Stave Prowess", "Deal 3 bonus damage with Staves"},
					{"Healing Mastery", "Increases healing from all sources by 15%"},
				},
				//Tier 2
				{
					{"Stave Mastery", "Deal 10 bonus damage with Staves"},
					{"Recovery", "Increases HP Regeneration by 5% of maximum health"},
					{"Defense Stance", "Reduces damage taken by 6%"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Stave Champion", "Deal 18% bonus damage with Staves"},
					{"Survival Stance", "Reduces damage taken by 10% and increases healing from non-regen sources by 20%"},
					{"Alchemist", "Increases healing from non-regen sources by 35%"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Fortification Stance", "Reduces damage taken by 18%"},
					{"Invulnerability Stance", "Reduces damage taken by 16% and increases healing from non-regen sources by 40%"},
					{"Legendary Stave", "Deal 30% bonus damage with Staves"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Johann's Pen", "Increases healing from non-regen sources by 100%"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Ascension", "Increases HP Regen by 8% of maximum health and increases healing from non-regen sources by 50%"},
				},
		}),
		WIZARD("Wizard", new String[][][] {
				//Tier 1
				{
					{"Wand Prowess", "Deal 5 bonus damage with Wands"},
					{"Artificial T2", "All wands will shoot Tier 2 Projectiles and at a Tier 2 speed"},
				},
				//Tier 2
				{
					{"Wand Mastery", "Deal 10 bonus damage with Wands"},
					{"Speedcasting", "Increases projectile shooting speed by 15%"},
					{"Artificial T3", "All wands will shoot Tier 3 Projectiles and at a Tier 3 speed"},
				},
				//Tier 3
				{
					{"Wand Champion", "Deal 10% bonus damage with Wands"},
					{"Aura Augmentation", "Increases range of auras by 25%"},
					{"Artificial T4", "All wands will shoot Tier 4 Projectiles and at a Tier 4 speed"},
				},
				//Tier 4
				{
					{"Wand of Legends", "Deal 20% bonus damage with Wands"},
					{"Aura Amplification", "Increases range of auras by 50%"},
					{"Artificial T5", "All wands will shoot Tier 5 Projectiles and at a Tier 5 speed"},
				},
				//Tier 5
				{
					{"Aura Awakening", "Increases range of auras by 75%"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"True Wizardry", "Reduces damage received by 20% and increases damage dealt with Wands by 25%"},
				},
		}),
		ARCHER("Archer", new String[][][] {
				//Tier 1
				{
					{"Bow Prowess", "Deal 4 bonus damage with Bows"},
					{"Critical Prowess", "Gain an additional 10% increased damage on critical hits"},
				},
				//Tier 2
				{
					{"Bow Mastery", "Deal 12 bonus damage with Bows"},
					{"Critical Mastery", "Gain an additional 20% increased damage for critical hits"},
					{"Nimble Body", "Reduces damage taken by 5%"},
				},
				//Tier 3
				{
					{"Bow Champion", "Deal 15% bonus damage with Bows"},
					{"Physical Training", "Bow whacks do 75% of normal damage"},
					{"Vital Vision", "Gain an additional 30% increased damage for critical hits"},
				},
				//Tier 4
				{
					{"Combat Expert", "Bow whacks do 100% of normal damage"},
					{"Sniper", "Gain an additional 50% increased damage for critical hits"},
					{"Nature Shield", "Reduces damage taken by 10%"},
				},
				//Tier 5
				{
					{"Railgun", "Deal 35% bonus damage with Bows"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Forest Essence", "Reduces damage taken by 20%"},
				},
		}),
		ASSASSIN("Assassin", new String[][][] {
				//Tier 1
				{
					{"Dagger Prowess", "Deal 4 bonus damage with Daggers"},
					{"Loot Finder", "Get a 2% chance to receive a Tier 2 drop from any mob"},
				},
				//Tier 2
				{
					{"Dagger Mastery", "Deal 13 bonus damage with Daggers"},
					{"Plunderer", "Get a 5% chance to receive a Tier 2 drop from any Tier 2 or higher mob"},
					{"Hunter", "Heal for 3% of Max HP upon killing any enemy"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Dagger Champion", "Deal 13% bonus damage with Daggers"},
					{"Treasure Hunter", "Get a 0.1% chance to receive a Tier 3 drop from any Tier 3 or higher mob"},
					{"Slayer", "Heal for 10% of Max HP upon killing any enemy"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Dagger Legend", "Deal 22% bonus damage with Daggers"},
					{"Bonanza", "Get an extra 0.3% chance to receive a Tier 3 drop from a Tier 4 or higher mob"},
					{"Terminator", "Heal for 20% of Max HP upon killing any enemy"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Legendary Looter", "Get an extra 0.1% chance to receive a Tier 4 drop from a Tier 5 mob"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Assassin's Creed", "Deal 4% of the enemy's maximum health on each hit with a Dagger, capped at 50000 bonus damage"},
				},
		}),
		BARBARIAN("Barbarian",  new String[][][] {
				//Tier 1
				{
					{"Bone Prowess", "Deal 10 bonus damage with Bones"},
					{"Persistent", "HP Regeneration is increased by 5"},
				},
				//Tier 2
				{
					{"Bone Mastery", "Deal 15 bonus damage with Bones"},
					{"Beefy", "Maximum HP is increased by 5%"},
					{"Primitive", "The four core stats are increased by 10"},
					{"Acrobat", "Have a 20% chance for a short speed and jump boost on every attack"},
				},
				//Tier 3
				{
					{"Bone Champion", "Deal 10% bonus damage with Bones"},
					{"Willpower", "50% chance to ignore slows and disables"},
					{"Massive", "Maximum HP is increased by 10%"},
					{"Chaser", "Gain a speed boost when attacked from a range"},
				},
				//Tier 4
				{
					{"Brute Force", "Deal 20% bonus damage with Bones"},
					{"Ferocity", "Increases damage dealt to players by 15%"},
					{"Tireless", "HP Regeneration is increased by 20%"},
					{"Unstoppable", "Have a 50% to nullify all knockback"},
				},
				//Tier 5
				{
					{"Barbaric", "Maximum HP is increased by 30%"},
					{"Spirit of Kastia", "Cooldowns are reduced to 70% of their length"},
					{"Versatility", "The four core stats are increased by 10%"},
				},
		});
	
		public String name;
		public String[][][] passives;
	
		public int getPassiveTier(String s) {
			for(int k = 0; k < passives.length; k++) {
				for(String[] s2 : passives[k])
					if(s2[0].equalsIgnoreCase(s))
						return k + 1;
			}
			System.out.println("Error: Could not find passive " + s + " for classtype " + this.name());
			return -1;
		}
		
		public static boolean tierAvailable(PlayerData pd, int tier) {
			return pd.level >= getLevelReq(tier);
		}
		
		public static int getLevelReq(int tier) {
			switch(tier) {
				case 1:
					return 1;
				case 2:
					return 10;
				case 3:
					return 30;
				case 4:
					return 60;
				case 5:
					return 100;
			}
			return 999999;
		}
		
		public byte getPassiveColor(PlayerData pd, int tier, int number) {
			for(int[] i : pd.activePassives)
				if(i[0] == tier && i[1] == number)
					return DyeColor.LIME.getData();
			if(pd.level >= getLevelReq(tier))
				return DyeColor.LIGHT_BLUE.getData();
			else
				return DyeColor.PINK.getData();
		}
		
		public ChatColor getPassiveChatColor(PlayerData pd, int tier, int number) {
			for(int[] i : pd.activePassives)
				if(i[0] == tier && i[1] == number)
					return ChatColor.GREEN;
			if(pd.level >= getLevelReq(tier))
				return ChatColor.AQUA;
			else
				return ChatColor.RED;
		}
		
		public static int getNumberPassivesAllowed(int level) {
			if(level < 30)
				return 1;
			if(level < 70)
				return 2;
			return 3;
		}
		
		public String getPassiveName(int tier, int num) {
			return passives[tier - 1][num - 1][0];
		}
		
		public static ArrayList<String> getActivePassives(PlayerData pd) {
			ArrayList<String> list = new ArrayList<String>();
			ClassType ct = ClassHandler.getClassType(pd.classType);
			for(int[] i : pd.activePassives) {
				if(i[0] > 0 && i[1] > 0)
					list.add(ct.passives[i[0] - 1][i[1] - 1][0]);
				if(list.size() == pd.activePassives.length)
					break;
			}
			return list;
		}
		
		public static int getClassChangeCost(int level) {
			int value = (int)(level / 10) + 1;
			switch(value) {
				case 0:
					return 1;
				case 1:
					return 50;
				case 2:
					return 150;
				case 3:
					return 400;
				case 4:
					return 1000;
				case 5:
					return 2500;
				case 6:
					return 10000;
				case 7:
					return 50000;
				case 8:
					return 100000;
				case 9:
					return 500000;
				default:
					return 1000000;
			}
		}
		
		public void openClassPassivesMenu(Player p) {
			Inventory inventory = Bukkit.createInventory(p, 9*6, name + " Class Passives");
			updateClassPassivesMenu(inventory, p);
			p.openInventory(inventory);
		}
		
		public void updateClassPassivesMenu(Inventory inventory, Player p) {
			PlayerData pd = plugin.getPD(p);
			
			ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.ORANGE.getData());
			ItemMeta im = i.getItemMeta();
			im.setDisplayName(ChatColor.WHITE + "Choose your passive" + (getNumberPassivesAllowed(pd.level) > 1 ? "s" : "") + "!");
			im.setLore(Arrays.asList(new String[] {ChatColor.LIGHT_PURPLE + "You may have up to " + getNumberPassivesAllowed(pd.level) + " active passives at a time.",
							ChatColor.LIGHT_PURPLE + (pd.level >= 70 ? "You have reached the maximum allowed number of passives!" : "At level " + (pd.level >= 30 ? "70" : "30") + " you can choose an additional passive."),
							"",
							ChatColor.LIGHT_PURPLE + "Click on any available passive to activate it.",
							ChatColor.LIGHT_PURPLE + "Click on any selected passive to de-activate it."}));
			i.setItemMeta(im);
			inventory.setItem(0, i);

			i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.ORANGE.getData());
			im = i.getItemMeta();
			im.setDisplayName(ChatColor.WHITE + "Color Guide");
			im.setLore(Arrays.asList(new String[] {ChatColor.LIGHT_PURPLE + "Available Passives are " + ChatColor.AQUA + "BLUE",
														  ChatColor.LIGHT_PURPLE + "Unavailable Passives are " + ChatColor.RED + "RED",
														  ChatColor.LIGHT_PURPLE + "Activated Passives are " + ChatColor.GREEN + "GREEN"}));
			i.setItemMeta(im);
			inventory.setItem(1, i);
			
			i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.ORANGE.getData());
			im = i.getItemMeta();
			im.setDisplayName(ChatColor.WHITE + "Currently Active Passives");
			ArrayList<String> currentlyActive = getActivePassives(pd);
			for(int k = 0; k < currentlyActive.size(); k++) {
				currentlyActive.set(k, ChatColor.LIGHT_PURPLE + currentlyActive.get(k));
			}
			im.setLore(currentlyActive);
			i.setItemMeta(im);
			inventory.setItem(2, i);
			
			i = new ItemStack(Material.HOPPER);
			im = i.getItemMeta();
			im.setDisplayName(ChatColor.WHITE + "Change Class");
			im.setLore(Arrays.asList(new String[] {ChatColor.LIGHT_PURPLE + "Changing your class will cost " + ChatColor.GOLD + getClassChangeCost(pd.level) + ChatColor.LIGHT_PURPLE + " gold.",
					"",
					ChatColor.LIGHT_PURPLE + "This gets more expensive every 10 levels.",
					ChatColor.LIGHT_PURPLE + "so change while you can afford it!",
					"",
					ChatColor.LIGHT_PURPLE + "Click here to open the Class Selection menu."}));
			i.setItemMeta(im);
			inventory.setItem(8, i);
			
			for(int tier = 0; tier < passives.length; tier++) {
				int row = (tier + 1) * 9;
				i = new ItemStack(Material.PAPER);
				im = i.getItemMeta();
				im.setDisplayName(ChatColor.GOLD + "Tier " + (tier + 1) + " Passives");
				im.setLore(Arrays.asList(new String[]{(tierAvailable(pd, tier + 1) ? ChatColor.GREEN + "Available": ChatColor.RED + "Unlocked at level " + getLevelReq(tier + 1))}));
				i.setItemMeta(im);
				inventory.setItem(0 + row, i);
				for(int passiveNum = 0; passiveNum < passives[tier].length; passiveNum++) {
					ItemStack item2 = new ItemStack(Material.STAINED_GLASS_PANE, 1, getPassiveColor(pd, tier + 1, passiveNum + 1));
					ItemMeta im2 = item2.getItemMeta();
					im2.setDisplayName(getPassiveChatColor(pd, tier + 1, passiveNum + 1) + passives[tier][passiveNum][0]);
					String description =  passives[tier][passiveNum][1];
					im2.setLore(Arrays.asList(Values.stringToLore(description, ChatColor.WHITE)));
					item2.setItemMeta(im2);
					inventory.setItem(passiveNum + 1 + row, item2);
				}
			}
		}
		
		ClassType(String name, String[][][] passives) {
			this.name = name;
			this.passives = passives;
		}
	}
	
	public static boolean checkPassive(String s, PlayerData pd) {
		for(String s2 : ClassType.getActivePassives(pd))
			if(s2.equalsIgnoreCase(s))
				return true;
		return false;
	}
	
	public static ClassType getClassType(String s) {
		for(ClassType ct : ClassType.values())
			if(ct.name.equalsIgnoreCase(s))
				return ct;
		return null;
	}
	
	public static final String[][] classDescriptions = new String[][] {
		{"Crusader",  "Crusaders are melee fighters specializing in Swords.", "They feature a mixture of survivability and damage.", "Crusaders use STR and DEX.", "Strong (120% dmg): Swords", "Average (100% dmg): Axes, Maces, Staves", "Weak (30% dmg): Bones, Wands, Bows, Daggers"},
		{"Berserker", "Berserkers are melee fighters specializing in Axes.", "They are risky fighters who get stronger as they approach death.", "Berserkers use STR and LUK.", "Strong (120% dmg): Axes", "Average (100% dmg): Swords, Maces, Staves", "Weak (30% dmg): Bones, Wands, Bows, Daggers"},
		{"Paladin",  "Paladins are melee fighters specializing in Maces.", "They are incredibly tanky and wield the power of holy elements.", "Paladins use STR and INT.", "Strong (120% dmg): Maces", "Average (100% dmg): Swords, Axes, Staves", "Weak (30% dmg): Bones,  Wands, Bows, Daggers"},
		{"Cleric",  "Clerics are melee fighters specializing in Staves.", "They are essential to any good party and have incredible healing spells.", "Clerics use INT and STR.", "Strong (120% dmg): Staves", "Average (100% dmg): Swords, Axes, Maces", "Weak (30% dmg): Bones, Wands, Bows, Daggers"},
		{"Wizard", "Wizards are ranged fighters specializing in Wands.", "They are difficult to play but have powerful spells and normal attacks.", "Wizards use INT and LUK.", "Strong (120% dmg): Wands", "Average (100% dmg): Staves, Bows", "Weak (30% dmg): Bones, Swords, Axes, Maces, Daggers"},
		{"Archer", "Archers are ranged fighters specializing in Bows.", "They are difficult to play but can be deadly with accurate bow aim.", "Archers use DEX and STR.", "Strong (120% dmg): Bows", "Average (100% dmg): Wands, Staves", "Weak (30% dmg): Bones, Swords, Axes, Maces, Daggers"},
		{"Assassin", "Assassins are melee fighters specializing in Daggers.", "They have low health but can quickly kill even the most threatening enemies.", "Assassins use LUK and DEX.", "Strong (120% dmg): Daggers", "Average (100% dmg): Staves", "Weak (30% dmg): Bones, Swords, Axes, Maces, Wands, Bows"},
		{"Barbarian", "Barbarians are melee fighters specializing in Bones.", "They rely heavily on their equipment because of their passives and stat requirements.", "Barbarians use STR, DEX, LUK, and INT.", "Strong (120% dmg): Bones", "Average (100% dmg): None", "Weak (30% dmg): Swords, Axes, Maces, Staves, Wands, Bows, Daggers"},
	};

	public static void openClassSelectionMenu(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9, "Class Selection Menu");
		updateClassSelectionMenu(inventory, p);
		p.openInventory(inventory);
	}
	
	public static void updateClassSelectionMenu(Inventory inventory, Player p) {
		PlayerData pd = plugin.getPD(p);
		
		for(int k = 0; k < classDescriptions.length; k++) {
			ItemStack i = pd.selectedClass.equalsIgnoreCase(classDescriptions[k][0]) ? new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.ORANGE.getData()) : new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLACK.getData());
			ItemMeta im = i.getItemMeta();
			im.setDisplayName(ChatColor.WHITE + classDescriptions[k][0]);
			ArrayList<String> lore = new ArrayList<String>();
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][1], ChatColor.AQUA)));
			lore.add("");
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][2], ChatColor.AQUA)));
			lore.add("");
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][3], ChatColor.AQUA)));
			lore.add("");
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][4], ChatColor.GREEN)));
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][5], ChatColor.YELLOW)));
			lore.addAll(Arrays.asList(Values.stringToLore(classDescriptions[k][6], ChatColor.RED)));
			im.setLore(lore);
			i.setItemMeta(im);
			inventory.setItem(k, i);
		}
		ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.GREEN + "Confirm Class Selection");
		ArrayList<String> lore = new ArrayList<String>();
		if(ClassHandler.getClassType(pd.selectedClass) != null) {
			if(ClassHandler.getClassType(pd.classType) == null) {
				lore.add(ChatColor.LIGHT_PURPLE + "Click here to confirm your class selection!");
				lore.add(ChatColor.LIGHT_PURPLE + "You will become a " + ChatColor.GOLD + pd.selectedClass);
				lore.add(ChatColor.LIGHT_PURPLE + "");
				lore.add(ChatColor.LIGHT_PURPLE + "Class selections are not necessarily permanent.");
				lore.add(ChatColor.LIGHT_PURPLE + "");
				lore.add(ChatColor.LIGHT_PURPLE + "However, it will cost increasing amounts of gold");
				lore.add(ChatColor.LIGHT_PURPLE + "to change your class as you get to higher levels.");
			} else {
				lore.add(ChatColor.LIGHT_PURPLE + "Click here to confirm your class selection!");
				lore.add(ChatColor.LIGHT_PURPLE + "You will become a " + ChatColor.GOLD + pd.selectedClass);
				lore.add(ChatColor.LIGHT_PURPLE + "");
				lore.add(ChatColor.LIGHT_PURPLE + "This class change will cost you " + ChatColor.GOLD + ClassHandler.ClassType.getClassChangeCost(pd.level) + ChatColor.LIGHT_PURPLE + " gold");
			}
		} else {
			lore.add(ChatColor.LIGHT_PURPLE + "Click on any class to select it.");
			lore.add(ChatColor.LIGHT_PURPLE + "Then, click here to lock in your choice!");
		}
		im.setLore(lore);
		i.setItemMeta(im);
		inventory.setItem(8, i);
	}
	
	private ClassHandler() {
		
	}
	
}