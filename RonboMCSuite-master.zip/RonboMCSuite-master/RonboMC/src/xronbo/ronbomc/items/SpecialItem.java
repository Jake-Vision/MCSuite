package xronbo.ronbomc.items;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.SpellHandler;

public class SpecialItem {
	
	public int id;
	public String name;
	public int tier;
	public Material material;
	
	public int[] strength, dexterity, intelligence, luck;
	public int[] hpRegen;
	public int[] hp;
	
	public int[] attack;
	
	public int[] critChance; 
	public int[] critDamage;
	public int[] lifesteal;
	
	public String lore;
	public String spellName;
	
	public SpecialItem() {
	
	}
	
	public ItemStack generateItem() {
		ItemStack i = new ItemStack(material);
		String color = ChatColor.YELLOW.toString();
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(color + name);
		i.setItemMeta(im);
		ItemData id = new ItemData(i);
		if(attack != null) {
			id.attack = random(attack[0], attack[1]);
		}
		if(strength != null) {
			id.strength = random(strength[0], strength[1]);
		}
		if(dexterity != null) {
			id.dexterity = random(dexterity[0], dexterity[1]);
		}
		if(intelligence != null) {
			id.intelligence = random(intelligence[0], intelligence[1]);
		}
		if(luck != null) {
			id.luck = random(luck[0], luck[1]);
		}
		if(hpRegen != null) {
			id.hpRegen = random(hpRegen[0], hpRegen[1]);
		}
		if(hp!= null) {
			id.hp = random(hp[0], hp[1]);
		}
		if(critChance != null) {
			id.critChance = random(critChance[0], critChance[1]);
		}
		if(critDamage != null) {
			id.critDamage = random(critDamage[0], critDamage[1]);
		}
		if(lifesteal != null) {
			id.lifesteal = random(lifesteal[0], lifesteal[1]);
		}
		if(lore != null) {
			id.lore = lore;
		}
		id.tier = tier;
//		if(spellName == null || spellName.equals("") || spellName.equals("random")) {
//			Equip equip = null;
//			for(Equip e : Equip.values()) {
//				for(Material m : e.materials) {
//					if(m == material) {
//						equip = e;
//						break;
//					}
//				}
//			}
//			if(ItemHandler.isWeapon(equip)) {
//				int spellTier = 0;
//				switch(tier) {
//					case 1:
//						spellTier = 0;
//						break;
//					case 2:
//						spellTier = (Math.random() < 0.5 ? 0 : 1);
//						break;
//					case 3:
//						spellTier = 1;
//						break;
//					case 4:
//						spellTier = (Math.random() < 0.5 ? 1 : 2);
//						break;
//					case 5:
//						spellTier = 2;
//						break;
//				}
//				id.spellName = equip.spells[spellTier][(int)(Math.random() * equip.spells[spellTier].length)];
//			}
//		} else {
//			id.spellName = spellName;
//		}
		if(spellName != null) {
			id.spellName = spellName;
			id.spell = SpellHandler.getSpell(id.spellName);
		}
		id.addStatsToLore();
		ItemHandler.items.put(i, id);
		return ItemHandler.removeAttributes(i);
	}
	
	public static int random(int a, int b) {
		return (int) (Math.random() * (a - b) + b);
	}
	
	public String toString() {
		return name;
	}

	public ItemStack getShopItem(int price) {
		ItemStack i = new ItemStack(material);
		String color = ChatColor.YELLOW.toString();
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(color + name);
		ArrayList<String> lore = new ArrayList<String>();
		if(attack != null) {
			lore.add(ChatColor.WHITE + "Attack: " + attack[0] + "-" + attack[1]);
		}
		lore.add("");
		if(strength != null) {
			lore.add(ChatColor.GREEN + "Strength: " + strength[0] + "-" + strength[1]);
		}
		if(dexterity != null) {
			lore.add(ChatColor.GREEN + "Dexterity: " + dexterity[0] + "-" + dexterity[1]);
		}
		if(intelligence != null) {
			lore.add(ChatColor.GREEN + "Intelligence: " + intelligence[0] + "-" + intelligence[1]);
		}
		if(luck != null) {
			lore.add(ChatColor.GREEN + "Luck: " + luck[0] + "-" + luck[1]);
		}
		if(hpRegen != null) {
			lore.add(ChatColor.GREEN + "HP Regen: " + hpRegen[0] + "-" + hpRegen[1]);
		}
		if(hp!= null) {
			lore.add(ChatColor.GREEN + "HP: " + hp[0] + "-" + hp[1]);
		}
		if(critChance != null) {
			lore.add(ChatColor.GREEN + "Crit Chance: " + critChance[0] + "-" + critChance[1]);
		}
		if(critDamage != null) {
			lore.add(ChatColor.GREEN + "Crit Damage: " + critDamage[0] + "-" + critDamage[1]);
		}
		if(lifesteal != null) {
			lore.add(ChatColor.GREEN + "Lifesteal: " + lifesteal[0] + "-" + lifesteal[1]);
		}
		if(attack != null) {
			if(lore.size() > 3)
				lore.add("");
		} else {
			if(lore.size() > 1)
				lore.add("");
		}
		lore.add(ChatColor.GRAY + "" + ChatColor.ITALIC + "Tier " + tier);
		if(ItemHandler.isWeapon(material)) {
			if(spellName != null && !this.spellName.equals("") && !this.spellName.equals("random") && SpellHandler.getSpell(spellName) != null) {
				lore.add("");
				lore.add(ChatColor.AQUA + "Spell: " + spellName);
				for(String s : SpellHandler.getDescription(spellName))
					lore.add(ChatColor.AQUA + s);
				lore.add(ChatColor.AQUA + SpellHandler.getCooldown(spellName));
			} else {
				lore.add("");
				lore.add(ChatColor.AQUA + "Random Spell");
			}
		}
		if(this.lore != null && !this.lore.equals("")) {
			lore.add("");
			for(String s : Values.stringToLore(this.lore))
				lore.add(s);
		}
		lore.add("");
		lore.add(ChatColor.GOLD + "Price: " + price + "g");
		im.setLore(lore);
		i.setItemMeta(im);
		return ItemHandler.removeAttributes(i);
	}
	
}