package xronbo.ronbomc.items;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.horses.HorseHandler;
import xronbo.ronbomc.horses.HorseHandler.HorseType;
import xronbo.ronbomc.items.ItemHandler.Equip;
import xronbo.ronbomc.warps.WarpHandler;

public class EtcItemListeners implements Listener {
	
	public static RonboMC plugin;
	
	public EtcItemListeners(RonboMC plugin) {
		EtcItemListeners.plugin = plugin;
	}
	
	@EventHandler
	public void itemCastEvent(PlayerInteractEvent event) {
		try {
			EtcItem ei = EtcItem.getEtcType(event.getItem());
			if(ei != null) {
				final Player p = event.getPlayer();
				final PlayerData pd = plugin.getPD(p);
				if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
					Inventory inventory;
					int value, tier;
					switch(ei) {
						case WARPSCROLL_STONEHELM:
							WarpHandler.warp(p, "Stonehelm", ei);
							break;
						case WARPSCROLL_ZENTRELA:
							WarpHandler.warp(p, "Zentrela", ei);
							break;
						case WARPSCROLL_LIPTUS:
							WarpHandler.warp(p, "Liptus", ei);
							break;
						case WARPSCROLL_CIRTOHE:
							WarpHandler.warp(p, "Cirtohe", ei);
							break;
						case WARPSCROLL_SOUTHERNSETTLEMENT:
							WarpHandler.warp(p, "Southern_Settlement", ei);
							break;
						case WARPSCROLL_GWYNETH:
							WarpHandler.warp(p, "Gwyneth", ei);
							break;
						case WARPSCROLL_ELVENSTRONGHOLD:
							WarpHandler.warp(p, "Elven_Stronghold", ei);
							break;
						case WARPSCROLL_KARGOFF:
							WarpHandler.warp(p, "Kargoff", ei);
							break;
						case WARPSCROLL_AJAX:
							WarpHandler.warp(p, "Orc_Mines", ei);
							break;
						case HORSE_DUSTY:
							HorseHandler.giveHorse(p, HorseType.TIER1);
							p.getInventory().removeItem(event.getItem());
							break;
						case RONBON:
							handlePotionDrink(pd, ei, pd.maxHP + pd.maxHP_temp - pd.hp);
							break;
						case HP_POTION_1:
							handlePotionDrink(pd, ei, 30);
							break;
						case HP_POTION_2:
							handlePotionDrink(pd, ei, 200);
							break;
						case HP_POTION_3:
							handlePotionDrink(pd, ei, 1000);
							break;
						case HP_POTION_4:
							handlePotionDrink(pd, ei, 5000);
							break;
						case HP_POTION_5:
							handlePotionDrink(pd, ei, 15000);
							break;
						case HP_POTION_6:
							handlePotionDrink(pd, ei, 40000);
							break;
						case GWYNETH_CHEESE:
							handlePotionDrink(pd, ei, 100);
							break;
						case EXP_BOOSTER_30:
							pd.expBooster = 1.3;
							p.sendMessage(ChatColor.GREEN + "Boosted your EXP by 30% for 10 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.expBooster = 0;
										p.sendMessage(ChatColor.RED + "Your EXP Booster has worn off...");
									}
								}
							}, 20*60*10);
							remove(p, event.getItem());
							break;
						case EXP_BOOSTER_50:
							pd.expBooster = 1.5;
							p.sendMessage(ChatColor.GREEN + "Boosted your EXP by 50% for 10 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.expBooster = 0;
										p.sendMessage(ChatColor.RED + "Your EXP Booster has worn off...");
									}
								}
							}, 20*60*10);
							remove(p, event.getItem());
							break;
						case EXP_BOOSTER_100:
							pd.expBooster = 2;
							p.sendMessage(ChatColor.GREEN + "Boosted your EXP by 100% for 10 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.expBooster = 0;
										p.sendMessage(ChatColor.RED + "Your EXP Booster has worn off...");
									}
								}
							}, 20*60*10);
							remove(p, event.getItem());
							break;
						case DAMAGE_BOOSTER_10:
							pd.damageBooster = 1.1;
							p.sendMessage(ChatColor.GREEN + "Boosted your damage by 10% for 10 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.damageBooster = 0;
										p.sendMessage(ChatColor.RED + "Your Damage Booster has worn off...");
									}
								}
							}, 20*60*10);
							remove(p, event.getItem());
							break;
						case DAMAGE_BOOSTER_15:
							pd.damageBooster = 1.15;
							p.sendMessage(ChatColor.GREEN + "Boosted your damage by 15% for 15 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.damageBooster = 0;
										p.sendMessage(ChatColor.RED + "Your Damage Booster has worn off...");
									}
								}
							}, 20*60*15);
							remove(p, event.getItem());
							break;
						case DAMAGE_BOOSTER_20:
							pd.damageBooster = 1.2;
							p.sendMessage(ChatColor.GREEN + "Boosted your damage by 20% for 20 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										pd.damageBooster = 0;
										p.sendMessage(ChatColor.RED + "Your Damage Booster has worn off...");
									}
								}
							}, 20*60*20);
							remove(p, event.getItem());
							break;
						case SPEED_BOOSTER:
							p.addPotionEffect(PotionEffectType.SPEED.createEffect(5*60*20, 2));
							p.sendMessage(ChatColor.GREEN + "Boosted your speed for 5 minutes!");
							p.sendMessage(ChatColor.GREEN + "Remember, if you log off, your boost will be lost!");
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									if(pd != null && p != null && p.isOnline()) {
										p.sendMessage(ChatColor.RED + "Your Speed Booster has worn off...");
									}
								}
							}, 20*60*5);
							remove(p, event.getItem());
							break;
						case RONBOX_1:
							inventory = Bukkit.createInventory(p, 9 * 6, "Ronbox");
							value = 1 + (int)(Math.random() * 5);
							tier = 1;
							if(Math.random() < 0.3)
								tier = 2;
							if(Math.random() < 0.03)
								tier = 3;
							while(value > 0) {
								inventory.addItem(ItemHandler.createEquip(Equip.values()[(int)(Math.random() * Equip.values().length)], tier));
								if(tier == 1)
									value -= 1;
								else if(tier == 2)
									value -= 3;
								else if(tier == 3)
									value -= 5;
							}
							if(Math.random() < 0.3)
								inventory.addItem(EtcItem.DAMAGE_BOOSTER_10.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.HP_POTION_5.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.4)
								inventory.addItem(EtcItem.HP_POTION_6.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.7)
								inventory.addItem(PlayerData.createBanknote((int)(Math.random() * 1000)));
							p.openInventory(inventory);
							p.sendMessage(ChatColor.GREEN + "You open the Ronbox...");
							remove(p, event.getItem());
							break;
						case RONBOX_2:
							inventory = Bukkit.createInventory(p, 9 * 6, "Ronbox");
							value = 4 + (int)(Math.random() * 10);
							tier = 3;
							if(Math.random() < 0.3)
								tier = 2;
							if(Math.random() < 0.03)
								tier = 4;
							while(value > 0) {
								inventory.addItem(ItemHandler.createEquip(Equip.values()[(int)(Math.random() * Equip.values().length)], tier));
								if(tier == 2)
									value -= 3;
								else if(tier == 3)
									value -= 5;
								else if(tier == 4)
									value -= 8;
							}
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.DAMAGE_BOOSTER_10.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.3)
								inventory.addItem(EtcItem.DAMAGE_BOOSTER_15.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.2)
								inventory.addItem(EtcItem.EXP_BOOSTER_30.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.HP_POTION_5.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.4)
								inventory.addItem(EtcItem.HP_POTION_6.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.7)
								inventory.addItem(PlayerData.createBanknote((int)(Math.random() * 10000)));
							p.openInventory(inventory);
							p.sendMessage(ChatColor.GREEN + "You open the Ronbox...");
							remove(p, event.getItem());
							break;
						case RONBOX_3:
							inventory = Bukkit.createInventory(p, 9 * 6, "Ronbox");
							value = 6 + (int)(Math.random() * 15);
							tier = 3;
							if(Math.random() < 0.3)
								tier = 4;
							if(Math.random() < 0.01)
								tier = 5;
							while(value > 0) {
								inventory.addItem(ItemHandler.createEquip(Equip.values()[(int)(Math.random() * Equip.values().length)], tier));
								if(tier == 3)
									value -= 5;
								else if(tier == 4)
									value -= 8;
								else if(tier == 5)
									value -= 14;
							}
							if(Math.random() < 0.3)
								inventory.addItem(EtcItem.ENCHANTSCROLL_30_10.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.2)
								inventory.addItem(EtcItem.ENCHANTSCROLL_30_15.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.1)
								inventory.addItem(EtcItem.ENCHANTSCROLL_50_10.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.1)
								inventory.addItem(EtcItem.ENCHANTSCROLL_50_15.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.1)
								inventory.addItem(EtcItem.ENCHANTSCROLL_70_10.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.7)
								inventory.addItem(EtcItem.DAMAGE_BOOSTER_10.makeItems((int)(Math.random() * 5)));
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.DAMAGE_BOOSTER_15.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.EXP_BOOSTER_30.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.2)
								inventory.addItem(EtcItem.EXP_BOOSTER_50.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.5)
								inventory.addItem(EtcItem.HP_POTION_5.makeItems((int)(Math.random() * 3)));
							if(Math.random() < 0.4)
								inventory.addItem(EtcItem.HP_POTION_6.makeItems((int)(Math.random() * 2)));
							if(Math.random() < 0.7)
								inventory.addItem(PlayerData.createBanknote((int)(Math.random() * 30000)));
							p.openInventory(inventory);
							p.sendMessage(ChatColor.GREEN + "You open the Ronbox...");
							remove(p, event.getItem());
							break;
						case STAT_POINT_RESET:
							pd.strength = 5;
							pd.dexterity = 5;
							pd.intelligence = 5;
							pd.luck = 5;
							pd.sp = (pd.level - 1) * Values.SP_PER_LEVEL;
							p.sendMessage(ChatColor.GREEN + "Reset your SP! You now have " + pd.sp + " SP available.");
							remove(p, event.getItem());
							break;
						case PET_NAME_CHANGE:
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "Type in the name you want your pet to have.");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Don't worry, there will be a confirmation before it's changed.");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "If your entry is invalid your Pet Name Change won't be used.");
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			pd.awaitingPetNameChange = true;
							break;
						default:
							break;
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@EventHandler
	public void petNameChangeEvent(AsyncPlayerChatEvent event) {
		final String finalMessage = event.getMessage();
		final PlayerData pd = plugin.getPD(event.getPlayer());
		if(pd.awaitingPetNameChange) {
			event.setCancelled(true);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String message = ChatColor.stripColor(finalMessage).trim();
					if(pd.awaitingPetNameChange) {
						if(message.replaceAll("\\w|\\d|\\s", "").length() > 0) {
							pd.player.sendMessage(ChatColor.RED + "Invalid characters: " + ChatColor.BOLD + message.replaceAll("\\w|\\d|\\s", "") + ChatColor.RED + " were used in your desired name. Only letters, numbers, and spaces can be used!");
						} else {
							if(message.length() > 20) {
								pd.player.sendMessage(ChatColor.RED + "Your pet name can only be up to 20 characters long. Your desired one was " + message.length() + " characters. Try a shorter one!");
							} else {
								pd.player.sendMessage(ChatColor.GREEN + "Your desired pet name " + ChatColor.AQUA + ChatColor.BOLD + message + ChatColor.GREEN + " is valid!");
								pd.player.sendMessage(ChatColor.GREEN + "To confirm this name change, use " + ChatColor.YELLOW + "/pet confirmname" + ChatColor.GREEN + ".");
								pd.player.sendMessage(ChatColor.GREEN + "Name changes are PERMANENT! To change again you must use another Pet Name Change!");
								pd.proposedPetName = message;
							}
						}
						pd.awaitingPetNameChange = false;
					}
				}
			});
		}
	}
	
	public static void remove(Player p, ItemStack item) {
		if(item.getAmount() > 1) {
			item.setAmount(item.getAmount() - 1);
		} else {
			p.getInventory().removeItem(item);
		}
		p.updateInventory();
	}
	
	public void handlePotionDrink(final PlayerData pd, final EtcItem ei, int amount) {
		pd.heal(amount);
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				SoundHandler.playSound(pd.player, Sound.DRINK);
				if(EtcItem.getEtcType(pd.player.getItemInHand()) == ei)
					if(pd.player.getItemInHand().getAmount() > 1) {
						pd.player.getItemInHand().setAmount(pd.player.getItemInHand().getAmount() - 1);
					} else {
						pd.player.setItemInHand(new ItemStack(Material.AIR));
					}
				for(int k = 0; k < pd.player.getInventory().getContents().length; k++) {
					final ItemStack i = pd.player.getInventory().getContents()[k];
					if(EtcItem.getEtcType(i) == ei) {
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								if(pd.player.getItemInHand().getType() == Material.AIR) {
									pd.player.getInventory().removeItem(i);
									pd.player.getInventory().setItemInHand(i);
								}
							}
						}, 1);
						break;
					}
				}
			}
		});
	}
}