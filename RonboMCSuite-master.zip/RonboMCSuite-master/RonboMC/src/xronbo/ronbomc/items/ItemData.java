package xronbo.ronbomc.items;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.SpellHandler;
import xronbo.ronbomc.combat.spells.Spell;
import xronbo.ronbomc.items.ItemHandler.Equip;

public class ItemData {
	
	public int strength, dexterity, intelligence, luck;
	public int hpRegen;
	public int hp;
	
	public int attack;
	
	public int critChance; 
	public int critDamage;
	public int lifesteal;
	
	public String lore;
	
	public ItemStack i;
	
	public String attribute;
	public String legendName;
	public String name;
	public int tier;
	public Equip equip;
	public String rarity;
	public String spellName;
	public Spell spell;
	public int enchants = 0;
	
	public ItemData(ItemStack i) {
		this.i = i;
		
		strength = 0;
		dexterity = 0;
		intelligence = 0;
		luck = 0;
		hpRegen = 0;
		critChance = 0;
		critDamage = 0;
		lifesteal = 0;
		hp = 0;
		lore = "";
		attribute = "";
		rarity =  "";
		name = "";
		spellName = "";
		legendName = "";
		spell = null;
		attack = 0;
	}
	
	public void generateStats() {
		setDamageIfWeapon();
		giveHealthIfArmor();
		setAttributeStat(attribute, true);
		setOtherStats();
		calcRarityMultiplier();
//		setSpell();
		addStatsToLore();
	}
	
	public void giveHealthIfArmor() {
		if(ItemHandler.isArmor(equip)) {
			if(!attribute.equals("fortitude"))
				setAttributeStat("fortitude", false);
		}
	}
	
//	public void setSpell() {
//		if(equip != null) {
//			if(ItemHandler.isWeapon(equip)) {
//				int spellTier = 0;
//				switch(tier) {
//					case 1:
//						spellTier = 0;
//						break;
//					case 2:
//						spellTier = (Math.random() < 0.5 ? 0 : 1);
//						break;
//					case 3:
//						spellTier = 1;
//						break;
//					case 4:
//						spellTier = (Math.random() < 0.5 ? 1 : 2);
//						break;
//					case 5:
//						spellTier = 2;
//						break;
//				}
//				spellName = equip.spells[spellTier][(int)(Math.random() * equip.spells[spellTier].length)];
//				spell = SpellHandler.getSpell(spellName);
//			}
//		}
//	}
	
	public void setOtherStats() {
		String attrib = "";
		double chance = Math.random();
		int toAddCount = 0;
		if(chance < Values.STAT_COUNT_8)
			toAddCount = 8;
		else if(chance < Values.STAT_COUNT_7)
			toAddCount = 7;
		else if(chance < Values.STAT_COUNT_6)
			toAddCount = 6;
		else if(chance < Values.STAT_COUNT_5)
			toAddCount = 5;
		else if(chance < Values.STAT_COUNT_4)
			toAddCount = 4;
		else if(chance < Values.STAT_COUNT_3)
			toAddCount = 3;
		else
			toAddCount = 2;
		ArrayList<String> addedAttribs = new ArrayList<String>();
		if(!attribute.equals("")) {
			addedAttribs.add(attribute.toLowerCase());
		}
		boolean triedMain = false, triedMainAgain = false, triedSecondary = false, triedCrit = false;
		for(int k = 0; k < toAddCount; k++) {
			int count = 0;
			do {
				count++;
				attrib = ItemHandler.pickRandom(ItemHandler.attributes);
				boolean isArmor = false;
				if(ItemHandler.isArmor(equip)) {
					isArmor = true;
					String[] invalid = {"killing", "vampirism", "truesight", "seeking"};
					for(String s : invalid)
						if(attrib.equalsIgnoreCase(s))
							attrib = "";
				} else if(ItemHandler.isWeapon(equip)) {
					String[] invalid = {"fortitude"};
					for(String s : invalid)
						if(attrib.equalsIgnoreCase(s))
							attrib = "";
				}
				attrib = attrib.toLowerCase();
				if(!isArmor) {
					String higherChance1 = "", higherChance2 = "";
					switch(equip) {
						case SWORD:
							higherChance1 = "strength";
							higherChance2 = "dexterity";
							break;
						case AXE:
							higherChance1 = "strength";
							higherChance2 = "luck";
							break;
						case MACE:
							higherChance1 = "strength";
							higherChance2 = "intelligence";
							break;
						case STAVE:
							higherChance1 = "strength";
							higherChance2 = "intelligence";
							break;
						case WAND:
							higherChance1 = "intelligence";
							higherChance2 = "luck";
							break;
						case BOW:
							higherChance1 = "dexterity";
							higherChance2 = "strength";
							break;
						case DAGGER:
							higherChance1 = "luck";
							higherChance2 = "dexterity";
							break;
						default:
							break;
					}
					if(!triedMainAgain) {
						if(triedMain)
							triedMainAgain = true;
						triedMain = true;
						if(!addedAttribs.contains(higherChance1)) {
							if(Math.random() < Values.CHANCE_OF_MAIN_STAT) {
								attrib = higherChance1;
							}
						}
					}
					if(!triedSecondary) {
						triedSecondary = true;
						if(!attrib.equalsIgnoreCase(higherChance1)) {
							if(!addedAttribs.contains(higherChance2)) {
								if(Math.random() < Values.CHANCE_OF_SECONDARY_STAT) {
									attrib = higherChance2;
								}
							}
						}
					}
					if(attrib.equals("strength") || attrib.equals("dexterity") || attrib.equals("intelligence") || attrib.equals("luck")) {
						if(!(attrib.equals(higherChance1) || attrib.equals(higherChance2))) {
							attrib = Math.random() < 0.4 ? higherChance2 : higherChance1;
						}
					}
				}
				if(!triedCrit) {
					triedCrit = true;
					if(addedAttribs.contains("seeking") && !addedAttribs.contains("truesight")) {
						if(Math.random() < Values.CHANCE_OF_CRIT_CHANCE_WITH_CRIT_DAMAGE) {
							attrib = "truesight";
						}
					}
				}
				if(addedAttribs.contains(attrib) || attrib.equalsIgnoreCase("killing") || attrib.equalsIgnoreCase("fortitude"))
					attrib = "";
			} while(attrib.equals("") && count < 7);
			if(attrib.length() > 0) {
				addedAttribs.add(attrib);
				setAttributeStat(attrib, false);
			}
		}
		if(addedAttribs.contains("seeking") && !addedAttribs.contains("truesight")) {
			if(Math.random() < Values.CHANCE_OF_CRIT_CHANCE_WITH_CRIT_DAMAGE) {
				attrib = "truesight";
				addedAttribs.add(attrib);
				setAttributeStat(attrib, false);
			}
		}
	}
	
	public void calcRarityMultiplier() {
		double statMultiplier = 1;
		switch(rarity.toLowerCase()) {
			case "common":
				statMultiplier = Values.MULTIPLIER_COMMON;
				attack += 0;
				break;
			case "uncommon":
				statMultiplier = Values.MULTIPLIER_UNCOMMON;
				attack += 10;
				break;
			case "rare":
				statMultiplier = Values.MULTIPLIER_RARE;
				attack += 20;
				break;
			case "epic":
				statMultiplier = Values.MULTIPLIER_EPIC;
				attack += 30;
				break;
			case "unique":
				statMultiplier = Values.MULTIPLIER_UNIQUE;
				attack += 40;
				break;
			case "legendary":
				statMultiplier = Values.MULTIPLIER_LEGENDARY;
				attack += 50;
				break;
			case "godlike":
				statMultiplier = Values.MULTIPLIER_GODLIKE;
				attack += 70;
				break;
		}
		if(ItemHandler.isArmor(equip))
			attack = 0;
		if(attack == 0) {
			if(equip != null) {
				switch(equip) {
					case HELMET:
						statMultiplier += Values.MULTIPLIER_HELMET_BONUS;
						break;
					case CHESTPLATE:
						statMultiplier += Values.MULTIPLIER_CHESTPLATE_BONUS;
						break;
					case LEGGINGS:
						statMultiplier += Values.MULTIPLIER_LEGGINGS_BONUS;
						break;
					case BOOTS:
						statMultiplier += Values.MULTIPLIER_BOOTS_BONUS;
						break;
					default:
						break;
				}
			}
		}
		strength *= statMultiplier;
		dexterity *= statMultiplier;
		intelligence *= statMultiplier;
		luck *= statMultiplier;
		hpRegen *= statMultiplier;
		critChance *= (statMultiplier / Values.STAT_DECREASE_CRIT_CHANCE > 1 ? statMultiplier / Values.STAT_DECREASE_CRIT_CHANCE : 1);
		critDamage *= (statMultiplier / Values.STAT_DECREASE_CRIT_DAMAGE > 1 ? statMultiplier / Values.STAT_DECREASE_CRIT_DAMAGE : 1);
		lifesteal *= (statMultiplier / Values.STAT_DECREASE_LIFESTEAL > 1 ? statMultiplier / Values.STAT_DECREASE_LIFESTEAL : 1);
		hp *= (statMultiplier / Values.STAT_DECREASE_HP > 1 ? statMultiplier / Values.STAT_DECREASE_HP : 1);
	}
	
	public void setDamageIfWeapon() {
		if(!ItemHandler.isWeapon(equip)) {
			attack = 0;
			return;
		}
		String valueName = "T" + tier + "_ATK_" + equip.toString();
		int[] range = null;
		try {
			range = new int[2];
			range[0] = ((int[])(Values.class.getField(valueName).get(Values.values)))[0];
			range[1] = ((int[])(Values.class.getField(valueName).get(Values.values)))[1];
		} catch (Exception e) {
			e.printStackTrace();
		}
		String baseName = "T" + tier + "_ATK_BASE";
		try {
			int[] temp = new int[2];
			temp[0] = ((int[])(Values.class.getField(baseName).get(Values.values)))[0];
			temp[1] = ((int[])(Values.class.getField(baseName).get(Values.values)))[1];
			range[0] += temp[0];
			range[1] += temp[1];
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(range[0] < 1)
			range[0] = 1;
		if(range[1] < 1)
			range[1] = 1;
		attack = (int)(Math.random() * (range[1] - range[0] + 1)) + range[0];
		if(!legendName.equals("")) {
			attack += Values.LEGEND_NAME_ATTACK_BONUS;
		}
	}
	
	public void setAttributeStat(String s, boolean isMainAttribute) {
		if(s.equals(""))
			return;
		int value = getAttributeValue(s.toLowerCase(), tier, isMainAttribute);
		switch(s.toLowerCase()) {
			case "strength":
				strength = value;
				break;
			case "dexterity":
				dexterity = value;
				break;
			case "intelligence":
				intelligence = value;
				break;
			case "luck":
				luck = value;
				break;
			case "fortitude":
				hp = value;
				break;
			case "regeneration":
				hpRegen = value;
				break;
			case "vampirism":
				lifesteal = value;
				break;
			case "truesight":
				critChance = value;
				break;
			case "seeking":
				critDamage = value;
				break;
			case "killing":
				switch(tier) {
					case 1:
						attack += 5;
						break;
					case 2:
						attack += 8;
						break;
					case 3:
						attack += 11;
						break;
					case 4:
						attack += 14;
						break;
					case 5:
						attack += 17;
						break;
				}
				break;
		}
	}
	
	public int getAttributeValue(String attribute, int tier, boolean isMainAttribute) {
		int value = 0;
		switch(attribute.toLowerCase()) {
			case "strength":
			case "dexterity":
			case "intelligence":
			case "luck":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.CORE_STAT_RANGE_T1[0], Values.CORE_STAT_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.CORE_STAT_RANGE_T2[0], Values.CORE_STAT_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.CORE_STAT_RANGE_T3[0], Values.CORE_STAT_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.CORE_STAT_RANGE_T4[0], Values.CORE_STAT_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.CORE_STAT_RANGE_T5[0], Values.CORE_STAT_RANGE_T5[1]);
						break;
				}
				break;
			case "fortitude":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.HP_RANGE_T1[0], Values.HP_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.HP_RANGE_T2[0], Values.HP_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.HP_RANGE_T3[0], Values.HP_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.HP_RANGE_T4[0], Values.HP_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.HP_RANGE_T5[0], Values.HP_RANGE_T5[1]);
						break;
				}
				break;
			case "regeneration":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.HP_REGEN_RANGE_T1[0], Values.HP_REGEN_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.HP_REGEN_RANGE_T2[0], Values.HP_REGEN_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.HP_REGEN_RANGE_T3[0], Values.HP_REGEN_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.HP_REGEN_RANGE_T4[0], Values.HP_REGEN_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.HP_REGEN_RANGE_T5[0], Values.HP_REGEN_RANGE_T5[1]);
						break;
				}
				break;
			case "vampirism":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.LIFESTEAL_RANGE_T1[0], Values.LIFESTEAL_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.LIFESTEAL_RANGE_T2[0], Values.LIFESTEAL_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.LIFESTEAL_RANGE_T3[0], Values.LIFESTEAL_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.LIFESTEAL_RANGE_T4[0], Values.LIFESTEAL_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.LIFESTEAL_RANGE_T5[0], Values.LIFESTEAL_RANGE_T5[1]);
						break;
				}
				break;
			case "truesight":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.CRIT_CHANCE_RANGE_T1[0], Values.CRIT_CHANCE_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.CRIT_CHANCE_RANGE_T2[0], Values.CRIT_CHANCE_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.CRIT_CHANCE_RANGE_T3[0], Values.CRIT_CHANCE_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.CRIT_CHANCE_RANGE_T4[0], Values.CRIT_CHANCE_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.CRIT_CHANCE_RANGE_T5[0], Values.CRIT_CHANCE_RANGE_T5[1]);
						break;
				}
				break;
			case "seeking":
				switch(tier) {
					case 1:
						value = Values.randInt(Values.CRIT_DAMAGE_RANGE_T1[0], Values.CRIT_DAMAGE_RANGE_T1[1]);
						break;
					case 2:
						value = Values.randInt(Values.CRIT_DAMAGE_RANGE_T2[0], Values.CRIT_DAMAGE_RANGE_T2[1]);
						break;
					case 3:
						value = Values.randInt(Values.CRIT_DAMAGE_RANGE_T3[0], Values.CRIT_DAMAGE_RANGE_T3[1]);
						break;
					case 4:
						value = Values.randInt(Values.CRIT_DAMAGE_RANGE_T4[0], Values.CRIT_DAMAGE_RANGE_T4[1]);
						break;
					case 5:
						value = Values.randInt(Values.CRIT_DAMAGE_RANGE_T5[0], Values.CRIT_DAMAGE_RANGE_T5[1]);
						break;
				}
				break;
		}
		if(!legendName.equals("")) {
			value *= Values.LEGEND_NAME_MULTIPLIER_ARMOR;
		}
		if(isMainAttribute) {
			return (int)(Math.ceil(value * Values.MAIN_ATTRIBUTE_MULTIPLIER));
		} else {
			return value;
		}
	}
	
	public void addStatsToLore() {
		ItemMeta im = i.getItemMeta();
		ArrayList<String> lore = new ArrayList<String>();
		if(enchants > 0) {
			StringBuilder sb = new StringBuilder("");
			for(int k = 0; k < enchants; k++)
				sb.append("\u2738");
			lore.add(ChatColor.GOLD + sb.toString());
		}
		if(attack > 0)
			lore.add(ChatColor.WHITE + "Attack: " + ChatColor.GRAY + attack);
		lore.add("");
		if(strength > 0)
			lore.add(ChatColor.GREEN + "Strength: +" + strength);
		if(dexterity > 0)
			lore.add(ChatColor.GREEN + "Dexterity: +" + dexterity);
		if(intelligence > 0)
			lore.add(ChatColor.GREEN + "Intelligence: +" + intelligence);
		if(luck > 0)
			lore.add(ChatColor.GREEN + "Luck: +" + luck);
		if(hpRegen > 0)
			lore.add(ChatColor.GREEN + "HP Regen: +" + hpRegen + " HP/SEC");
		if(critChance > 0)
			if(critChance > 85)
				lore.add(ChatColor.GREEN + "Crit Chance: +85%");
			else
				lore.add(ChatColor.GREEN + "Crit Chance: +" + critChance +"%");
		if(critDamage > 0)
			lore.add(ChatColor.GREEN + "Crit Damage: +" + critDamage +"%");
		if(hp > 0)
			lore.add(ChatColor.GREEN + "HP: +" + hp);
		if(lifesteal > 0)
			lore.add(ChatColor.GREEN + "Lifesteal: +" + lifesteal + "%");
		if(lore.size() > (attack > 0 ? 1 : 2))
			lore.add("");
		lore.add(ChatColor.GRAY + "" + ChatColor.ITALIC + "Tier " + tier);
		if(spellName != null && !this.spellName.equals("")) {
			lore.add("");
			lore.add(ChatColor.AQUA + "Spell: " + spellName);
			for(String s : SpellHandler.getDescription(spellName))
				lore.add(ChatColor.AQUA + s);
			lore.add(ChatColor.AQUA + SpellHandler.getCooldown(spellName));
		}
		if(this.lore != "") {
			lore.add("");
			for(String s : Values.stringToLore(this.lore, ChatColor.ITALIC))
				lore.add(ChatColor.WHITE + s);
		}
		im.setLore(lore);
		i.setItemMeta(im);
	}
	
	
}