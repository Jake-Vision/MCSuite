package xronbo.ronbomc.items;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.NMSStuff;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.SpellHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.entities.MobType;

public class ItemHandler {
	
	public static RonboMC plugin;
	
	public static HashMap<ItemStack, ItemData> items = new HashMap<ItemStack, ItemData>();
	
	public static String[] legendaryNames =
		{ //The Eleven Holy Spirits
			"Ronbo",
			"Elvarg",
			"Silvia",
			"Saki",
			"Fenrir",
			"Cendrillon",
			"Etzali",
			"Vasilisa",
			"Acqua",
			"Fiamma",
			"Aleister"
		};
	
	public static String[] rarities =
		{
			"Common",
			"Uncommon",
			"Rare",
			"Epic",
			"Unique",
			"Legendary",
			"Godlike"
		};

	public enum Equip {
		SWORD(		new Material[]{Material.WOOD_SWORD, Material.STONE_SWORD, Material.IRON_SWORD, Material.GOLD_SWORD, Material.DIAMOND_SWORD}, 
					new String[]{"Sword"}
//					new String[][]{
//						new String[]{"Power Strike I", "Charge I", "Focus I", "Focus II", "Cleave I"},
//						new String[]{"Power Strike II", "Charge II", "Judgement I", "Focus III", "Cleave II"},
//						new String[]{"Power Strike III", "Power Strike IV", "Charge III", "Judgement II", "Judgement III", "Focus IV", "Focus V",
//									 "Cleave III", "Cleave IV"},
//					}
		),
				
		AXE(		new Material[]{Material.WOOD_AXE, Material.STONE_AXE, Material.IRON_AXE, Material.GOLD_AXE, Material.DIAMOND_AXE},
					new String[]{"Axe"}
//					new String[][]{
//						new String[]{"Wild Swing I", "Wild Swing II", "Sacrifice I", "Blood Call I"},
//						new String[]{"Wild Swing III", "Wild Swing IV", "Sacrifice II", "Blood Call II"},
//						new String[]{"Wild Swing V", "Wild Swing VI", "Wild Swing VII", "Sacrifice III", "Sacrifice IV", "Blood Call III", "Blood Call IV"},
//					}
		),
				
		MACE(		new Material[]{Material.WOOD_SPADE, Material.STONE_SPADE, Material.IRON_SPADE, Material.GOLD_SPADE, Material.DIAMOND_SPADE}, 
					new String[]{"Mace"}
//					new String[][]{
//						new String[]{"Smash I", "Smash II", "Indomitable I", "Divine Shield I"},
//						new String[]{"Smash III", "Smash IV", "Indomitable II", "Indomitable III", "Divine Shield II", "Divine Shield III", "Chant of Necessarius I"},
//						new String[]{"Smash V", "Smash VI", "Indomitable IV", "Indomitable V", "Divine Shield IV", "Divine Shield V", "Chant of Necessarius II"},
//					}
		),
					
		STAVE(		new Material[]{Material.STICK, Material.STICK, Material.STICK, Material.STICK, Material.STICK}, 
					new String[]{"Stave"}
//					new String[][]{
//						new String[]{"Self Heal I", "Self Heal II", "Party Heal I", "Party Heal II", "Bless I"},
//						new String[]{"Self Heal III", "Self Heal IV", "Party Heal III", "Party Heal IV", "Bless II", "Bless III", "Intervention I"},
//						new String[]{"Self Heal V", "Self Heal VI", "Party Heal V", "Party Heal VI", "Bless IV", "Bless V", "Intervention II", "Intervention III"},
//					}
		),
					
		WAND(		new Material[]{Material.WOOD_HOE, Material.STONE_HOE, Material.IRON_HOE, Material.GOLD_HOE, Material.DIAMOND_HOE}, 
					new String[]{"Wand"}
//					new String[][]{
//						new String[]{"Fire Bolt I", "Fire Bolt II", "Triple Bolt I", "Triple Bolt II", "Magic Burst I", "Magic Barrage I", "Fire Aura I", "Fire Aura II", "Drain Aura I", "Drain Aura II"},
//						new String[]{"Fire Bolt III", "Fire Bolt IV", "Triple Bolt III", "Triple Bolt IV", "Magic Burst II", "Magic Barrage II", "Magic Barrage III", "Fire Aura III", "Fire Aura IV", "Drain Aura III", "Drain Aura IV"},
//						new String[]{"Fire Bolt V", "Fire Bolt VI", "Triple Bolt V", "Triple Bolt VI", "Magic Burst III", "Magic Barrage IV", "Magic Barrage V", "Fire Aura V", "Fire Aura VI", "Drain Aura V", "Drain Aura VI"},
//					}
		),
					
		BOW(		new Material[]{Material.BOW, Material.BOW, Material.BOW, Material.BOW, Material.BOW},
					new String[]{"Bow"}
//					new String[][]{
//						new String[]{"Double Shot I", "Double Shot II", "Double Shot III", "Empowered Shot I", "Triple Shot I", "Triple Shot II", "Hawkeye I",
//								"Blunt Arrow I"},
//						new String[]{"Double Shot IV", "Empowered Shot II", "Empowered Shot III", "Triple Shot III", "Hurricane I", "Hurricane II", 
//								"Hurricane III", "Hawkeye II", "Rapid Fire I", "Quad Shot I", "Arrow Rain I", "Blunt Arrow II"},
//						new String[]{"Triple Shot IV", "Empowered Shot IV", "Empowered Shot V", "Hurricane IV", "Hurricane V", "Hawkeye III", "Rapid Fire II", 
//								"Rapid Fire III", "Quad Shot II", "Quad Shot III", "Arrow Rain II", "Blunt Arrow III"},
//					}
		),
					
		DAGGER( 	new Material[]{Material.SHEARS, Material.SHEARS, Material.SHEARS, Material.SHEARS, Material.SHEARS},
					new String[]{"Dagger"}
//					new String[][]{
//						new String[]{"Double Stab I", "Double Stab II", "Puncture I", "Sneak Attack I", "Sneak Attack II", "Stealth I", "Golden Touch I"},
//						new String[]{"Double Stab III", "Double Stab IV", "Puncture II", "Sneak Attack III", "Stealth II", "Golden Touch II", "Ambush I", 
//								"Disable I", "Disable II"},
//						new String[]{"Double Stab V", "Double Stab VI", "Puncture III", "Puncture IV", "Sneak Attack IV", "Stealth III", "Golden Touch III", 
//								"Golden Touch IV", "Ambush II", "Ambush III", "Disable III"},
//					}
		),
					
		BONE( 	new Material[]{Material.BONE, Material.BONE, Material.BONE, Material.BONE, Material.BONE},
					new String[]{"Bone"}
//					new String[][]{
//						new String[]{"MMBLARG I", "MMBLARG II", "BOHAAAHA I", "UNNHG I", "UNNHG II"},
//						new String[]{"MMBLARG III", "MMBLARG IV", "BOHAAAHA II", "BOHAAAHA III", "UNNHG III", "UNNHG IV"},
//						new String[]{"MMBLARG V", "MMBLARG VI", "MMBLARG VII", "BOHAAAHA IV", "BOHAAAHA V", "UNNHG V", "UNNHG VI"},
//					}
		),
					
		HELMET(		new Material[] {Material.LEATHER_HELMET, Material.CHAINMAIL_HELMET, Material.IRON_HELMET, Material.GOLD_HELMET, Material.DIAMOND_HELMET},
					new String[]{"Helmet"}
					),
					
		CHESTPLATE(	new Material[] {Material.LEATHER_CHESTPLATE, Material.CHAINMAIL_CHESTPLATE, Material.IRON_CHESTPLATE, Material.GOLD_CHESTPLATE, Material.DIAMOND_CHESTPLATE},
					new String[]{"Chestplate"}
					),
					
		LEGGINGS(	new Material[] {Material.LEATHER_LEGGINGS, Material.CHAINMAIL_LEGGINGS, Material.IRON_LEGGINGS, Material.GOLD_LEGGINGS, Material.DIAMOND_LEGGINGS},
					new String[]{"Leggings"}
					),
					
		BOOTS(		new Material[] {Material.LEATHER_BOOTS, Material.CHAINMAIL_BOOTS, Material.IRON_BOOTS, Material.GOLD_BOOTS, Material.DIAMOND_BOOTS},
					new String[]{"Boots"}
					);
					
		public final Material[] materials;
		public final String[] name;
//		public final String[][] spells;
		
		Equip(Material[] materials, String[] name) {
			this.materials = materials;
			this.name = name;
		}	
		
//		Equip(Material[] materials, String[] name, String[][] spells) {
//			this.materials = materials;
//			this.name = name;
//			this.spells = spells;
//		}	
		
		public boolean isType(ItemStack i) {
			for(Material m : materials)
				if(i.getType() == m)
					return true;
			return false;
		}
	}
	
	public static List<Equip> getArmors() {
		return Arrays.asList(new Equip[] {Equip.HELMET, Equip.CHESTPLATE, Equip.LEGGINGS, Equip.BOOTS});
	}
	
	public static List<Equip> getWeapons() {
		return Arrays.asList(new Equip[] {Equip.SWORD, Equip.AXE, Equip.MACE, Equip.STAVE, Equip.WAND, Equip.BOW, Equip.DAGGER, Equip.BONE});
	}
	
	public static boolean isArmor(Equip e) {
		return getArmors().contains(e);
	}
	
	public static boolean isWeapon(Equip e) {
		return getWeapons().contains(e);
	}
	
	public static Equip getEquip(ItemStack i) {
		for(Equip e : Equip.values())
			if(e.isType(i))
				return e;
		return null;
	}
	
	public static boolean isArmor(Material material) {
		for(Equip e : getArmors()) {
			for(Material m : e.materials) {
				if(m == material)
					return true;
			}
		}
		return false;
	}
	
	public static boolean isWeapon(Material material) {
		for(Equip e : getWeapons()) {
			for(Material m : e.materials) {
				if(m == material)
					return true;
			}
		}
		return false;
	}
	
	
	public static String[] attributes =
		{
			"Strength", //str bonus
			"Luck", //luck bonus
			"Intelligence", //int bonus
			"Dexterity", //dex bonus
			"Killing", //more damage
			"Fortitude", //hp bonus
			"Regeneration", //hp regen
			"Vampirism", //lifesteal
			"Truesight", //crit chance
			"Seeking" //crit damage
		};
	
	private ItemHandler() {
		
	}	
	
	public static HashMap<Integer, SpecialItem> specialItems;
	
	public static void load() {
		specialItems = new HashMap<Integer, SpecialItem>();
		try {
			String itemDataLoc = plugin.getDataFolder() + File.separator + "items.dat";
			Scanner scan = new Scanner(new File(itemDataLoc));
			String s = "";
			if(scan.hasNextLine())
				s = scan.nextLine();
			while(scan.hasNextLine()) {
				if(s.startsWith("ID - ")) {
					SpecialItem si = new SpecialItem();
					si.id = Integer.parseInt(s.substring("ID - ".length()));
					si.name = scan.nextLine();
					s = scan.nextLine();
					si.tier = Integer.parseInt(s.substring("Tier ".length()));
					si.material = Material.getMaterial(scan.nextLine());
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.startsWith("ID - "))
							break;
						if(s.contains("Attack") && !s.contains("Crit")) {
							String s2 = s.substring("Damage: ".length());
							String[] range = s2.split("-");
							si.attack = new int[2];
							si.attack[0] = Integer.parseInt(range[0]);
							si.attack[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Strength")) {
							String s2 = s.substring("Strength: ".length());
							String[] range = s2.split("-");
							si.strength = new int[2];
							si.strength[0] = Integer.parseInt(range[0]);
							si.strength[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Dexterity")) {
							String s2 = s.substring("Dexterity: ".length());
							String[] range = s2.split("-");
							si.dexterity = new int[2];
							si.dexterity[0] = Integer.parseInt(range[0]);
							si.dexterity[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Intelligence")) {
							String s2 = s.substring("Intelligence: ".length());
							String[] range = s2.split("-");
							si.intelligence = new int[2];
							si.intelligence[0] = Integer.parseInt(range[0]);
							si.intelligence[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Luck")) {
							String s2 = s.substring("Luck: ".length());
							String[] range = s2.split("-");
							si.luck = new int[2];
							si.luck[0] = Integer.parseInt(range[0]);
							si.luck[1] = Integer.parseInt(range[1]);
						} else if(s.contains("HP Regen")) {
							String s2 = s.substring("HP Regen: ".length());
							String[] range = s2.split("-");
							si.hpRegen = new int[2];
							si.hpRegen[0] = Integer.parseInt(range[0]);
							si.hpRegen[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Crit Chance")) {
							String s2 = s.substring("Crit Chance: ".length());
							String[] range = s2.split("-");
							si.critChance = new int[2];
							si.critChance[0] = Integer.parseInt(range[0]);
							si.critChance[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Crit Damage")) {
							String s2 = s.substring("Crit Damage: ".length());
							String[] range = s2.split("-");
							si.critDamage = new int[2];
							si.critDamage[0] = Integer.parseInt(range[0]);
							si.critDamage[1] = Integer.parseInt(range[1]);
						} else if(s.contains("HP")) {
							String s2 = s.substring("HP: ".length());
							String[] range = s2.split("-");
							si.hp = new int[2];
							si.hp[0] = Integer.parseInt(range[0]);
							si.hp[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Lifesteal")) {
							String s2 = s.substring("Lifesteal: ".length());
							String[] range = s2.split("-");
							si.lifesteal = new int[2];
							si.lifesteal[0] = Integer.parseInt(range[0]);
							si.lifesteal[1] = Integer.parseInt(range[1]);
						} else if(s.contains("Spell")) {
							String s2 = s.substring("Spell: ".length());
							si.spellName = s2;
						} else {
							if(!s.equals(""))
								si.lore = s;
						}
					}
					if(si.material == null) {
						System.out.println(ChatColor.RED + "Uh oh! Special item " + si.name + " has an invalid Material!");
						continue;
					}
					specialItems.put(si.id, si);
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Loaded " + specialItems.size() + " special items.");
	}
	
	public static ItemData tempLoadItem(ItemStack i) {
		if(i == null)
			return null;
		if(items.containsKey(i))
			return items.get(i);
		if(i.getItemMeta() == null)
			return null;
		ArrayList<String> lore = (ArrayList<String>) (i.getItemMeta().getLore());
		if(lore == null)
			return null;
		ItemData id = new ItemData(i);
		id.name = ChatColor.stripColor(i.getItemMeta().getDisplayName());
		boolean foundTier = false; //used to see if an item has stats or not
		for(String s : lore) {
			s = ChatColor.stripColor(s);
			s = s.replace("%", "");
			if(s.startsWith("Attack")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.attack = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Strength")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.strength = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Dexterity")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.dexterity = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Intelligence")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.intelligence = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Luck")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.luck = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("HP Regen")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.hpRegen = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Crit Chance")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.critChance = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Crit Damage")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.critDamage = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("HP")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.hp = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.contains("Lifesteal")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.lifesteal = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
			} else if(s.startsWith("Tier")) {
				Scanner scan = new Scanner(s);
				while(scan.hasNext()) {
					if(scan.hasNextInt()) {
						id.tier = scan.nextInt();
						break;
					} else {
						scan.next();
					}
				}
				scan.close();
				foundTier = true;
			} else if(s.startsWith("Spell")) {
				id.spellName = ChatColor.stripColor(s).substring("Spell: ".length());
				id.spell = SpellHandler.getSpell(id.spellName);
			} else if(s.contains("\u2738")) {
				id.enchants = ChatColor.stripColor(s).length()/"\u2738".length();
			} else {
				//usually just lore stuff
			} 
		}
		if(!foundTier)
			return null;
		for(String s : rarities) {
			if(id.name.contains(s)) {
				id.rarity = s;
			}
		}
		for(Equip e : Equip.values()) {
			if(e.isType(i)) {
				id.equip = e;
				break;
			}
		}
		return id;
	}
	
	public static boolean loadItem(ItemStack i) {
		ItemData id = tempLoadItem(i);
		if(id != null) {
			items.put(i, id);
			return true;
		} else {
			return false;
		}
	}
	
	@SuppressWarnings("unused")
	public static ItemData statReset(ItemData id) {
		Field field;
		int[] stat_range = null;
		try {
			field = Values.class.getField("CORE_STAT_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.tier > 3) {
			id.tier = 3;
			ItemMeta im = id.i.getItemMeta();
			String name = ChatColor.stripColor(im.getDisplayName());
			if(id.rarity.length() > 0 && !id.rarity.equalsIgnoreCase("Common")) {
				name = name.substring(id.rarity.length() + 1);
			}
			id.rarity = "Epic";
			im.setDisplayName(ChatColor.RED + "Epic " + name);
			id.i.setItemMeta(im);
			id.i.setType(id.equip.materials[2]);
		}
		if(id.i.getItemMeta().getDisplayName().contains(" of ")) {
			String newName = id.i.getItemMeta().getDisplayName().substring(0, id.i.getItemMeta().getDisplayName().lastIndexOf(" of "));
			ItemMeta im = id.i.getItemMeta();
			im.setDisplayName(newName);
			id.i.setItemMeta(im);
		}
		id.setDamageIfWeapon();
//		System.out.println("Changed attack from " + original2 + " to " + id.attack);
		if(id.strength > 0) {
			int original = id.strength;
			id.strength = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed strength from " + original + " to " + id.strength);
		}
		if(id.dexterity > 0) {
			int original = id.dexterity;
			id.dexterity = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed dexterity from " + original + " to " + id.dexterity);
		}
		if(id.intelligence > 0) {
			int original = id.intelligence;
			id.intelligence = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed intelligence from " + original + " to " + id.intelligence);
		}
		if(id.luck > 0) {
			int original = id.luck;
			id.luck = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed luck from " + original + " to " + id.luck);
		}
		if(id.luck > 0) {
			int original = id.luck;
			id.luck = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed luck from " + original + " to " + id.luck);
		}
		
		try {
			field = Values.class.getField("HP_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.hp > 0) {
			int original = id.hp;
			id.hp = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed hp from " + original + " to " + id.hp);
		}
		
		try {
			field = Values.class.getField("HP_REGEN_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.hpRegen > 0) {
			int original = id.hpRegen;
			id.hpRegen = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed hpRegen from " + original + " to " + id.hpRegen);
		}
		
		try {
			field = Values.class.getField("LIFESTEAL_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.lifesteal > 0) {
			int original = id.lifesteal;
			id.lifesteal = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed lifesteal from " + original + " to " + id.lifesteal);
		}
		
		try {
			field = Values.class.getField("CRIT_CHANCE_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.critChance > 0) {
			int original = id.critChance;
			id.critChance = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed critChance from " + original + " to " + id.critChance);
		}
		
		try {
			field = Values.class.getField("CRIT_DAMAGE_RANGE_T" + id.tier);
			stat_range = (int[])field.get(Values.values);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id.critDamage > 0) {
			int original = id.critDamage;
			id.critDamage = Values.randInt(stat_range[0], stat_range[1]);
//			System.out.println("Changed critDamage from " + original + " to " + id.critDamage);
		}

		id.calcRarityMultiplier();
		id.addStatsToLore();
		return id;
	}
	
	public static Equip getRandomEquip() {
		return Equip.values()[(int)(Math.random() * Equip.values().length)];
	}

	public static double getRand(double multiplier) {
		double rand = Math.random();
		try {
			rand /= multiplier;
		} catch(Exception e) {
			rand = 1;
		}
		if(rand > 1)
			rand = 1;
		return rand;
	}
	
	
	public static ArrayList<ItemStack> generateDrops(int tier, double multiplier) {
		return generateDrops(tier,multiplier,true);
	}
	
	public static int[] tierkilled = new int[5];

	public static ArrayList<ItemStack> generateDrops(int tier, double multiplier, boolean potions) {
		ArrayList<ItemStack> drops = new ArrayList<ItemStack>();
		switch(tier) {
			case 1:
				tierkilled[tier-1]++;
				if(getRand(multiplier) < Values.DROP_RATE_TIER1_GET_TIER2)
					drops.add(createEquip(getRandomEquip(), 2));
				if(getRand(multiplier) < Values.DROP_RATE_TIER1_GET_TIER1 * (1 + 0.01 * tierkilled[tier-1])) {
					drops.add(createEquip(getRandomEquip(), 1));
					tierkilled[tier-1] = 0;
				}
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER1_GET_HP1)
					drops.add(EtcItem.HP_POTION_1.makeItems(1)[0]);
				break;
			case 2:
				tierkilled[tier-1]++;
				if(getRand(multiplier) < Values.DROP_RATE_TIER2_GET_TIER2 * (1 + 0.01 * tierkilled[tier-1])) {
					drops.add(createEquip(getRandomEquip(), 2));
					tierkilled[tier-1] = 0;
				}
				if(getRand(multiplier) < Values.DROP_RATE_TIER2_GET_TIER1)
					drops.add(createEquip(getRandomEquip(), 1));
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER2_GET_HP1)
					drops.add(EtcItem.HP_POTION_1.makeItems(1)[0]);
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER2_GET_HP2)
					drops.add(EtcItem.HP_POTION_2.makeItems(1)[0]);
				break;
			case 3:
				tierkilled[tier-1]++;
				if(getRand(multiplier) < Values.DROP_RATE_TIER3_GET_TIER3 * (1 + 0.01 * tierkilled[tier-1])) {
					drops.add(createEquip(getRandomEquip(), 3));
					tierkilled[tier-1] = 0;
				}
				if(getRand(multiplier) < Values.DROP_RATE_TIER3_GET_TIER2)
					drops.add(createEquip(getRandomEquip(), 2));
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER3_GET_HP1)
					drops.add(EtcItem.HP_POTION_1.makeItems(1)[0]);
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER3_GET_HP2)
					drops.add(EtcItem.HP_POTION_2.makeItems(1)[0]);
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER3_GET_HP1)
					drops.add(EtcItem.HP_POTION_3.makeItems(1)[0]);
				break;
			case 4:
				tierkilled[tier-1]++;
				if(getRand(multiplier) < Values.DROP_RATE_TIER4_GET_TIER4 * (1 + 0.01 * tierkilled[tier-1])) {
					drops.add(createEquip(getRandomEquip(), 4));
					tierkilled[tier-1] = 0;
				}
				if(getRand(multiplier) < Values.DROP_RATE_TIER4_GET_TIER3)
					drops.add(createEquip(getRandomEquip(), 3));
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER4_GET_HP4)
					drops.add(EtcItem.HP_POTION_4.makeItems(1)[0]);
				break;
			case 5:
				tierkilled[tier-1]++;
				if(getRand(multiplier) < Values.DROP_RATE_TIER5_GET_TIER5 * (1 + 0.01 * tierkilled[tier-1])) {
					drops.add(createEquip(getRandomEquip(), 5));
					tierkilled[tier-1] = 0;
				}
				if(getRand(multiplier) < Values.DROP_RATE_TIER5_GET_TIER4)
					drops.add(createEquip(getRandomEquip(), 4));
				if(getRand(multiplier) < Values.DROP_RATE_TIER5_GET_TIER3)
					drops.add(createEquip(getRandomEquip(), 3));
				if(potions && getRand(multiplier) < Values.DROP_RATE_TIER5_GET_HP5)
					drops.add(EtcItem.HP_POTION_5.makeItems(1)[0]);
				break;
		}
		return drops;
	}
	
	public static ItemStack makeUntradeable(ItemStack item) {
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(im.getDisplayName() + ChatColor.RED + " [Untradeable]");
		item.setItemMeta(im);
		return item;
	}
	
	public static ItemStack makeTradeable(ItemStack item) {
		if(isTradeable(item))
			return item;
		ItemMeta im = item.getItemMeta();
		String name = im.getDisplayName();
		int index = name.indexOf(ChatColor.RED + " [Untradeable]");
		im.setDisplayName(name.substring(0, index) + name.substring(index + (ChatColor.RED + " [Untradeable]").length()));
		item.setItemMeta(im);
		return item;
	}
	
	public static boolean isTradeable(ItemStack item) {
		try {
			return !item.getItemMeta().getDisplayName().contains(ChatColor.RED + " [Untradeable]");
		} catch(Exception e) {
			return true;
		}
	}
	
	public static ArrayList<ItemStack> generateDrops(int tier) {
		return generateDrops(tier, 1.0);
	}
	
	public static ArrayList<ItemStack> generateDrops(Entity entity) {
		MobData md = MobHandler.spawnedMobs.get(entity.getUniqueId());
		MobType mt = md.mobType;
		int tier = mt.tier;
		ArrayList<ItemStack> drops = generateDrops(tier, mt.equipmentDropMultiplier);
		return drops;
	}

	
	public static String[] armorPrefixes = {
		"Fancy", "Shiny", "Worn", "Comfortable", "Sturdy", "Ancient", "Casual", "Clingy", "Cool", "Formal", "Bulky", "Light", 
		"Padded", "Tight", "Unfashionable", "Heavy", "Necessarius", "Blessed", "Cursed", "Holy", "Battle", "Traditional", "Demonic", "Azusa"
		};
	public static String[] weaponPrefixes = {
		"Revered", "Worn", "Traditional", "Pretty", "Deadly", "Cracked", "Ancient", "Assault", "Battle", "Wicked", "Cursed",
		"Holy", "Blessed", "Necessarius", "Demonic", "Fancy", "Shiny", "Lethal", "Mortal", "Fatal", "Savage", "Infamous", "Azusa"
		};
	
	public static ItemStack createEquip(Equip e, int tier) {
		Material m = e.materials[tier - 1];
		String name = e.name[(int)(Math.random() * e.name.length)];

		String legendName = "";
		if(tier == 4) {
			if(Math.random() < Values.T4_LEGEND_NAME_CHANCE) {
				legendName = pickRandom(legendaryNames);
			}
		} else if(tier == 5) {
			if(Math.random() < Values.T5_LEGEND_NAME_CHANCE) {
				legendName = pickRandom(legendaryNames);
			}
		}
		
		int rarity_value = 0;
		double rarity_chance = Math.random();
		if(rarity_chance < Values.RARITY_GODLIKE) {
			rarity_value = 6;
		} else if(rarity_chance < Values.RARITY_LEGENDARY) {
			rarity_value = 5;
		} else if(rarity_chance < Values.RARITY_UNIQUE) {
			rarity_value = 4;
		} else if(rarity_chance < Values.RARITY_EPIC) {
			rarity_value = 3;
		} else if(rarity_chance < Values.RARITY_RARE) {
			rarity_value = 2;
		} else if(rarity_chance < Values.RARITY_UNCOMMON) {
			rarity_value = 1;
		}
		
		if(legendName != null && !legendName.equals("")) {
			if(rarity_value < 2)
				rarity_value = Math.random() < 0.3 ? 3 : 2;
		}
		
		String rarity = rarities[rarity_value];
		
		String color = getRarityColor(rarity).toString();
		String attribute = "";
		if(Math.random() < Values.ITEM_HAS_ATTRIBUTE) {
			boolean retry = false;
			int count = 0;
			do {
				count++;
				attribute = pickRandom(attributes);
				if(isArmor(e)) {
					String[] invalid = {"killing", "vampirism", "truesight", "seeking"};
					for(String s : invalid) {
						if(attribute.toLowerCase().equals(s)) {
							attribute = "";
							retry = true;
						}
					}
				}
			} while(retry && count < 10);
		}
		
		String prefix = "";
		
		if(Math.random() < 0.2 || (Math.random() < 0.75 && attribute.equals(""))) {
			if(isArmor(e)) {
				prefix = armorPrefixes[((int)(Math.random() * armorPrefixes.length))];
			} else if(isWeapon(e)) {
				prefix = weaponPrefixes[((int)(Math.random() * weaponPrefixes.length))];
			}
		}
		
		String fullName = color + (legendName.equals("") ? "" : legendName + "\'s ") + (rarity.equals("Common") ? "" : rarity + " ") + (prefix.equals("") ? "" : prefix + " ") + name + (attribute.equals("") ? "" : " of " + attribute);
		
		ItemStack i = new ItemStack(m);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(fullName);
		i.setItemMeta(im);
		
		ItemData id = new ItemData(i);
		id.rarity = rarity;
		id.tier = tier;
		id.legendName = legendName;
		id.attribute = attribute;
		id.name = name;
		id.equip = e;
		id.generateStats();
		items.put(i, id);
		
		return removeAttributes(i);
	}
	
	public static ChatColor getRarityColor(String s) {
		switch(s) {
			case "Common":
				return ChatColor.GRAY;
			case "Uncommon":
				return ChatColor.WHITE;
			case "Rare":
				return ChatColor.LIGHT_PURPLE;
			case "Epic":
				return ChatColor.RED;
			case "Unique":
				return ChatColor.AQUA;
			case "Legendary":
				return ChatColor.GREEN;
			case "Godlike":
				return ChatColor.GOLD;
		}
		return ChatColor.GRAY;
	}
	
    public static ItemStack removeAttributes(ItemStack item){
		try {
		  Object nmsItem = NMSStuff.getNMSItem(item);
		  if(nmsItem == null)
			  return item;
		  Object modifiers = NMSStuff.getNMSClass("NBTTagList").newInstance();
		  Object tag = NMSStuff.getNMSValue("ItemStack", "tag", nmsItem);
		  if(tag == null) {
		      tag = NMSStuff.getNMSClass("NBTTagCompound").newInstance();
		      NMSStuff.setNMSValue("ItemStack", "tag", nmsItem, tag);
		  }
		  Method meth = NMSStuff.getNMSClass("NBTTagCompound").getDeclaredMethod("set", String.class, NMSStuff.getNMSClass("NBTBase"));
		  meth.invoke(tag, "AttributeModifiers", modifiers);
		  NMSStuff.setNMSValue("ItemStack", "tag", nmsItem, tag);
		  return NMSStuff.getBukkitItem(nmsItem);
		} catch (Exception e) {
			
		}
        return item;
    }
	
	public static String pickRandom(String[] vals) {
		int i = (int) (Math.random() * vals.length);
		return vals[i];
	}
	
	public static String pickRandom(String[] vals, int min, int max) {
		if(min > vals.length)
			min = vals.length;
		if(max > vals.length)
			max = vals.length;
		int i = (int) (Math.random() * (max - min) + min);
		return vals[i];
	}
	
}