package xronbo.ronbomc.items;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.Values;


public enum EtcItem {
	
	/*
	 * Misc.
	 */
	GOLD("gold", Material.GOLD_NUGGET, ChatColor.GOLD + "Gold", "The official currency of Kastia"),
	
	/*
	 * Vote Rewards
	 */
	STAT_POINT_RESET("spreset", Material.PAPER, ChatColor.GOLD + "Stat Point Reset", "Right click with this to reset your Stat Points!"),
	EXP_BOOSTER_30("expbooster30", Material.PAPER, ChatColor.GOLD + "EXP Booster +30% (10 min.)", "Right click with this to receive 30% bonus EXP from all sources for 10 minutes!", "The effects of EXP Boosts do NOT stack with other EXP Boosts.", "WARNING: If you log off, the EXP Boost will stop."),
	EXP_BOOSTER_50("expbooster50", Material.PAPER, ChatColor.GOLD + "EXP Booster +50% (10 min.)", "Right click with this to receive 50% bonus EXP from all sources for 10 minutes!", "The effects of EXP Boosts do NOT stack with other EXP Boosts.", "WARNING: If you log off, the EXP Boost will stop."),
	EXP_BOOSTER_100("expbooster100", Material.PAPER, ChatColor.GOLD + "EXP Booster +100% (10 min.)", "Right click with this to receive 100% bonus EXP from all sources for 10 minutes!", "The effects of EXP Boosts do NOT stack with other EXP Boosts.", "WARNING: If you log off, the EXP Boost will stop."),
	DAMAGE_BOOSTER_10("damagebooster10", Material.PAPER, ChatColor.GOLD + "Damage Booster +10% (10 min.)", "Right click with this to deal 10% bonus damage for 10 minutes!", "The effects of Damage Boosts do NOT stack with other Damage Boosts.", "WARNING: If you log off, the Damage Boost will stop."),
	DAMAGE_BOOSTER_15("damagebooster15", Material.PAPER, ChatColor.GOLD + "Damage Booster +15% (15 min.)", "Right click with this to deal 15% bonus damage for 15 minutes!", "The effects of Damage Boosts do NOT stack with other Damage Boosts.", "WARNING: If you log off, the Damage Boost will stop."),
	DAMAGE_BOOSTER_20("damagebooster20", Material.PAPER, ChatColor.GOLD + "Damage Booster +20% (20 min.)", "Right click with this to deal 20% bonus damage for 20 minutes!", "The effects of Damage Boosts do NOT stack with other Damage Boosts.", "WARNING: If you log off, the Damage Boost will stop."),
	SPEED_BOOSTER("speedbooster", Material.PAPER, ChatColor.GOLD + "Speed Booster (5 min.)", "Right click for 5 minutes of super speed!", "The effects of Speed Boosts do NOT stack with other Speed Boosts.", "WARNING: If you log off, the Speed Boost will stop."),
	RONBOX_1("ronbox1", Material.CHEST, ChatColor.GOLD + "Dirty Ronbox", "A dirty Ronbox. What could be inside?", "Right click with this to open it!", "Careful, it only opens once."),
	RONBOX_2("ronbox2", Material.CHEST, ChatColor.GOLD + "Shiny Ronbox", "A shiny Ronbox. What could be inside?", "Right click with this to open it!", "Careful, it only opens once."),
	RONBOX_3("ronbox3", Material.CHEST, ChatColor.GOLD + "Lnlopxjntej Ronbox", "A lnlopxjntej Ronbox. What does it mean? What's inside?", "Right click with this to open it!", "Careful, it only opens once."),
	
	/*
	 * Pet Stuff
	 */
	PET_NAME_CHANGE("petnamechange", false, Material.PAPER, ChatColor.GOLD + "Pet Name Change", "Change your beloved pet's name!", "Name changes cannot be reverted without another Pet Name Change item.", "", "Your desired name CAN ONLY CONTAIN alphanumeric characters and spaces.", "(a.k.a. A-Z, a-z, 0-9, and spaces)", "", "Vulgar and inappropriate names will be forcibly changed.", "Names are limited to 20 characters in length.", "", "To begin, right click with this item!"),
	
	/*
	 * Healing
	 */
	HP_POTION_1("hp1", Material.POTION, ChatColor.WHITE + "Minor Healing Potion", "A minor healing potion.", "Drink it for an instant 30 HP heal!"),
	HP_POTION_2("hp2", Material.POTION, ChatColor.WHITE + "Lesser Healing Potion", "A lesser healing potion.", "Drink it for an instant 200 HP heal!"),
	HP_POTION_3("hp3", Material.POTION, ChatColor.WHITE + "Greater Healing Potion", "A greater healing potion.", "Drink it for an instant 1000 HP heal!"),
	HP_POTION_4("hp4", Material.POTION, ChatColor.WHITE + "Superior Healing Potion", "A superior healing potion.", "Drink it for an instant 5000 HP heal!"),
	HP_POTION_5("hp5", Material.POTION, ChatColor.WHITE + "Major Healing Potion", "A major healing potion.", "Drink it for an instant 15000 HP heal!"),
	HP_POTION_6("hp6", Material.POTION, ChatColor.WHITE + "Master Healing Potion", "A master healing potion.", "Drink it for an instant 40000 HP heal!"),
	GWYNETH_CHEESE("gwyneth_cheese", Material.POISONOUS_POTATO, ChatColor.WHITE + "Gwyneth Cheese", "Yummy!", "Eat it for an instant 100 HP heal!"),
	RONBON("ronbon", Material.BREAD, ChatColor.WHITE + "Ronbon", "A true delicacy.", "Eat it to instantly heal all your health!"),
	
	/*
	 * Warp Scrolls
	 */
	WARPSCROLL_STONEHELM("warpscroll_stonehelm", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Stonehelm", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_ZENTRELA("warpscroll_zentrela", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Zentrela", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_LIPTUS("warpscroll_liptus", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Liptus", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_CIRTOHE("warpscroll_cirtohe", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Cirtohe", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_SOUTHERNSETTLEMENT("warpscroll_southernsettlement", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Southern Settlement", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_GWYNETH("warpscroll_gwyneth", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Gwyneth", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_ELVENSTRONGHOLD("warpscroll_elvenstronghold", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Elven Stronghold", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_KARGOFF("warpscroll_kargoff", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Kargoff", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	WARPSCROLL_AJAX("warpscroll_ajax", Material.PAPER, ChatColor.AQUA + "Warp Scroll - Orc Mines", "A magical scroll which will warp you to its destination 5 seconds after casting it.", "If you move, the cast will be cancelled!"),
	
	/*
	 * Questing
	 */
	PRETTY_EGG("pretty_egg", Material.EGG, ChatColor.WHITE + "Pretty Egg", "A pretty egg.", "It's really quite pretty."),
	MERCENARY_TOKEN("mercenary_token", false, Material.GHAST_TEAR, ChatColor.WHITE + "Mercenary's Token", "A token that the mercenaries' leader was carrying."),
	KROLAR_HEART("krolar_heart", false, Material.ROTTEN_FLESH, ChatColor.WHITE + "Krolar's Heart", "The heart of General Krolar."),
	AJAX_HEAD("ajax_head", false, Material.SKULL_ITEM, ChatColor.WHITE + "Ajax's Head", "The head of General Ajax"),
	ASTAROTH_BONE("astaroth_bone", false, Material.BONE, ChatColor.WHITE + "Astaroth's Bone", "A bone from General Astaroth's body"),
	AJAX_MANUSCRIPT("ajax_manuscript", false, Material.BOOK, ChatColor.WHITE + "Ajax Manuscript", "A mysterious manuscript."),
	KARGETH_BADGE("kargeth_badge", false, Material.MAGMA_CREAM, ChatColor.WHITE + "Kargeth's Badge", "A badge from the one and only Lord Kargeth."),
	ROYAL_DIAMOND("royal_diamond", false, Material.DIAMOND, ChatColor.WHITE + "Royal Diamond", "Oh, gosh! It's so shiny!"),
	SEWER1("sewer1", false, Material.APPLE, ChatColor.WHITE + "Red Apple", "It's red."),
	SEWER2("sewer2", false, Material.COOKIE, ChatColor.WHITE + "Chocolate Cookie", "Yum!"),
	SEWER3("sewer3", false, Material.SUGAR, ChatColor.WHITE + "Sugar", "Use with caution."),
	SEWER4("sewer4", false, Material.BOWL, ChatColor.WHITE + "Bowl", "Just your standard bowl."),
	SEWER5("sewer5", false, Material.BRICK, ChatColor.WHITE + "Brick", "It doesn't look edible."),
	
	/*
	 * Horse Tokens 
	 */
	HORSE_DUSTY("horse_dusty", false, Material.GHAST_TEAR, ChatColor.WHITE + "Horse Token: Dusty", "It's Dusty, the horse!", "Right-click with this token to receive Dusty.", "If you already have a horse, that horse will be replaced!"),
	
	/*
	 * Enchanting
	 */
	ENCHANTSCROLL_30_5("enchantscroll_30_5", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 30% (+5)", "Raises all stats on an equip by 5", "30% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_50_5("enchantscroll_50_5", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 50% (+5)", "Raises all stats on an equip by 5", "50% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_70_5("enchantscroll_70_5", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 70% (+5)", "Raises all stats on an equip by 5", "70% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_30_10("enchantscroll_30_10", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 30% (+10)", "Raises all stats on an equip by 10", "30% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_50_10("enchantscroll_50_10", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 50% (+10)", "Raises all stats on an equip by 10", "50% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_70_10("enchantscroll_70_10", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 70% (+10)", "Raises all stats on an equip by 10", "70% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_30_15("enchantscroll_30_15", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 30% (+15)", "Raises all stats on an equip by 15", "30% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_50_15("enchantscroll_50_15", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 50% (+15)", "Raises all stats on an equip by 15", "50% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	ENCHANTSCROLL_70_15("enchantscroll_70_15", Material.PAPER, ChatColor.GREEN + "Enchant Scroll 70% (+15)", "Raises all stats on an equip by 15", "70% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_30_10("darkenchantscroll_30_10", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 30% (+10)", "Raises all stats on an equip by 10", "30% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_50_10("darkenchantscroll_50_10", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 50% (+10)", "Raises all stats on an equip by 10", "50% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_70_10("darkenchantscroll_70_10", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 70% (+10)", "Raises all stats on an equip by 10", "70% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_30_15("darkenchantscroll_30_15", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 30% (+15)", "Raises all stats on an equip by 15", "30% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_50_15("darkenchantscroll_50_15", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 50% (+15)", "Raises all stats on an equip by 15", "50% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_70_15("darkenchantscroll_70_15", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 70% (+15)", "Raises all stats on an equip by 15", "70% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_30_20("darkenchantscroll_30_20", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 30% (+20)", "Raises all stats on an equip by 20", "30% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_50_20("darkenchantscroll_50_20", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 50% (+20)", "Raises all stats on an equip by 20", "50% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DARKENCHANTSCROLL_70_20("darkenchantscroll_70_20", Material.PAPER, ChatColor.GREEN + "Dark Enchant Scroll 70% (+20)", "Raises all stats on an equip by 20", "70% chance of successful enchant.", "If enchant fails, 50% chance of item destruction.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	VIPENCHANTSCROLL_100_10("vipenchantscroll_100_10", false, Material.PAPER, ChatColor.GREEN + "VIP Enchant Scroll 100% (+10)", "Raises all stats on an equip by 10", "100% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	VIPENCHANTSCROLL_100_20("vipenchantscroll_100_20", false, Material.PAPER, ChatColor.GREEN + "VIP Enchant Scroll 100% (+20)", "Raises all stats on an equip by 20", "100% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	VIPENCHANTSCROLL_100_30("vipenchantscroll_100_30", false, Material.PAPER, ChatColor.GREEN + "VIP Enchant Scroll 100% (+30)", "Raises all stats on an equip by 30", "100% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	DESTINY_SCROLL("destinyscroll", false, Material.PAPER, ChatColor.GREEN + "Destiny Enchant Scroll 100% (+50)", "A scroll filled with raw power", "Raises all stats on an equip by 50", "100% chance of successful enchant.", "", "Use /enchant to begin enchanting!", "Make sure you read all the information on enchanting!"),
	GUARDIAN_CHARM("guardian_charm", new ItemStack(Material.INK_SACK, 1, (byte)(15 - DyeColor.LIGHT_BLUE.getData())), ChatColor.GREEN + "Guardian Charm", "Used in Enchanting.", "", "Prevents an item from being destroyed for any reason."),
	LUCKY_CHARM("lucky_charm", new ItemStack(Material.INK_SACK, 1, (byte)(15 - DyeColor.GREEN.getData())), ChatColor.GREEN + "Lucky Charm", "Used in Enchanting.", "", "Increases the success rate of a scroll by 5%"),
	;
	
	public String identifier, name;
	public List<String> lore;
	public ItemStack item;
	public ItemStack template;
	public boolean tradeable;
	
	EtcItem(String identifier, Object itemstack, String name, String... lore) {
		this(identifier,true,itemstack,name,lore);
	}
	
	EtcItem(String identifier, boolean tradeable, Object itemstack, String name, String... lore) {
		this.identifier = identifier;
		this.name = name;
		this.tradeable = tradeable;
		if(itemstack instanceof Material)
			this.template = new ItemStack((Material)itemstack);
		else if(itemstack instanceof ItemStack)
			this.template = (ItemStack)itemstack;
		this.lore = Arrays.asList(format(lore));
	}
	
	public static String[] format(String[] lore) {
		ArrayList<String> newLore = new ArrayList<String>();
		for(String s2 : lore) {
			newLore.addAll(Arrays.asList(Values.stringToLore(s2, ChatColor.YELLOW)));
			if(lore.length > 1)
				newLore.add("");
		}
		if(newLore.get(newLore.size() - 1).equals(""))
			newLore.remove(newLore.size() - 1);
		return newLore.toArray(new String[newLore.size()]);
	}
	
	public void loadItem() {
		item = template.clone();
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(name);
		im.setLore(lore);
		item.setItemMeta(im);
	}
	
	public boolean checkInventory(Player p, int amount) {
		int count = 0;
		for(int k = 0; k < p.getInventory().getContents().length; k++) {
			ItemStack i = p.getInventory().getContents()[k];
			if(i != null) {
				if(getEtcType(i) == this)
					count += i.getAmount();
			}
			if(count >= amount) {
				for(int k2 = 0; k2 < p.getInventory().getContents().length; k2++) {
					ItemStack i2 = p.getInventory().getContents()[k2];
					if(i2 != null) {
						if(getEtcType(i2) == this) {
							if(i2.getAmount() > amount) {
								i2.setAmount(i2.getAmount() - amount);
								amount = 0;
							} else {
								amount -= i2.getAmount();
								p.getInventory().removeItem(i2);
							}
						}
					}
				}
				return true;
			}
		}
		return false;
	}
	
	public ItemStack[] makeItems(int amount) {
		ArrayList<ItemStack> i = new ArrayList<ItemStack>();
		while(amount > 0) {
			int toAdd = 0;
			if(amount > 64) {
				toAdd = 64;
			} else {
				toAdd = amount;
			}
			if(item == null)
				loadItem();
			ItemStack clone = item.clone();
			if(toAdd > clone.getMaxStackSize())
				toAdd = clone.getMaxStackSize();
			clone.setAmount(toAdd);
			i.add(clone);
			amount -= toAdd;
		}
		ItemStack[] array = new ItemStack[i.size()];
		return i.toArray(array);
	}
	
	public static EtcItem getEtcItem(String s) {
		for(EtcItem ei : EtcItem.values()) {
			if(ei.identifier.equalsIgnoreCase(s))
				return ei;
		}
		System.out.println("Could not find EtcItem " + s);
		return null;
	}
	
	public static EtcItem getEtcType(ItemStack i) {
		for(EtcItem ei : EtcItem.values()) {
			try {
				if(ei.item == null)
					ei.loadItem();
				if(!ItemHandler.isTradeable(i)) {
					i = i.clone();
					ItemHandler.makeTradeable(i);
				}
				if(ei.item.getItemMeta().getDisplayName().equals(i.getItemMeta().getDisplayName()))
					return ei;
			} catch(Exception e) {
				
			}
		}
		return null;
	}

}