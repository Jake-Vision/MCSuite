package xronbo.ronbomc.warps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.EtcItemListeners;

public class WarpHandler {
	
	public static RonboMC plugin;
	public static HashMap<String, Location> warps = new HashMap<String, Location>();
	
	public static void registerWarp(String s, Player p) {
		s = s.toLowerCase();
		if(warps.keySet().contains(s)) {
			p.sendMessage("The warp name " + s + " has already been registered.");
		} else {
			warps.put(s, p.getLocation().add(0, 0.3, 0));
			save();
			p.sendMessage("Stored new warp " + s + " at location " + (int)p.getLocation().getX() + "," + (int)p.getLocation().getY() + "," + (int)p.getLocation().getZ());
		}
	}
	
	public static void save() {
		Properties prop = new Properties();
		String dir = plugin.getDataFolder() + File.separator;
		String fileName = dir + "warps.properties";
		for(String s2 : warps.keySet()) {
			if(s2 == null)
				continue;
			Location loc = warps.get(s2);
			if(loc != null && loc.getWorld() != null)
				prop.setProperty(s2, loc.getX() + " " + loc.getY() + " " + loc.getZ() + " " + loc.getYaw() + " " + loc.getPitch() + " " + loc.getWorld().getName());
		}
		try {
			prop.store(new FileOutputStream(fileName), null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void load() {
		Properties prop = new Properties();
		String dir = plugin.getDataFolder() + File.separator;
		String fileName = dir + "warps.properties";
		try {
			if(new File(fileName).isFile()) {
				prop.load(new FileInputStream(fileName));
				Set<String> existing = prop.stringPropertyNames();
				for(String s : existing) {
					String[] data = prop.getProperty(s).split(" ");
					double x = Double.parseDouble(data[0]);
					double y = Double.parseDouble(data[1]);
					double z = Double.parseDouble(data[2]);
					float yaw = Float.parseFloat(data[3]);
					float pitch = Float.parseFloat(data[4]);
					StringBuilder sb = new StringBuilder("");
					for(int k = 5; k < data.length; k++)
						sb.append(data[k] + " ");
					warps.put(s.toLowerCase(), new Location(plugin.getServer().getWorld(sb.toString().trim()),x,y,z,yaw,pitch));
				}
				System.out.println("Loaded " + warps.size() + " warps.");
			} else {
				File f = new File(dir);
				if(!f.exists())
					f.mkdirs();
				File f2 = new File(fileName);
				f2.createNewFile();
				prop.store(new FileOutputStream(fileName), null);
			}
		} catch(Exception e) {
			
		}
	}
	
	private WarpHandler() {
		
	}

	public static void warp(final Player p, final String placeName, final EtcItem ei, final int delay, final boolean remove) {
		final String s = placeName.replace("_", " ");
		p.sendMessage("Warping to " + s + " in " + delay + " seconds... Don't move!");
		final Location loc = p.getLocation();
		final ArrayList<Integer> taskIds = new ArrayList<Integer>();
		for(int k = 1; k < delay; k++) {
			final int k2 = k;
			taskIds.add(SuperDebugger.scheduleSyncDelayedTask(WarpHandler.class.getClass(), EtcItemListeners.plugin, new Runnable() {
				public void run() {
					if((int)(loc.getX()) != (int)(p.getLocation().getX()) ||
					   (int)(loc.getY()) != (int)(p.getLocation().getY()) ||
					   (int)(loc.getZ()) != (int)(p.getLocation().getZ())) {
						for(Integer i : taskIds)
							plugin.getServer().getScheduler().cancelTask(i);
						p.sendMessage("You moved! Warp Scroll casting was canceled.");
					} else {
						p.sendMessage("Warping to " + s + " in " + (delay - k2) + " second" + (delay - k2 > 1 ? "s..." : "...") + " Don't move!");
						if(delay - k2 == 4) {
							SoundHandler.playSound(p, Sound.PORTAL_TRIGGER);
						}
					}
				}
			}, k2 * 20));
		}
		taskIds.add(SuperDebugger.scheduleSyncDelayedTask(WarpHandler.class.getClass(), EtcItemListeners.plugin, new Runnable() {
			public void run() {
				if((int)(loc.getX()) != (int)(p.getLocation().getX()) ||
				   (int)(loc.getY()) != (int)(p.getLocation().getY()) ||
				   (int)(loc.getZ()) != (int)(p.getLocation().getZ())) {
					for(Integer i : taskIds)
						plugin.getServer().getScheduler().cancelTask(i);
					p.sendMessage("You moved! Warp Scroll casting was canceled.");
				} else {
					boolean foundScroll = false;
					if(remove) {
						for(int k = 0; k < p.getInventory().getContents().length; k++) {
							final ItemStack item = p.getInventory().getContents()[k];
							try {
								if(EtcItem.getEtcType(item) == ei) {
									ItemStack i = p.getInventory().getItem(k);
									i.setAmount(i.getAmount() - 1);
									p.getInventory().setItem(k, i);
									foundScroll = true;
									break;
								}
							} catch(Exception e) {
								
							}
						}
					}
					if(foundScroll || !remove) {
						p.sendMessage("Warping to " + s + "...");
						p.teleport(warps.get(placeName.toLowerCase()));
					} else {
						p.sendMessage("Something happened to your Warp Scroll - it's gone!");
					}
				}
			}
		}, delay * 20));
	}

	public static void warp(final Player p, final String s, final Location destination, final int delay, final int fee) {
		final ArrayList<Integer> taskIds = new ArrayList<Integer>();
		final Location loc = p.getLocation();
		for(int k = 1; k < delay; k++) {
			final int k2 = k;
			taskIds.add(SuperDebugger.scheduleSyncDelayedTask(WarpHandler.class.getClass(), EtcItemListeners.plugin, new Runnable() {
				public void run() {
					if((int)(loc.getX()) != (int)(p.getLocation().getX()) ||
					   (int)(loc.getY()) != (int)(p.getLocation().getY()) ||
					   (int)(loc.getZ()) != (int)(p.getLocation().getZ())) {
						for(Integer i : taskIds)
							plugin.getServer().getScheduler().cancelTask(i);
						p.sendMessage("You moved! Warping was canceled.");
					} else {
						p.sendMessage("Warping to " + s + " in " + (delay - k2) + " second" + (delay - k2 > 1 ? "s..." : "...") + " Don't move!");
						if(delay - k2 == 4) {
							SoundHandler.playSound(p, Sound.PORTAL_TRIGGER);
						}
					}
				}
			}, k2 * 20));
		}
		taskIds.add(SuperDebugger.scheduleSyncDelayedTask(WarpHandler.class.getClass(), EtcItemListeners.plugin, new Runnable() {
			public void run() {
				if((int)(loc.getX()) != (int)(p.getLocation().getX()) ||
				   (int)(loc.getY()) != (int)(p.getLocation().getY()) ||
				   (int)(loc.getZ()) != (int)(p.getLocation().getZ())) {
					for(Integer i : taskIds)
						plugin.getServer().getScheduler().cancelTask(i);
					p.sendMessage("You moved! Warping was canceled.");
				} else {
					p.sendMessage("Warping to " + s + "...");
					if(EtcItemListeners.plugin.getPD(p).bankGold >= fee) {
						EtcItemListeners.plugin.getPD(p).bankGold -= fee;
						p.teleport(destination);
					} else {
						p.sendMessage(ChatColor.RED + "You don't have the required " + ChatColor.GOLD + fee + "g " + ChatColor.RED + " for this warp!"); 
					}
				}
			}
		}, delay * 20));
	}

	public static void warp(final Player p, String placeName, final EtcItem ei) {
		warp(p, placeName, ei, 5, true);
	}
	
}