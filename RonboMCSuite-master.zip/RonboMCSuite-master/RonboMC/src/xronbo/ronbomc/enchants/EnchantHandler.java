package xronbo.ronbomc.enchants;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;

public class EnchantHandler implements Listener {
	
	public static RonboMC plugin;
	
	public EnchantHandler(RonboMC plugin) {
		EnchantHandler.plugin = plugin;
	}
	
	public static void openEnchantInventory(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9 * 3, ChatColor.BLACK + " \u2738\u2738\u2738 Enchant Interface \u2738\u2738\u2738");
		ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.MAGENTA.getData());
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(" ");
		item.setItemMeta(im);
		int[] slotsToFill = new int[] {0,1,2,3,4,5,6,7,8,9,17,18,19,20,21,22,23,24,25,26};
		for(int i : slotsToFill)
			inventory.setItem(i, item);
		
		item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.DARK_GREEN + "Instructions");
		im.setLore(Arrays.asList(new String[]{ChatColor.LIGHT_PURPLE + "1. Click on an equip in your inventory",
				ChatColor.LIGHT_PURPLE + "   to place it in the enchant window.",
				ChatColor.LIGHT_PURPLE + "2. Click on a scroll in your inventory",
				ChatColor.LIGHT_PURPLE + "   to place it in the enchant window.",
				ChatColor.LIGHT_PURPLE + "3. Click on any charms you wish to use",
				ChatColor.LIGHT_PURPLE + "   to place them in the enchant window.",
				ChatColor.LIGHT_PURPLE + "4. Click on the green button at the",
				ChatColor.LIGHT_PURPLE + "   right to attempt your enchant!",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Double-check to see if you've chosen",
				ChatColor.LIGHT_PURPLE + "the right scrolls before enchanting!",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "You can only use ONE scroll at a time.",
				ChatColor.LIGHT_PURPLE + "You can only enchant ONE equip at a time.",
				ChatColor.LIGHT_PURPLE + "You can use up to THREE charms at a time.",
				ChatColor.LIGHT_PURPLE + "Charms of the same type DO NOT stack."
				}));
		item.setItemMeta(im);
		inventory.setItem(10, item);
		
		item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Click to Enchant");
		im.setLore(Arrays.asList(new String[]{ChatColor.RED + "" + ChatColor.BOLD + "-- Warnings --",
				ChatColor.RED + "1. If an equip has 7 or more Enchants, it",
				ChatColor.RED + "   has a 50% chance of being permanently",
				ChatColor.RED + "   destroyed if the scroll fails.",
				"",
				ChatColor.RED + "2. Destroyed items, scrolls, and charms",
				ChatColor.RED + "   may NOT be recovered.",
				"",
				ChatColor.RED + "3. If you're not sure about something, ask",
				ChatColor.RED + "   before you enchant. You don't want to",
				ChatColor.RED + "   accidentally destroy something!",
				"",
				ChatColor.GOLD + "" + ChatColor.BOLD + "Good luck!",
				"",
				ChatColor.RED + "" + ChatColor.BOLD + "Once you enchant, there's no going back!"}));
		item.setItemMeta(im);
		inventory.setItem(16, item);
		
		p.openInventory(inventory);
		plugin.getPD(p).isEnchanting = true;
	}
	
	public static ItemStack[] getItemsInInventory(Inventory inventory) {
		int[] slotsToCheck = new int[] {11,12,13,14,15};
		ArrayList<ItemStack> items = new ArrayList<ItemStack>();
		for(int i : slotsToCheck)
			if(inventory.getItem(i) != null && inventory.getItem(i) != null)
				items.add(inventory.getItem(i));
		return items.toArray(new ItemStack[items.size()]);
	}
	
	@EventHandler
	public void onEnchantInventoryClick(InventoryClickEvent event) {
		if(event.getInventory().getTitle().equals(ChatColor.BLACK + " \u2738\u2738\u2738 Enchant Interface \u2738\u2738\u2738")) {
			if(RonboMC.TESTING_INVENTORY_CANCELS)
				System.out.println("Cancelling here. " + this.getClass().getName());
			event.setCancelled(true);
			final Player p = (Player)(event.getWhoClicked());
			ItemStack item = event.getCurrentItem();
			if(item == null || item.getType() == Material.AIR)
				return;
			if(event.getRawSlot() > 26) {
				if(getItemsInInventory(event.getInventory()).length >= 5) {
					p.sendMessage(ChatColor.RED + "You cannot add any more things to this enchant!");
					return;
				}
				boolean isEquip = false;
				for(Equip e : Equip.values()) {
					if(e.isType(item)) {
						isEquip = true;
						break;
					}
				}
				if(isEquip) {
					boolean containsEquipAlready = false;
					for(ItemStack inInventory : getItemsInInventory(event.getInventory())) {
						for(Equip e : Equip.values()) {
							if(e.isType(inInventory)) {
								containsEquipAlready = true;
								break;
							}
						}
						if(containsEquipAlready)
							break;
					}
					if(containsEquipAlready) {
						p.sendMessage(ChatColor.RED + "You've already selected an item to enchant!");
						p.sendMessage(ChatColor.RED + "You can only enchant one item at a time.");
						return;
					}
					transferToInventory(event.getInventory(), item, p);
				} else {
					EtcItem ei = EtcItem.getEtcType(item);
					if(ei == null) {
						p.sendMessage(ChatColor.RED + "That is not a valid item to use during enchanting!");
						return;
					}
					boolean isScroll = false;
					boolean isCharm = false;
					for(EtcItem ei2 : validEnchantScrolls) {
						if(ei2 == ei) {
							isScroll = true;
							break;
						}
					}
					if(!isScroll) {
						for(EtcItem ei2 : validEnchantCharms) {
							if(ei2 == ei) {
								isCharm = true;
								break;
							}
						}
					}
					if(!(isScroll || isCharm)) {
						p.sendMessage(ChatColor.RED + "That is not a valid item to use during enchanting!");
						return;
					}
					if(isScroll) {
						boolean containsScrollAlready = false;
						for(ItemStack i : getItemsInInventory(event.getInventory())) {
							if(EtcItem.getEtcType(i) != null) {
								for(EtcItem ei2 : validEnchantScrolls) {
									if(ei2 == EtcItem.getEtcType(i)) {
										containsScrollAlready = true;
										break;
									}
								}
							}
							if(containsScrollAlready)
								break;
						}
						if(containsScrollAlready) {
							p.sendMessage(ChatColor.RED + "You've already selected a scroll to use!");
							p.sendMessage(ChatColor.RED + "You can only use one scroll at a time.");
							return;
						}
					}
					transferToInventory(event.getInventory(), item, p);
				}
			} else {
				if(item.hasItemMeta()) {
					if(item.getItemMeta().hasDisplayName()) {
						switch(ChatColor.stripColor(item.getItemMeta().getDisplayName().toLowerCase())) {
							case "click to enchant":
								handleEnchant(event.getInventory(), p);
								plugin.getPD(p).isEnchanting = false;
								p.closeInventory();
								break;
						}
					}
				}
				int[] slotsToCheck = new int[] {11,12,13,14,15};
				for(int i : slotsToCheck) {
					if(i == event.getRawSlot()) {
						p.getInventory().addItem(event.getInventory().getItem(i));
						event.getInventory().setItem(i, new ItemStack(Material.AIR));
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								p.updateInventory();
							}
						}, 1);
						break;
					}
				}
			}
		}
	}
	
	public static void transferToInventory(Inventory inventory, ItemStack item, final Player p) {
		if(item.getAmount() == 1) {
			inventory.addItem(item);
			p.getInventory().removeItem(item);
		} else {
			ItemStack clone = item.clone();
			clone.setAmount(1);
			inventory.addItem(clone);
			p.getInventory().removeItem(item);
			item.setAmount(item.getAmount() - 1);
			p.getInventory().addItem(item);
			SuperDebugger.scheduleSyncDelayedTask(EnchantHandler.class.getClass(), plugin, new Runnable() {
				public void run() {
					p.updateInventory();
				}
			}, 1);
		}
	}
	
	public static EtcItem[] validEnchantScrolls = new EtcItem[] {
		EtcItem.ENCHANTSCROLL_30_5,
		EtcItem.ENCHANTSCROLL_50_5,
		EtcItem.ENCHANTSCROLL_70_5,
		EtcItem.ENCHANTSCROLL_30_10,
		EtcItem.ENCHANTSCROLL_50_10,
		EtcItem.ENCHANTSCROLL_70_10,
		EtcItem.ENCHANTSCROLL_30_15,
		EtcItem.ENCHANTSCROLL_50_15,
		EtcItem.ENCHANTSCROLL_70_15,
		EtcItem.DARKENCHANTSCROLL_30_10,
		EtcItem.DARKENCHANTSCROLL_50_10,
		EtcItem.DARKENCHANTSCROLL_70_10,
		EtcItem.DARKENCHANTSCROLL_30_15,
		EtcItem.DARKENCHANTSCROLL_50_15,
		EtcItem.DARKENCHANTSCROLL_70_15,
		EtcItem.DARKENCHANTSCROLL_30_20,
		EtcItem.DARKENCHANTSCROLL_50_20,
		EtcItem.DARKENCHANTSCROLL_70_20,
		EtcItem.DESTINY_SCROLL,
		EtcItem.VIPENCHANTSCROLL_100_10,
		EtcItem.VIPENCHANTSCROLL_100_20,
		EtcItem.VIPENCHANTSCROLL_100_30,
	};
	public static EtcItem[] validEnchantCharms = new EtcItem[] {
		EtcItem.GUARDIAN_CHARM,
		EtcItem.LUCKY_CHARM,
	};
	
	public static void handleEnchant(Inventory inventory, Player p) {
		ItemStack[] items = getItemsInInventory(inventory);
		ItemStack equip = null;
		EtcItem scroll = null;
		ArrayList<EtcItem> charms = new ArrayList<EtcItem>();
		for(ItemStack i : items) {
			boolean isEquip = false;
			for(Equip e : Equip.values()) {
				if(e.isType(i)) {
					isEquip = true;
					break;
				}
			}
			if(isEquip) {
				equip = i;
				continue;
			}
			boolean isScroll = false;
			boolean isCharm = false;
			EtcItem ei = EtcItem.getEtcType(i);
			if(ei == null) {
				p.sendMessage(ChatColor.RED + "ERROR: COULD NOT IDENTIFY ENCHANT MATERIAL!");
				return;
			}
			for(EtcItem ei2 : validEnchantScrolls) {
				if(ei2 == ei) {
					isScroll = true;
					scroll = ei;
					break;
				}
			}
			if(isScroll)
				continue;
			for(EtcItem ei2 : validEnchantCharms) {
				if(ei2 == ei) {
					isCharm = true;
					charms.add(ei);
					break;
				}
			}
			if(isCharm)
				continue;
			p.sendMessage(ChatColor.RED + "ERROR: COULD NOT IDENTIFY ENCHANT MATERIAL!");
			return;
		}
		if(equip == null) {
			p.sendMessage(ChatColor.RED + "ERROR: COULD NOT FIND EQUIP TO ENCHANT!");
			return;
		}
		if(scroll == null) {
			p.sendMessage(ChatColor.RED + "ERROR: COULD NOT FIND SCROLL TO USE!");
			return;
		}
		ItemHandler.loadItem(equip);
		ItemData id = ItemHandler.items.get(equip);
		int chance = 0;
		int bonus = 0;
		boolean chanceToDestroy = id.enchants >= 7;
		switch(scroll) {
			case ENCHANTSCROLL_30_5:
				chance = 30;
				bonus = 5;
				break;
			case ENCHANTSCROLL_50_5:
				chance = 50;
				bonus = 5;
				break;
			case ENCHANTSCROLL_70_5:
				chance = 70;
				bonus = 5;
				break;
			case ENCHANTSCROLL_30_10:
				chance = 30;
				bonus = 10;
				break;
			case ENCHANTSCROLL_50_10:
				chance = 50;
				bonus = 10;
				break;
			case ENCHANTSCROLL_70_10:
				chance = 70;
				bonus = 10;
				break;
			case ENCHANTSCROLL_30_15:
				chance = 30;
				bonus = 15;
				break;
			case ENCHANTSCROLL_50_15:
				chance = 50;
				bonus = 15;
				break;
			case ENCHANTSCROLL_70_15:
				chance = 70;
				bonus = 15;
				break;
			case DARKENCHANTSCROLL_30_10:
				chance = 30;
				bonus = 10;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_50_10:
				chance = 50;
				bonus = 10;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_70_10:
				chance = 70;
				bonus = 10;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_30_15:
				chance = 30;
				bonus = 15;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_50_15:
				chance = 50;
				bonus = 15;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_70_15:
				chance = 70;
				bonus = 15;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_30_20:
				chance = 30;
				bonus = 20;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_50_20:
				chance = 50;
				bonus = 20;
				chanceToDestroy = true;
				break;
			case DARKENCHANTSCROLL_70_20:
				chance = 70;
				bonus = 20;
				chanceToDestroy = true;
				break;
			case DESTINY_SCROLL:
				chance = 100;
				bonus = 50;
				break;
			case VIPENCHANTSCROLL_100_10:
				chance = 100;
				bonus = 10;
				break;
			case VIPENCHANTSCROLL_100_20:
				chance = 100;
				bonus = 20;
				break;
			case VIPENCHANTSCROLL_100_30:
				chance = 100;
				bonus = 30;
				break;
			default:
				p.sendMessage(ChatColor.RED + "ERROR: COULD NOT FIND PROPER SCROLL STATS! REPORT TO RONBO PLS!");
				return;
		}
		for(EtcItem ei : charms) {
			if(ei == EtcItem.GUARDIAN_CHARM)
				chanceToDestroy = false;
			if(ei == EtcItem.LUCKY_CHARM)
				chance += 5;
		}
		if(Math.random() < chance/100.0) {
			id.enchants++;
			if(id.critChance > 0)
				id.critChance += bonus / 5;
			if(id.critDamage > 0)
				id.critDamage += bonus;
			if(id.attack > 0)
				id.attack += bonus;
			if(id.dexterity > 0)
				id.dexterity += bonus;
			if(id.hp > 0)
				id.hp += bonus * 5;
			if(id.hpRegen > 0)
				id.hpRegen += bonus;
			if(id.intelligence > 0)
				id.intelligence += bonus;
			if(id.lifesteal > 0)
				id.lifesteal += bonus / 5;
			if(id.luck > 0)
				id.luck += bonus;
			if(id.strength > 0)
				id.strength += bonus;
			id.addStatsToLore();
			SoundHandler.playSound(p, Sound.LEVEL_UP);
			p.sendMessage(ChatColor.GOLD + "Congratulations! Your enchant was a success!");
			p.sendMessage(ChatColor.GOLD + "Your " + ChatColor.stripColor(id.i.getItemMeta().getDisplayName()) + " now has " + id.enchants + " enchants.");
			p.getInventory().addItem(ItemHandler.removeAttributes(id.i));
		} else {
			p.sendMessage(ChatColor.RED + "Your scroll glows brightly, but suddenly bursts into ashes.");
			p.sendMessage(ChatColor.RED + "Your enchant failed, sorry!");
			if(chanceToDestroy && Math.random() < 0.5) {
				SoundHandler.playSound(p, Sound.ITEM_BREAK);
				p.sendMessage(ChatColor.RED + "Your " + ChatColor.stripColor(id.i.getItemMeta().getDisplayName()) + " explodes in flames due to the failed enchant.");
			} else {
				SoundHandler.playSound(p, Sound.FIZZ);
				p.getInventory().addItem(ItemHandler.removeAttributes(id.i));
			}
		}
		plugin.getPD(p).justFinishedEnchanting = true;
		inventory.clear();
	}
	
	@EventHandler
	public void onEnchantInventoryClose(InventoryCloseEvent event) {
		if(event.getInventory().getTitle().equals(ChatColor.BLACK + " \u2738\u2738\u2738 Enchant Interface \u2738\u2738\u2738")) {
			ItemStack[] items = getItemsInInventory(event.getInventory());
			final Player p = (Player)(event.getPlayer());
			plugin.getPD(p).isEnchanting = false;
			if(!plugin.getPD(p).justFinishedEnchanting) {
				p.getInventory().addItem(items);
				p.sendMessage(ChatColor.RED + "You decide to not enchant anything for now...");
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						p.updateInventory();
					}
				}, 1);
			}
			plugin.getPD(p).justFinishedEnchanting = false;
		}
	}
	
	@EventHandler
	public void onPickupItemWhileEnchanting(PlayerPickupItemEvent event) {
		try {
			if(plugin.getPD(event.getPlayer()).isEnchanting)
				event.setCancelled(true);
		} catch(Exception e) {
			
		}
	}
}