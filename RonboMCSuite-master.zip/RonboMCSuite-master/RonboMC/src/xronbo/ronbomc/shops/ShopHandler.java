package xronbo.ronbomc.shops;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;

public class ShopHandler implements Listener {
	
	public static LinkedHashMap<Integer, Shop> shops = new LinkedHashMap<Integer, Shop>();
	public static boolean shopsLoaded = false;
	public static ArrayList<Inventory> shopsDisplay = new ArrayList<Inventory>();
	
	public static void load() {
		final ResultSet rs = plugin.executeQuery("SELECT * FROM rpg_shops");
		SuperDebugger.runTaskAsynchronously(ShopHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				try {
					while(rs.next()) {
						int id = rs.getInt("id");
						String owner = rs.getString("owner");
						String uuid = rs.getString("uuid");
						String itemsToParse = rs.getString("items");
						ArrayList<ShopItem> items = deserializeShop(itemsToParse);
						boolean open = rs.getBoolean("open");
						String name = rs.getString("name");
						boolean vip = rs.getBoolean("vip");
						Shop s = new Shop(owner,uuid,items);
						if(name != null)
							s.name = name;
						s.vip = vip;
						s.id = id;
						s.open = open;
						if(rs.getTimestamp("expiryTime") != null) {
							s.expiryTime = rs.getTimestamp("expiryTime");
						} else {
							s.expiryTime = new Timestamp(0);
						}
						s.checkExpiry();
						shops.put(s.id, s);
					}
					rs.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
				System.out.println("Loaded " + shops.size() + " shops.");
				shopsLoaded = true;
			}
		});
	}
	
	public static Inventory basics(Inventory inventory) {
		ItemStack item;
		ItemMeta im;

		item = new ItemStack(Material.INK_SACK, 1, DyeColor.PURPLE.getData());
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GREEN + "Previous Page");
		item.setItemMeta(im);
		inventory.setItem(45, item);
		
		item = new ItemStack(Material.SNOW_BALL);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Search by Type + Tier");
		item.setItemMeta(im);
		inventory.setItem(46, item);
		
		item = new ItemStack(Material.SNOW_BALL);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Search by Owner");
		item.setItemMeta(im);
		inventory.setItem(47, item);
		
		item = new ItemStack(Material.SNOW_BALL);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Search by Shop Name");
		item.setItemMeta(im);
		inventory.setItem(48, item);
		
		item = new ItemStack(Material.SIGN);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Manage your shop!");
		item.setItemMeta(im);
		inventory.setItem(49, item);
		
		item = new ItemStack(Material.INK_SACK, 1, DyeColor.PURPLE.getData());
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GREEN + "Next Page");
		item.setItemMeta(im);
		inventory.setItem(53, item);
		
		return inventory;
	}
	
	public static void openShopManager(Player p) {
		if(getShop(p) == null) {
			p.sendMessage(ChatColor.RED + "Looks like you don't have a shop just yet!");
			p.sendMessage(ChatColor.RED + "Please wait a moment, one is being created for you.");
			p.sendMessage(ChatColor.RED + "Use " + ChatColor.YELLOW + "/shop " + ChatColor.RED + "again in a few seconds.");
			return;
		}
		p.updateInventory();
		PlayerData pd = plugin.getPD(p);
		Inventory inventory = Bukkit.createInventory(null, 9*6, ChatColor.BLACK + "Shop Management");
		ItemStack item;
		ItemMeta im;
		
		item = new ItemStack(Material.PAPER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Shop Setup Instructions 1/4");
		im.setLore(Arrays.asList(Values.stringToLore("To add items to your shop, just click on them in your inventory. "
				+ "You will be asked to type in a price for the item. "
				+ "Then, the item will be put into your shop. ", ChatColor.LIGHT_PURPLE)));
		item.setItemMeta(im);
		inventory.setItem(45, item);
		
		item = new ItemStack(Material.PAPER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Shop Setup Instructions 2/4");
		im.setLore(Arrays.asList(Values.stringToLore("It costs 5000g to open your shop for 12 hours. "
				+ "It costs 25000g to open your shop for 24 hours. "
				+ "Longer shop permits may be purchased at our store online. "
				+ "Other players can only see your shop when it's open.", ChatColor.LIGHT_PURPLE)));
		item.setItemMeta(im);
		inventory.setItem(46, item);
		
		item = new ItemStack(Material.PAPER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Shop Setup Instructions 3/4");
		im.setLore(Arrays.asList(Values.stringToLore("The gold you earn from sold items will be stored in here. "
				+ "Click the Collect Gold icon to collect your earnings.", ChatColor.LIGHT_PURPLE)));
		item.setItemMeta(im);
		inventory.setItem(47, item);

		item = new ItemStack(Material.PAPER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "Shop Setup Instructions 4/4");
		im.setLore(Arrays.asList(Values.stringToLore("You start with a shop of one row. "
				+ "Rows that you don't have access to are filled in with Iron Bars. "
				+ "You can expand your shop size for a fee. "
				+ "The maximum shop size is 5 rows, or 45 items.", ChatColor.LIGHT_PURPLE)));
		item.setItemMeta(im);
		inventory.setItem(48, item);

		item = new ItemStack(Material.BOOK_AND_QUILL);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Change Shop Name (25000g)");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add(ChatColor.LIGHT_PURPLE + "Current Name: " + getShop(p).name);
		lore.add("");
		lore.add(ChatColor.LIGHT_PURPLE + "Click to change your shop name.");
		im.setLore(lore);
		item.setItemMeta(im);
		inventory.setItem(49, item);

		if(pd.shopSize < 5) {
			item = new ItemStack(Material.DIAMOND);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "Expand Shop Size (" + pd.getShopExpansionCost() + "g)");
			im.setLore(Arrays.asList(Values.stringToLore("Expand your shop size by 1 row. "
					+ "You currently have " + pd.shopSize + " rows. "
					+ "There is no confirmation for this button. Click it and you pay for the expansion!", ChatColor.LIGHT_PURPLE)));
			item.setItemMeta(im);
			inventory.setItem(50, item);
		} else {
			item = new ItemStack(Material.DIAMOND);
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.GREEN + "Shop Size Maxed!");
			im.setLore(Arrays.asList(Values.stringToLore("You have the largest shop possible. I guess you're really rollin' in the dough.", ChatColor.GREEN)));
			item.setItemMeta(im);
			inventory.setItem(50, item);
		}

		item = new ItemStack(Material.GOLD_INGOT);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Collect Gold (" + pd.shopGold + "g)");
		im.setLore(Arrays.asList(Values.stringToLore("Collect the gold in your shop. "
				+ "You currently have earned " + ChatColor.GOLD + pd.shopGold + "g" + ChatColor.LIGHT_PURPLE + ".", ChatColor.LIGHT_PURPLE)));
		item.setItemMeta(im);
		inventory.setItem(51, item);

		if(getShop(p).open) {
			item = new ItemStack(Material.INK_SACK, 1, DyeColor.ORANGE.getData());
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.RED + "Your shop is already open.");
			im.setLore(Arrays.asList(Values.stringToLore("Wait until it's closed to open it again. "
					+ "Click this button to close your shop. If you close shop, you cannot reopen without paying the fee again!", ChatColor.RED)));
			item.setItemMeta(im);
			inventory.setItem(52, item);

			item = new ItemStack(Material.INK_SACK, 1, DyeColor.ORANGE.getData());
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.RED + "Your shop is already open.");
			im.setLore(Arrays.asList(Values.stringToLore("Wait until it's closed to open it again. "
					+ "Click this button to close your shop. If you close shop, you cannot reopen without paying the fee again!", ChatColor.RED)));
			item.setItemMeta(im);
			inventory.setItem(53, item);
		} else {
			item = new ItemStack(Material.INK_SACK, 1, DyeColor.PURPLE.getData());
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "Open Shop - 12h (1000g)");
			im.setLore(Arrays.asList(Values.stringToLore("Open your shop for 12 hours. "
					+ "You must have 1000g in your wallet to pay the fee. "
					+ "ONCE YOU OPEN SHOP YOU CANNOT ADD OR REMOVE ITEMS UNTIL IT CLOSES. "
					+ "DON'T ACCIDENTALLY SELL SOMETHING YOU WANT TO KEEP.", ChatColor.LIGHT_PURPLE)));
			item.setItemMeta(im);
			inventory.setItem(52, item);

			item = new ItemStack(Material.INK_SACK, 1, DyeColor.PURPLE.getData());
			im = item.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "Open Shop - 24h (5000g)");
			im.setLore(Arrays.asList(Values.stringToLore("Open your shop for 24 hours. "
					+ "You must have 5000g in your wallet to pay the fee. "
					+ "ONCE YOU OPEN SHOP YOU CANNOT ADD OR REMOVE ITEMS UNTIL IT CLOSES. "
					+ "DON'T ACCIDENTALLY SELL SOMETHING YOU WANT TO KEEP." , ChatColor.LIGHT_PURPLE)));
			item.setItemMeta(im);
			inventory.setItem(53, item);
		}

		item = new ItemStack(Material.IRON_FENCE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.RED + "Slot Unavailable");
		im.setLore(Arrays.asList(Values.stringToLore("Expand your shop size to use this slot.", ChatColor.RED)));
		item.setItemMeta(im);
		for(int k = 0; k < 45; k++) {
			if(k / 9 + 1 > pd.shopSize) {
				inventory.setItem(k, item);
			}
		}
		int slot = 0;
		Shop shop = getShop(p);
		for(ShopItem si : shop.items) {
			inventory.setItem(slot++, si.item);
		}
		
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().contains(ChatColor.BLACK + "The Kastia Player Market") || event.getInventory().getName().contains(ChatColor.BLACK + "Search Results")) {
				int current = Integer.parseInt(event.getInventory().getName().replaceAll("[^0-9]", "")) - 1;
				event.setCancelled(true);
				Player p = (Player)event.getWhoClicked();
				if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Manage your shop!")) {
					try {
						openShopManager(p);
					} catch(Exception e) {
						
					}
				} else if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Previous Page")) {
					try {
						p.openInventory(shopsDisplay.get(current - 1));
					} catch(Exception e) {
						p.sendMessage(ChatColor.RED + "You are on the first page of shops.");
					}
				} else if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Next Page")) {
					try {
						event.getWhoClicked().openInventory(shopsDisplay.get(current + 1));
					} catch(Exception e) {
						p.sendMessage(ChatColor.RED + "You are on the last page of shops.");
					}
				} else if(event.getCurrentItem().getType() == Material.CHEST) {
					String name = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getLore().toString());
					int id = Integer.parseInt(name.substring(name.indexOf("Shop ID: ")).replaceAll("[^0-9]", ""));
					if(shops.containsKey(id) && shops.get(id).open) {
						p.openInventory(shops.get(id).getMenu());
					} else {
						p.sendMessage(ChatColor.RED + "That shop no longer open!");
					}
				} else if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Search by Type + Tier")) {
					openSearchByTypeTier(p);
				} else if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Search by Owner")) {
					p.closeInventory();
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type a shop owner name to search for in open shops.");
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			plugin.getPD(p).waitingOnShopSearchOwner = true;
				} else if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Search by Shop Name")) {
					p.closeInventory();
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type a phrase to search for in shop names.");
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			plugin.getPD(p).waitingOnShopSearchName = true;
				}
			} else if(event.getInventory().getName().contains(ChatColor.BLACK + "Shop Management")) {
				event.setCancelled(true);
				final Player p = (Player)event.getWhoClicked();
				final ItemStack item = event.getCurrentItem();
				final PlayerData pd = plugin.getPD(p);
				if(event.getRawSlot() >= 54) {
					if(ItemHandler.isTradeable(item) && !(item.getItemMeta().getDisplayName().contains("The Ronbook") || item.getItemMeta().getDisplayName().contains("The Navigator") || EtcItem.getEtcType(item) == EtcItem.GOLD)) {
						pd.itemToAddToShop = item;
						pd.waitingOnItemPrice = true;
						p.closeInventory();
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type the price of the item you just selected.");
            			p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "It will then be placed into your shop for that price.");
            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Make sure to open your shop afterwards to sell it.");
            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
					} else {
						p.sendMessage(ChatColor.RED + "That item is untradeable and cannot be sold.");
					}
				} else {
					if(item.getItemMeta().getDisplayName().contains("Change Shop Name (25000g)")) {
						int cost = 25000;
						if(pd.wallet >= cost) {
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type the name that you want your shop to have.");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Max length: 25 characters.");
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			pd.waitingOnShopNameChange = true;
							p.closeInventory();
						} else {
							p.sendMessage(ChatColor.RED + "You don't have enough money in your wallet to afford that!");
						}
					} else if(item.getItemMeta().getDisplayName().contains("Expand Shop Size")) {
						int cost = pd.getShopExpansionCost();
						if(pd.wallet >= cost) {
							pd.shopSize++;
							pd.wallet -= cost;
							p.closeInventory();
							p.sendMessage(ChatColor.GREEN + "You have expanded your shop to " + pd.shopSize + " rows for " + ChatColor.GOLD + cost + "g" + ChatColor.GREEN + ".");
						} else {
							p.sendMessage(ChatColor.RED + "You don't have enough money in your wallet to afford that!");
						}
					} else if(item.getItemMeta().getDisplayName().contains("Collect Gold")) {
						if(pd.shopGold > 0) {
							pd.wallet += pd.shopGold;
							p.closeInventory();
							p.sendMessage(ChatColor.GREEN + "You collected " + ChatColor.GOLD + pd.shopGold + "g" + ChatColor.GREEN + " from your shop.");
							plugin.executePrepared("UPDATE rpg SET " + "shopGold" + "= shopGold - ? WHERE uuid='" + pd.uuid + "'", pd.shopGold + "");
							pd.shopGold = 0;
						} else {
							p.sendMessage(ChatColor.RED + "You don't have any gold to collect.");
						}
					} else if(item.getItemMeta().getDisplayName().contains("Open Shop - 12h")) {
						if(pd.wallet >= 1000) {
							Shop s = getShop(p);
							if(s.open) {
								p.sendMessage(ChatColor.RED + "Your shop is already open!");
							} else {
								pd.wallet -= 1000;
								s.addTime(12);
								s.vip = RankManager.check(p, "knight");
								p.sendMessage(ChatColor.GREEN + "Your shop will be open until " + PlayerData.dateformat.format(s.expiryTime) + ".");
								p.closeInventory();
								updateShop(s);
							}
						} else {
							p.sendMessage(ChatColor.RED + "You don't have " + ChatColor.GOLD + "1000g" + ChatColor.RED + " in your wallet!");
						}
					} else if(item.getItemMeta().getDisplayName().contains("Open Shop - 24h")) {
						if(pd.wallet >= 5000) {
							Shop s = getShop(p);
							if(s.open) {
								p.sendMessage(ChatColor.RED + "Your shop is already open!");
							} else {
								pd.wallet -= 5000;
								s.addTime(24);
								s.vip = RankManager.check(p, "knight");
								p.sendMessage(ChatColor.GREEN + "Your shop will be open for until " + PlayerData.dateformat.format(s.expiryTime) + ".");
								p.closeInventory();
								updateShop(s);
							}
						} else {
							p.sendMessage(ChatColor.RED + "You don't have " + ChatColor.GOLD + "5000g" + ChatColor.RED + " in your wallet!");
						}
					} else if(item.getItemMeta().getDisplayName().contains("Your shop is already open.")) {
						Shop s = getShop(p);
						if(s.open) {
							s.open = false;
							s.expiryTime = new Timestamp(0);
							p.sendMessage(ChatColor.RED + "You have closed your shop.");
							p.closeInventory();
							updateShop(s);
						} else {
							p.sendMessage(ChatColor.RED + "Your shop is already closed!");
						}
					} else if(item.getItemMeta().getLore().get(0).contains("Price: ")) {
						if(p.getInventory().firstEmpty() >= 0) {
							Shop s = getShop(p);
							if(s.open) {
								p.sendMessage(ChatColor.RED + "You can't take items out of your shop while it's open.");
							} else {
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										p.closeInventory();
										p.sendMessage(ChatColor.GREEN + "Fetching shop data to see if item is still available...");
										SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
											public void run() {
												final ResultSet rs = plugin.executeSynchronizedQuery("SELECT * FROM rpg_shops where uuid = '" + pd.uuid + "'");
												Shop updated = null;
												try {
													if(rs.next()) {
														int id = rs.getInt("id");
														String owner = rs.getString("owner");
														String uuid = rs.getString("uuid");
														String itemsToParse = rs.getString("items");
														ArrayList<ShopItem> items = deserializeShop(itemsToParse);
														boolean open = rs.getBoolean("open");
														String name = rs.getString("name");
														boolean vip = rs.getBoolean("vip");
														Shop s = new Shop(owner,uuid,items);
														if(name != null)
															s.name = name;
														s.vip = vip;
														s.id = id;
														s.open = open;
														if(rs.getTimestamp("expiryTime") != null) {
															s.expiryTime = rs.getTimestamp("expiryTime");
														} else {
															s.expiryTime = new Timestamp(0);
														}
														s.checkExpiry();
														updated = s;
													}
												} catch(Exception e) {
													
												}
												final Shop finalUpdated = updated;
												SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
													public void run() {
														if(finalUpdated.hasItem(item)) {
															finalUpdated.removeItem(item);
															ShopHandler.updateShop(finalUpdated);
															p.getInventory().addItem(deprice(item));
															p.sendMessage(ChatColor.GREEN + "You removed " + item.getItemMeta().getDisplayName() + ChatColor.GREEN + " from your shop.");
														} else {
															p.sendMessage(ChatColor.RED + "Your item was just sold to someone!");
														}
													}
												});
											}
										});
									}
								});
							}
							p.closeInventory();
						} else {
							p.sendMessage(ChatColor.RED + "You don't have enough inventory space to remove that item.");
						}
					}
				}
			} else if(event.getInventory().getName().contains("'s Player Shop")) {
				event.setCancelled(true);
				String owner = event.getInventory().getName().substring(0, event.getInventory().getName().indexOf("'s Player Shop"));
				Shop shop = null;
				for(Shop s : shops.values()) {
					if(s.owner.equals(owner)) {
						shop = s;
						break;
					}
				}
				if(event.getRawSlot() < shop.items.size() && event.getCurrentItem() != null && event.getCurrentItem().getType() != Material.AIR) {
					Player p = (Player)event.getWhoClicked();
					PlayerData pd = plugin.getPD(p);
					pd.waitingOnPurchaseConfirm = true;
					pd.itemToBuy = event.getCurrentItem();
					pd.itemToBuyPrice = Integer.parseInt(ChatColor.stripColor(pd.itemToBuy.getItemMeta().getLore().get(0)).replaceAll("[^0-9]", ""));
					pd.shopBuyingFrom = shop;
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Are you SURE you want to buy " + pd.itemToBuy.getItemMeta().getDisplayName() + ChatColor.AQUA + ChatColor.ITALIC + " for a price of " + ChatColor.GOLD + pd.itemToBuyPrice + "g" + ChatColor.AQUA + ChatColor.ITALIC + "?");
        			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "If you are sure, please say 'yes'. No refunds!");
        			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
        			p.closeInventory();
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public void openSearchByTypeTier(Player p) {
		PlayerData pd = plugin.getPD(p);
		p.closeInventory();
		String filter = "";
		
		Inventory searchTypeTier = Bukkit.createInventory(p, 9 * 6, ChatColor.BLACK + "Search by Type and Tier");
		
		ItemStack item = new ItemStack(Material.IRON_FENCE);
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(" ");
		item.setItemMeta(im);
		
		for(int k = 0; k < 9; k++)
			searchTypeTier.setItem(k, item);
		for(int k = 9 * 5; k < 9 * 6; k++)
			searchTypeTier.setItem(k, item);
		item = new ItemStack(Material.SNOW_BALL);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GREEN + "Search Now!");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 5 + 4, item);
		
		item = new ItemStack(Material.PAPER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Search Filters");
		im.setLore(Values.longStringToLoreList(ChatColor.AQUA, "Select the things you wish to include in your search!", "Green dye means the item will be searched for.", "Red dye means the item will not be searched for."));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1, item);

		item = new ItemStack(Material.IRON_SWORD);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Swords");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 1, ItemHandler.removeAttributes(item));
		
		filter = "Swords";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 1, ItemHandler.removeAttributes(item));
		
		item = new ItemStack(Material.IRON_AXE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Axes");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 2, ItemHandler.removeAttributes(item));
		
		filter = "Axes";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 2, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_SPADE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Maces");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 3, ItemHandler.removeAttributes(item));
		
		filter = "Maces";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 3, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.STICK);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Staves");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 4, ItemHandler.removeAttributes(item));
		
		filter = "Staves";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 4, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_HOE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Wands");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 5, ItemHandler.removeAttributes(item));
		
		filter = "Wands";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 5, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.BOW);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Bows");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 6, ItemHandler.removeAttributes(item));
		
		filter = "Bows";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 6, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.SHEARS);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Daggers");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 7, ItemHandler.removeAttributes(item));
		
		filter = "Daggers";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 7, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.BONE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Bones");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 1 + 8, ItemHandler.removeAttributes(item));
		
		filter = "Bones";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 2 + 8, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_HELMET);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Helmets");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 0, ItemHandler.removeAttributes(item));
		
		filter = "Helmets";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 0, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_CHESTPLATE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Chestplates");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 1, ItemHandler.removeAttributes(item));
		
		filter = "Chestplates";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 1, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_LEGGINGS);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Leggings");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 2, ItemHandler.removeAttributes(item));

		filter = "Leggings";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 2, ItemHandler.removeAttributes(item));
		
		item = new ItemStack(Material.IRON_BOOTS);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Boots");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 3, ItemHandler.removeAttributes(item));
		
		filter = "Boots";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 3, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.LEATHER);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Tier 1");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 4, ItemHandler.removeAttributes(item));
		
		filter = "Tier 1";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 4, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.STONE);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Tier 2");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 5, ItemHandler.removeAttributes(item));
		
		filter = "Tier 2";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 5, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.IRON_INGOT);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Tier 3");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 6, ItemHandler.removeAttributes(item));
		
		filter = "Tier 3";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 6, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.GOLD_INGOT);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Tier 4");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 7, ItemHandler.removeAttributes(item));
		
		filter = "Tier 4";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 7, ItemHandler.removeAttributes(item));

		item = new ItemStack(Material.DIAMOND);
		im = item.getItemMeta();
		im.setDisplayName(ChatColor.WHITE + "Tier 5");
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 3 + 8, ItemHandler.removeAttributes(item));
		
		filter = "Tier 5";
		item = new ItemStack(Material.INK_SACK, 1, pd.shopSearchFilters.contains(filter.toLowerCase()) ? DyeColor.LIME.getDyeData(): DyeColor.GRAY.getDyeData());
		im = item.getItemMeta();
		im.setDisplayName((pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN : ChatColor.RED) + filter);
		im.setLore(Arrays.asList(new String[] {ChatColor.AQUA + "Included in search? " + (pd.shopSearchFilters.contains(filter.toLowerCase()) ? ChatColor.GREEN + "Yes": ChatColor.RED + "No"), "", ChatColor.GRAY + "Click to Toggle"}));
		item.setItemMeta(im);
		searchTypeTier.setItem(9 * 4 + 8, ItemHandler.removeAttributes(item));
		
		p.openInventory(searchTypeTier);
	}
	
	@EventHandler
	public void onSearchClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(ChatColor.BLACK + "Search by Type and Tier")) {
				event.setCancelled(true);
				if((event.getRawSlot() >= 9 * 2 && event.getRawSlot() < 9 * 3)||(event.getRawSlot() >= 9 * 4 && event.getRawSlot() < 9 * 5)) {
					ItemStack item = event.getCurrentItem();
					Player p = (Player)event.getWhoClicked();
					PlayerData pd = plugin.getPD(p);
					p.closeInventory();
					if(item.getType() == Material.INK_SACK) {
						String filter = ChatColor.stripColor(item.getItemMeta().getDisplayName()).toLowerCase();
						if(pd.shopSearchFilters.contains(filter)) {
							pd.shopSearchFilters.remove(filter);
						} else {
							pd.shopSearchFilters.add(filter);
						}
					}
					openSearchByTypeTier(p);
				} else {
					try {
						int slot = event.getRawSlot() + 9;
						if((slot >= 9 * 2 && slot < 9 * 3)||(slot >= 9 * 4 && slot < 9 * 5)) {
							ItemStack item = event.getInventory().getItem(slot);
							Player p = (Player)event.getWhoClicked();
							PlayerData pd = plugin.getPD(p);
							p.closeInventory();
							if(item.getType() == Material.INK_SACK) {
								String filter = ChatColor.stripColor(item.getItemMeta().getDisplayName()).toLowerCase();
								if(pd.shopSearchFilters.contains(filter)) {
									pd.shopSearchFilters.remove(filter);
								} else {
									pd.shopSearchFilters.add(filter);
								}
							}
							openSearchByTypeTier(p);
						} 
					} catch(Exception e) {
						Player p = (Player)event.getWhoClicked();
						openSearchByTypeTier(p);
					}
					if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Search Now!")) {
						Player p = (Player)event.getWhoClicked();
						PlayerData pd = plugin.getPD(p);
						conductSearch(p, pd, null, null);
						p.closeInventory();
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public boolean checkTier(PlayerData pd, ItemData id) {
		boolean hasTierCheck = false;
		if(pd.shopSearchFilters.contains("tier 1")) {
			hasTierCheck = true;
			if(id.tier == 1) {
				return true;
			}
		}
		if(pd.shopSearchFilters.contains("tier 2")) {
			hasTierCheck = true;
			if(id.tier == 2) {
				return true;
			}
		}
		if(pd.shopSearchFilters.contains("tier 3")) {
			hasTierCheck = true;
			if(id.tier == 3) {
				return true;
			}
		}
		if(pd.shopSearchFilters.contains("tier 4")) {
			hasTierCheck = true;
			if(id.tier == 4) {
				return true;
			}
		}
		if(pd.shopSearchFilters.contains("tier 5")) {
			hasTierCheck = true;
			if(id.tier == 5) {
				return true;
			}
		}
		if(!hasTierCheck)
			return true;
		return false;
	}
	
	public void conductSearch(final Player p, final PlayerData pd, final String owner, final String name) {
		final ArrayList<Shop> possible = new ArrayList<Shop>();
		final ArrayList<Shop> current = new ArrayList<Shop>();
		current.addAll(shops.values());
		p.sendMessage(ChatColor.GREEN + "Conducting search...");
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				for(int checked = 0; checked < 100 && current.size() > 0;) {
					Shop s = current.remove(0);
					if(!s.open) {
						checked++;
						continue;
					}
					if(owner != null) {
						if(s.owner.equalsIgnoreCase(owner) || s.owner.toLowerCase().contains(owner.toLowerCase())) {
							checked++;
							possible.add(s);
							break;
						}
					}
					if(name != null) {
						if(s.name.toLowerCase().contains(name.toLowerCase()) || name.toLowerCase().contains(s.name.toLowerCase())) {
							checked++;
							possible.add(s);
						}
					}
					if(pd.shopSearchFilters.size() > 0) {
						for(ShopItem si : s.items) {
							checked++;
							ItemStack item = si.item;
							ItemData id = ItemHandler.tempLoadItem(item);
							if(id != null) {
								boolean containsEquipFilter = false;
								if(pd.shopSearchFilters.contains("swords")) {
									containsEquipFilter = true;
									if(id.equip == Equip.SWORD) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("axes")) {
									containsEquipFilter = true;
									if(id.equip == Equip.AXE) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("maces")) {
									containsEquipFilter = true;
									if(id.equip == Equip.MACE) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("staves")) {
									containsEquipFilter = true;
									if(id.equip == Equip.STAVE) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("wands")) {
									containsEquipFilter = true;
									if(id.equip == Equip.WAND) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("bows")) {
									containsEquipFilter = true;
									if(id.equip == Equip.BOW) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("daggers")) {
									containsEquipFilter = true;
									if(id.equip == Equip.DAGGER) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("bones")) {
									containsEquipFilter = true;
									if(id.equip == Equip.BONE) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("helmets")) {
									containsEquipFilter = true;
									if(id.equip == Equip.HELMET) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("chestplates")) {
									containsEquipFilter = true;
									if(id.equip == Equip.CHESTPLATE) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("leggings")) {
									containsEquipFilter = true;
									if(id.equip == Equip.LEGGINGS) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(pd.shopSearchFilters.contains("boots")) {
									containsEquipFilter = true;
									if(id.equip == Equip.BOOTS) {
										if(checkTier(pd, id)) {
											possible.add(s);
											break;
										}
									}
								}
								if(!containsEquipFilter) {
									if(checkTier(pd, id)) {
										possible.add(s);
										break;
									}
								}
							}
						}
					}
				}
				if(current.size() > 0)
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 1);
				else {
					pd.shopSearchFilters.clear();
					ArrayList<Inventory> result = new ArrayList<Inventory>();
					Inventory currentInventory = basics(Bukkit.createInventory(null, 6*9, ChatColor.BLACK + "Search Results (1)"));
					result.add(currentInventory);
					ItemStack item;
					ItemMeta im;
					int count = 0;
					Iterator<Shop> iter = possible.iterator();
					while(iter.hasNext()) {
						Shop s = iter.next();
						s.checkExpiry();
						if(!s.open)
							continue;
						item = new ItemStack(Material.CHEST);
						im = item.getItemMeta();
						im.setDisplayName((s.vip ? "" + ChatColor.GOLD + ChatColor.BOLD : ChatColor.LIGHT_PURPLE) + s.name);
						im.setLore(Arrays.asList(new String[] {
								ChatColor.AQUA + "Items: " + s.items.size(),
								"",
								ChatColor.AQUA + "Closing in: ",
								ChatColor.AQUA + s.getRemainingTime(),
								"",
								ChatColor.GRAY + "" + ChatColor.ITALIC + "Owner: " + s.owner,
								ChatColor.GRAY + "" + ChatColor.ITALIC + "Shop ID: " + s.id,
						}));
						item.setItemMeta(im);
						currentInventory.setItem(count++, item);
						if(count == 5*9 && iter.hasNext()) {
							count = 0;
							currentInventory = basics(Bukkit.createInventory(null, 6*9, ChatColor.BLACK + "Search Results (" + (shopsDisplay.size() + 1) + ")"));
							result.add(currentInventory);
						}
					}
					if(possible.size() == 0) {
						p.sendMessage(ChatColor.RED + "Sorry! No shops were found with items matching your criteria.");
					} else {
						p.sendMessage(ChatColor.GREEN + "Search complete!");
						p.openInventory(result.get(0));
					}
				}
			}
		});
	}
	
	public static ItemStack deprice(ItemStack item) {
		ItemMeta im = item.getItemMeta();
		List<String> lore = im.getLore();
		lore.remove(0);
		lore.remove(0);
		im.setLore(lore);
		item.setItemMeta(im);
		return ItemHandler.removeAttributes(item);
	}
	
	@EventHandler
	public void confirmPurchase(final AsyncPlayerChatEvent event) {
		if(plugin.getPD(event.getPlayer()).waitingOnPurchaseConfirm) {
			event.setCancelled(true);
			final PlayerData pd = plugin.getPD(event.getPlayer());
			final String uuid = pd.shopBuyingFrom.uuid;
			pd.waitingOnPurchaseConfirm = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					if(event.getMessage().toLowerCase().contains("yes")) {
						pd.player.sendMessage(ChatColor.GREEN + "Fetching shop data to see if item is still available...");
						SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
							public void run() {
								final ResultSet rs = plugin.executeSynchronizedQuery("SELECT * FROM rpg_shops where uuid = '" + uuid + "'");
								Shop updated = null;
								try {
									if(rs.next()) {
										int id = rs.getInt("id");
										String owner = rs.getString("owner");
										String uuid = rs.getString("uuid");
										String itemsToParse = rs.getString("items");
										ArrayList<ShopItem> items = deserializeShop(itemsToParse);
										boolean open = rs.getBoolean("open");
										String name = rs.getString("name");
										boolean vip = rs.getBoolean("vip");
										Shop s = new Shop(owner,uuid,items);
										if(name != null)
											s.name = name;
										s.vip = vip;
										s.id = id;
										s.open = open;
										if(rs.getTimestamp("expiryTime") != null) {
											s.expiryTime = rs.getTimestamp("expiryTime");
										} else {
											s.expiryTime = new Timestamp(0);
										}
										s.checkExpiry();
										updated = s;
									}
								} catch(Exception e) {
									
								}
								final Shop finalUpdated = updated;
								SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
									public void run() {
										pd.shopBuyingFrom = finalUpdated;
										if(pd.shopBuyingFrom.hasItem(pd.itemToBuy)) {
											if(pd.player.getInventory().firstEmpty() >= 0) {
												if(pd.wallet >= pd.itemToBuyPrice) {
													pd.wallet -= pd.itemToBuyPrice;
													pd.updateRonbook();
													pd.player.sendMessage(ChatColor.GREEN + "Successfully purchased " + pd.itemToBuy.getItemMeta().getDisplayName() + ChatColor.GREEN + " for " + ChatColor.GOLD + pd.itemToBuyPrice + "g" + ChatColor.GREEN + "!");
													pd.player.sendMessage(ChatColor.GREEN + "You now have " + ChatColor.GOLD + pd.wallet + "g" + ChatColor.GREEN + " in your wallet.");
													pd.shopBuyingFrom.removeItem(pd.itemToBuy);
													earnedGold(pd.shopBuyingFrom, pd.itemToBuyPrice, pd.player.getName());
													pd.player.getInventory().addItem(deprice(pd.itemToBuy));
													updateShop(pd.shopBuyingFrom);
												} else {
													pd.player.sendMessage(ChatColor.RED + "You don't have enough money in your wallet to buy that!");
												}
											} else {
												pd.player.sendMessage(ChatColor.RED + "Your inventory is full right now!");
											}
										} else {
											pd.player.sendMessage(ChatColor.RED + "The item you wanted to buy has been purchased by someone else. Sorry!");
										}
										pd.shopBuyingFrom = null;
										pd.itemToBuy = null;
										pd.itemToBuyPrice = 0;
									}
								});
							}
						});
					} else {
						pd.player.sendMessage(ChatColor.GREEN + "Cancelled pending purchase.");
					}
				}
			});
		}
	}
	
	public static void earnedGold(Shop s, final int value, final String buyer) {
		final String uuid = s.uuid;
		final String owner = s.owner;
		SuperDebugger.runTaskAsynchronously(ShopHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				System.out.println(owner + "'s shop earned " + value + " gold from " + buyer + ".");
				plugin.executePrepared("UPDATE rpg SET " + "shopGold" + "= shopGold + ? WHERE uuid='" + uuid + "'", value + "");
			}
		});
	}
	
	public static Shop getShop(Player p) {
		String uuid = plugin.getPD(p).uuid;
		for(Shop s : shops.values()) {
			if(s.uuid.equals(uuid))
				return s;
		}
		plugin.execute("INSERT INTO rpg_shops (id, owner, uuid, items, open, name, vip) "
				+ "VALUES (NULL, "
				+ "'" + p.getName() + "', " //owner
				+ "'" + uuid + "', " //uuid
				+ "'', " //items
				+ "0, " //open
				+ "'" + p.getName() + "\\'s Shop', " //name
				+ (RankManager.check(p, "knight") ? "1" : "0") //vip
				+ ");");
		return null;
	}
	
	public static void updateShop(Shop shop) {
		if(shop.expiryTime == null)
			shop.expiryTime = new Timestamp(0);
		String[][] data = new String[][] {
				{"owner", shop.owner},
				{"uuid", shop.uuid},
				{"items", serializeShop(shop.items)},
				{"open", shop.open ? "1" : "0"},
				{"expiryTime", shop.expiryTime + ""},
				{"name", shop.name},
				{"vip", shop.vip ? "1" : "0"},
		};
		StringBuilder statement = new StringBuilder("UPDATE rpg_shops SET ");
		String[] stringsOnly = new String[data.length];
		int count = 0;
		for(String[] s : data) {
			statement.append(s[0] + " = ?, ");
			stringsOnly[count++] = s[1];
		}
		if(statement.toString().endsWith(", "))
			statement = new StringBuilder(statement.substring(0, statement.length() - 2));
		statement.append(" WHERE uuid='" + shop.uuid + "'");
		plugin.executePrepared(statement.toString(), stringsOnly);
	}
	
	@EventHandler
	public void chatListener(final AsyncPlayerChatEvent event) {
		if(plugin.getPD(event.getPlayer()).waitingOnShopNameChange) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnShopNameChange = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String name = ChatColor.stripColor(event.getMessage());
					PlayerData pd = plugin.getPD(event.getPlayer());
					Player p = pd.player;
					if(name.length() > 25) {
						p.sendMessage(ChatColor.RED + "That shop name is too long! Max is 25 characters, yours was " + name.length() + ".");
					} else {
						int cost = 25000;
						if(pd.wallet >= cost) {
							getShop(p).name = name;
							pd.wallet -= cost;
							plugin.executePrepared("update shops set name = ? where uuid = '" + pd.uuid + "'", name);
							p.sendMessage(ChatColor.GREEN + "Your shop is now called " + name + ".");
						} else {
							p.sendMessage(ChatColor.RED + "You don't have enough money in your wallet to afford that!");
						}
					}
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnShopSearchOwner) {
			plugin.getPD(event.getPlayer()).waitingOnShopSearchOwner = false;
			event.setCancelled(true);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					conductSearch(event.getPlayer(), plugin.getPD(event.getPlayer()), event.getMessage(), null);
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnShopSearchName) {
			plugin.getPD(event.getPlayer()).waitingOnShopSearchName = false;
			event.setCancelled(true);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					conductSearch(event.getPlayer(), plugin.getPD(event.getPlayer()), null, event.getMessage());
				}
			});
		} else if(plugin.getPD(event.getPlayer()).waitingOnItemPrice) {
			event.setCancelled(true);
			plugin.getPD(event.getPlayer()).waitingOnItemPrice = false;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					Player p = event.getPlayer();
					PlayerData pd = plugin.getPD(p);
					ItemStack item = plugin.getPD(event.getPlayer()).itemToAddToShop;
					try {
						String message = event.getMessage().replaceAll("[^0-9]", "");
						int price = Integer.parseInt(message);
						if(price < 1 || price > 1000000000)
							throw new Exception("");
						if(p.getInventory().contains(item)) {
							Shop shop = getShop(p);
							if(!shop.open) {
								if(shop.items.size() < pd.shopSize * 9) {
									p.getInventory().removeItem(item);
									p.updateInventory();
									ItemMeta im = item.getItemMeta();
									ArrayList<String> lore = (ArrayList<String>) im.getLore();
									if(lore.get(0).contains("Price: ")) {
										lore.set(0, ChatColor.GOLD + "Price: " + ChatColor.BOLD + price + "g");
									} else {
										lore.add(0, ChatColor.GOLD + "Price: " + ChatColor.BOLD + price + "g");
										lore.add(1, "");
									}
									im.setLore(lore);
									item.setItemMeta(im);
									shop.items.add(new ShopItem(ItemHandler.removeAttributes(item), price));
									updateShop(shop);
									p.sendMessage(ChatColor.GREEN + "Successfully placed " + item.getAmount() + "x " + im.getDisplayName() + ChatColor.GREEN + " in your shop for " + ChatColor.GOLD + price + "g" + ChatColor.GREEN + ".");
									p.sendMessage(ChatColor.GREEN + "Make sure to Open Shop if you want to sell it now!");
									openShopManager(p);
								} else {
									p.sendMessage(ChatColor.RED + "Your shop appears to be full. Try reopening the shop interface if you know it's not full.");
								}
							} else {
								p.sendMessage(ChatColor.RED + "Your shop is currently open. You can't change it while it's open, sorry!");
							}
						} else {
							p.sendMessage(ChatColor.RED + "You don't seem to have the item you wanted to sell in your inventory!");
						}
					} catch(Exception e) {
						event.getPlayer().sendMessage(ChatColor.RED + "Error: Invalid item price. Must be between 1 and 1000000000.");
					}
				};
			});
		}
	}
	
	public static void updateShopInventory() {
		shopsDisplay.clear();
		Inventory currentInventory = basics(Bukkit.createInventory(null, 6*9, ChatColor.BLACK + "The Kastia Player Market (1)"));
		shopsDisplay.add(currentInventory);
		ItemStack item;
		ItemMeta im;
		int count = 0;
		Iterator<Shop> iter = shops.values().iterator();
		while(iter.hasNext()) {
			Shop s = iter.next();
			s.checkExpiry();
			if(!s.open)
				continue;
			item = new ItemStack(Material.CHEST);
			im = item.getItemMeta();
			im.setDisplayName((s.vip ? "" + ChatColor.GOLD + ChatColor.BOLD : ChatColor.LIGHT_PURPLE) + s.name);
			im.setLore(Arrays.asList(new String[] {
					ChatColor.AQUA + "Items: " + s.items.size(),
					"",
					ChatColor.AQUA + "Closing in: ",
					ChatColor.AQUA + s.getRemainingTime(),
					"",
					ChatColor.GRAY + "" + ChatColor.ITALIC + "Owner: " + s.owner,
					ChatColor.GRAY + "" + ChatColor.ITALIC + "Shop ID: " + s.id,
			}));
			item.setItemMeta(im);
			currentInventory.setItem(count++, item);
			if(count == 5*9 && iter.hasNext()) {
				count = 0;
				currentInventory = basics(Bukkit.createInventory(null, 6*9, ChatColor.BLACK + "The Kastia Player Market (" + (shopsDisplay.size() + 1) + ")"));
				shopsDisplay.add(currentInventory);
			}
		}
	}
	
	public static void openInventory(final Player p) {
		p.sendMessage(ChatColor.GREEN + "Fetching latest shop data...");
		final String uuid = plugin.getPD(p).uuid;
		SuperDebugger.runTaskAsynchronously(ShopHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				final ResultSet rs1 = plugin.executeSynchronizedQuery("SELECT shopGold FROM rpg where uuid = '" + uuid + "'");
				final ResultSet rs = plugin.executeSynchronizedQuery("SELECT * FROM rpg_shops");
				final ArrayList<Shop> tempshops = new ArrayList<Shop>();
				int shopGold = 0;
				try {
					if(rs1.next())
						shopGold = rs1.getInt("shopGold");
					while(rs.next()) {
						int id = rs.getInt("id");
						String owner = rs.getString("owner");
						String uuid = rs.getString("uuid");
						String itemsToParse = rs.getString("items");
						ArrayList<ShopItem> items = deserializeShop(itemsToParse);
						boolean open = rs.getBoolean("open");
						String name = rs.getString("name");
						boolean vip = rs.getBoolean("vip");
						Shop s = new Shop(owner,uuid,items);
						if(name != null)
							s.name = name;
						s.vip = vip;
						s.id = id;
						s.open = open;
						if(rs.getTimestamp("expiryTime") != null) {
							s.expiryTime = rs.getTimestamp("expiryTime");
						} else {
							s.expiryTime = new Timestamp(0);
						}
						s.checkExpiry();
						tempshops.add(s);
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
				final int realShopGold = shopGold;
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						shops.clear();
						Collections.sort(tempshops);
						for(Shop s : tempshops)
							shops.put(s.id, s);
						updateShopInventory();
						plugin.getPD(p).shopGold = realShopGold;
						p.sendMessage(ChatColor.GREEN + "Shop data updated!");
						p.openInventory(shopsDisplay.get(0));
					}
				});
			}
		});
	}
	
	public static String serializeShop(ArrayList<ShopItem> items) {
		StringBuilder sb = new StringBuilder("");
		for(ShopItem si : items) {
			sb.append(convertItemToString(si.item) + "@" + si.price + "~");
		}
		return sb.toString();
	}
	
	public static ArrayList<ShopItem> deserializeShop(String s) {
		ArrayList<ShopItem> items = new ArrayList<ShopItem>();
		for(String s2 : s.split("~")) {
			if(s2.length() < 1)
				continue;
			String[] data = s2.split("@");
			items.add(new ShopItem(convertStringToItem(data[0]), Integer.parseInt(data[1])));
		}
		return items;
	}
	
	public static ItemStack convertStringToItem(String s) {
		if(s.equals("null"))
			return null;
		String[] data = s.split("#");
		ItemStack i = new ItemStack(Material.getMaterial(data[0]), Integer.parseInt(data[1]), Byte.parseByte(data[2]));
		if(data.length > 3) {
			if(data[3].toLowerCase().contains("ronbook") || data[3].toLowerCase().contains("navigator"))
				return null;
			ItemMeta im = i.getItemMeta();
			im.setDisplayName(data[3]);
			ArrayList<String> lore = new ArrayList<String>();
			for(int k = 4; k < data.length; k++)
				lore.add(data[k]);
			im.setLore(lore);
			i.setItemMeta(im);
		}
		return ItemHandler.removeAttributes(i);
	}
	
	public static String convertItemToString(ItemStack i) {
		if(i == null)
			return "null";
		//type#amount#data#name#lores
		StringBuilder sb = new StringBuilder("");
		sb.append(i.getType() + "#");
		sb.append(i.getAmount() + "#");
		sb.append(i.getData().getData() + "#");
		if(i.hasItemMeta()) {
			ItemMeta im = i.getItemMeta();
			if(im.hasDisplayName())
				sb.append(im.getDisplayName() + "#");
			if(im.hasLore()) {
				for(String s : im.getLore())
					sb.append(s + "#");
			}
		}
		return sb.toString();
	}
	
	public static RonboMC plugin;
	
	public ShopHandler(RonboMC plugin) {
		ShopHandler.plugin = plugin;
	}
	
}