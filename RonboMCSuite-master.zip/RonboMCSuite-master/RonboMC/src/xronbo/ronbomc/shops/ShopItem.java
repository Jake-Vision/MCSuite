package xronbo.ronbomc.shops;

import org.bukkit.inventory.ItemStack;

public class ShopItem {
	
	public ItemStack item;
	public int price;
	
	public ShopItem(ItemStack item, int price) {
		this.item = item;
		this.price = price;
	}
	
}