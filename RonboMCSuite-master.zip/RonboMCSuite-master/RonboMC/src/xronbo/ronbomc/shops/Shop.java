package xronbo.ronbomc.shops;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.PlayerData;

public class Shop implements Comparable<Shop> {
	
	public int id = -1;
	public boolean open = false;
	public boolean vip = false;
	public String owner, uuid;
	public String name;
	public ArrayList<ShopItem> items;
	public Timestamp expiryTime;
	
	public String getRemainingTime() {
		long now = new Date().getTime();
		return PlayerData.timeDiff(expiryTime.getTime() - now);
	}
	
	public Inventory getMenu() {
		int size = (int)(Math.ceil(items.size()/ 9.0))*9;
		if(size == 0)
			size = 9;
		Inventory inventory = Bukkit.createInventory(null, size, owner + "'s Player Shop");
		int count = 0;
		for(ShopItem si : items)
			inventory.setItem(count++, si.item);
		return inventory;
	}
	
	public int compareTo(Shop other) {
		return this.expiryTime.compareTo(other.expiryTime);
	}
	
	public void removeItem(ItemStack i) {
		for(int k = 0; k < items.size(); k++) {
			if(items.get(k).item.equals(i)) {
				items.remove(k);
				return;
			}
		}
	}
	
	public boolean hasItem(ItemStack i) {
		for(ShopItem si : items)
			if(si.item.equals(i))
				return true;
		return false;
	}
	
	public void checkExpiry() {
		if(expiryTime.compareTo(new Timestamp(new Date().getTime())) < 0) {
			open = false;
		} else {
			open = true;
		}
		if(items.size() == 0) {
			open = false;
			expiryTime = new Timestamp(0);
		}
	}
	
	public void addTime(int hours) {
		expiryTime = new Timestamp(new Date().getTime() + 1000*60*60*hours);
		open = true;
	}
	
	public Shop(String owner, String uuid, ArrayList<ShopItem> items) {
		this.owner = owner;
		this.uuid = uuid;
		this.items = items;
		this.name = owner + "'s Shop";
	}
	
	public String toString() {
		return owner;
	}
	
}