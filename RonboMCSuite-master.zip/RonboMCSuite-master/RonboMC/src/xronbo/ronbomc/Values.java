package xronbo.ronbomc;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import net.minecraft.server.v1_8_R1.ChatSerializer;
import net.minecraft.server.v1_8_R1.EnumTitleAction;
import net.minecraft.server.v1_8_R1.IChatBaseComponent;
import net.minecraft.server.v1_8_R1.Packet;
import net.minecraft.server.v1_8_R1.PacketPlayOutChat;
import net.minecraft.server.v1_8_R1.PacketPlayOutPlayerListHeaderFooter;
import net.minecraft.server.v1_8_R1.PacketPlayOutTitle;
import net.minecraft.server.v1_8_R1.PlayerConnection;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import xronbo.ronbomc.warps.WarpHandler;

public final class Values {
	
	public static final double T4_LEGEND_NAME_CHANCE = 0.003;
	public static final double T5_LEGEND_NAME_CHANCE = 0.002;

	public static final double DROP_RATE_TIER1_GET_TIER2 = 0.005;
	public static final double DROP_RATE_TIER1_GET_TIER1 = 0.05;
	public static final double DROP_RATE_TIER1_GET_HP1 = 0.0125;

	public static final double DROP_RATE_TIER2_GET_TIER2 = 0.025;
	public static final double DROP_RATE_TIER2_GET_TIER1 = 0.03;
	public static final double DROP_RATE_TIER2_GET_HP1 = 0.01;
	public static final double DROP_RATE_TIER2_GET_HP2 = 0.025;
	 
	public static final double DROP_RATE_TIER3_GET_TIER3 = 0.002;
	public static final double DROP_RATE_TIER3_GET_TIER2 = 0.03;
	public static final double DROP_RATE_TIER3_GET_HP1 = 0.01;
	public static final double DROP_RATE_TIER3_GET_HP2 = 0.02;
	public static final double DROP_RATE_TIER3_GET_HP3 = 0.03;
	 
	public static final double DROP_RATE_TIER4_GET_TIER4 = 0.0006;
	public static final double DROP_RATE_TIER4_GET_TIER3 = 0.004;
	public static final double DROP_RATE_TIER4_GET_HP4 = 0.05;

	public static final double DROP_RATE_TIER5_GET_TIER5 = 0.0001;
	public static final double DROP_RATE_TIER5_GET_TIER4 = 0.0012;
	public static final double DROP_RATE_TIER5_GET_TIER3 = 0.05;
	public static final double DROP_RATE_TIER5_GET_HP5 = 0.05;
	
	public static final double RARITY_UNCOMMON = 0.30;
	public static final double RARITY_RARE = 0.05;
	public static final double RARITY_EPIC = 0.01;
	public static final double RARITY_UNIQUE = 0.001;
	public static final double RARITY_LEGENDARY = 0.0001;
	public static final double RARITY_GODLIKE = 0.00001;
	
	public static final double ITEM_HAS_ATTRIBUTE = 0.35;
	
	public static final double STAT_COUNT_3 = 0.65;
	public static final double STAT_COUNT_4 = 0.35;
	public static final double STAT_COUNT_5 = 0.15;
	public static final double STAT_COUNT_6 = 0.02;
	public static final double STAT_COUNT_7 = 0.001;
	public static final double STAT_COUNT_8 = 0.0005;
	
	public static final double MULTIPLIER_COMMON = 1.00;
	public static final double MULTIPLIER_UNCOMMON = 1.10;
	public static final double MULTIPLIER_RARE = 1.20;
	public static final double MULTIPLIER_EPIC = 1.55;
	public static final double MULTIPLIER_UNIQUE = 2.05;
	public static final double MULTIPLIER_LEGENDARY = 2.85;
	public static final double MULTIPLIER_GODLIKE = 3.45;
	
	public static final double MULTIPLIER_HELMET_BONUS = 0.03;
	public static final double MULTIPLIER_CHESTPLATE_BONUS = 0.09;
	public static final double MULTIPLIER_LEGGINGS_BONUS = 0.07;
	public static final double MULTIPLIER_BOOTS_BONUS = 0.01;
	
	public static final double STAT_DECREASE_CRIT_CHANCE = 2.00;
	public static final double STAT_DECREASE_CRIT_DAMAGE = 1.50;
	public static final double STAT_DECREASE_LIFESTEAL = 2.50;
	public static final double STAT_DECREASE_HP = 3.50;
	
	public static final int[] T1_ATK_BASE = {10, 30};
	public static final int[] T2_ATK_BASE = {50, 80};
	public static final int[] T3_ATK_BASE = {120, 160};
	public static final int[] T4_ATK_BASE = {210, 260};
	public static final int[] T5_ATK_BASE = {320, 380};
	
	public static final int[] T1_ATK_SWORD = {0, 0};
	public static final int[] T2_ATK_SWORD = {0, 0};
	public static final int[] T3_ATK_SWORD = {0, 0};
	public static final int[] T4_ATK_SWORD = {0, 0};
	public static final int[] T5_ATK_SWORD = {0, 0};
	
	public static final int[] T1_ATK_AXE = {-3, 3};
	public static final int[] T2_ATK_AXE = {-3, 4};
	public static final int[] T3_ATK_AXE = {-3, 5};
	public static final int[] T4_ATK_AXE = {-3, 6};
	public static final int[] T5_ATK_AXE = {-3, 7};

	public static final int[] T1_ATK_MACE = {0, 1};
	public static final int[] T2_ATK_MACE = {0, 2};
	public static final int[] T3_ATK_MACE = {0, 3};
	public static final int[] T4_ATK_MACE = {0, 4};
	public static final int[] T5_ATK_MACE = {0, 5};
	
	public static final int[] T1_ATK_STAVE = {0, 0};
	public static final int[] T2_ATK_STAVE = {0, 0};
	public static final int[] T3_ATK_STAVE = {3, 6};
	public static final int[] T4_ATK_STAVE = {4, 7};
	public static final int[] T5_ATK_STAVE = {5, 8};
	
	public static final int[] T1_ATK_WAND = {-2, -2};
	public static final int[] T2_ATK_WAND = {-3, -3};
	public static final int[] T3_ATK_WAND = {-4, -4};
	public static final int[] T4_ATK_WAND = {-5, -5};
	public static final int[] T5_ATK_WAND = {-6, -6};
	
	public static final int[] T1_ATK_BOW = {0, 0};
	public static final int[] T2_ATK_BOW = {0, 0};
	public static final int[] T3_ATK_BOW = {0, 0};
	public static final int[] T4_ATK_BOW = {0, 0};
	public static final int[] T5_ATK_BOW = {0, 0};
	
	public static final int[] T1_ATK_DAGGER = {-4, -2};
	public static final int[] T2_ATK_DAGGER = {-2, 0};
	public static final int[] T3_ATK_DAGGER = {0, 2};
	public static final int[] T4_ATK_DAGGER = {2, 4};
	public static final int[] T5_ATK_DAGGER = {4, 6};
	
	public static final int[] T1_ATK_BONE = {-5, -5};
	public static final int[] T2_ATK_BONE = {-5, -5};
	public static final int[] T3_ATK_BONE = {-5, -5};
	public static final int[] T4_ATK_BONE = {-5, -5};
	public static final int[] T5_ATK_BONE = {-5, -5};
	
	public static final double MAIN_ATTRIBUTE_MULTIPLIER = 1.35;
	
	public static final int[] CORE_STAT_RANGE_T1 = {1, 20};
	public static final int[] CORE_STAT_RANGE_T2 = {30, 60};
	public static final int[] CORE_STAT_RANGE_T3 = {80, 120};
	public static final int[] CORE_STAT_RANGE_T4 = {150, 200};
	public static final int[] CORE_STAT_RANGE_T5 = {240, 300};

	public static final int[] HP_RANGE_T1 = {20, 50};
	public static final int[] HP_RANGE_T2 = {100, 300};
	public static final int[] HP_RANGE_T3 = {600, 1500};
	public static final int[] HP_RANGE_T4 = {3000, 8000};
	public static final int[] HP_RANGE_T5 = {15000, 30000};
	
	public static final int[] HP_REGEN_RANGE_T1 = {1, 3};
	public static final int[] HP_REGEN_RANGE_T2 = {10, 15};
	public static final int[] HP_REGEN_RANGE_T3 = {30, 40};
	public static final int[] HP_REGEN_RANGE_T4 = {100, 150};
	public static final int[] HP_REGEN_RANGE_T5 = {300, 400};
	
	public static final int[] LIFESTEAL_RANGE_T1 = {1, 2};
	public static final int[] LIFESTEAL_RANGE_T2 = {2, 4};
	public static final int[] LIFESTEAL_RANGE_T3 = {2, 6};
	public static final int[] LIFESTEAL_RANGE_T4 = {3, 8};
	public static final int[] LIFESTEAL_RANGE_T5 = {3, 10};
	
	public static final int[] CRIT_CHANCE_RANGE_T1 = {1, 3};
	public static final int[] CRIT_CHANCE_RANGE_T2 = {2, 5};
	public static final int[] CRIT_CHANCE_RANGE_T3 = {2, 7};
	public static final int[] CRIT_CHANCE_RANGE_T4 = {3, 9};
	public static final int[] CRIT_CHANCE_RANGE_T5 = {3, 11};
	
	public static final int[] CRIT_DAMAGE_RANGE_T1 = {1, 3};
	public static final int[] CRIT_DAMAGE_RANGE_T2 = {2, 5};
	public static final int[] CRIT_DAMAGE_RANGE_T3 = {2, 7};
	public static final int[] CRIT_DAMAGE_RANGE_T4 = {3, 9};
	public static final int[] CRIT_DAMAGE_RANGE_T5 = {3, 11};
	
	public static final double LEGEND_NAME_ATTACK_BONUS = 35;
	public static final double LEGEND_NAME_MULTIPLIER_ARMOR = 1.45;
	
	public static final double CHANCE_OF_MAIN_STAT = 0.45;
	public static final double CHANCE_OF_SECONDARY_STAT = 0.15;
	public static final double CHANCE_OF_CRIT_CHANCE_WITH_CRIT_DAMAGE = 0.65;
	
	public static final double PVP_DEBUFF = 0.15;
	
	public static final double GLOBAL_EXP_RATE = 0.95;
	public static final double VIP_EXP_RATE = 1.25;
	public static final double EXP_BONUS = 1.00;
	
	public static final int HP_PER_LEVEL = 40;
	public static final int SP_PER_LEVEL = 5;
	
	public static final int LATENCY_THRESHOLD_HIGH = 300;
	public static final int LATENCY_THRESHOLD_MEDIUM = 150;
	
	public static final double PLAYER_THRESHOLD_HIGH = 0.9;
	public static final double PLAYER_THRESHOLD_MEDIUM = 0.5;
	
	public static final int SECONDS_BETWEEN_QUEST_NPC_CHAT = 5;
	
	public static final int WAND_RANGE = 12;

	public static final double SAFE_ITEM_LOST_ON_DEATH = 0.4;
	public static final double ITEM_LOST_ON_DEATH = 0.7;
	
	public static final int CHUNK_RANGE_TO_SPAWN = 2;
	
	public static final Values values = new Values();
	public static final int MOBS_PER_PLAYER = 5;
	public static final int MAX_NEARBY_MOBS = 20;
	
	public static String capitalize(String s) {
		StringBuilder sb = new StringBuilder("");
		boolean capitalize = true;
		for(int k = 0; k < s.length(); k++) {
			String s2 = s.substring(k, k+1);
			if(capitalize) {
				capitalize = false;
				s2 = s2.toUpperCase();
			}
			if(!s2.matches("[a-zA-z]{1}")) {
				capitalize = true;
			}
			sb.append(s2);
		}
		return sb.toString();
	}

	public static ArrayList<String> longStringToLoreList(ChatColor color, String... strings) {
		ArrayList<String> lore = new ArrayList<String>();
		for(String s : strings) {
			lore.addAll(Arrays.asList(stringToLore(s, color)));
			lore.add("");
		}
		if(lore.size() > 0) {
			if(lore.get(lore.size() - 1).equals(""))
				lore.remove(lore.size() - 1);
		}
		return lore;
	}
	
	public static String[] stringToLore(String s) {
		return stringToLore(s, ChatColor.AQUA);
	}
	
	public static String[] stringToLore(String s, ChatColor color) {
		ArrayList<String> lines = new ArrayList<String>();
		Scanner scan = new Scanner(s);
		StringBuilder temp = new StringBuilder("");
		while(scan.hasNext()) {
			String toAppend = scan.next();
			if(temp.length() + (toAppend + " ").length() > 35) {
				lines.add(color + temp.toString());
				temp.setLength(0);
				temp.append(toAppend + " ");
			} else {
				temp.append(toAppend + " ");
			}
		}
		if(temp.length() > 0)
			lines.add(color + temp.toString());
		scan.close();
		return lines.toArray(new String[lines.size()]);
	}
	
	public static int randInt(int min, int max) {
		return ((int)(Math.random() * (max - min + 1))) + min;
	}
	
	public static double randDouble(double min, double max) {
		return Math.random()*(max - min) + min;
	}
	
	private Values() {
		
	}
	
	public static void sendTitle(Player player, String title, String subtitle, int fadeIn, int stay, int fadeOut){
		CraftPlayer craftplayer = (CraftPlayer)player;
		PlayerConnection connection = craftplayer.getHandle().playerConnection;
		IChatBaseComponent titleJSON = ChatSerializer.a("{'text': '" + ChatColor.translateAlternateColorCodes('&', title) + "'}");
		IChatBaseComponent subtitleJSON = ChatSerializer.a("{'text': '" + ChatColor.translateAlternateColorCodes('&', subtitle) + "'}");
		Packet length = new PacketPlayOutTitle(EnumTitleAction.TIMES, titleJSON, fadeIn, stay, fadeOut);
		Packet titlePacket = new PacketPlayOutTitle(EnumTitleAction.TITLE, titleJSON, fadeIn, stay, fadeOut);
		Packet subtitlePacket = new PacketPlayOutTitle(EnumTitleAction.SUBTITLE, subtitleJSON, fadeIn, stay, fadeOut);
		connection.sendPacket(titlePacket);
		connection.sendPacket(length);
		connection.sendPacket(subtitlePacket);
	}

	public static void sendActionBar(Player p, String msg)	  {
		IChatBaseComponent cbc = ChatSerializer.a("{\"text\": \"" + msg + "\"}");
		PacketPlayOutChat ppoc = new PacketPlayOutChat(cbc, (byte)2);
		((CraftPlayer)p).getHandle().playerConnection.sendPacket(ppoc);
	}

	public static void sendHeaderAndFooter(Player p, String head, String foot)  {
		CraftPlayer craftplayer = (CraftPlayer)p;
		PlayerConnection connection = craftplayer.getHandle().playerConnection;
		IChatBaseComponent header = ChatSerializer.a("{'color': '', 'text': '" + ChatColor.translateAlternateColorCodes('&', head) + "'}");
		IChatBaseComponent footer = ChatSerializer.a("{'color': '', 'text': '" + ChatColor.translateAlternateColorCodes('&', foot) + "'}");
		PacketPlayOutPlayerListHeaderFooter packet = new PacketPlayOutPlayerListHeaderFooter();
		try
		{
			Field headerField = packet.getClass().getDeclaredField("a");
			headerField.setAccessible(true);
			headerField.set(packet, header);
			headerField.setAccessible(!headerField.isAccessible());

			Field footerField = packet.getClass().getDeclaredField("b");
			footerField.setAccessible(true);
			footerField.set(packet, footer);
			footerField.setAccessible(!footerField.isAccessible());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		connection.sendPacket(packet);
	}

	public static String locationToString(Location loc) {
		String s = loc.getX() + " " + loc.getY() + " " + loc.getZ() + " " + loc.getYaw() + " " + loc.getPitch() + " " + loc.getWorld().getName();
		if(s.toLowerCase().contains("nan") || Double.isNaN(loc.getX()) || Double.isNaN(loc.getY()) || Double.isNaN(loc.getZ())) {
			s = Values.locationToString(WarpHandler.warps.get("mainspawn"));
		}
		return s;
	}

	public static Location stringToLocation(String s) {
		String[] data = s.split(" ");
		double x = Double.parseDouble(data[0]);
		double y = Double.parseDouble(data[1]);
		if(Double.isNaN(y))
			y = 100.0;
		double z = Double.parseDouble(data[2]);
		float yaw = Float.parseFloat(data[3]);
		float pitch = Float.parseFloat(data[4]);
		StringBuilder sb = new StringBuilder("");
		for(int k = 5; k < data.length; k++)
			sb.append(data[k] + " ");
		return new Location(PlayerData.plugin.getServer().getWorld(sb.toString().trim()),x,y,z,yaw,pitch);
	}
}