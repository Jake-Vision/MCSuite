package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Slime extends PacketEffect {

    public Slime(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SLIME);
    }

    @Override
    public String getNmsName() {
        return "slime";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 20;
    }
}