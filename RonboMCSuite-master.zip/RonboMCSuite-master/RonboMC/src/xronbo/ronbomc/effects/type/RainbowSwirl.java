package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class RainbowSwirl extends PacketEffect {

    public RainbowSwirl(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.RAINBOWSWIRL);
    }

    @Override
    public String getNmsName() {
        return "mobSpell";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 20;
    }
}