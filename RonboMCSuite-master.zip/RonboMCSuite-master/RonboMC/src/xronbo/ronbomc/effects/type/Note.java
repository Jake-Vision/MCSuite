package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Note extends PacketEffect {

    public Note(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.NOTE);
    }

    @Override
    public String getNmsName() {
        return "note";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 20;
    }
}