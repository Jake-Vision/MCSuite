package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Heart extends PacketEffect {

    public Heart(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.HEART);
    }

    @Override
    public String getNmsName() {
        return "heart";
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 10;
    }
}