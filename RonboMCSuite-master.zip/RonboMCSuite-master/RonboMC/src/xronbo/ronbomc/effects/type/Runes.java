package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Runes extends PacketEffect {

    public Runes(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.RUNES);
    }

    @Override
    public String getNmsName() {
        return "enchantmenttable";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 100;
    }
}