package xronbo.ronbomc.effects.type;

import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import xronbo.ronbomc.effects.Effect;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketUtil;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.effects.ReflectionUtil;


public class Firework extends Effect {

    public FireworkEffect fireworkEffect;

    public Firework(EffectHolder effectHolder, FireworkEffect fireworkEffect) {
        super(effectHolder, ParticleType.FIREWORK);
        this.fireworkEffect = fireworkEffect;
    }
    
    public void doPlay() {
        for (Location l : this.displayType.getLocations(this.getHolder())) {
            ReflectionUtil.spawnFirework(new Location(l.getWorld(), l.getX(), l.getY() + 1, l.getZ()), this.fireworkEffect);
        }
    }

    public void playDemo(Player p) {
        ReflectionUtil.sendPacket(p, PacketUtil.createPacket("fireworksSpark", p.getLocation(), 50F, 30));
    }

    @Override
    public void doPlayAmount(int i) {
        this.doPlay();
    }
}