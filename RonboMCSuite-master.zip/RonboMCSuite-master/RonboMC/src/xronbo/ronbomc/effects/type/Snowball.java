package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Snowball extends PacketEffect {

    public Snowball(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SNOWBALL);
    }

    @Override
    public String getNmsName() {
        return "snowballpoof";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 20;
    }
}