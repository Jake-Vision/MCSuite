package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Snow extends PacketEffect {

    public Snow(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SNOW);
    }

    @Override
    public String getNmsName() {
        return "snowshovel";
    }

    @Override
    public float getSpeed() {
        return 0.02F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}