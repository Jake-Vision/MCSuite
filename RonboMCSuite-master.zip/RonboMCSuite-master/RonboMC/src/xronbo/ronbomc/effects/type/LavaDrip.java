package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class LavaDrip extends PacketEffect {

    public LavaDrip(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.LAVADRIP);
    }

    @Override
    public String getNmsName() {
        return "dripLava";
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}