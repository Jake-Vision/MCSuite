package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Explosion extends PacketEffect {

    public Explosion(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.EXPLOSION);
    }

    @Override
    public String getNmsName() {
        return "hugeexplosion";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 1;
    }
}