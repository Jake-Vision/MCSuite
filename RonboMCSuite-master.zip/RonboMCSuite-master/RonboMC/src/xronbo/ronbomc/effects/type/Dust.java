package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Dust extends PacketEffect {

    public int idValue;
    public int metaValue;

    public Dust(EffectHolder effectHolder, int idValue, int metaValue) {
        super(effectHolder, ParticleType.DUST);
        this.idValue = idValue;
        this.metaValue = metaValue;
    }

    @Override
    public String getNmsName() {
        return "blockdust_" + idValue + "_" + metaValue;
    }

    @Override
    public float getSpeed() {
        return 0F;
    }

    @Override
    public int getParticleAmount() {
        return 100;
    }
}