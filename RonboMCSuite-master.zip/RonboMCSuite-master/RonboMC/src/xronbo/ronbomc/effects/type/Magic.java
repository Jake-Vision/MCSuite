package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Magic extends PacketEffect {

    public Magic(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.MAGIC);
    }

    @Override
    public String getNmsName() {
        return "witchMagic";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}