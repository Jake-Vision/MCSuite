package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Splash extends PacketEffect {

    public Splash(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.SPLASH);
    }

    @Override
    public String getNmsName() {
        return "splash";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}