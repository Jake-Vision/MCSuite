package xronbo.ronbomc.effects.type;

import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.PacketEffect;
import xronbo.ronbomc.effects.ParticleType;


public class Portal extends PacketEffect {

    public Portal(EffectHolder effectHolder) {
        super(effectHolder, ParticleType.PORTAL);
    }

    @Override
    public String getNmsName() {
        return "portal";
    }

    @Override
    public float getSpeed() {
        return 1F;
    }

    @Override
    public int getParticleAmount() {
        return 50;
    }
}