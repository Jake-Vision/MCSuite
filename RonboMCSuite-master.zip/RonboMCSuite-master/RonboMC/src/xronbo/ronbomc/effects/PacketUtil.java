package xronbo.ronbomc.effects;

import java.util.HashMap;

import net.minecraft.server.v1_8_R1.EnumParticle;
import net.minecraft.server.v1_8_R1.PacketPlayOutWorldParticles;

import org.bukkit.Location;

/**
 *
 * @author ralitski
 */
public class PacketUtil {
    
    public static PacketPlayOutWorldParticles createPacket(PacketEffect e) {
        return createPacket(e.getNmsName(),
                e.getHolder().getLocation(),
                e.getSpeed(),
                e.getParticleAmount());
    }
    
    public static PacketPlayOutWorldParticles createPacket(PacketEffect e, int amt) {
        return createPacket(e.getNmsName(),
                e.getHolder().getLocation(),
                e.getSpeed(),
                amt);
    }

    public static PacketPlayOutWorldParticles createPacket(String name, Location loc, float speed, int amt) {
        return createPacket(name, loc, 0.5F, 1.0F, 0.5F, speed, amt);
    }
    
    private static enum Particle {
    	EXPLOSION_NORMAL("explode"),  EXPLOSION_LARGE("largeexplode"),  EXPLOSION_HUGE("hugeexplosion"),  FIREWORKS_SPARK("fireworksSpark"),  WATER_BUBBLE("bubble"),  WATER_SPLASH("splash"),  WATER_WAKE("wake"),  SUSPENDED("suspended"),  SUSPENDED_DEPTH("depthsuspend"),  CRIT("crit"),  CRIT_MAGIC("magicCrit"),  SMOKE_NORMAL("smoke"),  SMOKE_LARGE("largesmoke"),  SPELL("spell"),  SPELL_INSTANT("instantSpell"),  SPELL_MOB("mobSpell"),  SPELL_MOB_AMBIENT("mobSpellAmbient"),  SPELL_WITCH("witchMagic"),  DRIP_WATER("dripWater"),  DRIP_LAVA("dripLava"),  VILLAGER_ANGRY("angryVillager"),  VILLAGER_HAPPY("happyVillager"),  TOWN_AURA("townaura"),  NOTE("note"),  PORTAL("portal"),  ENCHANTMENT_TABLE("enchantmenttable"),  FLAME("flame"),  LAVA("lava"),  FOOTSTEP("footstep"),  CLOUD("cloud"),  REDSTONE("reddust"),  SNOWBALL("snowballpoof"),  SNOW_SHOVEL("snowshovel"),  SLIME("slime"),  HEART("heart"),  BARRIER("barrier"),  ICON_CRACK("iconcrack", 1),  BLOCK_CRACK("blockcrack", 1),  BLOCK_DUST("blockdust", 2),  WATER_DROP("droplet"),  ITEM_TAKE("take");
    	public final String name;
    	@SuppressWarnings("unused")
		public final int extra;
    	private static final HashMap<String, Particle> particleMap;
    	private Particle(String name) {
    		this(name, 0);
    	}
    	private Particle(String name, int extra) {
    		this.name = name;
    		this.extra = extra;
    	}
    	public static Particle find(String part) {
    		return (Particle)particleMap.get(part);
    	}
    	static {
    		particleMap = new HashMap<String, Particle>();
    		for (Particle particle : values()) {
    			particleMap.put(particle.name, particle);
    		}
    	}
    }

    public static PacketPlayOutWorldParticles createPacket(String name, Location loc, float x, float y, float z, float speed, int amt) {
    	String[] parts = name.split("_");
        Particle particle = Particle.find(parts[0]);
        return new PacketPlayOutWorldParticles(
                EnumParticle.valueOf(particle.toString()),
                true,
                (float)loc.getX(),
                (float)loc.getY(),
                (float)loc.getZ(),
                x,
                y,
                z,
                speed,
                amt);
    }
}
