package xronbo.ronbomc.entities;

import java.util.ArrayList;

import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.entities.MobStats.MobStat;

public class MobType {
	
	public int id = -1;
	
	public String species = "";
	public Class<?> type = null;
	public String typeName = "";
	public int tier = 0;
	public String[] prefixes = null;
	public String[] suffixes = null;
	public ArrayList<String> special = null;
	public String head = "";
	public ItemStack weapon = null;
	public ItemStack helmet = null;
	public ItemStack chest = null;
	public ItemStack legs = null;
	public ItemStack boots = null;
	public double equipmentDropMultiplier = 1.0;
	public ArrayList<MobDrop> drops = null;
	public int level = 1;
	public long hp = 100;
	public int minDamage = 0;
	public int maxDamage = 0;
	public int exp;
	public int damageReduction;
	
	public void getStats() {
		MobStat ms = MobStats.getMobStat(level);
		hp = ms.maxHP;
		minDamage = (int)(ms.damage * 0.85);
		maxDamage = ms.damage;
		exp = ms.exp;
		tier = ms.tier;
		checkSpecials();
	}
	
	public void checkSpecials() {
		for(String s : special) {
			s = s.toLowerCase();
			try {
				double multiplier = Double.parseDouble(s.replaceAll("[^0-9\\.]", ""));
				if((s.startsWith("dr") && !s.startsWith("drop")) || s.startsWith("damagereduction")) {
					if(multiplier < 1)
						System.out.println("Warning! " + s + " (special modifier) should be a percentage out of 100!");
					damageReduction = (int)multiplier;
				} else if(s.startsWith("hp")) {
					hp *= multiplier;
				} else if(s.startsWith("exp")) {
					exp *= multiplier;
				} else if(s.startsWith("damage") || s.startsWith("attack")) {
					minDamage *= multiplier;
					maxDamage *= multiplier;
				} else if(s.startsWith("equipmentDropMultiplier") || s.startsWith("drop")) {
					equipmentDropMultiplier = multiplier;
				}
			} catch(Exception e) {
				
			}
		}
	}
	
	public MobType() {
		
	}
	
	public String toString() {
		return "ID: " + id + " Species: " + species + " Tier: " + tier;
	}
}