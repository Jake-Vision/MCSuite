package xronbo.ronbomc.entities;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R1.CraftWorld;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.Inventory;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.entities.entitytypes.CustomVillager;
import xronbo.ronbomc.horses.HorseHandler;
import xronbo.ronbomc.listeners.GeneralListeners;
import xronbo.ronbomc.listeners.GeneralListeners.ChunkCoord;
import xronbo.ronbomc.quests.Quest;
import xronbo.ronbomc.quests.QuestHandler;
import xronbo.ronbomc.quests.Stage;
import xronbo.ronbomc.skills.harvesting.HarvestingHandler;

public class VillagerData {
	
	public enum VillagerType {
		MERCHANT,
		DUNGEON,
		HARVESTING,
		QUEST,
		NONINTERACTIVE,
		STABLE;
	}
	
	public CustomVillager entity;

	public static RonboMC plugin;
	
	public String name;
	public Location originalLoc;
	public int color;
	
	public int storeId;
	public ArrayList<String> lines;
	public ArrayList<Quest> myQuests;
	public int questNpcID;
	public String dungeon;
	public String dungeonRecLevel;
	public String dungeonDescription;
	public VillagerType villagerType;
	public boolean baby;
	public boolean noMove;
	
	public Location toRespawnLocation;
	
	public VillagerData(String name, Location loc, int color) {
		this(name, loc, color, false, false);
	}
	
	public VillagerData(String name, Location loc, int color, boolean baby, boolean noMove) {
		this.name = name;
		loc.setX(loc.getX() + 0.5);
		loc.setZ(loc.getZ() + 0.5);
		loc.setY(loc.getY() + 0.75);
		this.originalLoc = loc; 
		this.toRespawnLocation = loc;
		this.color = color;
		this.baby = baby;
		this.noMove = noMove;
		createEntity(name, loc, color);
	}
	
	public static HashMap<ChunkCoord, VillagerData> villagers = new HashMap<ChunkCoord, VillagerData>();
	
	public void createEntity(String name, Location loc, int color) {
		if(loc.getWorld().isChunkInUse(loc.getChunk().getX(), loc.getChunk().getZ())) {
			net.minecraft.server.v1_8_R1.World world = ((CraftWorld)(loc.getWorld())).getHandle();
			CustomVillager v = null;
			try {
				v = CustomVillager.class.getDeclaredConstructor(net.minecraft.server.v1_8_R1.World.class).newInstance(world);
			} catch (Exception e) {
				e.printStackTrace();
			}
			v.setCustomName(name);
			v.setPosition(loc.getX(), loc.getY(), loc.getZ());
			v.setCustomNameVisible(true);
			v.setProfession(color);
			world.addEntity(v, SpawnReason.CUSTOM);
			if(!noMove && villagerType == VillagerType.NONINTERACTIVE)
				v.allowWalk();
			if(baby) {
				Ageable a = (Ageable) v.getBukkitEntity();
				a.setBaby();
				a.setAgeLock(true);
			}
			NPCHandler.villagerData.put(v.getUniqueID(), this);
			entity = v;
		} else {
			GeneralListeners.addVillagerToReload(this, loc);
		}
	}

	public void handleInteract(final Player p) {
		switch(villagerType) {
			case QUEST:
	         	PlayerData pd = NPCHandler.plugin.getPD(p);
	         	boolean willChat = false;
	         	for(int k = 0; k < myQuests.size(); k++) {
	         		Quest q = myQuests.get(k);
	         		if(pd.inProgressQuests.keySet().contains(q)) {
	         			willChat = true;
	         		} else if(!pd.completedQuests.contains(q)) {
	         			if(pd.level >= q.reqLevel) {
	         				boolean hasReq = true;
	         				if(QuestHandler.quests.get(q.reqQuest) != null) {
	         					hasReq = pd.completedQuests.contains(QuestHandler.quests.get(q.reqQuest));
	         				}
	         				if(hasReq) {
	         					if(q.stages.get(0).npcID == this.questNpcID) {
	             					willChat = true;
	             					pd.inProgressQuests.put(q, 0);
	             					pd.player.sendMessage("");
	             					pd.player.sendMessage(ChatColor.GOLD + "New Quest Started: " + q.name + ChatColor.GOLD + "!");
	             					pd.player.sendMessage(ChatColor.GOLD + "" + ChatColor.ITALIC + q.description);
	             					pd.player.sendMessage(ChatColor.RED + "To skip dialogues when talking to Quest NPCs, use /skip.");
	             					pd.updateRonbook();
	         					}
	         				}
	         			}
	         		}
	         		if(willChat) {
	         			if(!q.stages.get(pd.inProgressQuests.get(q)).checkComplete(p, this)) {
	         				int index = pd.inProgressQuests.get(q) - 1;
	         				willChat = false;
	         				while(index > 0) {
	         					Stage s = q.stages.get(index);
	         					if(!s.type.equals("talk"))
	         						break;
	         					else {
	         						if(s.npcID == questNpcID) {
	         	                    	sendMessage(p, s.phrase);
	         							willChat = true;
	         							break;
	         						}
	         					}
	         					index--;
	         				}
	         			}
	         			break;
	         		}
	         	}
	         	if(!willChat && lines != null) {
	         		sendLines(p);
	         	}
				break;
			case DUNGEON:
	         	sendMessage(p, "Dungeon Name: " + dungeon);
	         	sendMessage(p, "Recommended Level: " + dungeonRecLevel);
	         	sendMessage(p, "Description: " + dungeonDescription);
	         	sendMessage(p, "Type \"enter\" to enter this dungeon! If you wish to challenge this dungeon as a party, your party leader must be the person to type \'enter\' and the rest of the party must be within 15 blocks of the leader.");
	         	plugin.getPD(p).waitingForDungeonEnter = true;
	         	plugin.getPD(p).dungeonToEnter = dungeon;
				break;
			case HARVESTING:
	         	HarvestingHandler.openInventory(p);
				break;
			case MERCHANT:
	             if(storeId > 0)
	              	openStore(p);
				break;
			case NONINTERACTIVE:
	              if(lines != null)
	          		sendLines(p);
				break;
			case STABLE:
	         	HorseHandler.openInventory(p);
				break;
			default:
				System.out.println("Error! Could not find villager type for " + entity.getCustomName() + ".");
				break;
		}
	}
	
	public void sendLines(Player p) {
		String lineToSend = lines.get((int)(Math.random() * lines.size()));
    	sendMessage(p, lineToSend);
	}
	
	public void sendMessage(Player p, String s) {
		p.sendMessage("");
    	p.sendMessage(entity.getCustomName() + ChatColor.WHITE + ": " + s);
	}
	
	public void openStore(Player p) {
		Store store = NPCHandler.stores.get(storeId);
		if(store != null) {
			Inventory s = store.store;
			if(s != null)
				p.openInventory(s);
		} else {
			System.out.println("COULD NOT FIND STORE ID " + storeId);
			System.out.println(NPCHandler.stores);
		}
	}
	
	public VillagerData(String name, Location loc, VillagerColor color) {
		this(name, loc, color.id);
	}
	
	public enum VillagerColor {
		BROWN(0),
		WHITE(1),
		PURPLE(2),
		BLACK_APRON(3),
		WHITE_APRON(4),
		GREEN(5);
		public int id;
		VillagerColor(int id) {
			this.id = id;
		}
	}
	
	public String toString() {
		return name;
	}
}