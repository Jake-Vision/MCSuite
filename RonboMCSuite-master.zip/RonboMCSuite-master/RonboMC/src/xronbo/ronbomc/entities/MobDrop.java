package xronbo.ronbomc.entities;

import java.util.ArrayList;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemHandler;

public class MobDrop {
	
	public int minAmount;
	public int maxAmount;
	public double chance;
	public ItemStack item;
	public boolean isEtc, isSpecial;
	
	public MobDrop(String itemStack, int minAmount, int maxAmount, int chance) {
		this.minAmount = minAmount;
		this.maxAmount = maxAmount;
		this.chance = chance / 100.0;
		this.item = getDrop(itemStack);
	}
	
	public static ItemStack getDrop(String s) {
		try {
			return ItemHandler.specialItems.get(Integer.parseInt(s)).generateItem();
		} catch(Exception e) {
			EtcItem ei = EtcItem.getEtcItem(s);
			if(ei != null) {
				if(ei.item == null) 
					ei.loadItem();
				return ei.item;
			}
			try {
				return new ItemStack(Material.getMaterial(s));
			} catch(Exception e2) {
				System.out.println("There is a problem with a mobdrop named " + s + "!");
				return null;
			}
		}
	}
	
	public ArrayList<ItemStack> createDrop() {
		ArrayList<ItemStack> list = new ArrayList<ItemStack>();
		int amount = (int)(Math.random() * (maxAmount - minAmount) + minAmount);
		while(amount > 0) {
			ItemStack i = item.clone();
			i.setAmount(amount > i.getMaxStackSize() ? i.getMaxStackSize() : amount);
			amount -= i.getAmount();
			list.add(i);
		}
		return list;
	}
	
	public boolean drop() {
		return Math.random() < chance;
	}
	
	public String toString() {
		return "Item: " + item.getType() + " [" + minAmount + "-" + maxAmount + "] Chance: " +  chance; 
	}
	
}