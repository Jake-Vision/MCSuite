package xronbo.ronbomc.entities.entityspells;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;
import xronbo.ronbomc.entities.MobData;

public class FreezeEntitySpell extends EntitySpell {

	public int durationSec;
	
	public FreezeEntitySpell(int durationSec) {
		message = new String[] {
				ChatColor.AQUA + "SLOW DOWN, SNAIL!!!",
		};
		this.durationSec = durationSec;
		cooldown = 20;
	}
	
	public void castSpell(MobData md, final Player p) {
		sendMessage(md, p);
		if(Math.random() < 0.5 && ClassHandler.getClassType(plugin.getPD(p).classType) == ClassType.BARBARIAN && ClassHandler.checkPassive("Willpower", plugin.getPD(p))) {
			p.sendMessage(ChatColor.GOLD + "ROARRRR!! You scream your defiance, and ignore the enemy's slow.");
		} else {
			p.addPotionEffect(PotionEffectType.SLOW.createEffect(durationSec * 20, 2));
		}
	}
	
}