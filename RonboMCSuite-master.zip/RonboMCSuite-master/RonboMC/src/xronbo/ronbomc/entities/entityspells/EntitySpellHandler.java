package xronbo.ronbomc.entities.entityspells;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.entity.LivingEntity;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;

public class EntitySpellHandler {
	
	public static Object[][] entityspells = new Object[][] {
		{"fireball", new FireballEntitySpell()},
		
		{"freeze", new FreezeEntitySpell(5)},
		{"freeze2", new FreezeEntitySpell(10)},
		{"freeze3", new FreezeEntitySpell(15)},
		
		{"smash", new SmashEntitySpell()},
		
		{"speed", new SpeedEntitySpell(1)},
		{"speed2", new SpeedEntitySpell(2)},
		{"speed3", new SpeedEntitySpell(3)},
		{"speed4", new SpeedEntitySpell(4)},
		{"speed5", new SpeedEntitySpell(5)},
		
		{"blink", new BlinkEntitySpell(1)},
		{"blink2", new BlinkEntitySpell(2)},
		{"blink3", new BlinkEntitySpell(3)},
		{"blink4", new BlinkEntitySpell(4)},
		{"blink5", new BlinkEntitySpell(5)},
	};

	public static class EntitySpellTask implements Runnable {
		public MobData md;
		public ArrayList<EntitySpellWrapper> spells;
		public void run() {
			if(md.entity == null || md.entity.isDead() || !md.entity.isValid() || md.dead || md.hp <= 0) {
				return;
			}
			spells.get(0).spell.castSpell(md);
			spells.get(0).cooldownticks = spells.get(0).spell.getCooldown();
			Collections.sort(spells);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, spells.get(0).cooldownticks + (int)(Math.random() * 3 - 1));
		}
		public void addSpell(EntitySpellWrapper spell) {
			spells.add(spell);
			Collections.sort(spells);
		}
		public EntitySpellTask(MobData md) {
			this.md = md;
			this.spells = new ArrayList<EntitySpellWrapper>();
		}
	}
	
	public static class EntitySpellWrapper implements Comparable<EntitySpellWrapper>{
		public EntitySpell spell;
		public int cooldownticks;
		public int compareTo(EntitySpellWrapper other) {
			return this.cooldownticks - other.cooldownticks;
		}
		public EntitySpellWrapper(EntitySpell spell, int cooldownticks) {
			this.spell = spell;
			this.cooldownticks = cooldownticks;
		}
	}
	
	public static HashMap<UUID, EntitySpellTask> spells = new HashMap<UUID, EntitySpellTask>();
	
	public static void giveSpell(MobData md, String spellName) {
		LivingEntity le = md.entity;
		EntitySpell spell = getSpell(spellName);
		EntitySpellWrapper wrapper = new EntitySpellWrapper(spell, spell.getCooldown());
		if(spells.containsKey(le.getUniqueId())) {
			spells.get(le.getUniqueId()).addSpell(wrapper);
		} else {
			EntitySpellTask est = new EntitySpellTask(md);
			est.addSpell(wrapper);
			SuperDebugger.scheduleSyncDelayedTask(EntitySpellHandler.class.getClass(), plugin, est, spell.getCooldown());
		}
	}
	
	public static EntitySpell getSpell(String s) {
		for(Object[] o : entityspells)
			if(((String)o[0]).equalsIgnoreCase(s))
				return (EntitySpell)(o[1]);
		return null;
	}
	
	public static RonboMC plugin;
	
	private EntitySpellHandler() {
		
	}
	
}