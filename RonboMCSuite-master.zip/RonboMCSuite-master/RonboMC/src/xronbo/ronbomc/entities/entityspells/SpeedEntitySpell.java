package xronbo.ronbomc.entities.entityspells;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;

public class SpeedEntitySpell extends EntitySpell {

	public int duration;
	public int amplifier;
	
	public SpeedEntitySpell(int tier) {
		message = new String[] {
				ChatColor.BLUE + "RUN, WEAKLING!",
		};
		this.cooldown = getInfo(tier)[0];
		this.duration = getInfo(tier)[1];
		this.amplifier = getInfo(tier)[2];
	}
	
	public int[] getInfo(int i) {
		switch(i) {
			case 1:
				return new int[] {30, 3, 1};
			case 2:
				return new int[] {20, 3, 1};
			case 3:
				return new int[] {15, 4, 2};
			case 4:
				return new int[] {10, 4, 2};
			case 5:
				return new int[] {7, 5, 2};
		}
		return new int[] {7, 5};
	}
	
	public void castSpell(final MobData md, final Player p) {
		sendMessage(md, p);
		md.entity.setVelocity(new Vector((int)(Math.random() * .5),1,(int)(Math.random() * .5)));
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(md.entity != null && md.entity.isValid() && !md.entity.isDead())
					md.entity.setVelocity(new Vector((int)(Math.random() * 2 - 1),0,(int)(Math.random() * 2 - 1)));
			}
		}, 20);
		md.entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * duration, amplifier, false));
	}
	
}