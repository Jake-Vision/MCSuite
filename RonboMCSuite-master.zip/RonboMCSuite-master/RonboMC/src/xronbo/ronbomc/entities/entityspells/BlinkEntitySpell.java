package xronbo.ronbomc.entities.entityspells;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.regions.RegionHandler;

public class BlinkEntitySpell extends EntitySpell {

	public int duration;
	public int amplifier;
	
	public BlinkEntitySpell(int tier) {
		message = new String[] {
				ChatColor.RED + "I'M COMING FOR YOU!!!",
		};
		this.cooldown = getCooldown(tier);
	}
	
	public int getCooldown(int tier) {
		switch(tier) {
			case 1:
				return 20;
			case 2:
				return 15;
			case 3:
				return 10;
			case 4:
				return 7;
			case 5:
				return 5;
		}
		return 5;
	}
	
	public void castSpell(final MobData md, final Player p) {
		sendMessage(md, p);
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(md.entity != null && md.entity.isValid() && !md.entity.isDead() && p != null && p.getLocation() != null && p.getLocation().getWorld().equals(md.entity.getWorld())) {
					if(!RegionHandler.getRegion(p.getLocation()).type.equals("secure"))
						md.entity.teleport(p.getLocation());
					md.entity.getLocation().getWorld().createExplosion(md.entity.getLocation().getX(),md.entity.getLocation().getY(),md.entity.getLocation().getZ(),2.0f,false,false);
				}
			}
		}, 40);
	}
	
}