package xronbo.ronbomc.entities.entityspells;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;

public class SmashEntitySpell extends EntitySpell {

	public SmashEntitySpell() {
		message = new String[] {
				ChatColor.GOLD + "FEAR ME!",
		};
		cooldown = 12;
	}
	
	public void castSpell(final MobData md, final Player p) {
		md.entity.setVelocity(md.entity.getVelocity().normalize().add(new Vector(0,1.0,0)));
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(md.entity == null || md.dead)
					return;
				Location loc = md.entity.getLocation();
				loc.getWorld().createExplosion(loc.getX(),loc.getY(),loc.getZ(),4.0f,false,false);
				for(Entity e : md.entity.getNearbyEntities(5, 5, 5)) {
					if(e instanceof Player) {
						sendMessage(md, (Player)e);
						int damage = Values.randInt(md.mobType.minDamage, md.mobType.maxDamage);
						damage *= 2;
						if(plugin.getPD((Player)e) != null && md.entity != null)
							plugin.getPD((Player)e).damage(damage, md.entity, true);
					}
				}
			}
		}, 15);
	}
	
}