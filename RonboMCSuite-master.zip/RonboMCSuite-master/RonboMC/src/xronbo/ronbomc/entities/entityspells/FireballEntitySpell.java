package xronbo.ronbomc.entities.entityspells;

import net.minecraft.server.v1_8_R1.EntityFireball;
import net.minecraft.server.v1_8_R1.EntityLiving;
import net.minecraft.server.v1_8_R1.EntitySmallFireball;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;

import xronbo.ronbomc.entities.MobData;


public class FireballEntitySpell extends EntitySpell {

	public FireballEntitySpell() {
		message = new String[] {
				ChatColor.RED + "FEEL THE FLAMES!!!",
		};
		cooldown = 15;
	}
	
	public void castSpell(MobData md, Player p) {
		sendMessage(md, p);
		for(int k = 0; k < 5; k++) {
			EntityLiving entityliving = (EntityLiving)((org.bukkit.craftbukkit.v1_8_R1.entity.CraftEntity)(p)).getHandle();
			EntityLiving thisEntity = (EntityLiving)((org.bukkit.craftbukkit.v1_8_R1.entity.CraftEntity)(md.entity)).getHandle();
	    	EntityFireball entity = null;
	    	double d0 = entityliving.locX - thisEntity.locX;
	     	double d1 = entityliving.getBoundingBox().b + entityliving.length / 2.0F - (thisEntity.locY + thisEntity.length / 2.0F);
	     	double d2 = entityliving.locZ - thisEntity.locZ;
			entity = new EntitySmallFireball(thisEntity.world, thisEntity, d0, d1, d2);
	        entity.locY = (thisEntity.locY + thisEntity.length / 2.0F + 0.5D);
			entity.getBukkitEntity().setMetadata("damageMultiplier", new FixedMetadataValue(plugin, 1.2));
	        thisEntity.world.addEntity(entity);
		}
	}
	
}