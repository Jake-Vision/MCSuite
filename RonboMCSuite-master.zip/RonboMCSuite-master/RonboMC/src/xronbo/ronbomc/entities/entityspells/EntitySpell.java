package xronbo.ronbomc.entities.entityspells;

import org.bukkit.craftbukkit.v1_8_R1.entity.CraftCreature;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftLivingEntity;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.entities.MobData;

public abstract class EntitySpell {

	public String[] message;
	public int cooldown;
	
	public void castSpell(MobData md) {
		spellTarget(md);
	}
	
	public void sendMessage(MobData md, Player p) {
		if(!plugin.getPD(p).options.checkOption("entityspell"))
			return;
		String name;
		if(md.entityName.indexOf(" [Lv.") != -1)
			name = md.entityName.substring(0, md.entityName.indexOf(" [Lv.")) + ": ";
		else
			name = "Enemy: ";
		String messageToSend = message[(int)(Math.random() * message.length)];
		p.sendMessage(name + messageToSend);
	}
	
	public int getCooldown() {
		return (int)((Math.random() * .4 + .8) * cooldown * 20);
	}

	public boolean sentError = false;
	
	public void spellTarget(MobData md) {
		try {
			CraftCreature entity = (CraftCreature) md.entity;
			CraftLivingEntity target = entity.getTarget();
			if(target instanceof CraftPlayer) {
				if(target.getLocation().distanceSquared(entity.getLocation()) < 15 * 15 * 7) {
					Player p = ((Player)target);
					castSpell(md, p);
				} else {
					target = null;
				}
			}
			if(target == null) {
				if(plugin.getServer().getPlayerExact(md.lastDamager) != null && md.entity.getLocation().distanceSquared(plugin.getServer().getPlayerExact(md.lastDamager).getLocation()) < 30 * 30 * 30) {
					castSpell(md, plugin.getServer().getPlayerExact(md.lastDamager));
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public abstract void castSpell(MobData md, Player p);
	
	public static RonboMC plugin;
	
	public EntitySpell() {
		
	}
	
}