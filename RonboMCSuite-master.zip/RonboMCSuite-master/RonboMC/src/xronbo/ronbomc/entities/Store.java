package xronbo.ronbomc.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemHandler;

public class Store {
	
	public int id;
	public HashMap<String, Integer> items;
	public Inventory store;
	public String name;
	
	public Store(int id, String name, HashMap<String, Integer> items) {
		this.id = id;
		this.name = name;
		this.items = items;
		createMenu();
	}
	
	public int getSize() {
		int i = items.size();
		return (int) (Math.ceil(i / 9.0)) * 9;
	}
	
	public void createMenu() {
		Inventory inventory = Bukkit.createInventory(null, getSize(), name);
		Iterator<String> i = items.keySet().iterator();
		int count = 0;
		while(i.hasNext()) {
			ItemStack item = null;
			String id = i.next();
			try {
				ItemHandler.specialItems.get(Integer.parseInt(id)).generateItem();
				item = ItemHandler.specialItems.get(Integer.parseInt(id)).getShopItem(items.get(id));
			} catch(Exception e) {
				EtcItem ei = EtcItem.getEtcItem(id);
				if(ei != null) {
					if(ei.item == null) 
						ei.loadItem();
					item = ei.makeItems(1)[0];
					ArrayList<String> lore = new ArrayList<String>();
					lore.addAll(item.getItemMeta().getLore());
					lore.add("");
					lore.add(ChatColor.GOLD + "Price: " + items.get(id) + "g");
					ItemMeta im = item.getItemMeta();
					im.setLore(lore);
					item.setItemMeta(im);
				}
			}
			inventory.setItem(count, item);
			count++;
		}
		store = inventory;
	}
	
	public String toString() {
		return "Store ID: " + id + "\n" + items;
	}
	
}