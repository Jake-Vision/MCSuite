package xronbo.ronbomc.entities;

import java.util.TreeMap;

import xronbo.ronbomc.RonboMC;

public class MobStats {

	public static RonboMC plugin;
	public static TreeMap<Integer, MobStat> mobstats = new TreeMap<Integer, MobStat>();
	
	public static final int[][] BASE_STATS = new int[][] {
		//maxHP, damage, exp
		{300, 20, 20}, //tier 1
		{5000, 100, 200}, //tier 2
		{30000, 500, 500}, //tier 3
		{200000, 2000, 4000}, //tier 4
		{3000000, 10000, 20000}, //tier 5
	};
	
	public static MobStat getMobStat(int i) {
		if(mobstats.containsKey(i))
			return mobstats.get(i);
		MobStat ms = new MobStat(i,0,0,0);
		int[] stats = BASE_STATS[getTier(i) - 1];
		double offset = getOffset(i);
		ms.maxHP = (long)(stats[0] * offset);
		ms.damage = (int)(stats[1] * offset);
		ms.exp = (int)(stats[2] * offset);
		ms.tier = getTier(i);
		mobstats.put(i, ms);
		return ms;
	}
	
	public static double getOffset(int i) {
		double levelDiff = 0;
		switch(getTier(i)) {
			case 1:
				levelDiff = i - 10;
				break;
			case 2:
				levelDiff = i - 35;
				break;
			case 3:
				levelDiff = i - 60;
				break;
			case 4:
				levelDiff = i - 85;
				break;
			case 5:
				levelDiff = i - 110;
				break;
		}
		if(levelDiff > 0)
			return 1 + 0.07 * levelDiff;
		else
			return 1 + (0.03 * levelDiff > -0.5 ? 0.03 * levelDiff : -0.5);
	}
	
	public static int getTier(int i) {
		if(i < 20)
			return 1;
		else if(i < 50)
			return 2;
		else if(i < 70)
			return 3;
		else if(i < 100)
			return 4;
		else
			return 5;
	}

	
	public static class MobStat implements Comparable<MobStat> {
		public int level;
		public long maxHP;
		public int damage;
		public int exp;
		public int tier;
		public MobStat(int a, long b, int c, int d) {
			level = a;
			maxHP = b;
			damage = c;
			exp = d;
			tier = getTier(level);
		}
		public String toString() {
			return level + ": " + maxHP + ", " + damage + ", " + exp;
		}
		public int compareTo(MobStat other) {
			return this.level - other.level;
		}
	}
	
	private MobStats() {
		 
	}

}
