package xronbo.ronbomc.entities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.UUID;

import net.minecraft.server.v1_8_R1.EntityLiving;

import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.craftbukkit.v1_8_R1.CraftWorld;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.entitytypes.CustomBlaze;
import xronbo.ronbomc.entities.entitytypes.CustomCaveSpider;
import xronbo.ronbomc.entities.entitytypes.CustomChicken;
import xronbo.ronbomc.entities.entitytypes.CustomCow;
import xronbo.ronbomc.entities.entitytypes.CustomIronGolem;
import xronbo.ronbomc.entities.entitytypes.CustomMagmaCube;
import xronbo.ronbomc.entities.entitytypes.CustomMushroomCow;
import xronbo.ronbomc.entities.entitytypes.CustomPig;
import xronbo.ronbomc.entities.entitytypes.CustomPigZombie;
import xronbo.ronbomc.entities.entitytypes.CustomSheep;
import xronbo.ronbomc.entities.entitytypes.CustomSilverfish;
import xronbo.ronbomc.entities.entitytypes.CustomSkeleton;
import xronbo.ronbomc.entities.entitytypes.CustomSlime;
import xronbo.ronbomc.entities.entitytypes.CustomSpider;
import xronbo.ronbomc.entities.entitytypes.CustomWolf;
import xronbo.ronbomc.entities.entitytypes.CustomZombie;
import xronbo.ronbomc.listeners.GeneralListeners.ChunkCoord;
import xronbo.ronbomc.regions.Cube;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;
import xronbo.ronbomc.regions.Spawn;

public class MobHandler {
	
	public static HashMap<Integer, MobType> mobTypes;
	public static HashMap<UUID, MobData> spawnedMobs;
	public static HashMap<UUID, Location> spawnedMobsOriginalLocations;
	
	public static RonboMC plugin;
	
	public static final double MOB_ROAM_BUFFER_ZONE = 75;
	
	public static void tick() {
		tick(false);
	}
	public static void tick(boolean forceTP) {
		for(World w : plugin.getServer().getWorlds()) {
			for(Entity e : w.getEntities()) {
				if(!(e instanceof LivingEntity) || e instanceof Player)
					continue;
				LivingEntity e2 = (LivingEntity)e;
				if(spawnedMobs.get(e.getUniqueId()) == null)
					continue;
				if(spawnedMobsOriginalLocations.containsKey(e.getUniqueId())) {
					if(RegionHandler.getRegion(e.getLocation()).type.equalsIgnoreCase("secure")) {
						e2.teleport(spawnedMobsOriginalLocations.get(e.getUniqueId()));
						if(e2 instanceof Creature)
							((Creature)e2).setTarget(null);
					}
				}
			}
		}
	}
	
	public static void generateMobList() {
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(plugin.getDataFolder() + File.separator + "moblist.txt"))));
			TreeMap<Integer, String> output = new TreeMap<Integer, String>();
			for(MobType mt : mobTypes.values())
				output.put(mt.id, mt.species + "\t Tier: " + mt.tier + "\t LV:" + mt.level + "\t HP: " + mt.hp + "\t EXP: " + mt.exp + "\t DMG: " + mt.minDamage + "-" + mt.maxDamage);
			for(Integer i : output.keySet())
				out.println(i + ": " + output.get(i));
			out.close();
			System.out.println("Updated moblist.txt");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Class<?> getType(String s) {
		switch(s.toLowerCase()) {
			case "chicken":
				return CustomChicken.class;
			case "skeleton":
				return CustomSkeleton.class;
			case "slime":
				return CustomSlime.class;
			case "zombie":
				return CustomZombie.class;
			case "cow":
				return CustomCow.class;
			case "spider":
				return CustomSpider.class;
			case "blaze":
				return CustomBlaze.class;
			case "irongolem":
			case "golem":
				return CustomIronGolem.class;
			case "cavespider":
				return CustomCaveSpider.class;
			case "magmacube":
				return CustomMagmaCube.class;
			case "pigzombie":
				return CustomPigZombie.class;
			case "wolf":
				return CustomWolf.class;
			case "silverfish":
				return CustomSilverfish.class;
			case "pig":
				return CustomPig.class;
			case "sheep":
				return CustomSheep.class;
			case "mushroomcow":
				return CustomMushroomCow.class;
		}
		return null;
	}
	
	public static void load() {
		mobTypes = new HashMap<Integer, MobType>();
		if(spawnedMobs == null)
			spawnedMobs = new HashMap<UUID, MobData>();
		if(spawnedMobsOriginalLocations == null)
			spawnedMobsOriginalLocations = new HashMap<UUID, Location>();
		try {
			String mobDataLoc = plugin.getDataFolder() + File.separator + "mobs.dat";
			Scanner scan = new Scanner(new File(mobDataLoc));
			String s = "";
			if(scan.hasNextLine())
				s = scan.nextLine();
			while(scan.hasNextLine()) {
				MobType mt = new MobType();
				try {
					mt.id = Integer.parseInt(s.split(" - ")[1].trim());
					s = scan.nextLine().trim();
					mt.species = s.substring("Species: ".length()).trim();
					s = scan.nextLine().trim();
					mt.typeName = s.substring("Type: ".length()).trim();
					mt.type = getType(mt.typeName);
					s = scan.nextLine().trim();
					mt.prefixes = s.substring("Prefixes: ".length()).trim().split(", ");
					s = scan.nextLine().trim();
					mt.suffixes = s.substring("Suffixes: ".length()).trim().split(", ");
					s = scan.nextLine().trim();
					mt.special = new ArrayList<String>();
					mt.special.addAll(Arrays.asList(s.substring("Special: ".length()).trim().split(", ")));
					s = scan.nextLine().trim();
					mt.level = Integer.parseInt(s.substring("Level: ".length()).trim());
					s = scan.nextLine().trim(); //placeholder armor line
					s = scan.nextLine().trim();
					while(s.startsWith("-")) {
						s = s.substring(1); //remove the -
						String[] data = s.split("=");
						switch(data[0].toLowerCase()) {
							case "weapon":
								mt.weapon = new ItemStack(Material.getMaterial(data[1]));
								break;
							case "chest":
								mt.chest = new ItemStack(Material.getMaterial(data[1]));
								break;
							case "legs":
								mt.legs = new ItemStack(Material.getMaterial(data[1]));
								break;
							case "boots":
								mt.boots = new ItemStack(Material.getMaterial(data[1]));
								break;
							case "helmet":
								mt.helmet = new ItemStack(Material.getMaterial(data[1]));
								break;
							case "head":
								mt.head = data[1];
								break;
						}
						s = scan.nextLine();
					}
					ArrayList<MobDrop> mds = new ArrayList<MobDrop>();
					if(scan.hasNextLine()) {
						s = scan.nextLine();
						while(s.startsWith("-")) {
							s = s.substring(1);
							String[] data = s.split(";");
							int min = Integer.parseInt(data[1].split("-")[0]);
							int max = Integer.parseInt(data[1].split("-")[1]);
							MobDrop md = new MobDrop(data[0], min, max, Integer.parseInt(data[2]));
							mds.add(md);
							if(scan.hasNextLine())
								s = scan.nextLine().trim();
							else
								s = "";
						}
					}
					if(scan.hasNextLine())
						s = scan.nextLine();
					mt.getStats();
					mt.drops = mds;
					mobTypes.put(mt.id, mt);
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("WARNING!!! MOBTYPE " + mt.id + " IS BROKEN.");
					System.out.println("Error on line: " + s + ".");
					while(!s.startsWith("ID"))
						if(scan.hasNextLine())
							s = scan.nextLine();
						else
							break;
					continue;
				}
			}
			scan.close();
			System.out.println("Loaded " + mobTypes.size() + " mobs.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static LivingEntity createLivingEntity(MobData md, Location loc) {
		MobType mt = md.mobType;
		net.minecraft.server.v1_8_R1.World world = ((CraftWorld)(loc.getWorld())).getHandle();
		net.minecraft.server.v1_8_R1.EntityLiving e = null;
		try {
			e = (EntityLiving) (mt.type.getDeclaredConstructor(net.minecraft.server.v1_8_R1.World.class).newInstance(world));
		} catch(Exception e2) {
			e2.printStackTrace();
		}
		
		switch(mt.typeName.toLowerCase()) {
			case "skeleton":
				if(mt.special.contains("wither"))
					((CustomSkeleton)e).makeWither();
				break;
			case "slime":
			case "magmacube":
				if(mt.special.contains("1"))
					((CustomSlime)e).setSize(1);
				else if(mt.special.contains("2"))
					((CustomSlime)e).setSize(2);
				else if(mt.special.contains("4"))
					((CustomSlime)e).setSize(4);
				else if(mt.special.contains("random12"))
					((CustomSlime)e).setSize(Math.random() < 0.5 ? 1 : 2);
				else if(mt.special.contains("random24"))
					((CustomSlime)e).setSize(Math.random() < 0.5 ? 2 : 4);
				else if(mt.special.contains("random124"))
					((CustomSlime)e).setSize(Math.random() < 0.33 ? 1 : Math.random() < 0.5 ? 2 : 4);
				break;
			case "chicken":
				if(mt.special.contains("aggressive"))
					((CustomChicken)e).makeAggressive();
				break;
			case "sheep":
				if(mt.special.contains("aggressive"))
					((CustomSheep)e).makeAggressive();
				break;
			case "pig":
				if(mt.special.contains("aggressive"))
					((CustomPig)e).makeAggressive();
				break;
			case "cow":
				if(mt.special.contains("aggressive"))
					((CustomCow)e).makeAggressive();
				break;
			case "mushroomcow":
				if(mt.special.contains("aggressive"))
					((CustomMushroomCow)e).makeAggressive();
				break;
			case "wolf":
				if(mt.special.contains("angry"))
					((CustomWolf)e).makeRedEyes(true);
				else
					((CustomWolf)e).makeRedEyes(false);
			default:
				break;
		}
		e.setPositionRotation(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
		world.addEntity(e, SpawnReason.CUSTOM);
		LivingEntity le = (LivingEntity)(((net.minecraft.server.v1_8_R1.Entity)e).getBukkitEntity());

		if(mt.special.contains("enchanted")) {
			LivingEntity bukkitEntity = (LivingEntity) e.getBukkitEntity();
			EntityEquipment equips = bukkitEntity.getEquipment();
			ItemStack item = equips.getHelmet();
			try {
				if(item != null && item.getType() != Material.AIR) {
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 1);
					equips.setHelmet(item);
				}
			} catch(Exception exception) {
				exception.printStackTrace();
			}
			item = equips.getChestplate();
			try {
				if(item != null && item.getType() != Material.AIR) {
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 1);
					equips.setChestplate(item);
				}
			} catch(Exception exception) {
				exception.printStackTrace();
			}
			item = equips.getLeggings();
			try {
				if(item != null && item.getType() != Material.AIR) {
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 1);
					equips.setLeggings(item);
				}
			} catch(Exception exception) {
				exception.printStackTrace();
			}
			item = equips.getBoots();
			try {
				if(item != null && item.getType() != Material.AIR) {
					item.addUnsafeEnchantment(Enchantment.PROTECTION_FALL, 1);
					equips.setBoots(item);
				}
			} catch(Exception exception) {
				exception.printStackTrace();
			}
			item = equips.getItemInHand();
			try {
				if(item != null && item.getType() != Material.AIR) {
					item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
					equips.setItemInHand(item);
				}
			} catch(Exception exception) {
				exception.printStackTrace();
			}
		}
		return le;
	}
	
	public static MobData createMob(int i, Location loc, Region r) {
		MobType mt = mobTypes.get(i);
		return createMob(mt, loc, r);
	}
	
	public static MobData createMob(MobType mt, Location loc, Region r) {
		return createMob(mt,loc,r,"");
	}

	public static HashMap<ChunkCoord, ArrayList<MobData>> dungeonMobs = new HashMap<ChunkCoord, ArrayList<MobData>>();
	
	public static MobData createDungeonMob(int id, Location loc, Region r) {
		MobData md = new MobData(mobTypes.get(id));
		md.despawnedLoc = loc;
		md.region = r;
		md.firstSpawn = true;
		md.spawnedFor = "";
		Chunk chunk = loc.getChunk();
		ChunkCoord cc = new ChunkCoord(chunk);
		md.lastChunk = cc;
		if(dungeonMobs.containsKey(cc)) {
			dungeonMobs.get(cc).add(md);
		} else {
			ArrayList<MobData> list = new ArrayList<MobData>();
			list.add(md);
			dungeonMobs.put(cc, list);
		}
		return md;
	}
	
	public static MobData createMob(MobType mt, Location loc, Region r, String spawnedFor) {
		MobData md = new MobData(mt);
		md.despawnedLoc = loc;
		md.region = r;
		md.firstSpawn = true;
		md.spawnedFor = spawnedFor;
		Chunk chunk = loc.getChunk();
		ChunkCoord cc = new ChunkCoord(chunk);
		md.lastChunk = cc;
		md.newEntity();
		return md;
	}
	
	public static boolean isGroundMaterial(Material m) {
		switch(m.getId()) {
			case 1: //stone
			case 2: //grass block
			case 3: //dirt
			case 7: //bedrock
			case 12: //sand
			case 13: //gravel
			case 79: //ice
			case 80: //snow block
			case 82: //clay block
			case 110: //mycelium
			case 159: //stained clay
			case 162: //stained clay
			case 172: //hardened clay
			case 174: //packed ice
			case 60: //farmland
				return true;
			default:
				return false;
		}
	}
	
	public static boolean isAirlike(Material m) {
		switch(m.getId()) {
			case 0: //air
			case 78: //snow layer
			case 51: //fire
			case 50: //torch
			case 59: //wheat
			case 39: //mushroom
			case 40: //mushroom
			case 55: //redstone wire
			case 70: //stone pressure
			case 72: //wood pressure
			case 106: //vines
			case 141: //carrots
			case 142: //potatoes
			case 175: //flowers
			case 31: //grasses
			case 32: //dead shrub
				return true;
			default:
				return false;
		}
	}
	
	public static class LocCoord {
		public int x,y,z,min;
		public LocCoord(int x, int y, int z, int min) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.min = min;
		}
		public String toString() {
			return x + "," + y + "," + z;
		}
	}
	
	public static class LocationFinder implements Runnable {
		public void run() {
			ArrayList<ChunkSnapshot> temp = new ArrayList<ChunkSnapshot>(list);
			boolean foundLoc = false;
			while(temp.size() > 0 && !foundLoc) {
				final ChunkSnapshot cs = temp.remove((int)(Math.random() * temp.size()));
				int x_min = 0 + cs.getX()*16;
				int x_max = 15 + cs.getX() * 16;
				int z_min = 0 + cs.getZ()*16;
				int z_max = 15 + cs.getZ() * 16;
				int csx = cs.getX();
				int csz = cs.getZ();
				ArrayList<LocCoord> locCoords = new ArrayList<LocCoord>();
				for(int x = x_min; x <= x_max; x++) {
					for(int z = z_min; z <= z_max; z++) {
						ArrayList<Cube> cubes = RegionHandler.checkRegionXZ(r, x, z);
						if(cubes.size() == 0)
							continue;
						int x_chunk = (int)x - csx * 16;
						int z_chunk = (int)z - csz * 16;
						int y = cs.getHighestBlockYAt(x_chunk, z_chunk);
						double highestCubeY = -1;
						double lowestCubeY = Double.MAX_VALUE;
						for(Cube c : cubes) {
							if(c.y2 > highestCubeY)
								highestCubeY = c.y2;
							if(c.y1 < lowestCubeY)
								lowestCubeY = c.y1;
						}
						if(highestCubeY < y)
							y = (int)highestCubeY + 3;
						locCoords.add(new LocCoord(x,y,z, (int)lowestCubeY));
					}
				}
				Collections.shuffle(locCoords);
				for(LocCoord lc : locCoords) {
					int x_world = lc.x;
					int y_world = lc.y;
					int z_world = lc.z;
					int x_chunk = (int)x_world - csx * 16;
					int z_chunk = (int)z_world - csz * 16;
					while(!foundLoc && y_world >= 0) {
						try {
							 Material m = Material.getMaterial(cs.getBlockTypeId(x_chunk, y_world, z_chunk));
								Material m_above = Material.getMaterial(cs.getBlockTypeId(x_chunk, y_world + 1, z_chunk));
								Material m_2above = Material.getMaterial(cs.getBlockTypeId(x_chunk, y_world + 2, z_chunk));
								if(y_world <= lc.min && isAirlike(Material.getMaterial(cs.getBlockTypeId(x_chunk, y_world, z_chunk)))
										&& isAirlike(Material.getMaterial(cs.getBlockTypeId(x_chunk, y_world + 1, z_chunk)))) {
									foundLoc = true;
									break;
								}
								if(isGroundMaterial(m) && isAirlike(m_above) && isAirlike(m_2above)) {
									y_world++;
									if(RegionHandler.checkRegion(r, x_world, y_world, z_world, cs.getWorldName())) {
										foundLoc = true;
										break;
									}
									y_world--;
								}
						} catch(Exception e) {
							
						}
						y_world--;
					}
					if(foundLoc) {
						final int x1 = x_world, y1 = y_world, z1 = z_world;
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								final String worldName = cs.getWorldName();
								final Location loc = new Location(plugin.getServer().getWorld(worldName), x1, y1, z1);
								if(RegionHandler.getRegion(loc).type.equals("secure")) {
									spawn.available++;
									if(plugin.getPD(spawnedFor) != null)
										plugin.getPD(spawnedFor).mobsQueuedOrSpawnedForPlayer--;
								} else {
									totalAutoSpawned++;
									SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
										public void run() {
											loc.setX(loc.getX() + 0.5);
											loc.setY(loc.getY() + 0.75);
											loc.setZ(loc.getZ() + 0.5);
											MobData md = createMob(mt, loc, r, spawnedFor);
											try {
												plugin.getPD(spawnedFor).mobsSpawnedForPlayer.add(md);
											} catch(Exception e) {
												
											}
										}
									}, (int)(Math.random() * 3 + 1));
								}
							}
						}, 1);
						break;
					}
				}
			}
			if(--remaining > 0) {
				SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, this);
			}
		}
		
		public ArrayList<ChunkSnapshot> list;
		public MobType mt;
		public Region r;
		public Spawn spawn;
		public int remaining;
		public String spawnedFor;
		public LocationFinder(ArrayList<ChunkSnapshot> list, Region r, MobType mt, Spawn spawn, int toSpawn, String spawnedFor) {
			this.list = list;
			this.mt = mt;
			this.r = r;
			this.spawn = spawn;
			this.remaining = toSpawn;
			this.spawnedFor = spawnedFor;
		}
	}
	
	public static int getMaxMobs(Player p) {
		if(plugin.getPD(p).inSpawnRegion)
			return Values.MAX_NEARBY_MOBS;
		else
			return Values.MOBS_PER_PLAYER;
	}
	
	public static class PlayerMobSpawner implements Runnable {
		public void run() {
			if(p == null || plugin.getPD(p) == null || !p.isOnline())
				return;
			if(plugin.getPD(p).mobsQueuedOrSpawnedForPlayer >= getMaxMobs(p)) {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 20*5);
				return;
			}
			/*
			 * Get all possible spawns for the player
			 */
			ArrayList<Region> regions = RegionHandler.getNearbyRegions(p.getLocation());
			ArrayList<Spawn> spawns = new ArrayList<Spawn>();
			ArrayList<Region> retainedRegions = new ArrayList<Region>();
			for(Region r : regions)
				if(r.restrictive)
					retainedRegions.add(r);
			if(retainedRegions.size() > 0) {
				regions.retainAll(retainedRegions);
				plugin.getPD(p).inSpawnRegion = true;
			} else {
				plugin.getPD(p).inSpawnRegion = false;
			}
			for(Region r : regions)
				spawns.addAll(r.spawns);
			ArrayList<Spawn> toRetain = new ArrayList<Spawn>();
			ArrayList<Integer> toRetainIds = new ArrayList<Integer>();
			for(Spawn s : spawns) {
				if(s.region.restrictive) {
					toRetain.add(s);
					toRetainIds.add(s.id);
				}
			}
			if(toRetain.size() > 0) {
				spawns.retainAll(toRetain);
				for(MobData md : new ArrayList<MobData>(plugin.getPD(p).mobsSpawnedForPlayer)) {
					if(!toRetainIds.contains(md.mobType.id))
						md.findNewOwner();
				}
			}
			/*
			 * Get the chunks near the player
			 */
			ArrayList<ChunkSnapshot> possibleChunks = new ArrayList<ChunkSnapshot>();
			Chunk playerChunk = p.getLocation().getChunk();
			for(int dx = -Values.CHUNK_RANGE_TO_SPAWN; dx <= Values.CHUNK_RANGE_TO_SPAWN; dx++) {
				for(int dz = -Values.CHUNK_RANGE_TO_SPAWN; dz <= Values.CHUNK_RANGE_TO_SPAWN; dz++) {
					Chunk chunk = p.getLocation().getWorld().getChunkAt(playerChunk.getX() + dx, playerChunk.getZ() + dz);
					possibleChunks.add(chunk.getChunkSnapshot(true,false,false));
				}
			}
			/*
			 * Check the total number of mobs available to be spawned
			 */
			int totalAvailable = 0;
			Collections.shuffle(spawns);
			for(Spawn s : spawns) {
				totalAvailable += s.available;
			}
			/*
			 * Determine how many to spawn
			 */
			int toSpawn = getMaxMobs(p) < totalAvailable ? Values.MOBS_PER_PLAYER : totalAvailable;
			toSpawn = toSpawn + plugin.getPD(p).mobsQueuedOrSpawnedForPlayer <= getMaxMobs(p) ? toSpawn : getMaxMobs(p) - plugin.getPD(p).mobsQueuedOrSpawnedForPlayer;
			int nearbyEntities = 0;
			for(Entity e : p.getNearbyEntities(Values.CHUNK_RANGE_TO_SPAWN * 16, Values.CHUNK_RANGE_TO_SPAWN * 16, Values.CHUNK_RANGE_TO_SPAWN * 16)) {
				if(e instanceof LivingEntity && !(e instanceof Villager || e instanceof Player)) {
					nearbyEntities++;
				}
			}
			if(nearbyEntities + toSpawn > Values.MAX_NEARBY_MOBS) {
				toSpawn = Values.MAX_NEARBY_MOBS - nearbyEntities;
				if(toSpawn < 0)
					toSpawn = 0;
			}
			/*
			 * Make a list of the mobs to spawn
			 */
			HashMap<Spawn, Integer> mobsToSpawn = new HashMap<Spawn, Integer>();
			int numSpawned = 0;
			while(numSpawned < toSpawn) {
				boolean oneAvailable = false;
				for(Spawn s : spawns) {
					if(s.available > 0) {
						oneAvailable = true;
						s.available--;
						numSpawned++;
						if(mobsToSpawn.containsKey(s)) {
							mobsToSpawn.put(s, mobsToSpawn.get(s) + 1);
						} else {
							mobsToSpawn.put(s, 1);
						}
					}
					if(numSpawned >= toSpawn)
						break;
				}
				if(!oneAvailable) {
					toSpawn = numSpawned;
					break;
				}
			}
			plugin.getPD(p).mobsQueuedOrSpawnedForPlayer += toSpawn;
			/*
			 * Spawn each mob that is queued to spawn
			 */
			for(Spawn spawn : mobsToSpawn.keySet()) {
				MobType mt = mobTypes.get(spawn.id);
				SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new LocationFinder(possibleChunks, spawn.region, mt, spawn, mobsToSpawn.get(spawn), p.getName()));
			}
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 20*5);
		}
		public Player p;
		public PlayerMobSpawner(Player p) {
			this.p = p;
		}
	}
	
	public static int totalAutoSpawned = 0;

	private MobHandler() {

	}
	
}