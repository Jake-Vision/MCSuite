package xronbo.ronbomc.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.Dungeon;
import xronbo.ronbomc.entities.entityspells.EntitySpellHandler;
import xronbo.ronbomc.entities.entitytypes.CustomSkeleton;
import xronbo.ronbomc.entities.entitytypes.CustomZombie;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.listeners.GeneralListeners.ChunkCoord;
import xronbo.ronbomc.quests.Quest;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.Spawn;

public class MobData {
	
	public static int ID = 0;
	
	public static RonboMC plugin;
	
	public int myID = ++ID;
	public LivingEntity entity;
	public MobType mobType;
	
	public Region region;
	
	public String prefix = "";
	public String suffix = "";
	public long hp;
	
	public boolean isDungeonBoss;
	public boolean isDungeonMob;
	public Dungeon dungeon;
	public String dungeonFullName;
	
	public boolean firstSpawn;

	public String spawnedFor;
	
	public Location despawnedLoc;
	
	public ChunkCoord lastChunk;
	
	public HashMap<String, Integer> damagedBy = new HashMap<String, Integer>();
	
	public String toString() {
		return mobType.species + " ID: " + myID;
	}
	
	public MobData(MobType mt) {
		mobType = mt;
		hp = mt.hp;
	}
	
	public void newEntity() {
		entity = MobHandler.createLivingEntity(this, despawnedLoc);
		for(String s : mobType.special) {
			if(s.startsWith("spell_")) {
				EntitySpellHandler.giveSpell(this, s.substring("spell_".length()));
			}
		}
		entity.setRemoveWhenFarAway(false);
		updateName();
		checkItems();
		setAttribute();
		MobHandler.spawnedMobs.put(entity.getUniqueId(), this);
		if(((CraftEntity)entity).getHandle() instanceof CustomSkeleton) {
			((CustomSkeleton)((CraftEntity)entity).getHandle()).setFightStyle();
		} else if(((CraftEntity)entity).getHandle() instanceof CustomZombie)
			((CustomZombie)((CraftEntity)entity).getHandle()).setFightStyle();
		if(firstSpawn) {
			MobHandler.spawnedMobsOriginalLocations.put(entity.getUniqueId(), despawnedLoc);
			firstSpawn = false;
		}
		lastAttack = System.currentTimeMillis();
	}
	
	public void setAttribute() {
		prefix = mobType.prefixes[(int)(Math.random() * mobType.prefixes.length)];
		if(prefix.equalsIgnoreCase("none"))
			prefix = "";
		suffix = mobType.suffixes[(int)(Math.random() * mobType.suffixes.length)];
		if(suffix.equalsIgnoreCase("none"))
			suffix = "";
		updateName();
	}
	
	public void checkItems() {
		if(mobType.weapon != null)
			setWeapon(mobType.weapon);
		if(mobType.chest != null)
			setChest(mobType.chest);
		if(mobType.legs != null)
			setLegs(mobType.legs);
		if(mobType.boots != null)
			setBoots(mobType.boots);
		if(mobType.helmet != null)
			setHelmet(mobType.helmet);
		if(!(mobType.head.equals("")))
			setHead(mobType.head);
	}

	public ArrayList<ItemStack> generateDrops() {
		ArrayList<ItemStack> drops = new ArrayList<ItemStack>();
		for(MobDrop md : mobType.drops) {
			if(md.drop())
				drops.addAll(md.createDrop());
		}
		return drops;
	}
	
	public String entityName = "";
	public void updateName() {
		entityName = getTierColor() + prefix + (prefix != "" ? " " : "") + mobType.species + (suffix != "" ? " " : "") + suffix + " [Lv. " + mobType.level + "]";
		entity.setCustomName(entityName);
		entity.setCustomNameVisible(true);
		if(isDungeonBoss)
			entity.setCustomName(entity.getCustomName() + ChatColor.RED + " [BOSS]");
	}

	public long lastSetDamaged = 0;
	public void setDamagedName() {
		entity.setCustomName(getDamagedName());
		lastSetDamaged = System.nanoTime();
		final long lastDamaged = lastSetDamaged;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(lastDamaged == lastSetDamaged) {
					if(entity != null && !entity.isDead())
						updateName();
				}
			}
		}, 40);
	}
	
	public String getDamagedName() {
		long currentHP = hp;
		long maxHP = mobType.hp;
		if(currentHP <= 0) {
			return ChatColor.GOLD + "+" + mobType.exp + " EXP";
		}
		StringBuilder sb = new StringBuilder(ChatColor.WHITE + "[");
		for(int k = 0; k < ((int)(currentHP*15.0/maxHP) == 0 ? (currentHP > 0 ? 1 : 0) : (int)(currentHP*15.0/maxHP)); k++)
			sb.append(ChatColor.GREEN + "|");
		while(ChatColor.stripColor(sb.toString()).length() < 16) {
			sb.append(ChatColor.DARK_RED + "|");
		}
		sb.append(ChatColor.WHITE + "]");
		return sb.toString();
	}
	
	public ChatColor getTierColor() {
		if(mobType.special.contains("boss"))
			return ChatColor.GOLD;
		switch(mobType.tier) {
			case 1:
				return ChatColor.WHITE;
			case 2:
				return ChatColor.AQUA;
			case 3:
				return ChatColor.DARK_GREEN;
			case 4:
				return ChatColor.LIGHT_PURPLE;
			case 5:
				return ChatColor.DARK_RED;
			default:
				return ChatColor.WHITE;
		}
	}
	
	public HashMap<UUID, Long> noDamageTicks = new HashMap<UUID, Long>();
	public boolean dead = false;
	public long lastAttack = 0;
	public boolean killed = false;
	public String lastDamager = "";

	public boolean damage(int i, Player p, boolean isSpell) {
		return damage(i,p,isSpell,1);
	}
	
	public HashMap<String, Integer> attackers = new HashMap<String, Integer>();
	public static final int MAX_CONSECUTIVE = 7;
	
	public boolean damage(int i, Player p, boolean isSpell, double knockback) {
		if(dead)
			return false;
		if(!isSpell) {
			if(noDamageTicks.containsKey(p.getUniqueId()) && noDamageTicks.get(p.getUniqueId()) > System.nanoTime()) {
				return false;
			}
		}
		if(attackers.containsKey(p.getName())) 
			attackers.put(p.getName(), attackers.get(p.getName()) + 1);
		else
			attackers.put(p.getName(), 1);
		if(attackers.get(p.getName()) > MAX_CONSECUTIVE) {
			entity.teleport(p.getLocation().add(0,1,0));
			attackers.clear();
		}
		lastAttack = System.currentTimeMillis();
		SoundHandler.playSound(p, Sound.HURT_FLESH);
		if(!isSpell)
			noDamageTicks.put(p.getUniqueId(), System.nanoTime() + 500000000);
		PlayerData pd = plugin.getPD(p);
		int levelDiff = pd.level - mobType.level;
		double levelMultiplier = 1;
		if(levelDiff < 0)
			levelMultiplier = 1 + levelDiff * 0.04;
		if(levelMultiplier < 0.1)
			levelMultiplier = 0.1;
		i *= levelMultiplier;
		if(i < 1)
			i = 1;
		if(CombatHandler.enqueuedMessages.get(p.getUniqueId()) != null)
			for(String s : CombatHandler.enqueuedMessages.get(p.getUniqueId()))
				plugin.db(p, s);
		if(Math.random() * 100.0 < (pd.critChance + pd.critChance_temp)) {
			plugin.db(p, "CRIT - [" + i + " -> " + (int)(i * pd.critDamage_temp / 100.0) + "]");
			i *= pd.critDamage_temp / 100.0;
			plugin.db(p, ChatColor.RED + "" + ChatColor.BOLD + "Critical hit!");
		}
		if(mobType.damageReduction > 0) {
			plugin.db(p, ChatColor.DARK_RED + "" + mobType.damageReduction + "% DR; DMG: " + i + " -> " + (int)(i - i * mobType.damageReduction / 100.0));
			i -= i * mobType.damageReduction / 100.0;
		}
		if(pd.lifesteal_temp > 0)
			pd.heal((int)(Math.ceil(i * (pd.lifesteal_temp) / 100.0)));
		plugin.db(p, ChatColor.AQUA + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.AQUA + "(" + ChatColor.stripColor(entityName.substring(0, entityName.indexOf(" [Lv"))) + ")" + ChatColor.YELLOW + " [" + hp + " -> " + (hp - i > 0 ? hp - i : 0) + "]");
		hp -= i;
		if(damagedBy.containsKey(p.getName())) {
			damagedBy.put(p.getName(), damagedBy.remove(p.getName()) + i);
		} else {
			damagedBy.put(p.getName(), i);
		}
		lastDamager = p.getName();
		if(hp <= 0) {
			hp = 0;
			double total = 0;
			for(Integer damage : damagedBy.values())
				total += damage;
			for(String s : damagedBy.keySet())
				if(plugin.getPD(s) != null) {
					plugin.getPD(s).addExp((int)(mobType.exp * (damagedBy.get(s) / total)));
					plugin.getPD(s).mobKills++;
					if(plugin.getPD(s).mobKills % 100 == 0)
						plugin.getPD(s).addGuildPoints(20);
					plugin.getPD(s).wallet += Values.randInt(getGoldDrop(mobType.tier)[0], getGoldDrop(mobType.tier)[1]) * (damagedBy.get(s) / total);
				}
			kill();
			if(killed && !dead)
				die();
			killed = true;
		}
		entity.playEffect(EntityEffect.HURT);
		if(p instanceof Entity) {
			Entity attacker = (Entity)p;
			Entity attacked = entity;
			attacked.setVelocity(attacked.getLocation().toVector().subtract(attacker.getLocation().toVector()).normalize().multiply(knockback));
		}
		setDamagedName();
		return true;
	}
	
	public static int[] getGoldDrop(int tier) {
		switch(tier) {
			case 1:
				return new int[]{1,10};
			case 2:
				return new int[]{10,50};
			case 3:
				return new int[]{50,100};
			case 4:
				return new int[]{100,200};
			case 5:
				return new int[]{500,2000};
		}
		return null;
	}

	public void kill() {
		if(!isDungeonMob) {
			try {
				ArrayList<ItemStack> drops = getDrops();
				for(ItemStack i : drops) {
					try {
						entity.getWorld().dropItemNaturally(entity.getLocation(), i);
					} catch(Exception e) {
						
					}
				}
			} catch(Exception e) {
				die();
			}
		}
		if(isDungeonBoss) {
			Dungeon d = dungeon;
			org.bukkit.World w = entity.getLocation().getWorld();
			for(Player p : w.getPlayers()) {
				d.complete(p);
			}
		}
		die();
	}
	
	public void die() {
		die(false);
	}
	
	public void die(boolean alreadyDecrementedForPlayer) {
		try {
			entity.playEffect(EntityEffect.DEATH);
			MobHandler.spawnedMobs.remove(entity.getUniqueId());
		} catch(Exception e) {
			
		}
		if(dead)
			return;
		dead = true;
		for(Spawn s : region.spawns) {
			if(s.id == mobType.id) {
				s.available++;
				break;
			}
		}
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				try {
					entity.remove();
				} catch(Exception e) {
					
				}
			}
		}, 10);
		if(!alreadyDecrementedForPlayer) {
			try {
				plugin.getPD(spawnedFor).mobsQueuedOrSpawnedForPlayer--;
				plugin.getPD(spawnedFor).mobsSpawnedForPlayer.remove(this);
			} catch(Exception e) {
				
			}
		}
	}
	
	public void findNewOwner() {
		if(entity.isDead() || entity == null || !entity.isValid()) {
			plugin.getPD(spawnedFor).mobsSpawnedForPlayer.remove(this);
			return;
		}
		try {
			plugin.getPD(spawnedFor).mobsQueuedOrSpawnedForPlayer--;
			plugin.getPD(spawnedFor).mobsSpawnedForPlayer.remove(this);
		} catch(Exception e) {
			
		}
		if(System.currentTimeMillis() - lastAttack > 20*1000) {
			die(true);
			return;
		}
		int leastAssigned = Integer.MAX_VALUE;
		PlayerData pd = null;
		for(Entity e : entity.getNearbyEntities(32,32,32)) {
			if(e instanceof Player) {
				PlayerData pd2 = plugin.getPD(((Player) e).getName());
				if(pd2 == null)
					continue;
				if(pd2.mobsQueuedOrSpawnedForPlayer < leastAssigned) {
					leastAssigned = pd2.mobsQueuedOrSpawnedForPlayer;
					pd = pd2;
				}
			}
		}
		if(pd == null || pd.player.getName().equals(spawnedFor)) {
			die(true);
			return;
		}
		if(leastAssigned >= 10) {
			for(int k = 0; k < pd.mobsSpawnedForPlayer.size(); k++) {
				if(System.currentTimeMillis() - pd.mobsSpawnedForPlayer.get(k).lastAttack > 20*1000) {
					pd.mobsSpawnedForPlayer.remove(k--);
					pd.mobsQueuedOrSpawnedForPlayer--;
				}
			}
		}
		if(pd.mobsQueuedOrSpawnedForPlayer >= 10) {
			die(true);
			return;
		}
		spawnedFor = pd.player.getName();
		pd.mobsQueuedOrSpawnedForPlayer++;
		pd.mobsSpawnedForPlayer.add(this);
	}
	
	public ArrayList<ItemStack> getDrops() {
		ArrayList<ItemStack> drops = new ArrayList<ItemStack>();
		if(MobHandler.spawnedMobs.get(entity.getUniqueId()) != null) {
			drops.addAll(ItemHandler.generateDrops(entity));
			drops.addAll(generateDrops());
			Player killer = null;
			int mostDamageDealt = 0;
			for(String s : damagedBy.keySet()) {
				Player p = plugin.getServer().getPlayer(s);
				if(p != null && damagedBy.get(s) > mostDamageDealt) {
					mostDamageDealt = damagedBy.get(s);
					killer = p;
				}
			}
			if(killer != null) {
				PlayerData pd = plugin.getPD(killer);
				Iterator<String> iterator = pd.mobKillTracker.keySet().iterator();
				while(iterator.hasNext()) {
					String nextTrack = iterator.next();
					if(nextTrack.replaceAll("-", " ").equalsIgnoreCase(mobType.species)) {
						for(Quest q : pd.mobKillTracker.get(nextTrack).keySet()) {
							pd.mobKillTracker.get(nextTrack).put(q, pd.mobKillTracker.get(nextTrack).remove(q) + 1);
							pd.player.sendMessage("You have now killed " + pd.mobKillTracker.get(nextTrack).get(q) + " " + mobType.species + " for " + q.name + ".");
							if(pd.mobKillTracker.get(nextTrack).get(q) >= q.stages.get(pd.inProgressQuests.get(q)).count)
								pd.player.sendMessage("You have completed the required number of " + mobType.species + " kills for " + q.name + ".");
						}
						break;
					}
				}
				if(ClassHandler.getClassType(pd.classType) == ClassType.ASSASSIN) {
					int tier = mobType.tier;
					if(ClassHandler.checkPassive("Loot Finder", pd)) {
						if(tier >= 1 && Math.random() < 0.02) {
							plugin.db(pd.player, "Found an extra equip with Loot Finder!");
							drops.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), 2));
						}
					}
					if(ClassHandler.checkPassive("Plunderer", pd)) {
						if(tier >= 2 && Math.random() < 0.05) {
							plugin.db(pd.player, "Found an extra equip with Plunderer!");
							drops.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), 2));
						}
					}
					if(ClassHandler.checkPassive("Treasure Hunter", pd)) {
						if(tier >= 3 && Math.random() < 0.001) {
							plugin.db(pd.player, "Found an extra equip with Treasure Hunter!");
							drops.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), 3));
						}
					}
					if(ClassHandler.checkPassive("Bonanza", pd)) {
						if(tier >= 4 && Math.random() < 0.003) {
							plugin.db(pd.player, "Found an extra equip with Bonanza!");
							drops.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), 3));
						}
					}
					if(ClassHandler.checkPassive("Legendary Looter", pd)) {
						if(tier >= 5 && Math.random() < 0.001) {
							plugin.db(pd.player, "Found an extra equip with Legendary Looter!");
							drops.add(ItemHandler.createEquip(ItemHandler.getRandomEquip(), 4));
						}
					}
					if(ClassHandler.checkPassive("Hunter", pd)) {
						int i = (int)(0.03 * (pd.maxHP + pd.maxHP_temp));
						plugin.db(pd.player, "Hunter healed for " + i + " HP");
						pd.heal(i);
					}
					if(ClassHandler.checkPassive("Slayer", pd)) {
						int i = (int)(0.10 * (pd.maxHP + pd.maxHP_temp));
						plugin.db(pd.player, "Slayer healed for " + i + " HP");
						pd.heal(i);
					}
					if(ClassHandler.checkPassive("Terminator", pd)) {
						int i = (int)(0.20 * (pd.maxHP + pd.maxHP_temp));
						plugin.db(pd.player, "Terminator healed for " + i + " HP");
						pd.heal(i);
					}
				}
			}
		}
		return drops;
	}
	
	public void setWeapon(ItemStack i) {
		EntityEquipment e = entity.getEquipment();
		e.setItemInHand(i);
		e.setItemInHandDropChance(0);
	}
	
	public void setChest(ItemStack i) {
		EntityEquipment e = entity.getEquipment();
		e.setChestplate(i);
		e.setChestplateDropChance(0);
	}
	
	public void setLegs(ItemStack i) {
		EntityEquipment e = entity.getEquipment();
		e.setLeggings(i);
		e.setLeggingsDropChance(0);
	}
	
	public void setBoots(ItemStack i) {
		EntityEquipment e = entity.getEquipment();
		e.setBoots(i);
		e.setBootsDropChance(0);
	}
	
	public void setHead(String s) {
		ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (short)(SkullType.PLAYER.ordinal()));
		SkullMeta sm = (SkullMeta)(head.getItemMeta());
		sm.setOwner(s);
		head.setItemMeta(sm);
		setHelmet(head);
	}
	
	public void setHelmet(ItemStack i) {
		EntityEquipment e = entity.getEquipment();
		e.setHelmet(i);
		e.setHelmetDropChance(0);
	}
	
}