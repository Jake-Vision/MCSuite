package xronbo.ronbomc.entities;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.VillagerData.VillagerColor;
import xronbo.ronbomc.entities.VillagerData.VillagerType;
import xronbo.ronbomc.listeners.GeneralListeners;
import xronbo.ronbomc.listeners.GeneralListeners.ChunkCoord;
import xronbo.ronbomc.quests.Quest;
import xronbo.ronbomc.quests.QuestHandler;

public class NPCHandler {

	public static RonboMC plugin;
		
	public static HashMap<Integer, Store> stores;
	public static HashMap<UUID, VillagerData> villagerData;
	
	private NPCHandler() {
		
	}
	
	public static void fixLocations() {
		if(villagerData == null)
			return;
		for(VillagerData vd : villagerData.values()) {
			vd.entity.setPosition(vd.originalLoc.getX(), vd.originalLoc.getY(), vd.originalLoc.getZ());
		}
	}

	
	public static void load() {
		load(true);
	}
	
	public static void load(final boolean showMessages) {
		GeneralListeners.villagersToReload = new HashMap<ChunkCoord, HashSet<VillagerData>>();
		SuperDebugger.scheduleSyncDelayedTask(NPCHandler.class.getClass(), plugin, new Runnable() {
			public void run() {
				villagerData = new HashMap<UUID, VillagerData>();
				loadStores(showMessages);
				loadMerchants(showMessages);
				if(!RonboMC.DEV_MODE_ACTIVE)
					loadNoninteractiveNpcs(showMessages);
				loadQuestNpcs(showMessages);
				loadStableNpcs(showMessages);
				loadDungeonNpcs(showMessages);
				loadHarvestingNpcs(showMessages);
			}
		}, 10);
	}
	
	public static void loadHarvestingNpcs(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "harvestingnpcs.dat"));
			while(scan.hasNextLine()) {
				String s = scan.nextLine();
				String[] data = s.split(" ");
				World locWorld = plugin.getServer().getWorld(data[3]);
				int x = Integer.parseInt(data[0]);
				int y = Integer.parseInt(data[1]);
				int z = Integer.parseInt(data[2]);
				Location loc = new Location(locWorld, x, y, z);
				VillagerData vd = new VillagerData(ChatColor.DARK_GREEN + "Crop Harvester", loc, VillagerColor.GREEN);
				vd.villagerType = VillagerType.HARVESTING;
				count++;
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " crop harvesters.");
	}
	
	public static void loadStableNpcs(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "stables.dat"));
			ArrayList<Location> locsToSpawn = new ArrayList<Location>();
			while(scan.hasNextLine()) {
				String s = scan.nextLine();
				String[] locData = s.split(" ");
				int x = Integer.parseInt(locData[0]);
				int y = Integer.parseInt(locData[1]);
				int z = Integer.parseInt(locData[2]);
				Location loc = new Location(plugin.getServer().getWorld(locData[3]), x, y, z);
				locsToSpawn.add(loc);
			}
			for(Location loc : locsToSpawn) {
				VillagerData vd = new VillagerData(ChatColor.DARK_RED + "Stable Manager", loc, VillagerColor.BLACK_APRON);
				vd.villagerType = VillagerType.STABLE;
				count++;
			}
			scan.close();
 		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " stable manager NPCs.");
	}
	
	public static void loadQuestNpcs(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "questnpcs.dat"));
			String s = scan.nextLine();
			while(scan.hasNextLine()) {
				int id = Integer.parseInt(s.substring("ID: ".length()));
				s = scan.nextLine();
				String name = s.substring("Name: ".length());
				int p = Integer.parseInt(scan.nextLine().substring("Profession: ".length()));
				String locWorld = scan.nextLine().substring("World: ".length());
				scan.nextLine();
				ArrayList<Location> locsToSpawn = new ArrayList<Location>();
				while(scan.hasNextLine()) {
					s = scan.nextLine();
					if(s.startsWith("Quest: "))
						break;
					String[] locData = s.split(" ");
					int x = Integer.parseInt(locData[0]);
					int y = Integer.parseInt(locData[1]);
					int z = Integer.parseInt(locData[2]);
					Location loc = new Location(plugin.getServer().getWorld(locWorld), x, y, z);
					locsToSpawn.add(loc);
				}
				ArrayList<Quest> quests = new ArrayList<Quest>();
				for(String questID : s.substring("Quest: ".length()).split(" ")) {
					int idToFind = Integer.parseInt(questID);
					try {
						Quest q = QuestHandler.quests.get(idToFind);
						quests.add(q);
					} catch(Exception e) {
						System.out.println("QUEST ID " + questID + " WAS NOT FOUND.");
					}
				}
				s = scan.nextLine();
				ArrayList<String> lines = new ArrayList<String>();
				while(scan.hasNextLine()) {
					s = scan.nextLine();
					if(s.length() == 0)
						break;
					lines.add(s);
				}
				for(Location loc : locsToSpawn) {
					VillagerData vd = new VillagerData(ChatColor.AQUA + name, loc, p);
					vd.myQuests = quests;
					vd.questNpcID = id;
					vd.lines = lines;
					vd.villagerType = VillagerType.QUEST;
					count++;
				}
				while(scan.hasNextLine()) {
					s = scan.nextLine();
					if(s.startsWith("ID: "))
						break;
				}
			}
			scan.close();
 		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " quest NPCs.");
	}
	
	public static void loadNoninteractiveNpcs(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder()+ File.separator + "noninteractivenpcs.dat"));
			String s = scan.nextLine();
			while(scan.hasNextLine()) {
				if(s.startsWith("Name: ")) {
					String name = s.substring("Name: ".length());
					int p = Integer.parseInt(scan.nextLine().substring("Profession: ".length()));
					String locWorld = scan.nextLine().substring("World: ".length());
					scan.nextLine();
					ArrayList<Location> locsToSpawn = new ArrayList<Location>();
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.startsWith("Lines:"))
							break;
						String[] locData = s.split(" ");
						int x = Integer.parseInt(locData[0]);
						int y = Integer.parseInt(locData[1]);
						int z = Integer.parseInt(locData[2]);
						Location loc = new Location(plugin.getServer().getWorld(locWorld), x, y, z);
						locsToSpawn.add(loc);
					}
					ArrayList<String> lines = new ArrayList<String>();
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.length() == 0)
							break;
						lines.add(s);
					}
					for(Location loc : locsToSpawn) {
						boolean noMove = name.toLowerCase().contains("_nomove");
						boolean baby = name.toLowerCase().contains("_baby");
						int cutLength = 0 + (noMove ? "_nomove".length() : 0) + (baby? "_baby".length() : 0);
						name = name.substring(0, name.length() - cutLength);
						VillagerData vd = new VillagerData(name, loc, p, baby, noMove);
						vd.lines = lines;
						vd.villagerType = VillagerType.NONINTERACTIVE;
						count++;
					}
					if(scan.hasNextLine())
						s = scan.nextLine();
				}
			}
			scan.close();
 		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " non-interactive NPCs.");
	}
	
	public static void loadDungeonNpcs(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "dungeonnpcs.dat"));
			while(scan.hasNextLine()) {
				String s = scan.nextLine();
				String[] data = s.split(" ");
				World locWorld = plugin.getServer().getWorld(data[3]);
				int x = Integer.parseInt(data[0]);
				int y = Integer.parseInt(data[1]);
				int z = Integer.parseInt(data[2]);
				Location loc = new Location(locWorld, x, y, z);
				VillagerData vd = new VillagerData(ChatColor.DARK_PURPLE + "Dungeon Master", loc, VillagerColor.PURPLE);
				vd.villagerType = VillagerType.DUNGEON;
				String[] dungeonData = s.substring((data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " ").length()).trim().split(";");
				vd.dungeon = dungeonData[0];
				vd.dungeonRecLevel = dungeonData[1];
				vd.dungeonDescription = dungeonData[2];
				count++;
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " dungeon masters.");
	}
	
	public static void loadStores(boolean showMessages) {
		stores = new HashMap<Integer, Store>();
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "stores.dat"));
			String s = scan.nextLine();
			while(scan.hasNextLine()) {
				if(s.startsWith("ID")) {
					int id = Integer.parseInt(s.substring("ID - ".length()));
					String name = scan.nextLine();
					HashMap<String, Integer> items = new HashMap<String, Integer>();
					while(scan.hasNextLine()) {
						s = scan.nextLine();
						if(s.length() == 0)
							break;
						String[] data = s.split(" - ");
						items.put(data[0], Integer.parseInt(data[1]));
					}
					stores.put(id, new Store(id, name, items));
					count++;
					if(scan.hasNextLine())
						s = scan.nextLine();
				}
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " stores.");
	}
	
	public static void loadMerchants(boolean showMessages) {
		int count = 0;
		try {
			Scanner scan = new Scanner(new File(plugin.getDataFolder() + File.separator + "merchants.dat"));
			while(scan.hasNextLine()) {
				String name = scan.nextLine().substring("Name: ".length());
				int store = Integer.parseInt(scan.nextLine().substring("Store: ".length()));
				String locWorld = scan.nextLine().substring("World: ".length());
				String[] locData = scan.nextLine().substring("Location: ".length()).split(" ");
				int x = Integer.parseInt(locData[0]);
				int y = Integer.parseInt(locData[1]);
				int z = Integer.parseInt(locData[2]);
				Location loc = new Location(plugin.getServer().getWorld(locWorld), x, y, z);
				VillagerData vd = new VillagerData(ChatColor.GOLD + name, loc, VillagerColor.WHITE_APRON);
				vd.villagerType = VillagerType.MERCHANT;
				vd.storeId = store;
				count++;
				if(scan.hasNextLine())
					scan.nextLine();
			}
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if(showMessages)
			System.out.println("Finished loading " + count + " merchant NPCs.");
	}
	
}