package xronbo.ronbomc;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.DyeColor;
import org.bukkit.Effect;
import org.bukkit.EntityEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.DungeonHandler;
import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.entities.MobHandler.PlayerMobSpawner;
import xronbo.ronbomc.entities.VillagerData;
import xronbo.ronbomc.guilds.GuildHandler;
import xronbo.ronbomc.horses.HorseHandler.HorseType;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;
import xronbo.ronbomc.listeners.GeneralListeners;
import xronbo.ronbomc.listeners.GeneralListeners.ChunkCoord;
import xronbo.ronbomc.options.OptionList;
import xronbo.ronbomc.options.OptionsHandler;
import xronbo.ronbomc.parties.Party;
import xronbo.ronbomc.pets.Pet;
import xronbo.ronbomc.quests.Quest;
import xronbo.ronbomc.quests.QuestHandler;
import xronbo.ronbomc.quests.Stage;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;
import xronbo.ronbomc.shops.Shop;
import xronbo.ronbomc.travel.TravelHandler.QTDestination;
import xronbo.ronbomc.warps.WarpHandler;


public class PlayerData implements Cloneable {
	
	public static RonboMC plugin;
	
	public static HashMap<String, String> bounties = new HashMap<String, String>();
	
	public String uuid;

	public boolean justFinishedEnchanting;
	public boolean isEnchanting;
	
	public boolean frozen = false;
	public int votepoints;
	public int attack;
	public int guildId;
	private int guildPoints;
	public int level, hp, maxHP, hpRegen, strength, dexterity, intelligence, luck, critChance, lifesteal_buff;
	public int damageReduction, damageReceivedIncrease;
	public String classType;
	public int[][] activePassives;
	public String selectedClass;
	public int strength_assigned, dexterity_assigned, intelligence_assigned, luck_assigned, SP_assigned;
	public int strength_temp, dexterity_temp, intelligence_temp, luck_temp, hpRegen_temp, critChance_temp, critDamage_temp, lifesteal_temp, maxHP_temp;
	public int critChance_buff;
	public int shootingSpeed_buff;
	public boolean doubleHit_buff;
	public double doubleHitMultiplier_buff;
	public boolean puncture_buff;
	public double punctureMultiplier_buff;
	public int punctureMaxDamage_buff;
	public boolean sneakAttack_buff;
	public double sneakAttackMultipler_buff;
	public boolean goldenTouch_buff;
	public double goldenTouchMultiplier_buff;
	public boolean ambush_buff;
	public double ambushMultiplier_buff;
	public int ambushHits_buff;
	public boolean disable_buff;
	public int disableDuration_buff;
	public boolean bless_buff;
	public double blessMultiplier_buff;
	public boolean intervention_buff;
	public boolean powerStrike_buff;
	public long lastIntervention;
	public double powerStrikeMultiplier_buff;
	public boolean focus_buff;
	public double focusMultiplier_buff;
	public boolean cleave_buff;
	public double cleaveMultiplier_buff;
	public int cleaveMaxDamage_buff;
	public boolean wildSwing_buff;
	public double wildSwingMultiplier_buff, wildSwingRecoil_buff;
	public boolean sacrifice_buff;
	public int sacrificeValue_buff;
	public boolean divineShield_buff;
	public double divineShieldMultiplier_buff;
	public boolean chantOfNecessarius_buff;
	public int chantOfNecessariusValue_buff;
	public boolean indomitable_buff;
	public int indomitableValue_buff;
	public int sp;
	public long exp;
	public int banklines = 1;
	public long bankGold;
	public boolean disabled;
	public int shield;
	public String toTrade;
	public long lastGlobalChat;
	public HorseType horseType;
	public long timeLeftWithHorse;
	public long gotOnHorse;
	public String spawn;
	public String joindate;
	public boolean intrade;
	
	public boolean movedDuringAFKCheck;
	
	public volatile boolean waitingForDungeonEnter = false;
	public String dungeonToEnter = "";
	public boolean allowedToTeleport = false;
	public String dungeon = "";
	public boolean inDungeon = false;
	public String dungeonFile, dungeonFullName;
	
	public Region region;
	public Region preUnwelcomedRegion;
	
	public boolean uuidRetrieved;
	
	public OptionList options;
	public boolean fullyLoaded;
	public boolean firstLogon;
	
	public double expBooster;
	public double damageBooster;
	
	public HashMap<Quest, Integer> inProgressQuests;
	public ArrayList<Quest> completedQuests;
	public HashMap<String, HashMap<Quest, Integer>> mobKillTracker;
	
	public volatile boolean awaitingBankGoldWithdrawValue;
	public volatile boolean awaitingBankBanknoteWithdrawValue;
	public volatile boolean awaitingBankSizeIncreaseConfirmation;
	
	public volatile boolean awaitingPetNameChange;
	public volatile String proposedPetName;
	
	public boolean invisible;
	public long nextSpellCast;
	public long lastCooldownLength;
	public int cooldownTask;
	
	public int checkLagTaskId;
	public long lastProjectileShot;
	public String lastDamager = "";
	public boolean lastDamagerPlayer = false;
	
	public Party party;
	public Party invitedTo;
	public Inventory bank;
	public Player player;
	public String playerName;
	public List<Integer> taskIds;

	public List<Integer> rewards;
	
	public List<Stage> alreadyTalked = new ArrayList<Stage>();
	public Stage lastStage = null;
	public VillagerData lastVillager = null;
	public List<Integer> autoTalkTask = new ArrayList<Integer>();
	
	public ArrayList<QTDestination> QTLocs = new ArrayList<QTDestination>();
	public int maxQT = 3;
	
	public boolean flyingHorse;
	
	public boolean flyhorse; //access to the command
	
	public int spiritPoints;
	public int minutesPlayed;
	public long logonTime;
	
	public ArrayList<MobData> mobsSpawnedForPlayer = new ArrayList<MobData>();
	public volatile int mobsQueuedOrSpawnedForPlayer = 0;
	
	public long wallet;
	
	public ArrayList<String> shopSearchFilters = new ArrayList<String>();
	public volatile boolean waitingOnShopSearchOwner, waitingOnShopSearchName;
	
	public int shopSize, shopGold;
	public ItemStack itemToAddToShop;
	public volatile boolean waitingOnItemPrice;
	public volatile boolean waitingOnShopNameChange;
	public ItemStack itemToBuy;
	public Shop shopBuyingFrom;
	public int itemToBuyPrice;
	public volatile boolean waitingOnPurchaseConfirm;
	
	public long lastUnstuckRequest = 0;
	
	public boolean sendingRegionChange;
	
	public Pet pet = null;
	
	public boolean justBoughtGuild;
	
	public volatile boolean waitingOnGuildName;
	public volatile boolean waitingOnGuildAbbreviation;
	public volatile boolean waitingOnGuildPurchaseConfirmation;
	public String desiredGuildName;
	public String desiredGuildPrefix;
	public volatile boolean waitingOnGuildExpansionConfirmation;
	public volatile int guildExpansionPrice;
	public boolean guildChatLock = false;
	public boolean partyChatLock = false;
	
	public boolean inSpawnRegion = false;
	
	public int playerKills,playerDeaths,mobKills,mobDeaths;
	
	public static final SimpleDateFormat dateformat;
	
	static {
		dateformat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss zzz");
	}
	
	public static final SimpleDateFormat dateformatCST;
	
	static {
		dateformatCST = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss zzz");
		dateformatCST.setTimeZone(TimeZone.getTimeZone("CST"));
	}
	
	public PlayerData(final Player p) {
		p.getInventory().clear();
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		p.updateInventory();
		logonTime = System.currentTimeMillis();
		uuid = p.getUniqueId().toString();
		uuidRetrieved = true; //just leave this here
		taskIds = new ArrayList<Integer>();
		critChance = 5;
		player = p;
		playerName = p.getName();
		checkLagTaskId = -1;
		invisible = false;
		party = null;
		selectedClass = "";
		toTrade = "";
		load();
	}
	
	
	public static class MusicTask implements Runnable {
		public Player p;
		public static Object[][] musics = {
			{Material.GREEN_RECORD, 3*60+5},
			{Material.RECORD_3, 5*60+45},
			{Material.RECORD_4, 3*60+5},
			{Material.RECORD_5, 2*60+54},
			{Material.RECORD_6, 3*60+17},
			{Material.RECORD_7, 1*60+36},
			{Material.RECORD_8, 2*60+30},
			{Material.RECORD_9, 3*60+8},
			{Material.RECORD_10, 4*60+11},
			{Material.RECORD_12, 3*60+51},
		};
		
		public void run() {
			if(p == null || !p.isOnline() || !p.isValid())
				return;
			if(plugin.getPD(p).options == null) {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 20);
				return;
			}
			if(!plugin.getPD(p).options.checkOption("music"))
				return;
			Object[] rand = musics[(int)(Math.random() * musics.length)];
			p.getWorld().playEffect(p.getLocation(), Effect.RECORD_PLAY, ((Material)rand[0]).getId());
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, (int)(rand[1])*20);
		}
		public MusicTask(Player p) {
			this.p = p;
		}
	}
	
	public boolean announcedVote = false;
	public int votedTimes = 0;
	
	public void voted() {
		votepoints++;
		votedTimes++;
		if(!announcedVote) {
			announcedVote = true;
			plugin.getServer().broadcastMessage(ChatColor.AQUA + player.getName() + " just earned some Vote Points.");
			plugin.getServer().broadcastMessage(ChatColor.AQUA + "Use /vote to get Vote Points in less than a minute!");
			plugin.getServer().broadcastMessage(ChatColor.AQUA + "Check out the awesome Vote Point rewards with /vp!");
		}
		player.sendMessage(ChatColor.GOLD + "Your vote has been registered! You now have " + votepoints + " Vote Points!");
		player.sendMessage(ChatColor.GOLD + "Use /votepoints to spend these Vote Points on something useful!");
	}

	public int getPrimaryStat() {
		ClassType ct = ClassHandler.getClassType(classType);
		if(ct == null)
			return strength + strength_temp;
		switch(ct) {
			case CRUSADER:
				return strength + strength_temp;
			case BERSERKER:
				return strength + strength_temp;
			case PALADIN:
				return strength + strength_temp;
			case CLERIC:
				return intelligence + intelligence_temp;
			case WIZARD:
				return intelligence + intelligence_temp;
			case ARCHER:
				return dexterity + dexterity_temp;
			case ASSASSIN:
				return luck + luck_temp;
			default:
				return 1;
		}
	}
	
	public int getSecondaryStat() {
		ClassType ct = ClassHandler.getClassType(classType);
		if(ct == null)
			return strength + strength_temp;
		switch(ct) {
			case CRUSADER:
				return dexterity + dexterity_temp;
			case BERSERKER:
				return luck + luck_temp;
			case PALADIN:
				return intelligence + intelligence_temp;
			case CLERIC:
				return strength + strength_temp;
			case WIZARD:
				return luck + luck_temp;
			case ARCHER:
				return strength + strength_temp;
			case ASSASSIN:
				return dexterity + dexterity_temp;
			default:
				return 1;
		}
	}
	
	public int getShopExpansionCost() {
		switch(shopSize) {
			case 1:
				return 5000;
			case 2:
				return 50000;
			case 3:
				return 500000;
			case 4:
				return 5000000;
		}
		return 1000000000;
	}
	
	/*
	 * PLAYER FILE LOADING
	 */
	
	public void load() {
		Values.sendHeaderAndFooter(player, ChatColor.GOLD + "" + ChatColor.BOLD + "-- The Kastia RPG --", ChatColor.AQUA + "Check us out at " + ChatColor.YELLOW + "www.kastia.net" + ChatColor.AQUA + "!");
		loadSavedStats();
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public int count = -1;
			public void run() {
				if(player == null || !player.isOnline())
					return;
				count++;
				if(!finishedLoading) {
					if(count % 4 == 0)
						player.sendMessage(ChatColor.RED + "(" + (count / 4 + 1) + ") Fetching your save data... This can take a while if too many players are on. Sorry!");
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 5);
					return;
				}
				RonboMCCommandExecutor.sendWelcomeMessage(player);
				updateArmorStats();
	            player.closeInventory();
	            PlayerData clone = (PlayerData)(plugin.getPD(player).clone());
	            GeneralListeners.clonedPDs.remove(player);
	            GeneralListeners.clonedPDs.put(player.getName(), clone);
				player.setLevel(level);
				updateLevel();
				updateCooldown();
				nextSpellCast = 0;
				fullyLoaded = true;
				if(hp <= 0)
					hp = 1;
				if(firstLogon)
					player.teleport(WarpHandler.warps.get("mainspawn"));
				if(player.getName().equalsIgnoreCase("xRonbo"))
					player.setAllowFlight(true);
				if(RankManager.check(player, "knight"))
					plugin.getServer().broadcastMessage("*   " + RankManager.getPrefix(player.getName()) + " " + ChatColor.RESET + player.getName() + " has logged on!");
				checkNavigator();
				Region r = RegionHandler.getWelcomeRegion(player.getLocation());
				r.sendWelcome(player, true);
				taskIds.add(SuperDebugger.scheduleSyncRepeatingTask(this.getClass(), plugin, new Runnable() {
					public int count = 0;
					public int numTimesGPEarned = 0;
					public void run() {
						count++;
						if(count % 5 == 0 && !RankManager.check(player, "knight")) {
							if(!movedDuringAFKCheck) {
								player.kickPlayer("AFK for 5 minutes.");
								return;
							}
							movedDuringAFKCheck = false;
						}
						if(pet != null) {
							pet.addExp(1);
						}
						if(spiritPoints >= getMaxSpiritPoints())
							return;
						if((minutesPlayed + (System.currentTimeMillis() - logonTime) / 1000 / 60) % 20 == 0) {
							spiritPoints++;
							player.sendMessage(ChatColor.GREEN + "You have received 1 Spirit Point for playing for 20 minutes. You now have " + spiritPoints + " Spirit Points.");
							minutesPlayed++;
							logonTime += 1000 * 60;
						}
						if((minutesPlayed + (System.currentTimeMillis() - logonTime) / 1000 / 60) % 10 == 0) {
							minutesPlayed++;
							logonTime += 1000 * 60;
							addGuildPoints(7 * ++numTimesGPEarned);
						}
					}
				}, 20*60, 20*60));
				plugin.loading.remove(player.getName());
				MusicTask mt = new MusicTask(player);
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, mt, 10);
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new PlayerMobSpawner(player), 40);
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						if(player == null || !player.isValid() || !player.isOnline())
							return;
						player.updateInventory();
						for(int k = 0; k < mobsSpawnedForPlayer.size(); k++) {
							MobData md = mobsSpawnedForPlayer.get(k);
							if(md.entity == null) {
								mobsSpawnedForPlayer.remove(k--);
								mobsQueuedOrSpawnedForPlayer--;
								continue;
							}
							try {
								int x = (int)Math.abs(md.entity.getLocation().getX() - player.getLocation().getX());
								int z = (int)Math.abs(md.entity.getLocation().getZ() - player.getLocation().getZ());
								int maxDistance = Values.CHUNK_RANGE_TO_SPAWN * 16 + 8;
								if(x > maxDistance || z > maxDistance) {
									throw new Exception("");
								}
							} catch(Exception e) {
								md.findNewOwner();
							}
						}
						if(mobsSpawnedForPlayer.size() == 0)
							mobsQueuedOrSpawnedForPlayer = 0;
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 20*5);
					}
				}, 5);
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						if(player == null || !player.isValid() || !player.isOnline())
							return;
						Chunk c = player.getLocation().getChunk();
						for(int dx = -4; dx <= 4; dx++) {
							for(int dz = -4; dz <= 4; dz++) {
								final ChunkCoord cc = new ChunkCoord(c);
								cc.x += dx;
								cc.z += dz;
								for(Entity e : cc.toChunk().getEntities()) {
									try {
										LivingEntity le = (LivingEntity)e;
										if(le.getCustomName().contains("[Lv. ") 
												|| le.getCustomName().contains("EXP")
												|| ChatColor.stripColor(le.getCustomName()).contains("[|||")) {
											if(!MobHandler.spawnedMobs.containsKey(le.getUniqueId())) {
												le.remove();
											}
										}
									} catch(Exception e2) {
										
									}
								}
								if(plugin.getPD(player).inDungeon) {
									final ArrayList<MobData> tospawn = new ArrayList<MobData>();
									if(MobHandler.dungeonMobs.containsKey(cc)) {
										for(MobData md : MobHandler.dungeonMobs.get(cc)) {
											if(md.entity != null)  {
												md.entity.remove();
											}
											tospawn.add(md);
										}
									}
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
										public void run() {
											for(MobData md : tospawn) {
												md.newEntity();
											}
										}
									}, 1);
									MobHandler.dungeonMobs.remove(cc);
								}
								if(GeneralListeners.villagersToReload.containsKey(cc)) {
									HashSet<VillagerData> respawn = GeneralListeners.villagersToReload.get(cc);
									Iterator<VillagerData> iter = respawn.iterator();
									while(iter.hasNext()) {
										VillagerData vd = iter.next();
										vd.createEntity(vd.name, vd.toRespawnLocation, vd.color);
										iter.remove();
									}
									if(respawn.size() == 0)
										GeneralListeners.villagersToReload.remove(cc);
								}
							}
						}
						for(Entity item : player.getNearbyEntities(1.5, 1.5, 1.5)) {
							if(item instanceof Item) {
								try {
									if(((Item) item).getItemStack().getType() == Material.GOLD_NUGGET) {
										wallet += ((Item)item).getItemStack().getAmount();
										updateRonbook();
										SoundHandler.playSound(player, Sound.ITEM_PICKUP, 0.2f, 3);
										item.remove();
									}
								} catch(Exception e) {
									
								}
							}
						}
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 1*10);
					}
				}, 1*10);
			}
		}, 1);
	}
	
	public int getMaxSpiritPoints() {
		if(RankManager.check(player, "knight"))
			return 15;
		return 10;
	}
	
	public ItemStack checkNavigator() {
		for(ItemStack i : player.getInventory().getContents()) {
			try {
				if(i.getItemMeta().getDisplayName().contains("The Navigator")) {
					return i;
				}
			} catch(Exception e) {
				
			}
		}
		ItemStack item = new ItemStack(Material.COMPASS);
		ItemMeta im = item.getItemMeta();
		im.setDisplayName(ChatColor.AQUA + "The Navigator");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add(ChatColor.RESET + "" + ChatColor.BOLD + "Left-Click: Teleport to Party Members");
		lore.add(ChatColor.RESET + "" + ChatColor.BOLD + "Right-Click: Quick Travel");
		lore.add("");
		lore.add(ChatColor.RESET + "" + ChatColor.WHITE + "Use " + ChatColor.YELLOW + "/navigate <x> <y> <z>");
		lore.add(ChatColor.RESET + "" + ChatColor.WHITE + "to point your Navigator to the given coordinates.");
		im.setLore(lore);
		item.setItemMeta(im);
		player.getInventory().addItem(item);
		return item;
	}
	
	public void updateNavigatorLoc(Location loc) {
		for(ItemStack i : player.getInventory().getContents()) {
			try {
				if(i.getItemMeta().getDisplayName().contains("The Navigator")) {
					
				}
			} catch(Exception e) {
				
			}
		}
	}
	
	public static long parseTimeString(String s) {
		int days = 0;
		int hours = 0;
		int minutes = 0;
		long millis = 0;
		if(s.contains("d")) {
			try {
				days += Integer.parseInt(s.substring(0, s.indexOf("d")));
			} catch(Exception e) {
				
			}
			s = s.substring(s.indexOf("d") + 1);
		}
		if(s.contains("h")) {
			try {
				hours += Integer.parseInt(s.substring(0, s.indexOf("h")));
			} catch(Exception e) {
				
			}
			s = s.substring(s.indexOf("h") + 1);
		}
		if(s.contains("m")) {
			try {
				minutes += Integer.parseInt(s.substring(0, s.indexOf("m")));
			} catch(Exception e) {
				
			}
		}
		millis += TimeUnit.DAYS.toMillis(days);
		millis += TimeUnit.HOURS.toMillis(hours);
		millis += TimeUnit.MINUTES.toMillis(minutes);
		return millis;
	}
	
	public static String timeDiff(Date a, Date b) {
		long diff = 0;
		if(a.compareTo(b) > 0)
			diff = a.getTime() - b.getTime();
		else
			diff = b.getTime() - a.getTime();
		return timeDiff(diff);
	}
	
	public static String timeDiff(long diff) {
		long days = diff / 1000 / 60 / 60 / 24;
		diff -= days * 1000 * 60 * 60 * 24;
		long hours = diff / 1000 / 60 / 60;
		diff -= hours * 1000 * 60 * 60;
		long minutes = diff / 1000 / 60;
		return (days > 0 ? days + " day" + (days == 1 ? "" : "s") + ", " : "") + (hours > 0 ? hours + " hour" + (hours == 1 ? "" : "s") + ", " : "") + minutes + " minute" + (minutes == 1 ? "" : "s");
	}
	
	public static Date applyDuration(long duration) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(cal.getTimeInMillis() + duration);
		return cal.getTime();
	}
	
	public int checkSpellCooldownMultiplier() {
		Equip e = ItemHandler.getEquip(player.getItemInHand());
		if(e == null)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.CRUSADER && e == Equip.SWORD)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.PALADIN && e == Equip.MACE)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.BERSERKER && e == Equip.AXE)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.WIZARD && e == Equip.WAND)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.ARCHER && e == Equip.BOW)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.ASSASSIN && e == Equip.DAGGER)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.BARBARIAN && e == Equip.BONE)
			return 1;
		if(ClassHandler.getClassType(classType) == ClassType.CLERIC && e == Equip.STAVE)
			return 1;
		
		if(ClassHandler.getClassType(classType) == ClassType.CRUSADER && (e == Equip.AXE || e == Equip.MACE || e == Equip.STAVE))
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.PALADIN && (e == Equip.AXE || e == Equip.SWORD || e == Equip.STAVE))
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.BERSERKER && (e == Equip.SWORD || e == Equip.MACE || e == Equip.STAVE))
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.WIZARD && (e == Equip.STAVE || e == Equip.BOW))
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.ARCHER && (e == Equip.STAVE || e == Equip.WAND))
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.ASSASSIN && e == Equip.STAVE)
			return 2;
		if(ClassHandler.getClassType(classType) == ClassType.CLERIC && (e == Equip.AXE || e == Equip.MACE || e == Equip.SWORD))
			return 2;
		
		return 3;
	}
	
//	public void checkVip() {
//		Date today = Calendar.getInstance().getTime();
//		if(vipExpiryDate != null) {
//			if(today.compareTo(vipExpiryDate) >= 0) {
//				vipExpiryDate = null;
//				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
//					public void run() {
//						player.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Your Knighthood has expired! You are now a normal member.");
//					}
//				}, 5);
//				if(rank == Values.RANK_KNIGHT) {
//					rank = Values.RANK_MEMBER;
//					rankString = "member";
//					save(false);
//				}
//			} else {
//				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
//					public void run() {
//						if(rank < Values.RANK_ALPHA) {
//							rank = 2;
//							rankString = "knight";
//						}
//						player.sendMessage(ChatColor.GOLD + "You are a VIP! Thanks for your support!");
//						player.sendMessage(ChatColor.RESET + "Your VIP will expire on " + ChatColor.YELLOW + dateformatCST.format(vipExpiryDate) + ChatColor.RESET + ".");
//						player.sendMessage(ChatColor.RESET + "The current time is " + ChatColor.YELLOW + dateformatCST.format(new Date()) + ChatColor.RESET + ".");
//					}
//				}, 5);
//			}
//		}
//	}
	
//	public void checkRewards() {
//		ArrayList<Integer> temp = new ArrayList<Integer>();
//		if(rewards == null)
//			return;
//		for(int i : rewards) {
//			temp.add(i);
//		}
//		for(int i : temp) {
//			if(RewardHandler.reward(player, i) && temp.size() > 1)
//				player.sendMessage("");
//		}
//	}
	
	public boolean finishedLoading = false;
	
	public void loadSavedStats() {
		try {
			SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
				public void run() {
					final ResultSet rs = plugin.executeQuery("SELECT * FROM rpg WHERE uuid = '" + uuid + "'");
					final ResultSet rs_pets = plugin.executeQuery("SELECT * FROM rpg_pets where uuid = '" + uuid + "'");
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							try {
								if(rs_pets.next()) {
									int id = rs_pets.getInt("id");
									String uuid = rs_pets.getString("uuid");
									String name = rs_pets.getString("name");
									int level = rs_pets.getInt("level");
									long exp = rs_pets.getLong("exp");
									String activePowersString = rs_pets.getString("activePowers");
									String ownedTypesString = rs_pets.getString("ownedTypes");
									if(activePowersString == null)
										activePowersString = "";
									if(ownedTypesString == null)
										ownedTypesString = "";
									String type = rs_pets.getString("type");
									pet = new Pet(id,uuid,name,level,exp,activePowersString,type,ownedTypesString);
								}
							} catch(Exception e) {
								e.printStackTrace();
							} finally {
								try {
									rs_pets.close();
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
							try {
								if(rs.next()) {
									level = rs.getInt("level");
									hp = rs.getInt("hp");
									maxHP = rs.getInt("maxHP");
									hpRegen = rs.getInt("hpRegen");
									strength = rs.getInt("strength");
									dexterity = rs.getInt("dexterity");
									intelligence = rs.getInt("intelligence");
									luck = rs.getInt("luck");
									sp = rs.getInt("sp");
									exp = rs.getLong("exp");
									banklines = rs.getInt("banklines");
									loadBank();
									bankGold = rs.getLong("gold");
									classType = rs.getString("classType");
									String[] data = rs.getString("activePassives").split(" ");
									activePassives = new int[(int)(data.length / 2)][2];
									for(int k = 0; k < data.length; k+=2) {
										activePassives[k / 2][0] = Integer.parseInt(data[k]);
										activePassives[k / 2][1] = Integer.parseInt(data[k + 1]);
									}
									completedQuests = new ArrayList<Quest>();
									data = rs.getString("completedQuests").split(" ");
									for(String s : data)
										if(s.length() > 0)
											completedQuests.add(QuestHandler.quests.get(Integer.parseInt(s)));
									data = rs.getString("inProgressQuests").split(" ");
									inProgressQuests = new HashMap<Quest, Integer>();
									for(String s : data)
										if(s.length() > 0)
											inProgressQuests.put(QuestHandler.quests.get(Integer.parseInt(s.split(":")[0])), Integer.parseInt(s.split(":")[1]));
									data = rs.getString("mobKillTracker").split(" ");
									mobKillTracker = new HashMap<String, HashMap<Quest, Integer>>();
									for(String s : data) {
										if(s.length() > 0) {
											String[] countData = s.split(":");
											if(countData.length == 3) {
												String species = countData[0];
												if(mobKillTracker.get(species) == null)
													mobKillTracker.put(species, new HashMap<Quest, Integer>());
												mobKillTracker.get(species).put(QuestHandler.quests.get(Integer.parseInt(countData[1])), Integer.parseInt(countData[2]));
											}
										}
									}
									data = rs.getString("options").split(" ");
									options = new OptionList();
									for(String s : data) {
										if(s.split(":").length == 2)
											options.addOption(s.split(":")[0], Boolean.parseBoolean(s.split(":")[1]));
									}
									horseType = rs.getString("horseType").equals("null") ? null : HorseType.valueOf(rs.getString("horseType"));
									timeLeftWithHorse = rs.getLong("timeLeftWithHorse");
									spawn = rs.getString("spawn");
									deserializeInventory(rs.getString("inventory"));
									deserializeBank(rs.getString("bank"));
									String location = rs.getString("location");
									if(location != null) {
										try {
											Location loc = Values.stringToLocation(rs.getString("location"));
											if(loc != null && loc.getWorld() != null) {
												player.teleport(loc);
											} else {
												player.sendMessage(ChatColor.RED + "Could not find previous location! Warping to Stonehelm...");
												player.teleport(WarpHandler.warps.get("mainspawn"));
											}
										} catch(Exception e) {
											player.teleport(WarpHandler.warps.get("mainspawn"));
										}
									} else {
										player.teleport(WarpHandler.warps.get("mainspawn"));
									}
									guildId = rs.getInt("guildId");
									votepoints = rs.getInt("votepoints");
									String rewardData = rs.getString("rewards");
									rewards = new ArrayList<Integer>();
									if(rewardData != null && rewardData.trim().length() > 0) {
										for(String s : rewardData.trim().split(" ")) {
											rewards.add(Integer.parseInt(s));
										}
									}
									QTLocs = new ArrayList<QTDestination>();
									String qtlocs_string = rs.getString("QTLocs");
									maxQT = rs.getInt("maxQT");
									if(maxQT < 3)
										maxQT = 3;
									for(int k = 0; k < maxQT; k++)
										QTLocs.add(new QTDestination());
									if(qtlocs_string != null) {
										try {
											int count = 0;
											for(String s: qtlocs_string.split("#")) {
												String[] data_temp = s.split("@");
												QTLocs.set(count++, new QTDestination(data_temp[0], Values.stringToLocation(data_temp[1])));
											}
										} catch(Exception e) {
											
										}
									}
									flyhorse = rs.getBoolean("flyhorse");
									spiritPoints = rs.getInt("spiritPoints");
									minutesPlayed = rs.getInt("minutesPlayed");
									wallet = rs.getLong("wallet");
									shopSize = rs.getInt("shopSize");
									if(shopSize == 0)
										shopSize = 1;
									shopGold = rs.getInt("shopGold");
									guildPoints = rs.getInt("guildPoints");
									playerKills = rs.getInt("kills");
									playerDeaths = rs.getInt("deaths");
									mobKills = rs.getInt("mobKills");
									mobDeaths = rs.getInt("mobDeaths");
									Values.sendTitle(player, ChatColor.GOLD + "Welcome back, " + player.getName() + "!", ChatColor.YELLOW + "Have fun!", 20, 40, 20);
								} else {
									firstLogon = true;
									player.getInventory().clear();
									loadBank();
									level = 1;
									hp = 100;
									maxHP = 100;
									hpRegen = 1;
									strength = 5;
									dexterity = 5;
									intelligence = 5;
									luck = 5;
									sp = 0;
									exp = 0;
									banklines = 1;
									bankGold = 0;
									nextSpellCast = 0;
									classType = "";
									activePassives = new int[(int)("0 0".split(" ").length / 2)][2];
									completedQuests = new ArrayList<Quest>();
									inProgressQuests = new HashMap<Quest, Integer>();
									mobKillTracker = new HashMap<String, HashMap<Quest, Integer>>();
									options = OptionsHandler.getDefaults();
									horseType = null;
									timeLeftWithHorse = 0;
									spawn = "mainspawn";
									guildId = 0;
									votepoints = 0;
									rewards = new ArrayList<Integer>();
									QTLocs = new ArrayList<QTDestination>();
									maxQT = 3;
									flyhorse = false;
									spiritPoints = 3;
									minutesPlayed = 0;
									wallet = 0;
									shopSize = 1;
									shopGold = 0;
									guildPoints = 0;
									playerKills = 0;
									playerDeaths = 0;
									mobKills = 0;
									mobDeaths = 0;
									for(int k = 0; k < maxQT; k++)
										QTLocs.add(new QTDestination());
									plugin.execute("INSERT INTO rpg (id, uuid, name, level, hp, maxHP, hpRegen, strength, dexterity, intelligence, luck, "
											+ "sp, exp, banklines, gold, classType, activePassives, completedQuests, inProgressQuests, mobKillTracker, "
											+ "options, horseType, timeLeftWithHorse, spawn, inventory, bank, location, guildId, votepoints, "
											+ "rewards, QTLocs, maxQT, flyhorse, spiritPoints, minutesPlayed, wallet, shopSize, shopGold, "
											+ "guildRank, guildPoints, kills, deaths, mobKills, mobDeaths) "
											+ "VALUES (NULL, "
											+ "'" + uuid + "', " //UUID
											+ "'" + player.getName() + "', " //Name
											+ "1, " //Level
											+ "100, " //HP
											+ "100, " //maxHP
											+ "1, " //hpRegen
											+ "5, " //strength
											+ "5, " //dexterity
											+ "5, " //intelligence
											+ "5, " //luck
											+ "0, " //sp
											+ "0, " //exp
											+ "1, " //banklines
											+ "0, " //gold
											+ "'', " //classType
											+ "'0 0', " //activePassives
											+ "'', " //completedQuests
											+ "'', " //inProgressQuests
											+ "'', " //mobKillTracker
											+ "'" + OptionsHandler.getDefaults().toString() + "'" + ", " //options
											+ "'null', " //horseType
											+ "0, " //timeLeftWithHorse
											+ "'mainspawn', " //spawn
											+ "NULL, " //inventory
											+ "NULL, " //bank
											+ "NULL, " //location
											+ "0, " //guild id
											+ "0, " //votepoints
											+ "'', " //rewards
											+ "''," //QTLocs
											+ "0, " //maxQT
											+ "0, " //flyhorse
											+ "3, " //spiritPoints
											+ "0, " //minutesPlayed
											+ "0, " //wallet
											+ "1, " //shopSize
											+ "0,  " //shopGold
											+ "1, " //guildRank
											+ "0, " //guildPoints
											+ "0, " //kills
											+ "0, " //deaths
											+ "0, " //mobKills
											+ "0 " //mobDeaths
											//REMEMBER TO ADD A COMMA AND ALSO UPDATE THE save() BELOW!
											//WHEN ADDING NEW VARIABLES REMEMBER TO ADD THEM IN THE rpg(...) part!
											+ ");");
									SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
										public void run() {
											player.setGameMode(GameMode.SURVIVAL);
											Values.sendTitle(player, ChatColor.GOLD + "Welcome to Kastia!", ChatColor.YELLOW + "We hope to see you around :)", 20, 60, 20);
//											player.sendMessage(ChatColor.GOLD + "Welcome to Kastia, " + player.getName() + "! Talk to Vorran to get started on your adventure!");
										}
									}, 40);
								}
							} catch(Exception e) {
								e.printStackTrace();
							} finally {
								try {
									rs.close();
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							finishedLoading = true;
						}
					});
				}
			});
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void save(boolean forced) {
		save(forced, false, null);
	}
	public void save(boolean forced, boolean channelChange, final String channelToChangeTo) {
		if(!uuidRetrieved || !finishedLoading)
			return;
		StringBuilder sb = new StringBuilder("");
		if(activePassives != null) {
			for(int[] i : activePassives) {
				sb.append(i[0] + " " + i[1] + " ");
			}
		}
		String activePassivesString = sb.substring(0, sb.length() - 1 >= 0 ? sb.length() - 1 : 0);
		sb = new StringBuilder("");
		if(completedQuests != null)
			for(Quest q : completedQuests)
				if(q != null)
					sb.append(q.id + " ");
		String completedQuestsString = sb.substring(0, sb.length() - 1 >= 0 ? sb.length() - 1 : 0);
		sb = new StringBuilder("");
		if(inProgressQuests != null)
			for(Quest q : inProgressQuests.keySet()) {
				if(q != null)
					sb.append(q.id + ":" + inProgressQuests.get(q) + " ");
			}
		String inProgressQuestsString = sb.substring(0, sb.length() - 1 >= 0 ? sb.length() - 1 : 0);
		sb = new StringBuilder("");
		if(mobKillTracker != null)
			for(String s : mobKillTracker.keySet()) {
				for(Quest q : mobKillTracker.get(s).keySet()) {
					if(q != null)
						sb.append(s + ":" + q.id + ":" + mobKillTracker.get(s).get(q) + " ");
				}
			}
		String mobKillTrackerString = sb.substring(0, sb.length() - 1 >= 0 ? sb.length() - 1 : 0);
		sb = new StringBuilder("");
		if(QTLocs != null) {
			for(QTDestination qtd : QTLocs) {
				if(qtd.loc != null)
					sb.append(qtd.name + "@" + Values.locationToString(qtd.loc) + "#");
			}
		}
		String QTLocsString = sb.substring(0, (sb.lastIndexOf("#") >= 0 ? sb.lastIndexOf("#") : 0));
		String[][] data = new String[][] {
				{"name", player.getName()},
				{"level", level + ""},
				{"hp", hp + ""},
				{"maxHP", maxHP + ""},
				{"hpRegen", hpRegen + ""},
				{"strength", strength + ""},
				{"dexterity", dexterity + ""},
				{"intelligence", intelligence + ""},
				{"luck", luck + ""},
				{"sp", sp + ""},
				{"exp", exp + ""},
				{"banklines", banklines + ""},
				{"gold", bankGold + ""},
				{"classType", classType + ""},
				{"activePassives", activePassivesString},
				{"completedQuests", completedQuestsString},
				{"inProgressQuests", inProgressQuestsString},
				{"mobKillTracker", mobKillTrackerString},
				{"options", options.toString()},
				{"horseType", horseType == null ? "null" : horseType.toString()},
				{"timeLeftWithHorse", timeLeftWithHorse + ""},
				{"spawn", spawn + ""},
				{"inventory", serializeInventory()},
				{"bank", serializeBank()},
				{"location", Values.locationToString(player.getLocation())},
				{"votepoints", votepoints + ""},
				{"QTLocs", QTLocsString},
				{"maxQT", maxQT + ""},
				{"flyhorse", flyhorse ? "1" : "0"},
				{"spiritPoints", spiritPoints + ""},
				{"minutesPlayed", "" + (minutesPlayed + (System.currentTimeMillis() - logonTime) / 1000 / 60)},
				{"wallet", "" + wallet},
				{"shopSize", "" + shopSize},
				{"kills", playerKills + ""},
				{"deaths", playerDeaths + ""},
				{"mobKills", mobKills + ""},
				{"mobDeaths", mobDeaths + ""},
		};
		StringBuilder statement = new StringBuilder("UPDATE rpg SET ");
		final String[] stringsOnly = new String[data.length];
		int count = 0;
		for(String[] s : data) {
			statement.append(s[0] + " = ?, ");
			stringsOnly[count++] = s[1];
		}
		if(statement.toString().endsWith(", "))
			statement = new StringBuilder(statement.substring(0, statement.length() - 2));
		statement.append(" WHERE uuid='" + uuid + "'");
		final String statementFinal = statement.toString();
		if(pet != null)
			pet.save(forced);
		if(channelChange) {
			player.sendMessage(ChatColor.GREEN + "Saving your data in preparation for channel change...");
			SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
				public void run() {
					if(receivedRewards.size() > 0) {
						StringBuilder rewardsRemover = new StringBuilder("");
						rewardsRemover.append("update rpg set rewards = placeholder");
						while(receivedRewards.size() > 1) {
							int k = receivedRewards.remove(0);
							String temp = rewardsRemover.toString().replace("placeholder", "insert(placeholder, locate('" + k + " ',placeholder),length('" + k + " '), '0 ')");
							rewardsRemover = new StringBuilder(temp);
						}
						int k = receivedRewards.remove(0);
						rewardsRemover.append(" where uuid=?");
						String rewardsRemoveString = rewardsRemover.toString().replace("placeholder", "insert(rewards, locate('" + k + " ',rewards),length('" + k + " '), '0 ')");
						plugin.executePrepared(rewardsRemoveString, true, uuid);
					}
					plugin.executePrepared(statementFinal.toString(), true, stringsOnly);
					plugin.executePrepared("UPDATE rpg SET " + "inventory" + "= ? WHERE uuid='" + uuid + "'", true, serializeInventory());
					plugin.executePrepared("UPDATE rpg SET " + "bank" + "= ? WHERE uuid='" + uuid + "'", true, serializeBank());
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							player.sendMessage(ChatColor.GREEN + "Player data saved! Changing channels now.");
							ChannelManager.sendChannelChange(player, channelToChangeTo);
						}
					});
				}
			});
		} else {
			if(receivedRewards.size() > 0) {
				SuperDebugger.runTaskAsynchronously(this.getClass(), plugin, new Runnable() {
					public void run() {
						StringBuilder rewardsRemover = new StringBuilder("");
						rewardsRemover.append("update rpg set rewards = placeholder");
						while(receivedRewards.size() > 1) {
							int k = receivedRewards.remove(0);
							String temp = rewardsRemover.toString().replace("placeholder", "insert(placeholder, locate('" + k + " ',placeholder),length('" + k + " '), '0 ')");
							rewardsRemover = new StringBuilder(temp);
						}
						int k = receivedRewards.remove(0);
						rewardsRemover.append(" where uuid=?");
						String rewardsRemoveString = rewardsRemover.toString().replace("placeholder", "insert(rewards, locate('" + k + " ',rewards),length('" + k + " '), '0 ')");
						plugin.executePrepared(rewardsRemoveString, uuid);
					}
				});
			}
			plugin.executePrepared(statement.toString(), forced, stringsOnly);
			plugin.executePrepared("UPDATE rpg SET " + "inventory" + "= ? WHERE uuid='" + uuid + "'", forced, serializeInventory());
			plugin.executePrepared("UPDATE rpg SET " + "bank" + "= ? WHERE uuid='" + uuid + "'", forced, serializeBank());
		}
		updateHealth();
		updateLevel();
		updateExp();
	}
	
	public ArrayList<Integer> receivedRewards = new ArrayList<Integer>();
	
	public void loadBank() {
		if(bank != null) {
			ItemStack[] items = bank.getContents();
			bank = Bukkit.createInventory(player, banklines * 9, player.getName() + "'s Bank");
			bank.setContents(items);
		} else {
			bank = Bukkit.createInventory(player, banklines * 9, player.getName() + "'s Bank");
		}
	}
	
	public String serializeInventory() {
		StringBuilder sb = new StringBuilder("");
		for(ItemStack i : player.getInventory().getContents()) {
			sb.append(convertItemToString(i) + "@");
		}
		sb.append("~");
		for(ItemStack i : player.getInventory().getArmorContents()) {
			sb.append(convertItemToString(i) + "@");
		}
		return sb.toString();
	}
	
	public void deserializeInventory(String serialized) {
		if(serialized == null) {
			serialized = serializeInventory();
		}
		String[] data = serialized.split("~");
		String[] inventoryContents = data[0].split("@");
		String[] armorContents = data[1].split("@");
		ItemStack[] inventoryItems = new ItemStack[player.getInventory().getContents().length];
		ItemStack[] armorItems = new ItemStack[player.getInventory().getArmorContents().length];
		for(int k = 0; k < inventoryContents.length; k++) {
			if(inventoryContents[k].length() > 0)
				inventoryItems[k] = convertStringToItem(inventoryContents[k]);
		}
		for(int k = 0; k < armorContents.length; k++) {
			if(armorContents[k].length() > 0)
				armorItems[k] = convertStringToItem(armorContents[k]);
		}
		player.getInventory().setContents(inventoryItems);
		player.getInventory().setArmorContents(armorItems);
	}
	
	public String serializeBank() {
		if(bank == null)
			loadBank();
		StringBuilder sb = new StringBuilder("");
		for(ItemStack i : bank.getContents()) {
			sb.append(convertItemToString(i) + "@");
		}
		return sb.toString();
	}
	
	public void deserializeBank(String serialized) {
		if(serialized == null) {
			serialized = serializeBank();
		}
		String[] inventoryContents = serialized.split("@");
		ItemStack[] inventoryItems = new ItemStack[inventoryContents.length];
		for(int k = 0; k < inventoryContents.length; k++) {
			if(inventoryContents[k].length() > 0)
				inventoryItems[k] = convertStringToItem(inventoryContents[k]);
		}
		if(bank.getSize() < inventoryItems.length)
			banklines++;
		loadBank();
		bank.setContents(inventoryItems);
	}
	
	public ItemStack convertStringToItem(String s) {
		if(s.equals("null"))
			return null;
		String[] data = s.split("#");
		ItemStack i = new ItemStack(Material.getMaterial(data[0]), Integer.parseInt(data[1]), Byte.parseByte(data[2]));
		if(data.length > 3) {
			if(data[3].toLowerCase().contains("ronbook") || data[3].toLowerCase().contains("navigator"))
				return null;
			ItemMeta im = i.getItemMeta();
			im.setDisplayName(data[3]);
			ArrayList<String> lore = new ArrayList<String>();
			for(int k = 4; k < data.length; k++)
				lore.add(data[k]);
			im.setLore(lore);
			i.setItemMeta(im);
		}
		return ItemHandler.removeAttributes(i);
	}
	
	public String convertItemToString(ItemStack i) {
		if(i == null)
			return "null";
		//type#amount#data#name#lores
		StringBuilder sb = new StringBuilder("");
		sb.append(i.getType() + "#");
		sb.append(i.getAmount() + "#");
		sb.append(i.getData().getData() + "#");
		if(i.hasItemMeta()) {
			ItemMeta im = i.getItemMeta();
			if(im.hasDisplayName())
				sb.append(im.getDisplayName() + "#");
			if(im.hasLore()) {
				for(String s : im.getLore())
					sb.append(s + "#");
			}
		}
		return sb.toString();
	}
	
	public Location getRespawnLocation() {
		Location toReturn = null;
		if(inDungeon)
			toReturn = DungeonHandler.loadedDungeons.get(dungeon).originalLocations.get(player.getName());
		else
			toReturn = WarpHandler.warps.get(spawn.toLowerCase());
		return toReturn == null ? WarpHandler.warps.get("mainspawn") : toReturn;
	}

	/*
	 * COMBAT
	 */
	
	/*public Class<? extends Projectile> getProjectile(boolean triedItemLoad) {
		ItemStack i = player.getItemInHand();
		if(ItemHandler.items.containsKey(i)) {
			if(Equip.BOW.isType(i))
				return Arrow.class;
			if(Equip.WAND.isType(i)) {
				int tier = 1;
				if(ItemHandler.items.containsKey(i)) {
					tier = ItemHandler.items.get(i).tier;
				}
				if(ClassHandler.getClassType(classType) == ClassType.WIZARD) {
					if(ClassHandler.checkPassive("Artificial T2", this))
						tier = 2;
					if(ClassHandler.checkPassive("Artificial T3", this))
						tier = 3;
					if(ClassHandler.checkPassive("Artificial T4", this))
						tier = 4;
					if(ClassHandler.checkPassive("Artificial T5", this))
						tier = 5;
				}
				switch(tier) {
					case 1:
						return Egg.class;
					case 2:
						return Snowball.class;
					case 3:
						return Fireball.class;
					case 4:
						return LargeFireball.class;
					case 5:
						return WitherSkull.class;
				}
			}
		} else {
			if(!triedItemLoad) {
				ItemHandler.loadItem(i);
				return getProjectile(true);
			} else {
				if(i.getType() == Material.BOW)
					return Arrow.class;
				else
					return Egg.class;
			}
		}
		if(i.getType() == Material.BOW)
			return Arrow.class;
		else
			return Egg.class;
	}
	
	public Class<? extends Projectile> getProjectile() {
		return getProjectile(false);
	}*/
	
	public ParticleType getWandEffect() {
		ItemStack i = player.getItemInHand();
		ParticleType pt = null;
		int tier = 1;
		if(ItemHandler.items.containsKey(i)) {
			tier = ItemHandler.items.get(i).tier;
		}
		if(ClassHandler.getClassType(classType) == ClassType.WIZARD) {
			if(ClassHandler.checkPassive("Artificial T2", this))
				tier = 2;
			if(ClassHandler.checkPassive("Artificial T3", this))
				tier = 3;
			if(ClassHandler.checkPassive("Artificial T4", this))
				tier = 4;
			if(ClassHandler.checkPassive("Artificial T5", this))
				tier = 5;
		}
		switch(tier) {
			case 1:
				pt = ParticleType.FIREWORKSPARK;
				break;
			case 2:
				pt = ParticleType.CRITICAL;
				break;
			case 3:
				pt = ParticleType.FIRE;
				break;
			case 4:
				pt = ParticleType.RAINBOWSWIRL;
				break;
			case 5:
				pt = ParticleType.MAGIC;
				break;
		}
		return pt;
	}
	
	public long getWandDelay() {
		ItemStack i = player.getItemInHand();
		double seconds = 1;
		int tier = 1;
		if(ItemHandler.items.containsKey(i)) {
			tier = ItemHandler.items.get(i).tier;
		}
		if(ClassHandler.getClassType(classType) == ClassType.WIZARD) {
			if(ClassHandler.checkPassive("Artificial T2", this))
				tier = 2;
			if(ClassHandler.checkPassive("Artificial T3", this))
				tier = 3;
			if(ClassHandler.checkPassive("Artificial T4", this))
				tier = 4;
			if(ClassHandler.checkPassive("Artificial T5", this))
				tier = 5;
		}
		switch(tier) {
			case 1:
				seconds = .8;
				break;
			case 2:
				seconds = .7;
				break;
			case 3:
				seconds = .6;
				break;
			case 4:
				seconds = .5;
				break;
			case 5:
				seconds = .4;
				break;
			case 6:
				seconds = .3;
				break;
		}
		if(ClassHandler.checkPassive("Speedcasting", this))
			seconds *= 0.85;
		return (long)(seconds * 1000000000);
	}
	
	public long getBowDelay() {
		ItemStack i = player.getItemInHand();
		double seconds = 1;
		int tier = 1;
		if(ItemHandler.items.containsKey(i)) {
			tier = ItemHandler.items.get(i).tier;
		}
		switch(tier) {
			case 1:
				seconds = .9;
				break;
			case 2:
				seconds = .8;
				break;
			case 3:
				seconds = .7;
				break;
			case 4:
				seconds = .6;
				break;
			case 5:
				seconds = .5;
				break;
			case 6:
				seconds = .4;
				break;
		}
		return (long)(seconds * 1000000000);
	}
	
	public boolean canCastSpell() {
		return nextSpellCast <= System.nanoTime();
	}
	
	public double getRemainingCooldownInSeconds() {
		double value =  (double)(nextSpellCast - System.nanoTime());
		if(value < 0) {
			nextSpellCast = 0;
			value = (double)(nextSpellCast - System.nanoTime());
		}
		return value / 1000000000.0;
	}
	
	public void registerCooldown(long cooldown, boolean isFromLoad) {
		if(ClassHandler.checkPassive("time warp", this) && Math.random() < 0.01) {
			player.sendMessage("You feel a warp in time resetting your spell cooldown.");
			return;
		}
		if(ClassHandler.checkPassive("time stasis", this) && Math.random() < 0.03) {
			player.sendMessage("You feel a statis in time resetting your spell cooldown.");
			return;
		}
		if(ClassHandler.checkPassive("spirit of kastia", this))
			cooldown *= 0.7;
		if(!isFromLoad)
			lastCooldownLength = cooldown;
		nextSpellCast = System.nanoTime() + cooldown;
		final PlayerData pd = this;
		cooldownTask = SuperDebugger.scheduleSyncRepeatingTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.updateCooldown();
			}
		}, 0, 10);
		taskIds.add(cooldownTask);
	}
	
	public void updateCooldown() {
		try {
			BigDecimal bd = BigDecimal.valueOf(nextSpellCast - System.nanoTime());
			if(bd.compareTo(BigDecimal.ZERO) < 0 || lastCooldownLength <= 0) {
				player.setFoodLevel(20);
				return;
			}
			bd = bd.divide(BigDecimal.valueOf(lastCooldownLength), 2, RoundingMode.HALF_UP);
			bd = bd.multiply(BigDecimal.valueOf(20));
			double value = bd.toBigInteger().doubleValue();
			if(bd.compareTo(BigDecimal.valueOf(20)) > 0) {
				player.setFoodLevel(20);
				return;
			}
			if(value > 19)
				value = 19;
			if(value < 1)
				value = 1;
			player.setFoodLevel((int)(20 - value));
		} catch(Exception e) {
			e.printStackTrace();
			player.setFoodLevel(20);
		}
		if(player.getFoodLevel() >= 20)
			try {
				plugin.getServer().getScheduler().cancelTask(cooldownTask);
			} catch(Exception e) {
				
			}
	}
	
	public void makeInvisible(int durationTicks) {
		if(invisible)
			return;
		if(inDungeon) {
			player.sendMessage(ChatColor.RED + "Invisibility cannot be used in dungeons!");
			return;
		}
		invisible = true;
		for(Player p : plugin.getServer().getOnlinePlayers())
			p.hidePlayer(p);
		for(Entity e : player.getNearbyEntities(10, 10, 10)) {
			if(e instanceof Creature) {
				((Creature)e).setTarget(null);
			}
		}
		player.sendMessage(ChatColor.RESET + "You are now invisible!");
		player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, durationTicks, 1));
		player.getLocation().getWorld().playEffect(player.getLocation(), Effect.SMOKE, 4);
		player.getLocation().getWorld().playSound(player.getLocation(), Sound.PORTAL_TRAVEL, 1, 1);
	}
	
	public void makeVisible() {
		if(!invisible)
			return;
		invisible = false;
		player.removePotionEffect(PotionEffectType.INVISIBILITY);
		for(Player p : plugin.getServer().getOnlinePlayers())
			p.showPlayer(p);
		player.sendMessage(ChatColor.RESET + "Your invisibility has worn off!");
	}
	
	public void applyDisable(int i) {
		if(Math.random() < 0.5 && ClassHandler.getClassType(classType) == ClassType.BARBARIAN && ClassHandler.checkPassive("Willpower", this)) {
			player.sendMessage(ChatColor.GOLD + "ROARRRR!! You scream your defiance, and ignore the enemy's disable.");
		} else {
			disabled = true;
			player.sendMessage("You have been disabled, and are no longer regenerating health!");
			final PlayerData pd = this;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					pd.disabled = false;
					pd.player.sendMessage("You are no longer disabled.");
				}
			}, i);
		}
	}
	
	/*
	 * BANKING
	 */
	
	public void takeGold(int i) {
		if(i > wallet) {
			player.sendMessage("You don't have enough money for that!");
			return;
		}
		wallet -= i;
	}
	
	public static ItemStack createBanknote(int value) {
		ItemStack i = new ItemStack(Material.PAPER);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Bank Note: " + value +"g");
		BigInteger uniqueId = new BigInteger(64, new Random());
		im.setLore(Arrays.asList(ChatColor.LIGHT_PURPLE + "A bank note worth " + value + " gold.", ChatColor.LIGHT_PURPLE + "Bank Note ID: " + uniqueId.toString()));
		i.setItemMeta(im);
		return i;
	}
	
	public void giveBanknote(int value) {
		if(value <= 0)
			return;
		player.getInventory().addItem(createBanknote(value));
	}
	
	public void checkBankGold() {
		int amount = 0;
		ArrayList<ItemStack> toRemove = new ArrayList<ItemStack>();
		for(ItemStack i : bank.getContents()) {
			if(i != null) {
				if(i.getType() == Material.GOLD_NUGGET) {
					amount += i.getAmount();
					toRemove.add(i);
				}
				if(i.getType() == Material.PAPER) {
					ItemMeta im = i.getItemMeta();
					if(im != null) {
						if(im.hasDisplayName() && im.getDisplayName().contains("Bank Note")) {
							amount += Integer.parseInt(ChatColor.stripColor(im.getDisplayName()).replaceAll("[^0-9]", ""));
							toRemove.add(i);
						}
					}
				}
			}
		}
		bank.removeItem(toRemove.toArray(new ItemStack[toRemove.size()]));
		bankGold += amount;
		if(amount > 0)
			player.sendMessage(ChatColor.GREEN + "Stored " + ChatColor.GOLD + amount + "g" + ChatColor.GREEN + " in your bank! You now have " + ChatColor.GOLD + bankGold + "g" + ChatColor.GREEN + ".");
	}
	
	public int getBankExpansionCost() {
		switch(banklines) {
			case 1:
				return 5000;
			case 2:
				return 10000;
			case 3:
				return 50000;
			case 4:
				return 100000;
			case 5:
				return 1000000;
		}
		return 1999999999;
	}
	
	public void openBank() {
		if(!uuidRetrieved)
			return;
		ItemStack i = new ItemStack(Material.ENDER_PEARL);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "" + "Gold Balance");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add(ChatColor.RESET + "Current balance: " + bankGold + "g");
		lore.add("");
		lore.add(ChatColor.RESET + "You can store a maximum of " + (banklines * 9 - 1) + " items in your bank.");
		lore.add("");
		lore.add(ChatColor.RESET + "" + ChatColor.RESET + "Left-click to withdraw gold to your wallet");
		lore.add(ChatColor.RESET + "" + ChatColor.RESET + "Right-click to withdraw a banknote");
		lore.add(ChatColor.RESET + "" + ChatColor.RESET + "Sneak+Right-click to deposit your wallet and banknotes");
		if(banklines < 6)
			lore.add(ChatColor.RESET + "" + ChatColor.RESET + "Sneak+Left-click to expand your bank size (Cost: " + getBankExpansionCost() + "g)");
		im.setLore(lore);
		i.setItemMeta(im);
		ItemStack i8 = bank.getItem(8);
		bank.setItem(8, i);
		if(i8 != null) {
			boolean isPearl = false;
			if(i8.hasItemMeta())
				if(i8.getItemMeta().hasDisplayName())
					if(i8.getItemMeta().getDisplayName().contains("Gold Balance"))
						isPearl = true;
			if(!isPearl)
				bank.addItem(i8);
		}
		player.openInventory(bank);
	}
	
	/*
	 * UPDATING STATS AND MENUS
	 */
	
	public int getTierReq(int tier) {
		switch(tier) {
			case 1:
				return 0;
			case 2:
				return 10;
			case 3:
				return 30;
			case 4:
				return 70;
			case 5:
				return 100;
		}
		return 100;
	}
	
	public int getMaxTier() {
		if(level < 10)
			return 1;
		if(level < 30)
			return 2;
		if(level < 70)
			return 3;
		if(level < 100)
			return 4;
		return 5;
	}
	
	public long lastunuseable = 0;
	
	public void updateArmorStats() {
		if(!uuidRetrieved)
			return;
		strength_temp = 0;
		dexterity_temp = 0;
		intelligence_temp = 0;
		luck_temp = 0;
		hpRegen_temp = 0;
		critChance_temp = 0;
		critDamage_temp = 150;
		lifesteal_temp = 0;
		maxHP_temp = 0;
		damageReduction = 0;
		damageReceivedIncrease = 0;
		attack = 0;
		ArrayList<ItemStack> equipment = new ArrayList<ItemStack>();
		equipment.addAll(Arrays.asList(player.getEquipment().getArmorContents()));
		if(!equipment.contains(player.getItemInHand())) {
			ItemStack i = player.getItemInHand();
			if(ItemHandler.isWeapon(i.getType()))
				equipment.add(player.getItemInHand());
		}
		boolean unuseable = false;
		for(ItemStack i : equipment) {
			i.setDurability((short) 0);
			if(ItemHandler.loadItem(i)) {
				ItemData id = ItemHandler.items.get(i);
				if(level < getTierReq(id.tier)) {
					unuseable = true;
				} else {
					strength_temp += id.strength;
					dexterity_temp += id.dexterity;
					intelligence_temp += id.intelligence;
					luck_temp += id.luck;
					hpRegen_temp += id.hpRegen;
					critChance_temp += id.critChance;
					critDamage_temp += id.critDamage;
					lifesteal_temp += id.lifesteal;
					maxHP_temp += id.hp;
					attack += id.attack;
				}
			}
		}
		if(unuseable && System.currentTimeMillis() - lastunuseable > 10000 && options.checkOption("tierwarning")) {
			lastunuseable = System.currentTimeMillis();
			player.sendMessage(ChatColor.RED + "You are not high enough level to use some of your equipment.");
			player.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "You will not receive any bonuses from those equips.");
			player.sendMessage(ChatColor.RED + "You can only use equipment up to Tier " + getMaxTier() + ".");
			player.sendMessage(ChatColor.RED + "At level " + getTierReq(getMaxTier() + 1) + " you can use Tier " + (getMaxTier() + 1) + " equips.");
			player.sendMessage(ChatColor.RED + "To disable this message, go to /options and turn off Tier Warning.");
		}
		critChance_temp += critChance_buff;
		lifesteal_temp += lifesteal_buff;
		if(indomitable_buff)
			damageReduction += indomitableValue_buff;
		if(ClassHandler.getClassType(classType) == ClassType.CRUSADER) {
			if(ClassHandler.checkPassive("regeneration", this))
				hpRegen_temp += 3;
			if(ClassHandler.checkPassive("self recovery", this))
				hpRegen_temp += (int)(0.01 * (maxHP_temp + maxHP));
			if(ClassHandler.checkPassive("power stance", this)) {
				damageReduction += 5;
			}
			if(ClassHandler.checkPassive("stalwart", this)) {
				damageReduction += 8;
			}
			if(ClassHandler.checkPassive("combat prowess", this)) {
				damageReduction += 5;
			}
			if(ClassHandler.checkPassive("hero's will", this)) {
				damageReduction += 15;
			}
			if(ClassHandler.checkPassive("combat master", this)) {
				damageReduction += 10;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.BERSERKER) {
			if(ClassHandler.checkPassive("savage", this)) {
				lifesteal_temp += 5;
			}
			if(ClassHandler.checkPassive("blood lust", this)) {
				lifesteal_temp += 10;
			}
			if(ClassHandler.checkPassive("rage", this)) {
				damageReceivedIncrease += 10;
			}
			if(ClassHandler.checkPassive("reckless", this)) {
				damageReceivedIncrease += 20;
			}
			if(ClassHandler.checkPassive("berserk", this)) {
				damageReceivedIncrease += 15;
			}
			if(ClassHandler.checkPassive("dangerous game", this)) {
				damageReceivedIncrease += 20;
			}
			if(desperationActive) {
				lifesteal_temp += 50;
			}
			if(undyingRageActive) {
				damageReduction += 35;
			}
			if(survivalInstinctActive) {
				damageReduction += 50;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.PALADIN) {
			if(ClassHandler.checkPassive("barricade", this)) {
				damageReduction += 7;
			}
			if(ClassHandler.checkPassive("valiant", this)) {
				damageReduction += 4;
			}
			if(ClassHandler.checkPassive("holy mastery", this)) {
				damageReduction += 12;
			}
			if(ClassHandler.checkPassive("transcendent", this)) {
				damageReduction += 15;
			}
			if(ClassHandler.checkPassive("citadel", this)) {
				damageReduction += 18;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.CLERIC) {
			if(ClassHandler.checkPassive("recovery", this)) {
				hpRegen_temp += (int)(0.05 * (maxHP_temp + maxHP));
			}
			if(ClassHandler.checkPassive("ascension", this)) {
				hpRegen_temp += (int)(0.08 * (maxHP_temp + maxHP));
			}
			if(ClassHandler.checkPassive("defense stance", this)) {
				damageReduction += 6;
			}
			if(ClassHandler.checkPassive("survival stance", this)) {
				damageReduction += 10;
			}
			if(ClassHandler.checkPassive("fortification stance", this)) {
				damageReduction += 18;
			}
			if(ClassHandler.checkPassive("invulnerability stance", this)) {
				damageReduction += 16;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.WIZARD) {
			if(ClassHandler.checkPassive("true wizardry", this)) {
				damageReduction += 20;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.ARCHER) {
			if(ClassHandler.checkPassive("critical prowess", this)) {
				critDamage_temp += 10;
			}
			if(ClassHandler.checkPassive("critical mastery", this)) {
				critDamage_temp += 20;
			}
			if(ClassHandler.checkPassive("vital vision", this)) {
				critDamage_temp += 30;
			}
			if(ClassHandler.checkPassive("sniper", this)) {
				critDamage_temp += 50;
			}
			if(ClassHandler.checkPassive("nimble body", this)) {
				damageReduction += 5;
			}
			if(ClassHandler.checkPassive("nature shield", this)) {
				damageReduction += 10;
			}
			if(ClassHandler.checkPassive("forest essence", this)) {
				damageReduction += 20;
			}
		} else if(ClassHandler.getClassType(classType) == ClassType.BARBARIAN) {
			if(ClassHandler.checkPassive("persistent", this)) {
				hpRegen_temp += 5;
			}
			if(ClassHandler.checkPassive("tireless", this)) {
				hpRegen_temp += (int)(0.2 * (hpRegen_temp + hpRegen));
			}
			if(ClassHandler.checkPassive("beefy", this)) {
				maxHP_temp += (int)(0.05 * (maxHP_temp + maxHP));
			}
			if(ClassHandler.checkPassive("massive", this)) {
				maxHP_temp += (int)(0.10 * (maxHP_temp + maxHP));
			}
			if(ClassHandler.checkPassive("barbaric", this)) {
				maxHP_temp += (int)(0.30 * (maxHP_temp + maxHP));
			}
			if(ClassHandler.checkPassive("primitive", this)) {
				strength_temp += 10;
				dexterity_temp += 10;
				intelligence_temp += 10;
				luck_temp += 10;
			}
			if(ClassHandler.checkPassive("versatility", this)) {
				strength_temp += (int)(0.1 * (strength_temp + strength));
				dexterity_temp += (int)(0.1 * (dexterity_temp + dexterity));
				intelligence_temp += (int)(0.1 * (intelligence_temp + intelligence));
				luck_temp += (int)(0.1 * (luck_temp + luck));
			}
		}
		
		if(GuildHandler.checkBuff(player, "damagereduction"))
			damageReduction += 10;
		
		if(critChance_temp > 100)
			critChance = 100;
		if(damageReduction > 85)
			damageReduction = 85;
		updateRonbook();
	}
	
	public void updateRonbook() {
		if(!uuidRetrieved)
			return;
		ItemStack itemStackronbook = null;
		boolean noBook = true;
		for(int k = 0; k < player.getInventory().getContents().length; k++) {
			try {
				ItemStack item = player.getInventory().getContents()[k];
				if(item.hasItemMeta() && item.getItemMeta().getDisplayName().contains("Ronbook")) {
					noBook = false;
					itemStackronbook = item;
					break;
				}
			} catch(Exception e) {
				
			}
		}
		if(itemStackronbook == null) {
			itemStackronbook = new ItemStack(Material.WRITTEN_BOOK);
		}
		itemStackronbook.setAmount(1);
		ItemMeta im = itemStackronbook.getItemMeta();
		String displayName = ChatColor.RESET + "" + ChatColor.AQUA + "The Ronbook " + ChatColor.YELLOW + "[" + ChatColor.GOLD + wallet + "g" + ChatColor.YELLOW + "]";
		im.setDisplayName(displayName);
		ArrayList<String> bookLore = new ArrayList<String>();
		bookLore.add(ChatColor.RESET + "" + ChatColor.YELLOW + ChatColor.BOLD + "Wallet: " + ChatColor.GOLD + ChatColor.BOLD + wallet + "g - " + ChatColor.YELLOW + "/wallet " + ChatColor.WHITE + "for more info.");
		bookLore.add(ChatColor.RESET + "");
		bookLore.add(ChatColor.RESET + "" + ChatColor.BOLD + "Left-Click: Open Class Menu");
		bookLore.add(ChatColor.RESET + "" + ChatColor.BOLD + "Right-Click: Open Book");
		bookLore.add(ChatColor.RESET + "" + ChatColor.BOLD + "Sneak+Left-Click: Open Stats Menu");
		im.setLore(bookLore);
		BookMeta bookMetaronbook = (BookMeta)im;
		bookMetaronbook.setAuthor(playerName);
		bookMetaronbook.setTitle(displayName);
		int pageNum = 1;
		bookMetaronbook.setPages("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Character Stats" +
   				   ChatColor.RESET + "\nLevel: " + level +
				   ChatColor.RESET + "\nRank: "  + RankManager.getPrefix(player.getName()) +
				   ChatColor.RESET + "\nClass: " + (classType != null ? classType.equals("") ? "None" : classType : "None") +
				   ChatColor.RESET + "\nEXP: " + ((exp + "/" + getExpForNextLevel(level)).length() > 14 ? exp + "/\n" + getExpForNextLevel(level) : exp + "/" + getExpForNextLevel(level)) +
				   " \n" +
				   ChatColor.RESET + "\nMax HP: " + (maxHP + maxHP_temp) +   
				   ChatColor.RESET + "\nHP Regen: " + (hpRegen + hpRegen_temp) + " HP/s" + (hpRegen + hpRegen_temp > 9999 ? "" : "ec") +  
				   ChatColor.RESET + "\nSTR: " + (strength + strength_temp) +  
				   ChatColor.RESET + "\nDEX: " + (dexterity + dexterity_temp) + 
				   ChatColor.RESET + "\nINT: " + (intelligence + intelligence_temp) + 
				   ChatColor.RESET + "\nLUK: " + (luck + luck_temp) +
				   " \n" +
				   ChatColor.RESET + "\nBank: " + (bankGold) + "g"
			   );
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "The following pages will cover specific info for each Class.\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.BOLD + ChatColor.UNDERLINE + "Terminology\n" +
				   ChatColor.RESET + " \n" +
				   ChatColor.BOLD + "STR" + ChatColor.RESET + " = Strength\n" +
				   ChatColor.BOLD + "DEX" + ChatColor.RESET + " = Dexterity\n" +
				   ChatColor.BOLD + "INT" + ChatColor.RESET + " = Intelligence\n" +
				   ChatColor.BOLD + "LUK" + ChatColor.RESET + " = Luck\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Crusader\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "STR\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "DEX\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Swords\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Wands, Bows, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Berserker\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "STR\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "LUK\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Axes\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Wands, Bows, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Paladin\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "STR\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "INT\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Maces\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Wands, Bows, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Cleric\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "STR\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "INT\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Staves\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Wands, Bows, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Wizard\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "INT\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "LUK\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Wands\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Swords, Axes, Maces, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Archer\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "DEX\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "STR\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Bows\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Swords, Axes, Maces, Daggers\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Assassin\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "LUK\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "DEX\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Daggers\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Swords, Axes, Maces, Wands, Bows\n"
				);
		bookMetaronbook.addPage("");
		bookMetaronbook.setPage(pageNum++, ChatColor.BOLD + "Class Overview\n" + 
				   ChatColor.RESET + ChatColor.RESET + "Barbarian\n" + 
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Primary Stat: " + ChatColor.BOLD + "ALL\n" +
				   ChatColor.RESET + "Secondary Stat: " + ChatColor.BOLD + "None\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Specialty: \n" +
				   ChatColor.RESET + "Bones\n" +
				   ChatColor.RESET + " \n" + 
				   ChatColor.RESET + "Weakness: \n" + 
				   ChatColor.RESET + "Everything else!\n"
				);
		itemStackronbook.setItemMeta(bookMetaronbook);
		if(noBook)
			player.getInventory().addItem(itemStackronbook);
		PlayerData clone = (PlayerData)(this.clone());
        GeneralListeners.clonedPDs.remove(player);
        GeneralListeners.clonedPDs.put(player.getName(), clone);
	}
	
	public void addShield(double i) {
		shield += i;
		if(shield > getShieldMax()) {
			shield = getShieldMax();
			player.sendMessage(ChatColor.RED + "You have reached your max shield size of " + getShieldMax() + " HP.");
		}
	}
	
	public int getShieldMax() {
		return level * 50;
	}
	
	public void giveQuestLog() {
		if(!uuidRetrieved)
			return;
		int toRemove = -1;
		for(int k = 0; k < player.getInventory().getContents().length; k++) {
			try {
				ItemStack item = player.getInventory().getContents()[k];
				if(item.hasItemMeta()) {
					if(item.getItemMeta().getDisplayName().contains("Quest Log")) {
						toRemove = k;
						break;
					}
				}
			} catch(Exception e) {
				
			}
		}
		player.sendMessage("Here is your Quest Log! Left click while holding the quest log to update it.");
		ItemStack questlogItem = new ItemStack(Material.WRITTEN_BOOK);
		ItemMeta im = questlogItem.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + player.getName() + "'s Quest Log");
		ArrayList<String> bookLore = new ArrayList<String>();
		bookLore.add(ChatColor.RESET + "Quests galore! Left click while");
		bookLore.add(ChatColor.RESET + "holding this log to update it.");
		im.setLore(bookLore);
		BookMeta questlogMeta = (BookMeta)im;
		questlogMeta.setAuthor(player.getName());
		questlogMeta.setTitle(player.getName() + "'s Quest Log");
		int pageNum = 1;
		questlogMeta.addPage("");
		questlogMeta.setPage(1, "You aren't doing any quests!");
		for(Quest q : QuestHandler.quests.values()) {
			if(q.noInfo)
				continue;
			questlogMeta.addPage("");
			String s = q.getObjective(this);
			questlogMeta.setPage(pageNum++, ChatColor.BOLD + q.name + "\n" + 
					   ChatColor.RESET + "\n" + 
					   ChatColor.RESET + "Required Level: " + q.reqLevel + "\n" +
					   ChatColor.RESET + "Required Quest:\n" + (q.reqQuest == 0 ? "None" : QuestHandler.quests.get(q.reqQuest).name) + "\n" +
					   ChatColor.RESET + "Status: " + (inProgressQuests.containsKey(q) ? "In Progress..." : completedQuests.contains(q) ? "Complete!" : "Not started.") + "\n" + 
					   ChatColor.RESET + "\n" + 
					   ChatColor.RESET + "Current Objective: \n" +
					   ChatColor.RESET + s + "\n"
					);
		}
		questlogItem.setItemMeta(questlogMeta);
		if(toRemove != -1 && player.getInventory().getContents()[toRemove] != null && player.getInventory().getContents()[toRemove].hasItemMeta()
				&& player.getInventory().getContents()[toRemove].getItemMeta().hasDisplayName() 
				&& player.getInventory().getContents()[toRemove].getItemMeta().getDisplayName().contains("Quest Log"))
			player.getInventory().setItem(toRemove, questlogItem);
		else
			player.getInventory().addItem(questlogItem);
	}
	
	public void openStatsMenu() {
		if(!uuidRetrieved)
			return;
		Inventory inventory = Bukkit.createInventory(null, 9 * 2, "Assign Your Stat Points!");
		updateStatsMenu(inventory);
		player.openInventory(inventory);
	}
	
	public void updateStatsMenu(Inventory inventory) {
		if(!uuidRetrieved)
			return;
		ItemStack i = new ItemStack(Material.BOOK_AND_QUILL, 1);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.BOLD + "Base Stats");
		im.setLore(Arrays.asList(
	    		ChatColor.RESET + "" + ChatColor.GOLD + "Level: " + level,
	    		"",
				ChatColor.RESET + "" + ChatColor.AQUA + "Max HP: " + ChatColor.GREEN + maxHP, 
				ChatColor.RESET + "" + ChatColor.AQUA + "STR: " + ChatColor.GREEN + strength, 
				ChatColor.RESET + "" + ChatColor.AQUA + "DEX: " + ChatColor.GREEN + dexterity, 
				ChatColor.RESET + "" + ChatColor.AQUA + "INT: " + ChatColor.GREEN + intelligence, 
				ChatColor.RESET + "" + ChatColor.AQUA + "LUK: " + ChatColor.GREEN + luck
				));
		i.setItemMeta(im);
		inventory.setItem(0, i);
		
		i = new ItemStack(Material.NETHER_STAR);
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.BOLD + "Available Stat Points:");
		im.setLore(Arrays.asList(
				   ChatColor.RESET + "Total: " + (sp > 0 ? ChatColor.GREEN : ChatColor.RED) +  sp,
				   ChatColor.RESET + "Assigned: " + (SP_assigned > 0 ? ChatColor.GREEN : ChatColor.WHITE) +  SP_assigned,
				   ChatColor.RESET + "Remaining: " + (SP_assigned > 0 ? ChatColor.RED : ChatColor.WHITE) +  (sp - SP_assigned)
	        	));
		i.setItemMeta(im);
		inventory.setItem(1, i);

		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLUE.getData());
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + "Stat Point Information (1/2)");
		im.setLore(Arrays.asList(Values.stringToLore(ChatColor.GOLD + "IMPORTANT - READ ALL OF THIS!" + ChatColor.RED +" Each class in Kastia has a Primary Stat and a Secondary Stat from among STR, DEX, INT, and LUK. "
				+ "Together, these two stats are a major factor in determining your damage. So, it is important to put your stat points "
				+ "in the Primary or Secondary Stat for your class. You can check the Primary and Secondary stat for your class in the Ronbook. "
				+ "However, it is difficult to reset your Stat Points once they have been assigned - you will need a rare SP Reset Scroll.", ChatColor.RED)));
		i.setItemMeta(im);
		inventory.setItem(0 + 9, i);

		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.BLUE.getData());
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + "Stat Point Information (2/2)");
		im.setLore(Arrays.asList(Values.stringToLore("This can put you behind if you ever decide to "
				+ "switch classes, so keep that in mind. It is helpful to switch between classes that have a shared Primary or Secondary stat, "
				+ "so that when you switch you don't lose out on too much damage. Your Secondary Stat is also used in your minimum damage calculations, so the "
				+ "closer your Secondary Stat is to your Primary Stat, the higher your damage will be on average, since your minimum damage will be higher.", ChatColor.RED)));
		i.setItemMeta(im);
		inventory.setItem(1 + 9, i);
		
		i = new ItemStack(Material.IRON_SWORD);
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + ChatColor.BOLD + "Strength");
		im.setLore(Arrays.asList(
				ChatColor.RESET + "" + ChatColor.AQUA + "Current: " +  strength,
				ChatColor.RESET + "" + ChatColor.AQUA + "Assigned: " +  strength_assigned,
	        	ChatColor.RESET + "" + ChatColor.GOLD + "Assign 1 SP to " + ChatColor.LIGHT_PURPLE + "+1 STR"
	        	));
		i.setItemMeta(im);
		inventory.setItem(4, ItemHandler.removeAttributes(i));
		
		i = new ItemStack(Material.FEATHER);
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + ChatColor.BOLD + "Dexterity");
		im.setLore(Arrays.asList(
				ChatColor.RESET + "" + ChatColor.AQUA + "Current: " +  dexterity,
				ChatColor.RESET + "" + ChatColor.AQUA + "Assigned: " +  dexterity_assigned,
	        	ChatColor.RESET + "" + ChatColor.GOLD + "Assign 1 SP to " + ChatColor.LIGHT_PURPLE + "+1 DEX"
	        	));
		i.setItemMeta(im);
		inventory.setItem(5, i);
		
		i = new ItemStack(Material.BOOK);
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + ChatColor.BOLD + "Intelligence");
		im.setLore(Arrays.asList(
				ChatColor.RESET + "" + ChatColor.AQUA + "Current: " +  intelligence,
				ChatColor.RESET + "" + ChatColor.AQUA + "Assigned: " +  intelligence_assigned,
	        	ChatColor.RESET + "" + ChatColor.GOLD + "Assign 1 SP to " + ChatColor.LIGHT_PURPLE + "+1 INT"
	        	));
		i.setItemMeta(im);
		inventory.setItem(4+9, i);
		
		i = new ItemStack(Material.GOLD_INGOT);
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + ChatColor.BOLD + "Luck");
		im.setLore(Arrays.asList(
				ChatColor.RESET + "" + ChatColor.AQUA + "Current: " +  luck,
				ChatColor.RESET + "" + ChatColor.AQUA + "Assigned: " +  luck_assigned,
	        	ChatColor.RESET + "" + ChatColor.GOLD + "Assign 1 SP to " + ChatColor.LIGHT_PURPLE + "+1 LUK"
	        	));
		i.setItemMeta(im);
		inventory.setItem(5+9, i);

		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + "Click to Cancel");
		im.setLore(Arrays.asList(
				   ChatColor.RESET + "" + ChatColor.RED + "Cancel the stat points you have",
				   ChatColor.RESET + "" + ChatColor.RED + "assigned but not locked in."
	        	));
		i.setItemMeta(im);
		inventory.setItem(8, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
		im = i.getItemMeta();
		im.setDisplayName(ChatColor.RESET + "" + ChatColor.GREEN + "Click to Confirm");
		im.setLore(Arrays.asList(
				   ChatColor.RESET + "" + ChatColor.GOLD + "Strength +" + strength_assigned,
				   ChatColor.RESET + "" + ChatColor.GOLD + "Dexterity +" + dexterity_assigned,
				   ChatColor.RESET + "" + ChatColor.GOLD + "Intelligence +" + intelligence_assigned,
				   ChatColor.RESET + "" + ChatColor.GOLD + "Luck +" + luck_assigned,
				   "",
				   ChatColor.RESET + "" + ChatColor.RED + "Warning:",
				   ChatColor.RESET + "" + ChatColor.RED + "Once you have locked in your stat points,",
				   ChatColor.RESET + "" + ChatColor.RED + "you may not change them anymore!"
	        	));
		i.setItemMeta(im);
		inventory.setItem(8 + 9, i);
	}
	
	/*
	 * EXP + LEVEL METHODS
	 */
	
	public static Object[][] expreqs = {
		{2, 25},
		{3, 30},
		{4, 67},
		{5, 92},
		{6, 135},
		{7, 272},
		{8, 360},
		{9, 440},
		{10, 542},
		{11, 642},
		{12, 742},
		{13, 842},
		{14, 942},
		{15, 1042},
		{16, 1290},
		{17, 1388},
		{18, 1546},
		{19, 1875},
		{20, 2590},
		{21, 3508},
		{22, 4550},
		{23, 6340},
		{24, 9408},
		{25, 10690},
		{26, 11228},
		{27, 12074},
		{28, 15289},
		{29, 19947},
		{30, 20136},
		{31, 25136},
		{32, 30136},
		{33, 35136},
		{34, 40136},
		{35, 45136},
		{36, 50963},
		{37, 55556},
		{38, 60067},
		{39, 65681},
		{40, 70616},
		{41, 75425},
		{42, 80539},
		{43, 85982},
		{44, 90781},
		{45, 95963},
		{46, 100560},
		{47, 105605},
		{48, 110033},
		{49, 115084},
		{50, 120799},
		{51, 123023},
		{52, 125905},
		{53, 129497},
		{54, 139857},
		{55, 151046},
		{56, 163129},
		{57, 176180},
		{58, 190274},
		{59, 205496},
		{60, 221936},
		{61, 239691},
		{62, 258866},
		{63, 279575},
		{64, 301941},
		{65, 326097},
		{66, 352184},
		{67, 380359},
		{68, 410788},
		{69, 443651},
		{70, 479143},
		{71, 479143},
		{72, 479143},
		{73, 479143},
		{74, 479143},
		{75, 479143},
		{76, 512683},
		{77, 548571},
		{78, 586971},
		{79, 628059},
		{80, 672024},
		{81, 719065},
		{82, 769400},
		{83, 823258},
		{84, 880886},
		{85, 942548},
		{86, 1008526},
		{87, 1079123},
		{88, 1154662},
		{89, 1235488},
		{90, 1321972},
		{91, 1414510},
		{92, 1513526},
		{93, 1619473},
		{94, 1732836},
		{95, 1854135},
		{96, 1983924},
		{97, 2122799},
		{98, 2271395},
		{99, 2430393},
		{100, 2600521},
		{101, 2782557},
		{102, 2977336},
		{103, 3185750},
		{104, 3408753},
		{105, 3647366},
		{106, 3902682},
		{107, 4175870},
		{108, 4468181},
		{109, 4780954},
		{110, 5115621},
		{111, 5473714},
		{112, 5856874},
		{113, 6266855},
		{114, 6705535},
		{115, 7174922},
		{116, 7677167},
		{117, 8214569},
		{118, 8789589},
		{119, 9404860},
		{120, 10063200},
		{121, 10063200},
		{122, 10063200},
		{123, 10063200},
		{124, 10063200},
		{125, 10063200},
		{126, 10767624},
		{127, 11521358},
		{128, 12327853},
		{129, 13190803},
		{130, 14114159},
		{131, 15102150},
		{132, 16159301},
		{133, 17290452},
		{134, 18500784},
		{135, 19795839},
		{136, 21181548},
		{137, 22664256},
		{138, 24250754},
		{139, 25948307},
		{140, 27764688},
		{141, 29708216},
		{142, 31787791},
		{143, 34012936},
		{144, 36393842},
		{146, 41667310},
		{147, 44584022},
		{148, 47704904},
		{149, 51044247},
		{150, 54617344},
		{151, 58440558},
		{152, 62531397},
		{153, 66908595},
		{154, 71592197},
		{155, 76603651},
		{156, 81965907},
		{157, 87703520},
		{158, 93842766},
		{159, 100411760},
		{160, 107440583},
		{161, 113887018},
		{162, 120720239},
		{163, 127963453},
		{164, 135641260},
		{165, 143779736},
		{166, 152406520},
		{167, 161550911},
		{168, 171243966},
		{169, 181518604},
		{170, 192409720},
		{171, 203954303},
		{172, 216191561},
		{173, 229163055},
		{174, 242912838},
		{175, 257487608},
		{176, 272936864},
		{177, 289313076},
		{178, 306671861},
		{179, 325072173},
		{180, 344576503},
		{181, 365251093},
		{182, 387166159},
		{183, 410396129},
		{184, 435019897},
		{185, 461121091},
		{186, 488788356},
		{187, 518115657},
		{188, 549202596},
		{189, 582154752},
		{190, 617084037},
		{191, 654109079},
		{192, 693355624},
		{193, 734956961},
		{194, 779054379},
		{195, 825797642},
		{196, 875345501},
		{197, 927866231},
		{198, 983538205},
		{199, 1042550497},
		{200, 1105103527},
	};
	
	public static HashMap<Integer, Long> expreqs_map;
	
	public static long getExpForNextLevel(int currentLevel) {
		if(expreqs_map == null) {
			expreqs_map = new HashMap<Integer, Long>();
			for(Object[] o : expreqs) {
				expreqs_map.put(Integer.parseInt(o[0] + ""), Long.parseLong(o[1] + ""));
			}
		}
		if(expreqs_map.containsKey(currentLevel + 1)) {
			return expreqs_map.get(currentLevel + 1);
		} else if(currentLevel >= 200) {
			return expreqs_map.get(200) + 300 * (int)Math.pow(2.0, (currentLevel + 1 - 200) / 7.0);
		} else {
			return Integer.MAX_VALUE;
		}
//		double x = 0;
//		for(int k = 1; k <= currentLevel; k++) {
//			x += Math.floor(k + 300 * Math.pow(2.0, k / 7.0));
//		}
//		return (long) (Math.floor(x/4));
	}
	
	public void addExp(long exp) {
		addExp(exp, null);
	}
	
	public void addExp(long exp, Player source) {
		exp *= Values.GLOBAL_EXP_RATE * Values.EXP_BONUS;
		if(RankManager.check(player, "knight"))
			exp *= Values.VIP_EXP_RATE;
		if(expBooster >= 1) {
			plugin.db(player, "EXP BOOST: " + exp + " -> " + (int)(exp * expBooster));
			exp *= expBooster;
		}
		if(GuildHandler.checkBuff(player, "exp")) {
			plugin.db(player, "GUILD BOOST: " + exp + " -> " + (int)(exp * 1.1));
			exp *= 1.1;
		}
		if(exp < 1)
			return;
		if(party != null && source == null) {
			if(party.members.size() > 1) {
				plugin.db(player, ChatColor.GREEN + "" + ChatColor.BOLD + "+" + exp + " (+" + (long)(party.getExpMultiplier() * exp) + ") PARTY EXP");
				for(Player p : party.getMembers()) {
					try {
						if(player != p && p.getLocation().distance(p.getLocation()) < 150 && Math.abs(plugin.getPD(p).level - party.averagePartyLevel()) < 35)
							plugin.getPD(p).addExp((long)(exp * party.getExpMultiplier() / party.getMembers().size()), p);
					} catch(Exception e) {
						
					}
				}
				exp *= 1 + party.getExpMultiplier();
			}
		} else if(source != null) {
			plugin.db(player, ChatColor.GREEN + "" + ChatColor.BOLD + "+" + exp + " PARTY EXP");
		} else {
			plugin.db(player, ChatColor.GREEN + "" + ChatColor.BOLD + "+" + exp + " EXP");
		}
		setExp(this.exp + exp);
		player.playSound(player.getLocation(), Sound.ORB_PICKUP, 7, 1);
		checkLevelUp();
		updateExp();
		updateRonbook();
	}
	
	public void setExp(long exp) {
		this.exp = exp;
		updateExp();
		updateRonbook();
	}
	
	public void updateExp() {
		player.setExp(((float)exp) / getExpForNextLevel(level));
	}
	
	public int getGuildPoints() {
		return guildPoints;
	}
	
	public void addGuildPoints(int amount) {
		if(GuildHandler.getGuild(player) != null) {
			player.sendMessage(ChatColor.GRAY + ">> +" + amount + " Guild Points");
			guildPoints += amount;
			plugin.execute("update rpg set guildPoints = " + guildPoints + " where uuid = '" + uuid + "'");
		}
	}
	
	public void spendGuildPoints(int amount) {
		if(GuildHandler.getGuild(player) != null) {
			guildPoints -= amount;
			plugin.execute("update rpg set guildPoints = " + guildPoints + " where uuid = '" + uuid + "'");
		}
	}
	
	public void checkLevelUp() {
		if(exp >= getExpForNextLevel(level)) {
			exp -= getExpForNextLevel(level);
			level++;
			if(level < 10)
				addGuildPoints(20);
			else if(level < 20)
				addGuildPoints(25);
			else if(level < 30)
				addGuildPoints(35);
			else if(level < 40)
				addGuildPoints(50);
			else if(level < 50)
				addGuildPoints(70);
			else if(level < 60)
				addGuildPoints(90);
			else if(level < 70)
				addGuildPoints(110);
			else if(level < 80)
				addGuildPoints(130);
			else if(level < 90)
				addGuildPoints(150);
			else if(level < 100)
				addGuildPoints(180);
			else if(level < 110)
				addGuildPoints(250);
			else if(level < 120)
				addGuildPoints(300);
			else if(level < 130)
				addGuildPoints(400);
			else
				addGuildPoints(500);
			maxHP += Values.HP_PER_LEVEL;
			hp += Values.HP_PER_LEVEL;
			sp += Values.SP_PER_LEVEL;
			player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Congratulations! " + ChatColor.GOLD + "You are now Level " + level + ChatColor.GOLD + ChatColor.BOLD + "!");
			player.sendMessage(ChatColor.GOLD + "You gain 5 Stat Points. Sneak+Left-Click with the Ronbook to assign your SP.");
			player.playSound(player.getLocation(), Sound.LEVEL_UP, 1, 1);
			updateRonbook();
			player.setLevel(level);
			checkLevelUp();
			updateLevel();
			if(level == 30) {
				int[][] expandedPassives = new int[2][2];
				for(int k = 0; k < activePassives.length; k++) {
					expandedPassives[k][0] = activePassives[k][0];
					expandedPassives[k][1] = activePassives[k][1];
				}
				activePassives = expandedPassives;
				player.sendMessage(ChatColor.GOLD + "IMPORTANT: As a level 30, you can now have 2 passives active at once!");
			} else if (level == 70){
				int[][] expandedPassives = new int[3][2];
				for(int k = 0; k < activePassives.length; k++) {
					expandedPassives[k][0] = activePassives[k][0];
					expandedPassives[k][1] = activePassives[k][1];
				}
				activePassives = expandedPassives;
				player.sendMessage(ChatColor.GOLD + "IMPORTANT: As a level 70, you can now have 3 passives active at once!");
			}
		}
	}
	
	public Arrow shootArrow() {
		Projectile p = player.launchProjectile(Arrow.class);
		p.setVelocity(p.getVelocity().normalize().multiply(2));
		return (Arrow)p;
	}
	
	public void updateLevel() {
		if(!uuidRetrieved)
			return;
		player.setLevel(level);
	}
	
	/*
	 * HP + HP CHANGING METHODS
	 */
	
	public boolean desperationActive = false;
	public boolean undyingRageActive = false;
	public boolean survivalInstinctActive = false;
	
	public void updateHealth() {
		if(!fullyLoaded)
			return;
		if(player.isDead())
			return;
		if(hp <= 0)
			hp = 0;
		if(hp > maxHP + maxHP_temp) {
			hp = maxHP + maxHP_temp;
		}
		double percentage = ((double) hp / (maxHP + maxHP_temp));
		double hearts = percentage * 20;
		if(hearts <= 1 && hp > 0)
			hearts = 1;
		if(hearts > 20)
			hearts = 20;
		if(hp <= 0) {
			hearts = 1;
			die();
		}
		player.setHealth(hearts);
		if(ClassHandler.checkPassive("desperation", this)) {
			if(((double)hp)/(maxHP + maxHP_temp) < 0.4) {
				if(!desperationActive) {
					desperationActive = true;
					updateArmorStats();
				}
			} else {
				if(desperationActive) {
					desperationActive = false;
					updateArmorStats();
				}
			}
		}
		if(ClassHandler.checkPassive("undying rage", this)) {
			if(((double)hp)/(maxHP + maxHP_temp) < 0.4) {
				if(!undyingRageActive) {
					undyingRageActive = true;
					updateArmorStats();
				}
			} else {
				if(undyingRageActive) {
					undyingRageActive = false;
					updateArmorStats();
				}
			}
		}
		if(ClassHandler.checkPassive("survival instinct", this)) {
			if(((double)hp)/(maxHP + maxHP_temp) < 0.5) {
				if(!survivalInstinctActive) {
					survivalInstinctActive = true;
					updateArmorStats();
				}
			} else {
				if(survivalInstinctActive) {
					survivalInstinctActive = false;
					updateArmorStats();
				}
			}
		}
		//can add a sound here for checking if hp <= 0 then play a death sound :) since right now there's no sound if u die from a mob or player
		player.setLevel(hp);
		String percentageDisplay = String.format("%.1f%%", percentage * 100.0);
		if(percentage < 0.10) {
			Values.sendActionBar(player, ChatColor.DARK_RED + "" + ChatColor.BOLD + "DANGER: Your HP is at " + ChatColor.RED + ChatColor.BOLD  + percentageDisplay + ChatColor.DARK_RED + "!");
		} else if(percentage < 0.25) {
			Values.sendActionBar(player, ChatColor.GOLD + "" + ChatColor.BOLD + "Warning: Your HP is at " + ChatColor.YELLOW + ChatColor.BOLD  + percentageDisplay + ChatColor.GOLD + "!");
		} else if(percentage < 0.5) {
			Values.sendActionBar(player, ChatColor.DARK_AQUA + "" + ChatColor.BOLD +  "Caution: Your HP is at " + ChatColor.AQUA + ChatColor.BOLD  + percentageDisplay + ChatColor.DARK_AQUA + "!");
		} else if(options.checkOption("hpdisplay")) {
			Values.sendActionBar(player, ChatColor.DARK_GREEN + "" + ChatColor.BOLD +  "Caution: Your HP is at " + ChatColor.GREEN + ChatColor.BOLD  + percentageDisplay + ChatColor.DARK_GREEN + "!");	
		}
//		BossbarAPI.setMessage(player, ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "HP: " + ChatColor.RESET + "" + ChatColor.LIGHT_PURPLE + (hp > 0 ? hp : 0) + "/" + (maxHP + maxHP_temp), ((float) hp / (maxHP + maxHP_temp)) * 100);	
	}

	public HashMap<UUID, Long> noDamageTicks = new HashMap<UUID, Long>();
	public long lastDamagedByPlayer = 0;
	
	public boolean damage(int i, Object o, boolean isSpell) {
		return damage(i,o,isSpell,1);
	}
	
	public int multihitcount = 0;
	public String lasthitter = "";
	
	public boolean damage(int i, Object o, boolean isSpell, double knockback) {
		if(!fullyLoaded)
			return false;
		if(player.isDead())
			return false;
		if(region.type.equals("secure") || (o instanceof Player && (Player)o != player && !region.type.equals("perilous")))
			return false;
		if(o instanceof Player && o != player) {
			i *= Values.PVP_DEBUFF;
			if(plugin.getPD((Player)o).region.type.equals("secure"))
				return false;
		}
		if(o instanceof Player) {
			String currenthitter = ((Player)o).getName();
			if(lasthitter.equals(currenthitter)) {
				multihitcount++;
			} else {
				multihitcount = 0;
			}
			if(multihitcount > 0) {
				double multiplier = 1;
				multiplier -= 0.05 * multihitcount;
				if(multiplier < 0.3)
					multiplier = 0.3;
				i *= multiplier;
			}
			lasthitter = currenthitter;
			plugin.getPD(currenthitter).lasthitter = "";
		}
		if(o instanceof LivingEntity && (((LivingEntity) o).isDead() || !((LivingEntity)o).isValid()))
			return false;
		if(o instanceof LivingEntity && o != player) {
			LivingEntity le = (LivingEntity)o;
			if(!isSpell) {
				if(noDamageTicks.get(le.getUniqueId()) != null && noDamageTicks.get(le.getUniqueId()) > System.nanoTime()) {
					return false;
				}
			}
			noDamageTicks.put(le.getUniqueId(), System.nanoTime() + 500000000);
		}
		if(o instanceof Player) {
			if(party != null && o != player)
				if(plugin.getPD((Player)(o)).party == party)
					return false;
			Player p1 = (Player)o;
			if(CombatHandler.enqueuedMessages.get(p1.getUniqueId()) != null)
				for(String s : CombatHandler.enqueuedMessages.get(p1.getUniqueId()))
					plugin.db(p1, s);
			PlayerData pd1 = plugin.getPD(p1);
			if(Math.random() * 100.0 < (pd1.critChance + pd1.critChance_temp)) {
				plugin.db(p1, "CRIT - [" + i + " -> " + (int)(i * pd1.critDamage_temp / 100.0) + "]");
				i *= pd1.critDamage_temp / 100.0;
				plugin.db(p1, ChatColor.RED + "" + ChatColor.BOLD + "Critical hit!");
			}
		}
		if(Math.random() < 0.05 && ClassHandler.checkPassive("Block", this)) {
			plugin.db(player, "Block blocked " + i + " damage.");
			if(o instanceof Player)
				((Player)o).sendMessage(player.getName() + " blocked your hit!");
			return true;
		}
		if(Math.random() < 0.10 && ClassHandler.checkPassive("Divine Shield", this)) {
			plugin.db(player, "Divine Shield blocked " + i + " damage.");
			if(o instanceof Player)
				((Player)o).sendMessage(player.getName() + " blocked your hit!");
			return true;
		}
		if(Math.random() < 0.15 && ClassHandler.checkPassive("Divine Protection", this)) {
			plugin.db(player, "Divine Protection blocked " + i + " damage.");
			if(o instanceof Player)
				((Player)o).sendMessage(player.getName() + " blocked your hit!");
			return true;
		}
		if(Math.random() < 0.20 && ClassHandler.checkPassive("Sanctuary", this)) {
			plugin.db(player, "Sanctuary blocked " + i + " damage.");
			if(o instanceof Player)
				((Player)o).sendMessage(player.getName() + " blocked your hit!");
			return true;
		}
		if(damageReceivedIncrease > 0) {
			plugin.db(player, ChatColor.DARK_RED + "" + damageReceivedIncrease + "% DI; DMG: " + i + " -> " + (int)(i + i * damageReceivedIncrease / 100.0));
			if(o instanceof Player)
				plugin.db(player, ChatColor.DARK_GREEN + "" + damageReceivedIncrease + "% DI; DMG: " + i + " -> " + (int)(i + i * damageReceivedIncrease / 100.0));
			i += i * damageReceivedIncrease / 100.0;
		}
		if(damageReduction > 0) {
			plugin.db(player, ChatColor.DARK_GREEN + "" + damageReduction + "% DR; DMG: " + i + " -> " + (int)(i - i * damageReduction / 100.0));
			if(o instanceof Player)
				plugin.db(player, ChatColor.DARK_RED + "" + damageReduction + "% DR; DMG: " + i + " -> " + (int)(i - i * damageReduction / 100.0));
			i -= i * damageReduction / 100.0;
		}
		if(i <= 0)
			return true;
		if(intervention_buff) {
			if(o instanceof Player)
				((Player)o).sendMessage("Your damage to " + player.getName() + " is nullified by Intervention.");
			i = 0;
		}
		if(chantOfNecessarius_buff) {
			chantOfNecessariusValue_buff += i;
			plugin.db(player, "Chant nullified " + i + " damage.");
			if(o instanceof Player)
				((Player)o).sendMessage("Your damage to " + player.getName() + " is nullified by Chant of Necessarius.");
			i = 0;
		}
		if(o instanceof Player) {
			PlayerData pd1 = plugin.getPD((Player)o);
			if(pd1.lifesteal_temp > 0)
				pd1.heal((int)(Math.ceil(i * (pd1.lifesteal_temp) / 100.0)));
		}
		if(shield > 0) {
			plugin.db(player, ChatColor.LIGHT_PURPLE + "Shielded " + ChatColor.BOLD + (shield > i ? i : shield) + " HP" + ChatColor.LIGHT_PURPLE + ". " + (shield - i > 0 ? shield - i : 0) + " remaining shield.");
			if(o instanceof Player) {
				Player p2 = (Player)o;
				plugin.db(p2, ChatColor.LIGHT_PURPLE + player.getName() + " shielded " + ChatColor.BOLD + (shield > i ? i : shield) + " HP" + ChatColor.LIGHT_PURPLE + ". " + (shield - i > 0 ? shield - i : 0) + " remaining shield.");
			}
			shield -= i;
			if(shield < 0) {
				player.playSound(player.getLocation(), Sound.GLASS, 2, 2);
				damage(Math.abs(shield), o, true);
			}
		} else {
			if(o == null) {
				plugin.db(player, ChatColor.RED + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.YELLOW + "[" +  (hp - i > 0 ? hp - i : 0) + " HP]");
			} else if(o instanceof Player) {
				Player p2 = (Player)o;
				lastDamager = ChatColor.stripColor(p2.getName());
				lastDamagedByPlayer = System.currentTimeMillis();
				if(o != player)
					lastDamagerPlayer = true;
				plugin.db(player, ChatColor.RED + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.RED + "(" + ChatColor.stripColor(p2.getName()) + ") " + ChatColor.YELLOW + "[" +  (hp - i > 0 ? hp - i : 0) + " HP]");
				if(p2 != player)
					plugin.db(p2, ChatColor.AQUA + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.AQUA + "(" + ChatColor.stripColor(player.getName()) + ")" + ChatColor.YELLOW + " [" + hp + " -> " + (hp - i > 0 ? hp - i : 0) + "]");
			} else if(o instanceof LivingEntity) {
				LivingEntity e = (LivingEntity)o;
				MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
				if(md.isDungeonMob) {
					if(!md.dungeonFullName.equals(this.dungeonFullName)) {
						md.entity.remove();
						return false;
					}
				}
				md.attackers.remove(player.getName());
				int levelDiff = md.mobType.level - this.level;
				double levelMultiplier = 1;
				if(levelDiff > 1)
					levelMultiplier =  1 + levelDiff * 0.11;
				else
					levelMultiplier = 1 + levelDiff * 0.01;
				if(levelMultiplier < 0.7)
					levelMultiplier = 0.7;
				i *= levelMultiplier;
				if(i < 1)
					i = 1;
				if(System.currentTimeMillis() - lastDamagedByPlayer > 5000) {
					lastDamager = md.entityName;
					lastDamagerPlayer = false;
				}
				plugin.db(player, ChatColor.RED + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.RED + "(" + ChatColor.stripColor(md.entityName.substring(0, md.entityName.indexOf(" [Lv"))) + ") " + ChatColor.YELLOW + "[" + (hp - i > 0 ? hp - i : 0) + " HP]");
			} else {
				plugin.db(player, ChatColor.RED + "" + ChatColor.BOLD + "-" + i + " HP " + ChatColor.YELLOW + "[" + (hp - i > 0 ? hp - i : 0) + " HP]");
				lastDamagerPlayer = false;
			}
			hp -= i;
		}
		player.playEffect(EntityEffect.HURT);
		if(knockback != 1 && ClassHandler.checkPassive("chaser", this)) {
			player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1));
		}
		if(Math.random() < 0.5 && ClassHandler.checkPassive("unstoppable", this)) {
			knockback = 0;
		}
		if(o instanceof Player) {
			PlayerData pd2 = plugin.getPD((Player)o);
			if(Math.random() < 0.2 && ClassHandler.checkPassive("acrobat", pd2)) {
				pd2.player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1));
				pd2.player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 30, 1));
			}
		}
		if(o instanceof Entity && knockback > 0) {
			Entity attacker = (Entity)o;
			Entity attacked = player;
			attacked.setVelocity(attacked.getLocation().toVector().subtract(attacker.getLocation().toVector()).normalize().multiply(knockback));
		}
		updateHealth();
		return true;
	}
	
	public void dropItems() {
		try {
			ArrayList<ItemStack> deathDrops = new ArrayList<ItemStack>();
			ItemStack[] armorContents = player.getInventory().getArmorContents();
			ItemStack[] invContents = player.getInventory().getContents();
			for(int k = 0; k < armorContents.length; k++) {
				try {
					double chance = Values.SAFE_ITEM_LOST_ON_DEATH;
					boolean drop = Math.random() < chance;
					if(armorContents[k] != null && armorContents[k].getType() != Material.AIR && drop && !armorContents[k].getItemMeta().getDisplayName().contains("The Ronbook") && !armorContents[k].getItemMeta().getDisplayName().contains("The Navigator")) { 
						if(ItemHandler.isTradeable(armorContents[k]))
							deathDrops.add(armorContents[k]);
						armorContents[k] = new ItemStack(Material.AIR);
					}
				} catch(Exception e) {
					//no item meta or no display name
				}
			}
			for(int k = 0; k < invContents.length; k++) {
				try {
					double chance = k < 3 ? Values.SAFE_ITEM_LOST_ON_DEATH : Values.ITEM_LOST_ON_DEATH;
					boolean drop = Math.random() < chance;
					if(invContents[k] != null && invContents[k].getType() != Material.AIR && drop && !invContents[k].getItemMeta().getDisplayName().contains("The Ronbook") && !invContents[k].getItemMeta().getDisplayName().contains("The Navigator")) { 
						if(ItemHandler.isTradeable(invContents[k]))
							deathDrops.add(invContents[k]);
						invContents[k] = new ItemStack(Material.AIR);
					}
				} catch(Exception e) {
					//no item meta or no display name
				}
			}
			for(ItemStack i : deathDrops)
				if(i != null && i.getType() != Material.AIR)
					player.getWorld().dropItemNaturally(player.getLocation(), i);
			player.getInventory().setContents(invContents);
			player.getInventory().setArmorContents(armorContents);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public volatile boolean justdied = false;
	
	public static final String[] deathMessages = new String[] {
		"Better luck next time!",
		"That's karma for ya!",
		"You failed the King!",
		"Game over. (not really)",
		"Better stock up on Spirit Points!",
		"Another one bites the dust.",
		"Better tie your shoelaces next time.",
		"And such is the way of the Kastian.",
		"rekt.",
		"That wasn't so bad, was it?",
		"Ouch.",
		":(",
		"Looks like you couldn\\'t handle it!",
		"It happens to the best of us!",
		"But you respawned, so it's OK!",
		"That's a bit embarrassing...",
	};
	
	public String randomDeathMessage() {
		return deathMessages[(int)(Math.random() * deathMessages.length)];
	}
	
	public void die() {
		if(!uuidRetrieved)
			return;
		if(justdied) {
			return;
		}
		Values.sendTitle(player, ChatColor.RED + "" + ChatColor.BOLD + "You just died!", ChatColor.RED + randomDeathMessage(), 10, 40, 30);
		justdied = true;
		int playerKillerLevel = -1;
		if(!inDungeon && !region.arena) {
			if(spiritPoints == 0) {
				player.sendMessage(ChatColor.RED + "You have 0 Spirit Points, so you dropped some items upon dying! For more info, check /spiritpoints.");
				dropItems();
			} else {
				if(lastDamagerPlayer && !lastDamager.equals(player.getName())) {
					playerDeaths++;
					spiritPoints -= 3;
					if(plugin.getServer().getPlayer(lastDamager) != null) {
						PlayerData pd2 = plugin.getPD(lastDamager);
						if(pd2 != null && pd2.spiritPoints < pd2.getMaxSpiritPoints() && !RegionHandler.getRegion(pd2.player.getLocation()).arena) {
							pd2.spiritPoints++;
							pd2.player.sendMessage(ChatColor.GREEN + "You gained 1 Spirit Point for killing " + player.getName() + ". You now have " + pd2.spiritPoints + " Spirit Points.");
							pd2.playerKills++;
							if(pd2.guildId != 0 && pd2.guildId != guildId)
								pd2.addGuildPoints(20 - (pd2.level - level) > 3 ? 20 - (pd2.level - level) : 3);
							playerKillerLevel = pd2.level;
						}
					}
				} else {
					spiritPoints -= 1;
					mobDeaths++;
				}
				if(spiritPoints < 0) {
					player.sendMessage(ChatColor.RED + "You have lost more Spirit Points than you have, so you dropped some items upon dying! For more info, check /spiritpoints.");
					dropItems();
					spiritPoints = 0;
				} else if(spiritPoints == 0) {
					player.sendMessage(ChatColor.RED + "You are now at 0 Spirit Points, so you will lose items the next time you die! For more info, check /spiritpoints.");

				} else {
					player.sendMessage(ChatColor.RED + "You have lost " + (lastDamagerPlayer ? 3 : 1) + " Spirit Point" + (lastDamagerPlayer ? "s" : "") + "! You have " + spiritPoints + " Spirit Points left.");
					player.sendMessage(ChatColor.RED + "If you have 0 Spirit Points when you die, you will lose items. For more info, check /spiritpoints.");
				}
			}
			int amountOfGoldLost = (int)(wallet * (Math.random() / 10.0 + 0.1));
			wallet -= amountOfGoldLost;
		} else {
			player.sendMessage(ChatColor.GREEN + "You did not lose any Spirit Points.");
			if(plugin.getServer().getPlayer(lastDamager) != null) {
				PlayerData pd2 = plugin.getPD(lastDamager);
				pd2.playerKills++;
				playerKillerLevel = pd2.level;
			}
		}
		if(lastDamager != null && !(lastDamager.equals(""))) {
			plugin.getServer().broadcastMessage(ChatColor.RED + "" + player.getName() + " [Lv. " + level + "] was killed by " + ChatColor.stripColor(lastDamager) + (playerKillerLevel > -1 ? " [Lv. " + playerKillerLevel + "]": "") + "!");
		} else {
			plugin.getServer().broadcastMessage(ChatColor.RED + "" + player.getName() + " [Lv. " + level + "] has died!");
		}
		lastDamagerPlayer = false;
		lastDamager = "";
		updateRonbook();
		if(inDungeon) {
			DungeonHandler.leaveInstance(player);
		} else {
			player.teleport(getRespawnLocation());
		}
		Region currentRegion = RegionHandler.getRegion(player.getLocation());
		if(currentRegion != region) {
			if(!(currentRegion.welcome))
				preUnwelcomedRegion = region;
			region = currentRegion;
		}
		hp = maxHP;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				justdied = false;
			}
		}, 20 * 10);
	}
	
	public void heal(int i) {
		if(i <= 0)
			i = 1;
		if(!fullyLoaded)
			return;
		if(player.isDead())
			return;
		if(ClassHandler.getClassType(classType) == ClassType.CLERIC) {
			if(ClassHandler.checkPassive("healing mastery", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 1.15));
				i *= 1.15;
			}
			if(ClassHandler.checkPassive("alchemist", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 1.35));
				i *= 1.35;
			}
			if(ClassHandler.checkPassive("survival stance", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 1.2));
				i *= 1.2;
			}
			if(ClassHandler.checkPassive("ascension", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 1.5));
				i *= 1.5;
			}
			if(ClassHandler.checkPassive("invulnerability stance", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 1.4));
				i *= 1.4;
			}
			if(ClassHandler.checkPassive("johann's pen", this)) {
				plugin.db(player, "Heal amount " + i + " -> " + (i * 2));
				i *= 2;
			}
		}
		player.playSound(player.getLocation(), Sound.ORB_PICKUP, 1, 1);
		if(options.checkOption("healhearts")) {
			HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
			particles.add(new ParticleDetails(ParticleType.HEART));
			EffectHolder holder = EffectCreator.createLocHolder(particles, player.getLocation());
			holder.setRunning(true);
			holder.update();
			holder.setRunning(false);
		}
		plugin.db(player, ChatColor.GREEN + "" + ChatColor.BOLD + "+" + i + " HP " + ChatColor.YELLOW + "[" + hp + " -> " + (hp + i) + "]");
		if(hp < maxHP + maxHP_temp) {
			if(hp + i > maxHP + maxHP_temp)
				hp = maxHP + maxHP_temp;
			else
				hp += i;
			updateHealth();
		} else {
			hp = maxHP + maxHP_temp;
			updateHealth();
		}
	}
	
	public void recoverHealth() {
		if(disabled)
			return;
		if(!fullyLoaded)
			return;
		if(player.isDead())
			return;
		if(hp < maxHP + maxHP_temp) {
			if(hp + hpRegen > maxHP + maxHP_temp) {
				hp = maxHP + maxHP_temp;
				lastDamager = "";
			} else {
				hp += hpRegen + hpRegen_temp;
			}
		} else {
			hp = maxHP + maxHP_temp;
		}
		updateHealth();
	}
	
	/*
	 * GENERAL CLASS METHODS
	 */
	
	public boolean hasChanged(PlayerData pd) {
		return level != pd.level || maxHP != pd.maxHP || hpRegen != pd.hpRegen || strength != pd.strength ||
			   dexterity != pd.dexterity || intelligence != pd.intelligence || luck != pd.luck || sp != pd.sp || maxHP_temp != pd.maxHP_temp || 
			   hpRegen_temp != pd.hpRegen_temp || strength_temp != pd.strength_temp || 
			   dexterity_temp != pd.dexterity_temp || intelligence_temp != pd.intelligence_temp || luck_temp != pd.luck_temp || exp != pd.exp ||
			   !(classType.equalsIgnoreCase(pd.classType));
	}
	
	public Object clone(){  
	    try{  
	        PlayerData pd = (PlayerData)(super.clone());
	        return pd;
	    }catch(Exception e){ 
	    	e.printStackTrace();
	        return null; 
	    }
	}
	
	public String toString() {
		return "Level: " + level + " HP: " + hp + "/" + maxHP;
	}
	
}