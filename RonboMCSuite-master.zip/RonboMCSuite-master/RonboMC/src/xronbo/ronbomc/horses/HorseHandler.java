package xronbo.ronbomc.horses;

import java.util.Arrays;

import me.ronbo.core.ranks.RankManager;
import net.minecraft.server.v1_8_R1.AttributeInstance;
import net.minecraft.server.v1_8_R1.EntityInsentient;
import net.minecraft.server.v1_8_R1.GenericAttributes;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftLivingEntity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.HorseJumpEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.HorseInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;

public class HorseHandler implements Listener {
	
	public static RonboMC plugin;
	
	public HorseHandler(RonboMC plugin) {
		HorseHandler.plugin = plugin;
	}
	
	public enum HorseType {
		TIER1("Dusty", 500, 30, ChatColor.GRAY, Material.IRON_BARDING, Material.IRON_BARDING, 1, 1, Horse.Variant.HORSE, Horse.Color.GRAY, Horse.Style.WHITE_DOTS),
		TIER2("Chester", 5000, 30, ChatColor.WHITE, Material.IRON_BARDING, Material.IRON_BARDING, 2, 2, Horse.Variant.HORSE, Horse.Color.DARK_BROWN, Horse.Style.WHITEFIELD),
		TIER3("Rusty", 10000, 30, ChatColor.RED, Material.IRON_BARDING, Material.IRON_BARDING, 3, 2, Horse.Variant.HORSE, Horse.Color.CHESTNUT, Horse.Style.WHITE),
		TIER4("Whisper", 30000, 60, ChatColor.BLUE, Material.GOLD_BARDING, Material.GOLD_BARDING, 4, 3, Horse.Variant.HORSE, Horse.Color.WHITE, Horse.Style.BLACK_DOTS),
		TIER5("Scout", 75000, 60, ChatColor.GREEN, Material.GOLD_BARDING, Material.GOLD_BARDING, 5, 3, Horse.Variant.HORSE, Horse.Color.DARK_BROWN, Horse.Style.WHITEFIELD),
		TIER6("Apache", 100000, 60, ChatColor.YELLOW, Material.GOLD_BARDING, Material.GOLD_BARDING, 5, 4, Horse.Variant.HORSE, Horse.Color.BLACK, Horse.Style.WHITE_DOTS),
		TIER7("Charger", 250000, 120, ChatColor.LIGHT_PURPLE, Material.DIAMOND_BARDING, Material.DIAMOND_BARDING, 10, 5, Horse.Variant.HORSE, Horse.Color.CREAMY, Horse.Style.NONE),
		TIER8("Luna", 500000, 120, ChatColor.AQUA, Material.DIAMOND_BARDING, Material.DIAMOND_BARDING, 7, 6, Horse.Variant.HORSE, Horse.Color.WHITE, Horse.Style.NONE),
		TIER9("Midnight", 1000000, 240, ChatColor.GOLD, Material.DIAMOND_BARDING, Material.DIAMOND_BARDING, 9, 9, Horse.Variant.HORSE, Horse.Color.BLACK, Horse.Style.NONE),
		;
		public String name;
		public int speed, jump;
		public ChatColor descriptionColor;
		public Horse.Variant variant;
		public Horse.Color color;
		public Material material, armor;
		public int price,duration_minutes;
		public Horse.Style style;
		HorseType(String name, int cost, int duration_minutes, ChatColor descriptionColor, Material material, Material armor, int speed, int jump, Horse.Variant variant, Horse.Color color, Horse.Style style) {
			this.name = name;
			this.price = cost;
			this.duration_minutes = duration_minutes;
			this.descriptionColor = descriptionColor;
			this.speed = speed;
			this.jump = jump;
			this.variant = variant;
			this.color = color;
			this.material = material;
			this.armor = armor;
			this.style = style;
		}
	}
	
	public static void giveHorse(Player p, HorseType ht) {
		boolean isVip = RankManager.check(p, "knight");
		p.sendMessage(ChatColor.GREEN + "To mount your horse, simply type /horse.");
		p.sendMessage(ChatColor.GREEN + "You can ride " + ht.name + " for " + (isVip ? ht.duration_minutes * 2 : ht.duration_minutes) + " minutes.");
		p.sendMessage(ChatColor.GREEN + "Only the time that you actually are riding " + ht.name + " is counted.");
		plugin.getPD(p).horseType = ht;
		plugin.getPD(p).timeLeftWithHorse = (isVip ? ht.duration_minutes * 2 : ht.duration_minutes) * 60 * 1000;
	}
	
	public static boolean spawnHorse(Player p) {
		HorseType ht = plugin.getPD(p).horseType;
		if(ht == null)
			return false;
		Horse horse = (Horse) p.getWorld().spawnEntity(p.getLocation(), EntityType.HORSE);
		horse.setTamed(true);
		horse.setVariant(ht.variant);
		horse.setColor(ht.color);
		horse.setStyle(ht.style);
		horse.setJumpStrength(getJumpStrength(ht.jump));
		horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
		if(ht.armor != null)
			horse.getInventory().setArmor(new ItemStack(ht.armor));
		setSpeed(horse, getSpeed(ht.speed));
		horse.setPassenger(p);
		return true;
	}
	
	public static void setSpeed(Horse horse, double speed) {
		AttributeInstance attributes = ((EntityInsentient)((CraftLivingEntity)horse).getHandle()).getAttributeInstance(GenericAttributes.d);
        attributes.setValue(speed);
	}

	//Jump 0.4 - 1.0
	//Speed 0.1125 - 0.3375 (player speed is 0.1)
	public static double getJumpStrength(int i) {
		return 0.4 + 0.06 * i;
	}
	
	public static double getSpeed(int i) {
		return 0.1325 + 0.0225 * i;
	}
	
	public static String buildStars(int i) {
		StringBuilder sb = new StringBuilder("");
		for(int k = 0; k < i; k++)
			sb.append("\u2735");
		return ChatColor.GOLD + sb.toString();
	}
	
	public static void openInventory(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "The Kastia Stables");
		int count = 0;
		boolean isVip = RankManager.check(p, "knight");
		for(HorseType ht : HorseType.values()) {
			ItemStack i = new ItemStack(ht.material);
			ItemMeta im = i.getItemMeta();
			im.setDisplayName(ht.descriptionColor + ht.name);
			im.setLore(Arrays.asList(new String[]{
					ChatColor.LIGHT_PURPLE + "Duration: " + (isVip ? ht.duration_minutes * 2 : ht.duration_minutes) + " minutes",
					"",
					ChatColor.AQUA + "Speed",
					buildStars(ht.speed),
					ChatColor.AQUA + "Jump",
					buildStars(ht.jump),
					"",
					ChatColor.RED + "Price: " + ChatColor.GOLD + ht.price + "g",
					"",
					ChatColor.BLUE + "" + ChatColor.ITALIC + "Click to rent this horse!",
					}));
			i.setItemMeta(im);
			inventory.setItem(count++, i);
		}
		p.openInventory(inventory);
	}
	
	@EventHandler
	public void onVehicleEnter(VehicleEnterEvent event) {
		if(event.getVehicle() instanceof Horse && event.getEntered() instanceof Player) {
			Player p = (Player)event.getEntered();
			PlayerData pd = plugin.getPD(p);
			if(pd != null)
				pd.gotOnHorse = System.currentTimeMillis();
		}
	}

	@EventHandler
	public void onHorseJump(HorseJumpEvent event) {
		final Horse h = event.getEntity();
		if(h.getPassenger() != null && h.getPassenger() instanceof Player) {
			if(plugin.getPD((Player)h.getPassenger()).flyingHorse) {
				if(event.getPower() > 0.9)
					h.setVelocity(h.getPassenger().getLocation().getDirection().setY(1));
				else
					h.setVelocity(h.getPassenger().getLocation().getDirection().setY(0.75));
				for(int k = 0; k < 10; k++) {
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							if(h != null && h.getWorld() != null && h.isValid())
								h.getWorld().playEffect(h.getLocation(), Effect.SPELL, 1);
						}
					}, k*2);
				}
			}
		}
	}
	
	@EventHandler
	public void onVehicleExit(VehicleExitEvent event) {
		if(event.getVehicle() instanceof Horse && event.getExited() instanceof Player) {
			event.getVehicle().remove();
			Player p = (Player)event.getExited();
			PlayerData pd = plugin.getPD(p);
			if(pd.flyingHorse) {
				pd.flyingHorse = false;
				p.sendMessage(ChatColor.GREEN + "You gracefully dismount Pegasus.");
			} else {
				boolean isVip = RankManager.check(p, "knight");
				pd.timeLeftWithHorse -= System.currentTimeMillis() - pd.gotOnHorse;
				if(pd.timeLeftWithHorse <= 0) {
					p.sendMessage("");
					p.sendMessage(ChatColor.RED + "Your " + (isVip ? pd.horseType.duration_minutes * 2 : pd.horseType.duration_minutes) + " minutes with " + pd.horseType.name + " are up!");
					pd.horseType = null;
				} else {
					p.sendMessage("");
	    			p.sendMessage(ChatColor.GREEN + "You can ride " + pd.horseType.name + " for " + (int)(Math.round(pd.timeLeftWithHorse / 1000.0 / 60.0)) + " more minutes.");
				}
			}
		}
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		if(event.getInventory().getTitle().equals(ChatColor.BLACK + "The Kastia Stables")) {
			if(RonboMC.TESTING_INVENTORY_CANCELS)
				System.out.println("Cancelling here. " + this.getClass().getName());
			event.setCancelled(true);
			try {
				String s = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
				for(HorseType ht : HorseType.values()) {
					if(ht.name.equalsIgnoreCase(s)) {
						Player p = (Player)(event.getWhoClicked());
						PlayerData pd = plugin.getPD(p);
						int price = ht.price;
	            		if(pd.wallet >= price) {
	            			pd.takeGold(price);
	        				p.sendMessage("");
	            			p.sendMessage(ChatColor.GREEN + "You have rented out " + ht.name + "!");
	            			giveHorse(p, ht);
		            	} else {
		    				p.sendMessage("");
	            			p.sendMessage(ChatColor.RED + "You don't have enough gold with you to rent " + ht.name + "!");
	            			p.sendMessage(ChatColor.RED + "You need to have " + ht.price + "g.");
	            		}
						break;
					}
				}
			} catch(Exception e) {
				
			}
			event.getWhoClicked().closeInventory();
		}
	}
	
	@EventHandler
	public void onInventoryOpen(InventoryOpenEvent event) {
		if(event.getInventory() instanceof HorseInventory) {
			event.setCancelled(true);
		}
	}
	
}