package xronbo.ronbomc.skills.harvesting;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;

public class HarvestingHandler {

	public static RonboMC plugin;

	public static final int WHEAT_PRICE = 10;
	public static final int POTATO_PRICE = 12;
	public static final int CARROT_PRICE = 15;
	
	public enum Basket {
		TIER1("Cheap Basket", 10, 90, 1),
		TIER2("Straw Basket", 20, 170, 2),
		TIER3("Sturdy Basket", 40, 320, 3),
		TIER4("Harvesting Basket", 80, 600, 4),
		TIER5("Gardener's Basket", 250, 1750, 5),
		;
		public String name;
		public int maxSize;
		public int price;
		public int tier;
		Basket(String name, int maxSize, int price, int tier) {
			this.name = ChatColor.WHITE + name;
			this.maxSize = maxSize;
			this.price = price;
			this.tier = tier;
		}
	}

	public static void buyBasket(Basket b, Player p) {
		PlayerData pd = plugin.getPD(p);
		long carried = pd.wallet;
		if(carried >= b.price) {
			pd.takeGold(b.price);
			giveBasket(p, b.tier);
			p.sendMessage(ChatColor.GREEN + "You have purchased a " + ChatColor.stripColor(b.name) + ".");
		} else {
			p.sendMessage(ChatColor.RED + "You don't have " + b.price + "g with you!");
		}
	}
	
	public static void sellBasket(ItemStack i, Player p) {
		int banknote = 0;
		for(String s : i.getItemMeta().getLore()) {
			s = ChatColor.stripColor(s);
			if(s.endsWith("g")) {
				banknote = Integer.parseInt(s.substring(0, s.lastIndexOf("g")));
				break;
			}
		}
		p.getInventory().removeItem(i);
		plugin.getPD(p).giveBanknote(banknote);
	}
	
	public static void openInventory(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9, ChatColor.BLACK + "The Harvest Begins!");
		int count = 0;
		ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.LIME.getData());
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(ChatColor.GREEN + "" + ChatColor.UNDERLINE + "Click to learn about Harvesting!");
		im.setLore(new ArrayList<String>());
		i.setItemMeta(im);
		inventory.setItem(count++, i);
		count++;
		for(Basket b : Basket.values()) {
			i = new ItemStack(Material.FLOWER_POT_ITEM);
			im = i.getItemMeta();
			im.setLore(Arrays.asList(new String[]{
					ChatColor.YELLOW + "Max Capacity: " + b.maxSize,
					ChatColor.YELLOW + "Basket Price: " + ChatColor.GOLD + b.price +"g",
					}));
			im.setDisplayName(b.name);
			i.setItemMeta(im);
			inventory.setItem(count++, i);
		}
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.YELLOW.getData());
		im = i.getItemMeta();
		im.setLore(Arrays.asList(new String[] {
				ChatColor.AQUA + "To sell a basket that is in your",
				ChatColor.AQUA + "inventory, just click on it. You will",
				ChatColor.AQUA + "be paid the Basket Value.",
		}));
		im.setDisplayName(ChatColor.GREEN + "" + ChatColor.UNDERLINE + "Selling Baskets");
		i.setItemMeta(im);
		inventory.setItem(++count, i);
		p.openInventory(inventory);
	}
	
	public static void harvestBlock(Player p, Block b) {
		ItemStack i = p.getItemInHand();
		if(countCapacity(i) >= getCapacity(i)) {
			p.sendMessage(ChatColor.RED + "Your basket is full!");
			return;
		}
		String type = "";
		String display = "";
		switch(b.getType()) {
			case POTATO:
				type = "Potatoes";
				display = "potato";
				break;
			case CARROT:
				type = "Carrots";
				display = "carrot";
				break;
			case CROPS:
				type = "Wheat";
				display = "wheat";
				break;
			default:
				break;
		}
		p.setItemInHand(harvest(i, type));
		if(plugin.getPD(p).options.checkOption("harvesting"))
			p.sendMessage(ChatColor.GREEN + "You harvested one " + display + ".");
		b.setData((byte)0);
	}
	
	public static ItemStack harvest(ItemStack i, String type) {
		ItemMeta im = i.getItemMeta();
		ArrayList<String> lore = new ArrayList<String>();
		for(String s : im.getLore()) {
			if(s.toLowerCase().contains(type.toLowerCase())) {
				int current = Integer.parseInt(ChatColor.stripColor(s).substring(type.length() + ": ".length()));
				s = ChatColor.YELLOW + ChatColor.stripColor(s).substring(0, type.length() + ": ".length()) + ChatColor.GOLD + ++current;
			}
			if(s.toLowerCase().endsWith("g")) {
				s = ChatColor.GOLD + "" + calcValue(i) + "g";
			}
			lore.add(s);
			im.setLore(lore);
			i.setItemMeta(im);
		}
		return i;
	}
	
	public static int getCapacity(ItemStack i) {
		for(String s : i.getItemMeta().getLore()) {
			s = ChatColor.stripColor(s);
			if(s.contains("Max Capacity: "))
				return Integer.parseInt(s.substring("Max Capacity: ".length()));
		}
		return 0;
	}
	
	public static int calcValue(ItemStack i) {
		int total = 0;
		for(String s : i.getItemMeta().getLore()) {
			s = ChatColor.stripColor(s);
			if(s.contains("Wheat: ")) {
				total += WHEAT_PRICE * Integer.parseInt(s.substring("Wheat: ".length()));
			}
			if(s.contains("Potatoes: ")) {
				total += POTATO_PRICE * Integer.parseInt(s.substring("Potatoes: ".length()));
			}
			if(s.contains("Carrots: ")) {
				total += CARROT_PRICE * Integer.parseInt(s.substring("Carrots: ".length()));
			}
		}
		return total;
	}
	
	public static int countCapacity(ItemStack i) {
		int total = 0;
		for(String s : i.getItemMeta().getLore()) {
			s = ChatColor.stripColor(s);
			if(s.contains("Wheat: ")) {
				total += Integer.parseInt(s.substring("Wheat: ".length()));
			}
			if(s.contains("Potatoes: ")) {
				total += Integer.parseInt(s.substring("Potatoes: ".length()));
			}
			if(s.contains("Carrots: ")) {
				total += Integer.parseInt(s.substring("Carrots: ".length()));
			}
		}
		return total;
	}
	
	public static void giveBasket(Player p, int tier) {
		String name = "TIER" + tier;
		Basket b = Basket.valueOf(name);
		ItemStack i = new ItemStack(Material.FLOWER_POT_ITEM);
		ItemMeta im = i.getItemMeta();
		BigInteger uniqueId = new BigInteger(64, new Random());
		im.setLore(Arrays.asList(new String[]{
				ChatColor.YELLOW + "Max Capacity: " + b.maxSize,
				"",
				ChatColor.YELLOW + "Wheat: " + ChatColor.GOLD + 0,
				ChatColor.YELLOW + "Potatoes: " + ChatColor.GOLD + 0,
				ChatColor.YELLOW + "Carrots: " + ChatColor.GOLD + 0,
				"",
				ChatColor.YELLOW + "Current Basket Value: ",
				ChatColor.GOLD + "" + 0 + "g",
				"",
				ChatColor.YELLOW + "Unique Basket ID: " + uniqueId.toString()
				}));
		im.setDisplayName(b.name);
		i.setItemMeta(im);
		p.getInventory().addItem(i);
	}
	
	private HarvestingHandler() {
		
	}
	
}