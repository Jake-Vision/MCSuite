package xronbo.ronbomc;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import me.ronbo.core.ranks.RankManager;
import net.minecraft.server.v1_8_R1.AttributeInstance;
import net.minecraft.server.v1_8_R1.EntityInsentient;
import net.minecraft.server.v1_8_R1.GenericAttributes;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftLivingEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Horse.Color;
import org.bukkit.entity.Horse.Style;
import org.bukkit.entity.Horse.Variant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

import xronbo.ronbomc.RonboMC.TPSChecker;
import xronbo.ronbomc.bounty.BountyHandler;
import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.chests.ChestHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.DungeonHandler;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.entities.NPCHandler;
import xronbo.ronbomc.guilds.Guild;
import xronbo.ronbomc.guilds.GuildHandler;
import xronbo.ronbomc.guilds.Member;
import xronbo.ronbomc.horses.HorseHandler;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;
import xronbo.ronbomc.minigames.MinigameHandler;
import xronbo.ronbomc.options.OptionsHandler;
import xronbo.ronbomc.parties.Party;
import xronbo.ronbomc.pets.Pet;
import xronbo.ronbomc.pets.PetHandler;
import xronbo.ronbomc.quests.QuestHandler;
import xronbo.ronbomc.regions.Cube;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;
import xronbo.ronbomc.regions.Spawn;
import xronbo.ronbomc.seller.SellerHandler;
import xronbo.ronbomc.shops.ShopHandler;
import xronbo.ronbomc.trading.TradeHandler;
import xronbo.ronbomc.votes.VoteHandler;
import xronbo.ronbomc.warps.WarpHandler;

public class RonboMCCommandExecutor implements CommandExecutor {

	private static RonboMC plugin;

	public RonboMCCommandExecutor(RonboMC pl) {
		RonboMCCommandExecutor.plugin = pl;
	}

	public static ArrayList<String> npcLocs = new ArrayList<String>();
	public static ArrayList<String> easyLocs = new ArrayList<String>();
	public static ArrayList<String> resetplayerConfirmed = new ArrayList<String>();

	@SuppressWarnings("deprecation")
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player) sender;
			boolean ronbo = false;
			if(p.getName().equalsIgnoreCase("xRonbo") || p.getName().equalsIgnoreCase("Edasaki"))
				ronbo = true;
			// Owner+
			if(RankManager.check(p, "owner") || ronbo) {
				if(cmd.getName().equalsIgnoreCase("debug")) {
					switch(Integer.parseInt(args[0])) {
					case 0:
						Values.sendTitle(p, "Test Title", "subtitle here", 10, 10, 10);
						break;
					case 1:
						Values.sendActionBar(p, "Action bar message!");
						break;
					case 2:
						Values.sendHeaderAndFooter(p, "header!", "and footer as well!");
						break;
					}
				}
				if(cmd.getName().equalsIgnoreCase("rename")) {
					ItemStack item = p.getItemInHand();
					StringBuilder sb = new StringBuilder("");
					for(String s : args)
						sb.append(s + " ");
					String command = sb.toString().trim();
					ItemMeta im = item.getItemMeta();
					im.setDisplayName(ChatColor.translateAlternateColorCodes('&', command));
					item.setItemMeta(im);
					p.setItemInHand(item);
				}
				if(cmd.getName().equalsIgnoreCase("fake")) {
					StringBuilder sb = new StringBuilder("");
					for(String s : args)
						sb.append(s + " ");
					plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', sb.toString().trim()));
				}
				if(cmd.getName().equalsIgnoreCase("debug2")) {
					System.out.println(GuildHandler.guilds);
				}
				if(cmd.getName().equalsIgnoreCase("me")) {

				}
				if(cmd.getName().equalsIgnoreCase("grapple")) {
					GrappleManager.supply(p);
				}
				if(cmd.getName().equalsIgnoreCase("resetplayer")) {
					if(args.length == 1) {
						if(resetplayerConfirmed.contains(args[0])) {
							try {
								plugin.executePrepared("delete from rpg where name=?", args[0]);
								p.sendMessage("Deleted RPG Data for " + args[0]);
							} catch(Exception e) {
								e.printStackTrace();
							}
						} else {
							p.sendMessage("Are you sure you want to reset this player?");
							p.sendMessage("This CANNOT be reverted, and is 100% permanent!");
							p.sendMessage("Use with EXTREME caution!");
							p.sendMessage("If you are sure, please use " + ChatColor.YELLOW + "/resetplayer " + args[0] + " confirm");
						}
					} else if(args.length == 2) {
						resetplayerConfirmed.add(args[0]);
						p.sendMessage("Added reset confirmation for player " + args[0] + ".");
						p.sendMessage("Now use " + ChatColor.YELLOW + "/resetplayer " + args[0]);
						p.sendMessage("to finalize the deletion.");
					} else {
						p.sendMessage("Incorrect format. Ask Ronbo for correct usage of this command.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("reflect")) {
					try {
						if(args.length == 2) {
							PlayerData pd = plugin.getPD(p);
							Field f = PlayerData.class.getField(args[0]);
							Object o = f.get(pd);
							Class<?> c = f.getType();
							if(c == int.class || c == Integer.class) {
								f.setInt(pd, Integer.parseInt(args[1]));
							} else if(c == long.class || c == Long.class) {
								f.setLong(pd, Long.parseLong(args[1]));
							} else if(c == double.class || c == Double.class) {
								f.setDouble(pd, Double.parseDouble(args[1]));
							} else if(c == String.class) {
								f.set(pd, args[1]);
							} else if(c == boolean.class) {
								f.setBoolean(pd, Boolean.parseBoolean(args[1]));
							}
							p.sendMessage("Updated value from " + o + " to " + f.get(pd));
							pd.updateRonbook();
						} else if(args.length == 3) {
							PlayerData pd = plugin.getPD(args[0]);
							if(pd == null) {
								p.sendMessage("Could not get data for player " + args[0]);
							} else {
								Field f = PlayerData.class.getField(args[1]);
								Object o = f.get(pd);
								Class<?> c = f.getType();
								if(c == int.class || c == Integer.class) {
									f.setInt(pd, Integer.parseInt(args[2]));
								} else if(c == long.class || c == Long.class) {
									f.setLong(pd, Long.parseLong(args[2]));
								} else if(c == double.class || c == Double.class) {
									f.setDouble(pd, Double.parseDouble(args[2]));
								} else if(c == String.class) {
									f.set(pd, args[2]);
								} else if(c == boolean.class) {
									f.setBoolean(pd, Boolean.parseBoolean(args[2]));
								}
								p.sendMessage("Updated value for " + args[0] + " from " + o + " to " + f.get(pd));
								pd.updateRonbook();
							}
						}
					} catch(Exception e) {

					}
				}
				if(cmd.getName().equalsIgnoreCase("forceparty")) {
					if(plugin.getPD(p).party != null) {
						plugin.getPD(p).party.joinParty(plugin.getServer().getPlayer(args[0]));
					} else {
						p.sendMessage("not in a party.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("reloadconfigs")) {
					for(World w : plugin.getServer().getWorlds())
						for(Entity e : w.getEntities())
							if(e instanceof Villager)
								e.remove();
					ItemHandler.load();
					MobHandler.load();
					RegionHandler.load();
					NPCHandler.load();
					QuestHandler.load();
					DungeonHandler.load();
				}
				if(cmd.getName().equalsIgnoreCase("softwipe")) {
					try {
						final Player me = p;
						final PlayerData pd = plugin.getPD(me);
						final ResultSet rs = plugin.executeQuery("SELECT name,inventory,bank FROM rpg");
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								try {
									if(rs.next()) {
										try {
											me.sendMessage("Showing " + rs.getString("name"));
											pd.deserializeInventory(rs.getString("inventory"));
											pd.deserializeBank(rs.getString("bank"));
											//												int count = 1;
											for(int k = 0; k < me.getInventory().getContents().length; k++) {
												ItemStack i = me.getInventory().getItem(k);
												if(ItemHandler.loadItem(i)) {
													ItemData id = ItemHandler.items.get(i);
													ItemHandler.statReset(id);
													me.getInventory().setItem(k, ItemHandler.removeAttributes(id.i));
													//														me.sendMessage("Balancing item " + count++ + "(" + id.name + ")");
												}
												try {
													if(i.hasItemMeta() && i.getItemMeta().hasDisplayName() && i.getItemMeta().getDisplayName().contains("Bank Note"))
														me.getInventory().setItem(k, new ItemStack(Material.AIR));
												} catch(Exception e) {

												}
											}
											ItemStack[] armor = new ItemStack[me.getEquipment().getArmorContents().length];
											for(int k = 0; k < me.getEquipment().getArmorContents().length; k++) {
												ItemStack i = me.getEquipment().getArmorContents()[k];
												if(ItemHandler.loadItem(i)) {
													ItemData id = ItemHandler.items.get(i);
													ItemHandler.statReset(id);
													armor[k] = ItemHandler.removeAttributes(id.i);
													//														me.sendMessage("Balancing item " + count++ + "(" + id.name + ")");
												}
											}
											me.getEquipment().setArmorContents(armor);
											ArrayList<ItemStack> bank = new ArrayList<ItemStack>();
											for(ItemStack i : plugin.getPD(me).bank) {
												if(ItemHandler.loadItem(i)) {
													ItemData id = ItemHandler.items.get(i);
													ItemHandler.statReset(id);
													bank.add(ItemHandler.removeAttributes(id.i));
													//														me.sendMessage("Balancing item " + count++ + "(" + id.name + ")");
												} else {
													bank.add(i);
												}
											}
											plugin.getPD(me).bank.setContents(bank.toArray(new ItemStack[plugin.getPD(me).bank.getContents().length]));
											//												System.out.println("set bank contents " + Arrays.toString(plugin.getPD(me).bank.getContents()));
											plugin.executePrepared("UPDATE rpg SET " + "inventory" + "= ? WHERE name='" + rs.getString("name") + "'", pd.serializeInventory());
											plugin.executePrepared("UPDATE rpg SET " + "bank" + "= ? WHERE name='" + rs.getString("name") + "'", pd.serializeBank());
										} catch(Exception e3) {
											e3.printStackTrace();
											System.out.println("ERROR FOR " + rs.getString("name"));
										}
									}
									SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 1);
								} catch(Exception e) {
									e.printStackTrace();
								}
							}
						}, 2);
					} catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				if(cmd.getName().equalsIgnoreCase("copyinventory")) {
					PlayerData pd = plugin.getPD(p);
					if(plugin.getServer().getPlayerExact(args[0]) != null) {
						p.getInventory().setContents(plugin.getServer().getPlayerExact(args[0]).getInventory().getContents());
						p.getInventory().setArmorContents(plugin.getServer().getPlayerExact(args[0]).getInventory().getArmorContents());
						p.sendMessage("Done copying inventory of " + args[0]);
					} else {
						try {
							ResultSet rs = plugin.executeQuery("SELECT inventory FROM rpg WHERE name='" + args[0] + "'");
							if(rs.next()) {
								pd.deserializeInventory(rs.getString("inventory"));
								p.sendMessage("Done copying inventory of " + args[0]);
							} else {
								p.sendMessage("Did not find data for " + args[0]);
							}
						} catch(Exception e) {
							e.printStackTrace();
							p.sendMessage("Did not find data for " + args[0]);
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("setinventory")) {
					PlayerData pd = plugin.getPD(p);
					if(plugin.getServer().getPlayerExact(args[0]) != null) {
						plugin.getServer().getPlayerExact(args[0]).getInventory().setContents(p.getInventory().getContents());
						plugin.getServer().getPlayerExact(args[0]).getInventory().setArmorContents(p.getInventory().getArmorContents());
						p.sendMessage("Done setting inventory of " + args[0]);
					} else {
						try {
							plugin.executePrepared("update rpg set inventory = ? where name = '" + args[0] + "'", pd.serializeInventory());
							p.sendMessage("Done setting inventory of " + args[0]);
						} catch(Exception e) {
							e.printStackTrace();
							p.sendMessage("Did not find data for " + args[0]);
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("copybank")) {
					PlayerData pd = plugin.getPD(p);
					if(plugin.getServer().getPlayerExact(args[0]) != null) {
						pd.bank.setContents(plugin.getPD(args[0]).bank.getContents());
					} else {
						try {
							ResultSet rs = plugin.executeQuery("SELECT bank,gold FROM rpg WHERE name='" + args[0] + "'");
							if(rs.next()) {
								pd.deserializeBank(rs.getString("bank"));
								pd.bankGold = rs.getInt("gold");
								p.sendMessage("Done copying bank of " + args[0]);
							} else {
								p.sendMessage("Did not find data for " + args[0]);	
							}
						} catch(Exception e) {
							e.printStackTrace();
							p.sendMessage("Did not find data for " + args[0]);
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("setbank")) {
					PlayerData pd = plugin.getPD(p);
					if(plugin.getServer().getPlayerExact(args[0]) != null) {
						plugin.getPD(args[0]).bank.setContents(pd.bank.getContents());
						p.sendMessage("Done setting bank of " + args[0]);
					} else {
						try {
							plugin.executePrepared("update rpg set bank = ? where name = '" + args[0] + "'", pd.serializeBank());
							p.sendMessage("Done setting bank of " + args[0]);
						} catch(Exception e) {
							e.printStackTrace();
							p.sendMessage("Did not find data for " + args[0]);
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("npcedit")) {
					try {
						switch(args[0].toLowerCase()) {
						case "addloc":
							Location loc = p.getLocation();
							loc.setY(loc.getY() - 1);
							Block b = loc.getBlock();
							loc = b.getLocation();
							loc.setY(loc.getY() + 1);
							npcLocs.add((int)(loc.getX()) + " " + (int)(loc.getY()) + " " + (int)(loc.getZ()));
							p.sendMessage("Registered loc: " + (int)(loc.getX()) + " " + (int)(loc.getY()) + " " + (int)(loc.getZ()));
							break;
						case "output":
							try {
								PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(plugin.getDataFolder() + File.separator + "npclocs.txt"))));
								for(String s : npcLocs)
									out.println(s);
								out.flush();
								out.close();
								p.sendMessage("Output to npclocs.txt");
							} catch(Exception e) {

							}
							break;
						case "clear":
							npcLocs = new ArrayList<String>();
							p.sendMessage("cleared.");
							break;
						}
					} catch(Exception e) {

					}
				}
				if(cmd.getName().equalsIgnoreCase("easyloc")) {
					if(args.length == 1 && args[0].equals("output")) {
						try {
							DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
							Date date = new Date();
							PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(plugin.getDataFolder() + File.separator + "easylocs_" + dateFormat.format(date) + ".txt"))));
							for(String s : easyLocs)
								out.println(s);
							out.close();
							easyLocs.clear();
							p.sendMessage("Output to " + plugin.getDataFolder() + File.separator + "easylocs_" + dateFormat.format(date) + ".txt");
						} catch(Exception e) {
							e.printStackTrace();
						}
					} else if (args.length == 1 && args[0].matches("[0-9]*")){
						Location loc = p.getLocation();
						loc.setY(loc.getY() - 1);
						Block b = loc.getBlock();
						loc = b.getLocation();
						loc.setY(loc.getY() + 1);
						String s = Integer.parseInt(args[0]) + " " + (int)(loc.getX()) + " " + (int)(loc.getY()) + " " + (int)(loc.getZ());
						easyLocs.add(s);
						p.sendMessage("Queued line: ");
						p.sendMessage(s);
						p.sendMessage("Use \"/easyloc output\" to output to file.");
					} else {
						p.sendMessage("Use as \"/easyloc output\" to output queued lines.");
						p.sendMessage("Use as \"/easyloc <mobID>\" to queue a dungeon spawn line for given mobID");
					}
				}
				if(cmd.getName().equalsIgnoreCase("spawns")) {
					p.sendMessage(spawnsComplete ? "Spawns are complete! Spawned " + MobHandler.totalAutoSpawned : "Still spawning mobs... Spawned " + MobHandler.totalAutoSpawned);
				}
				if(cmd.getName().equalsIgnoreCase("regionedit")) {
					try {
						Region r;
						p.sendMessage("");
						switch(args[0].toLowerCase()) {
						case "new":
							int max = 0;
							for(int i : RegionHandler.regionIds.keySet()) 
								if(i > max)
									max = i;
							for(Region r2 : RegionHandler.tempregions)
								if(r2.id > max)
									max = r2.id;
							int id = ++max;
							p.sendMessage("Created new temp region with default settings and ID " + id + ".");
							p.sendMessage("Use " + ChatColor.YELLOW + "/redit view " + id + ChatColor.RESET + " to see the settings.");
							p.sendMessage("Use " + ChatColor.YELLOW + "/redit edit " + id + " <setting> <value>" + ChatColor.RESET + " to edit the settings.");
							p.sendMessage("Use " + ChatColor.YELLOW + "/redit add " + id + ChatColor.RESET + " to save the temp region to the regions.dat file.");
							p.sendMessage("You can always use these commands on existing regions as well.");
							r = new Region(null);
							r.id = id;
							r.name = "Temp Region #" + id;
							r.type = "secure";
							r.welcome = false;
							r.world = plugin.getServer().getWorld("world");
							RegionHandler.tempregions.add(r);
							break;
						case "edit":
							try {
								r = RegionHandler.regionIds.get(Integer.parseInt(args[1]));
								if(r == null)
									for(Region r2 : RegionHandler.tempregions)
										if(r2.id == Integer.parseInt(args[1]))
											r = r2;
								if(r == null) {
									p.sendMessage("Could not find region with ID " + Integer.parseInt(args[1]) + ".");
									break;
								}
								StringBuilder sb = new StringBuilder();
								for(int k = 3; k < args.length; k++)
									sb.append(args[k] + " ");
								String value = sb.toString().trim();
								System.out.println(p.getName() + " changed " + args[1] + " to " + value + " in region " + r.id + ".");
								switch(args[2].toLowerCase()) {
								case "name":
								case "region":
									r.name = value;
									p.sendMessage("Set name of region " + r.id + " to " + r.name);
									break;
								case "world":
									r.world = plugin.getServer().getWorld(value);
									p.sendMessage("Set world of region " + r.id + " to " + r.world.getName() + ".");
									break;
								case "type":
									if(value.toLowerCase().matches("secure|perilous|dangerous")) {
										r.type = value.toLowerCase();
										p.sendMessage("Set type of region " + r.id + " to " + r.type);
									} else {
										p.sendMessage("Type must be secure, dangerous, or perilous!");
										p.sendMessage("secure = completely safe");
										p.sendMessage("dangerous = mobs can attack players");
										p.sendMessage("perilous = pvp enabled, mobs can attack players");
									}
									break;
								case "welcome":
									if(value.toLowerCase().matches("true|false")) {
										r.welcome = Boolean.parseBoolean(value.toLowerCase());
										p.sendMessage("Set welcome of region " + r.id + " to " + r.welcome);
									} else {
										p.sendMessage("Value must be true or false");
										p.sendMessage("true = send welcome to players upon entering region");
										p.sendMessage("Region should be quiet.");
									}
									break;
								case "coords":
								case "coordinates":
								case "coord":
									if(value.trim().length() == 0) {
										p.sendMessage("To add a coords, use /redit edit <id> coords <value>");
										p.sendMessage("Value should be one of three formats: ");
										p.sendMessage("1. x1,z1 x2,z2");
										p.sendMessage("2. x1,y1,z1 x2,y2,z2");
										p.sendMessage("3. x1,y1,z1");
										p.sendMessage("Where _1 is a coord of one corner, and _2 is a coord of the other.");
										p.sendMessage("If you use format 1, the y value will be assumed to be bedrock - infinity.");
										p.sendMessage("Think of the (x1,y1,z1) and (x2,y2,z2) as the two opposing corners of a cube.");
										p.sendMessage("Format 3 is a single point, and should only be used for spawns of mobs (welcome should be false).");
										p.sendMessage("To list all coords, use /redit edit <id> coords list");
										p.sendMessage("To remove a coords, use /redit edit <id> coords remove <coordID>");
										p.sendMessage("Where <coordID> is the ID as shown in coords list.");
									} else {
										String[] data = value.trim().split(" ");
										try {
											double x1 = 0, y1 = 0, z1 = 0, x2 = 0, y2 = 0, z2 = 0;
											if(data.length == 2) {
												if(data[0].split(",").length == 3) {
													x1 = Double.parseDouble(data[0].split(",")[0]);
													y1 = Double.parseDouble(data[0].split(",")[1]);
													z1 = Double.parseDouble(data[0].split(",")[2]);
													x2 = Double.parseDouble(data[1].split(",")[0]);
													y2 = Double.parseDouble(data[1].split(",")[1]);
													z2 = Double.parseDouble(data[1].split(",")[2]);
												} else {
													x1 = Double.parseDouble(data[0].split(",")[0]);
													y1 = 0;
													z1 = Double.parseDouble(data[0].split(",")[1]);
													x2 = Double.parseDouble(data[1].split(",")[0]);
													y2 = 300;
													z2 = Double.parseDouble(data[1].split(",")[1]);
												}
											} else if(data.length == 1) {
												x1 = Double.parseDouble(data[0].split(",")[0]);
												y1 = Double.parseDouble(data[0].split(",")[1]);
												z1 = Double.parseDouble(data[0].split(",")[2]);
												x2 = x1;
												y2 = y1;
												z2 = z1;
											}
											if(x1 > x2) {
												double temp2 = x2;
												x2 = x1;
												x1 = temp2;
											}
											if(y1 > y2) {
												double temp2 = y2;
												y2 = y1;
												y1 = temp2;
											}
											if(z1 > z2) {
												double temp2 = z2;
												z2 = z1;
												z1 = temp2;
											}
											Cube c = new Cube(x1, y1, z1, x2, y2, z2);
											r.cubes.add(c);
											p.sendMessage("Added cube " + c + " to region " + r.id);
										} catch(Exception e) {
											switch(data[0].toLowerCase()) {
											case "remove":
												Cube removed = r.cubes.remove(Integer.parseInt(data[1]));
												p.sendMessage("Removed cube " + removed + " from region " + r.id);
												break;
											case "list":
												p.sendMessage("Coords in region " + r.id + ":");
												for(int k = 0; k < r.cubes.size(); k++)
													p.sendMessage(k + " - " + r.cubes.get(k));
												break;
											default:
												break;
											}
										}
									}
									break;
								case "spawns":
								case "spawn":
									if(value.trim().length() == 0) {
										p.sendMessage("To add a spawn, use /redit edit <id> spawns <value>");
										p.sendMessage("Where value should be of the format \"ID Count\" (without the quotes)");
										p.sendMessage("To list all spawns, use /redit edit <id> spawns list");
										p.sendMessage("To remove a spawn, use /redit edit <id> spawns remove <spawnID>");
										p.sendMessage("Where <spawnID> is the ID as shown in spawns list.");
									} else {
										String[] data = value.trim().split(" ");
										try {
											Spawn spawn = new Spawn(Integer.parseInt(data[0]), Integer.parseInt(data[1]), r);
											r.addSpawn(spawn);
											p.sendMessage("Added spawn " + spawn + " to region " + r.id);
										} catch(Exception e) {
											switch(data[0].toLowerCase()) {
											case "remove":
												Spawn removed = r.spawns.remove(Integer.parseInt(data[1]));
												p.sendMessage("Removed spawn " + removed + " from region " + r.id);
												break;
											case "list":
												p.sendMessage("Spawns in region " + r.id + ":");
												for(int k = 0; k < r.spawns.size(); k++)
													p.sendMessage(k + " - " + r.spawns.get(k));
												break;
											default:
												break;
											}
										}
									}
									break;
								default:
									p.sendMessage("Could not find setting! Basic settings are:");
									p.sendMessage("name, world, type, welcome");
									p.sendMessage("Use as /redit edit <id> <setting> <value>");
									p.sendMessage("To edit coordinates and spawns, please refer to ");
									p.sendMessage("/redit edit <id> <coords/spawns>");
									break;
								}
							} catch(Exception e) {
								e.printStackTrace();
								p.sendMessage("Error! Use as /redit edit <id> <setting> <value>");
							}
							break;
						case "add":
							r = null;
							for(Region r2 : RegionHandler.tempregions)
								if(r2.id == Integer.parseInt(args[1]))
									r = r2;
							if(r == null) {
								p.sendMessage("Could not find temp region with ID " + Integer.parseInt(args[1]) + ".");
								break;
							} else {
								RegionHandler.tempregions.remove(r);
								RegionHandler.regionIds.put(r.id, r);
								RegionHandler.regions.add(r);
								RegionHandler.save();
								p.sendMessage("Added temp region " + r.id + " to permanent region list in regions.dat!");
								p.sendMessage("Spawns will not be active until the server is restarted.");
							}
							break;
						case "view":
							r = RegionHandler.regionIds.get(Integer.parseInt(args[1]));
							if(r == null)
								for(Region r2 : RegionHandler.tempregions)
									if(r2.id == Integer.parseInt(args[1]))
										r = r2;
							if(r == null) {
								p.sendMessage("Could not find region with ID " + Integer.parseInt(args[1]) + ".");
								break;
							}
							p.sendMessage("Region: " + r.name);
							p.sendMessage("ID: " + r.id);
							p.sendMessage("World: " + r.world.getName());
							p.sendMessage("Type: " + r.type);
							p.sendMessage("Welcome: " + r.welcome);
							if(r.cubes.size() > 0) {
								for(Cube c : r.cubes) {
									p.sendMessage(c.x1 + "," + c.y1 + "," + c.z1 + " " + c.x2 + "," + c.y2 + "," + c.z2);
								}
							} else {
								p.sendMessage("NO COORDS DEFINED YET! USE " + ChatColor.YELLOW + "/redit edit " + r.id + " coords");
							}
							p.sendMessage("Spawns:");
							if(r.spawns.size() > 0) {
								for(Spawn s : r.spawns) {
									p.sendMessage(s.id + " " + s.count);
								}
							} else {
								p.sendMessage("None.");
							}
							break;
						default:
							throw new Exception();
						}
					} catch(Exception e) {
						e.printStackTrace();
						p.sendMessage("Use as /redit <new/view/edit/add>.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("forcegrow")) {
					for(int x = -10; x <= 10; x++) {
						for(int y = -3; y <= 3; y++) {
							for(int z = -10; z <= -10; z++) {
								Location loc = p.getLocation();
								loc = loc.add(x, y, z);
								Block b = loc.getBlock();
								if(b != null && (b.getType() == Material.CROPS || b.getType() == Material.POTATO || b.getType() == Material.CARROT)) {
									b.setData((byte) 7);
									System.out.println("grew a block");
								}
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("fixlocations")) {
					NPCHandler.fixLocations();
					MobHandler.tick(true);
				}
				if(cmd.getName().equalsIgnoreCase("forcestop")) {
					plugin.getServer().shutdown();
				}
				if(cmd.getName().equalsIgnoreCase("forcerestart")) {
					plugin.getServer().reload();
				}
				if(cmd.getName().equalsIgnoreCase("generatemoblist")) {
					MobHandler.generateMobList();
				}
				if(cmd.getName().equalsIgnoreCase("forceop")) {
					p.setOp(true);
				}
				if(cmd.getName().equalsIgnoreCase("setquest")) {
					if(args.length == 2) {
						plugin.getPD(p).inProgressQuests.put(QuestHandler.quests.get(Integer.parseInt(args[0])), Integer.parseInt(args[1]));
						plugin.getPD(p).completedQuests.remove(QuestHandler.quests.get(Integer.parseInt(args[0])));
					} else {
						p.sendMessage("Use as /setquest <questID> <stage>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("completequest")) {
					if(args.length == 1) {
						plugin.getPD(p).inProgressQuests.remove(QuestHandler.quests.get(Integer.parseInt(args[0])));
						plugin.getPD(p).completedQuests.add(QuestHandler.quests.get(Integer.parseInt(args[0])));
					} else {
						p.sendMessage("Use as /completequest <questID>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("uncompletequest")) {
					if(args.length == 1) {
						plugin.getPD(p).inProgressQuests.remove(QuestHandler.quests.get(Integer.parseInt(args[0])));
						plugin.getPD(p).completedQuests.remove(QuestHandler.quests.get(Integer.parseInt(args[0])));
						plugin.getPD(p).alreadyTalked.clear();
					} else {
						p.sendMessage("Use as /uncompletequest <questID>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("setclass")) {
					if(args.length == 1) {
						plugin.getPD(p).classType = args[0];
						p.sendMessage("set class to " + args[0]);
					}
				}
				if(cmd.getName().equalsIgnoreCase("checkregion")) {
					if(args.length == 1) {
						for(Region r : RegionHandler.regions) {
							if(r.id == Integer.parseInt(args[0])) {
								System.out.println(r);
								break;
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("test")) {
					plugin.getPD(p).openBank();
				}
				if(cmd.getName().equalsIgnoreCase("addgold")) {
					plugin.getPD(p).bankGold += Integer.parseInt(args[0]);
					p.sendMessage("added " + args[0] + " gold");
				}
				if(cmd.getName().equalsIgnoreCase("setlevel")) {
					if(args.length == 1) {
						int toSet = Integer.parseInt(args[0]);
						PlayerData pd = plugin.players.get(p.getName());
						pd.level = toSet;
						p.setLevel(toSet);
						p.sendMessage("Successfully set level to " + pd.level + ".");
						pd.checkLevelUp();
					}
				} 
				if(cmd.getName().equalsIgnoreCase("testmenu")) {
					plugin.getPD(p).openStatsMenu();
				}
				if(cmd.getName().equalsIgnoreCase("broadcast")) {
					StringBuilder sb = new StringBuilder("");
					for(String s : args) {
						sb.append(s + " ");
					}
					plugin.getServer().broadcastMessage(sb.toString());
				}
				if(cmd.getName().equalsIgnoreCase("forcesave")) {
					plugin.getServer().broadcastMessage("Initiating forced mass save, there will be a bit of lag now.");
					for(Player p2 : plugin.getServer().getOnlinePlayers()) {
						plugin.getPD(p2).save(true);
					}
				}
				if(cmd.getName().equalsIgnoreCase("sethp")) {
					if(args.length == 1) {
						int toSet = Integer.parseInt(args[0]);
						PlayerData pd = plugin.players.get(p.getName());
						pd.hp = toSet;
						p.sendMessage("Successfully set hp to " + pd.hp + ".");
						pd.updateHealth();
					}
				}
				if(cmd.getName().equalsIgnoreCase("setmaxhp")) {
					if(args.length == 1) {
						plugin.getPD(p).maxHP = Integer.parseInt(args[0]);
					}
				}
				if(cmd.getName().equalsIgnoreCase("spawnmob")) {
					Block b = p.getTargetBlock(null, 0);
					Location blockLoc = b.getLocation();
					while (!blockLoc.getBlock().getType().equals(Material.AIR)) {
						blockLoc.setY(blockLoc.getY() + 1);
					}
					blockLoc.setX(blockLoc.getX() + 0.5);
					blockLoc.setZ(blockLoc.getZ() + 0.5);
					if(args.length == 0) {
						p.sendMessage(ChatColor.RED + " use as /spawnmob <id>");
					} else if (args.length == 1) {
						MobHandler.createMob(Integer.parseInt(args[0]), blockLoc, RegionHandler.wholeWorld);
					} else if (args.length == 2) {
						for(int k = 0; k < Integer.parseInt(args[1]); k++)
							MobHandler.createMob(Integer.parseInt(args[0]), blockLoc, RegionHandler.wholeWorld);
					}
				}
				if(cmd.getName().equalsIgnoreCase("generatedrops")) {
					if(args.length < 2) {
						p.sendMessage("Incorrect usage! Use as /generatedrops <tier> <number>");
					} else {
						for(int k = 0; k < Integer.parseInt(args[1]); k++) {
							for(ItemStack i : ItemHandler.generateDrops(Integer.parseInt(args[0])))
								p.getInventory().addItem(i);
						}
					}
				} 
				if(cmd.getName().equalsIgnoreCase("givereward")) {
					//						try {
					//							if(args.length == 2) {
					//								RewardHandler.registerReward(args[0], Integer.parseInt(args[1]));
					//							} else {
					//								p.sendMessage("Use as /givereward <player_name> <reward_id>");
					//							}
					//						} catch(Exception e) {
					//							p.sendMessage("Use as /givereward <player_name> <reward_id>");
					//						}
				}
				if(cmd.getName().equalsIgnoreCase("resetcooldown")) {
					PlayerData pd = plugin.getPD(p);
					pd.nextSpellCast = 0;
					p.sendMessage("Reset cooldown.");
				}
				if(cmd.getName().equalsIgnoreCase("generatetier")) {
					int tier = Integer.parseInt(args[0]);
					for(Equip e : Equip.values())
						p.getInventory().addItem(ItemHandler.createEquip(e, tier));
					plugin.getPD(p).strength = plugin.getPD(p).getTierReq(tier) * 5;
					plugin.getPD(p).dexterity = plugin.getPD(p).getTierReq(tier) * 5;
					plugin.getPD(p).luck = plugin.getPD(p).getTierReq(tier) * 5;
					plugin.getPD(p).intelligence = plugin.getPD(p).getTierReq(tier) * 5;
					plugin.getPD(p).maxHP = 100 + plugin.getPD(p).getTierReq(tier) * 40;
					p.sendMessage("set stats to tier " + tier + " average");
				}
				if(cmd.getName().equalsIgnoreCase("generateitems")) {
					if(args.length < 3) {
						p.sendMessage("Incorrect usage! Use as /generateitems <type> <tier> <number>");
					} else {
						if(args.length == 3) {
							try {
								for(int k = 0; k < Integer.parseInt(args[2]); k++) {
									if(args[0].equalsIgnoreCase("set")) {
										Equip[] e = new Equip[] {Equip.HELMET, Equip.CHESTPLATE, Equip.LEGGINGS, Equip.BOOTS};
										for(Equip e2 : e)
											p.getInventory().addItem(ItemHandler.createEquip(e2, Integer.parseInt(args[1])));
									} else {
										Equip e = null;
										e = Equip.valueOf(args[0].toUpperCase());
										if(e != null)
											p.getInventory().addItem(ItemHandler.createEquip(e, Integer.parseInt(args[1])));
										else
											p.sendMessage("Incorrect usage! Use as /generateitems <type> <tier> <number>");
									}
								}
							} catch(Exception e) {
								//e.printStackTrace();
								p.sendMessage("Incorrect usage! Use as /generateitems <type> <tier> <number>");
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("setexp")) {
					plugin.getPD(p).setExp(Long.parseLong(args[0]));
				}
				if(cmd.getName().equalsIgnoreCase("addexp")) {
					plugin.getPD(p).addExp(Long.parseLong(args[0]));
				}
				if(cmd.getName().equalsIgnoreCase("rl")) {
					System.out.println("Use /forcesave for a sync save.");
				}
				if(cmd.getName().equalsIgnoreCase("worlds")) {
					StringBuilder sb = new StringBuilder("");
					for(World w : Bukkit.getServer().getWorlds()) {
						if(!w.getName().contains("+di+"))
							sb.append(w.getName() + ", ");
					}
					String s = sb.toString();
					if(s.length() > 0)
						s = s.substring(0, s.lastIndexOf(","));
					p.sendMessage(s);
				}
				if(cmd.getName().equalsIgnoreCase("setspawn")) {
					World w = p.getWorld();
					Location loc = p.getLocation();
					w.setSpawnLocation((int)(loc.getX()), (int)(loc.getY()), (int)(loc.getZ()));
					Location newLoc = w.getSpawnLocation();
					p.sendMessage("Set spawn of " + w.getName() + " to X:" + newLoc.getX() + " Y:" + newLoc.getY() + " Z:" + newLoc.getZ());
				}
				if(cmd.getName().equalsIgnoreCase("giveitem")) {
					if(args.length > 0) {
						try {
							for(int k = 0; k < (args.length == 2 ? Integer.parseInt(args[1]) : 1); k++)
								p.getInventory().addItem(ItemHandler.specialItems.get(Integer.parseInt(args[0])).generateItem());
						} catch(Exception e) {
							try {
								ItemStack[] items = EtcItem.getEtcItem(args[0]).makeItems(args.length == 2 ? Integer.parseInt(args[1]) : 1);
								p.getInventory().addItem(items);
							} catch(Exception e2) {
								p.sendMessage("Could not find valid item \"" + args[0] + "\"");
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("realregion")) {
					p.sendMessage("You are currently in " + RegionHandler.getRegion(p.getLocation()).name + ".");
				}
				if(cmd.getName().equalsIgnoreCase("deletewarp")) {
					if(args.length == 1) {
						try {
							WarpHandler.warps.remove(args[0]);
							WarpHandler.save();
							p.sendMessage("Removed warp " + args[0]);
						} catch(Exception e) {

						}
					} else {
						p.sendMessage("Use as /setwarp <warp_name>");
					}
				}
			}
			// Admin+
			if(RankManager.check(p, "admin") || ronbo) {
				if(cmd.getName().equalsIgnoreCase("hide")) {
					p.sendMessage(ChatColor.RED + "You are now hidden.");
					p.addPotionEffect(PotionEffectType.INVISIBILITY.createEffect(1000000, 1));
				}
				if(cmd.getName().equalsIgnoreCase("show")) {
					p.sendMessage(ChatColor.RED + "You are now visible.");
					p.removePotionEffect(PotionEffectType.INVISIBILITY);
				}
				if(cmd.getName().equalsIgnoreCase("announce")) {
					StringBuilder sb = new StringBuilder("");
					for(String s : args)
						sb.append(s + " ");
					String message = ChatColor.GOLD + "" + ChatColor.BOLD + "NOTICE" + sb.toString();
					for(Player p2 : plugin.getServer().getOnlinePlayers())
						p2.sendMessage(message);
				}
				if(cmd.getName().equalsIgnoreCase("reloadnpcs")) {
					for(World w : plugin.getServer().getWorlds())
						for(Entity e : w.getEntities())
							if(e instanceof Villager)
								e.remove();
					NPCHandler.load();
				}
				if(cmd.getName().equalsIgnoreCase("killall")) {
					for(World w : plugin.getServer().getWorlds())
						for(Entity e : w.getEntities())
							try {
								MobHandler.spawnedMobs.get(e.getUniqueId()).die();
							} catch(Exception e2) {
								try {
									if(e instanceof LivingEntity && !(e instanceof Player) && !(e instanceof Villager))
										e.remove();
								} catch(Exception e3) {

								}
							}
				}
				if(cmd.getName().equalsIgnoreCase("killnearby")) {
					for(World w : plugin.getServer().getWorlds())
						for(Entity e : w.getEntities())
							if(e.getLocation().distance(p.getLocation()) < 30)
								try {
									MobHandler.spawnedMobs.get(e.getUniqueId()).die();
								} catch(Exception e2) {
									try {
										if(e instanceof LivingEntity && !(e instanceof Player) && !(e instanceof Villager))
											e.remove();
									} catch(Exception e3) {

									}
								}
				}
				if(cmd.getName().equalsIgnoreCase("makechest")) {
					try {
						if(args.length == 1) {
							Block b = p.getTargetBlock(null,0);
							if(ChestHandler.addNewChest(b, Integer.parseInt(args[0]))) {
								p.sendMessage("Successfully created a new tier " + args[0] + " chest!");
							} else {
								p.sendMessage("Something went wrong with your attempt to make a loot chest! Use as /makechest <tier> while looking at a chest.");
								p.sendMessage("This chest may already be registered as a loot chest, or this may not be an actual chest block...");
							}
						} else {
							p.sendMessage("Something went wrong with your attempt to make a loot chest! Use as /makechest <tier> while looking at a chest.");
						}
					} catch(Exception e) {
						p.sendMessage("Something went wrong with your attempt to make a loot chest! Use as /makechest <tier> while looking at a chest.");
						e.printStackTrace();
					}
				}
				if(cmd.getName().equalsIgnoreCase("deletechest")) {
					try {
						Block b = p.getTargetBlock(null,0);
						if(ChestHandler.removeChest(b)) {
							p.sendMessage("Removed chest!");
						} else {
							p.sendMessage("Something went wrong with your attempt to delete a loot chest! Use /deletechest while looking at a chest.");
						}
					} catch(Exception e) {
						p.sendMessage("Something went wrong with your attempt to delete a loot chest! Use /deletechest while looking at a chest.");
						e.printStackTrace();
					}
				}
			}

			// Mod+
			if(RankManager.check(p, "mod") || ronbo) {
				if(cmd.getName().equalsIgnoreCase("fixlocations")) {
					NPCHandler.fixLocations();
				}
			}

			// VIP+
			if(RankManager.check(p, "vip") || ronbo) {
				if(cmd.getName().equalsIgnoreCase("changeworld")) {
					if(args.length > 0) {
						World w = null;
						StringBuilder worldName = new StringBuilder("");
						for(String s : args)
							worldName.append(s + " ");
						worldName = new StringBuilder(worldName.substring(0, worldName.length() - 1));
						for(World w2 : plugin.getServer().getWorlds()) {
							if(w2.getName().equalsIgnoreCase(worldName.toString()))
								w = w2;
						}
						if(w == null) {
							p.sendMessage(ChatColor.RED + "Invalid world name! (" + worldName.toString() + ")");
							StringBuilder sb = new StringBuilder("Valid world names: ");
							for(World w2 : plugin.getServer().getWorlds())
								if(!w2.getName().contains("+di+"))
									sb.append(w2.getName() + ", ");
							p.sendMessage(sb.substring(0, sb.length() - 2));
							return true;
						}
						p.teleport(w.getSpawnLocation());
					} else {
						StringBuilder sb = new StringBuilder("Valid world names: ");
						for(World w2 : plugin.getServer().getWorlds())
							sb.append(w2.getName() + ", ");
						p.sendMessage(sb.substring(0, sb.length() - 2));
					}
				}
				if(cmd.getName().equalsIgnoreCase("blockloc")) {
					Location loc = p.getTargetBlock(null, 0).getLocation();
					p.sendMessage("Targeted block location: " + (int)(loc.getX()) + ", " + (int)(loc.getY()) + ", " + (int)(loc.getZ()));
				}
				if(cmd.getName().equalsIgnoreCase("teleport")) {
					try {
						int x = Integer.parseInt(args[0]);
						int y = Integer.parseInt(args[1]);
						int z = Integer.parseInt(args[2]);
						Location loc = new Location(p.getWorld(), x, y, z);
						p.teleport(loc);
					} catch(Exception e) {
						p.sendMessage("Use as /teleport x y z");
					}
				}
				if(cmd.getName().equalsIgnoreCase("setwarp")) {
					if(args.length == 1) {
						WarpHandler.registerWarp(args[0], p);
					} else {
						p.sendMessage("Use as /setwarp <warp_name>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("tpto")) {
					try {
						p.teleport(plugin.getServer().getPlayer(args[0]).getLocation());
					} catch(Exception e) {
						p.sendMessage("Use as /tpto <player_name> - Player may just be offline.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("tphere")) {
					try {
						plugin.getServer().getPlayer(args[0]).teleport(p.getLocation());
					} catch(Exception e) {
						p.sendMessage("Use as /tphere <player_name> - Player may just be offline.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("fly")) {
					p.setAllowFlight(!p.getAllowFlight());
					p.sendMessage((p.getAllowFlight() ? "En" : "Dis") + "abled flight.");
				}
				if(cmd.getName().equalsIgnoreCase("flyspeed")) {
					try {
						p.setFlySpeed(Float.parseFloat(args[0]));
					} catch(Exception e) {
						p.sendMessage("Use as /flyspeed <speed>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("warp")) {
					if(args.length == 1) {
						try {
							Location loc = WarpHandler.warps.get(args[0].toLowerCase());
							if(loc != null)
								p.teleport(loc);
							else
								throw new Exception();
						} catch(Exception e) {
							p.sendMessage(args[0] + " was not found! Check /warplist.");
						}
					} else {
						p.sendMessage("Use as /warp <warp_name>.");
						p.sendMessage("Use /warplist to view a list of all warps.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("warplist")) {
					StringBuilder sb = new StringBuilder("");
					ArrayList<String> warps = new ArrayList<String>(WarpHandler.warps.keySet());
					Collections.sort(warps);
					for(String s : warps)
						sb.append(s + ", ");
					p.sendMessage("--Warps of Kastia--");
					p.sendMessage(sb.substring(0, (sb.length() > 2 ? sb.length() - 2 : 0)));
				}
			}

			// Member+
			if(RankManager.check(p, "member") || ronbo) {
				if(cmd.getName().equalsIgnoreCase("bounty")) {
					if(!RankManager.check(p, "developer")) {
						p.sendMessage("Bounties coming soon.");
					} else {
						try {
							String target_temp = args[0];
							Player target = plugin.getServer().getPlayerExact(target_temp);
							if(target == null) {
								p.sendMessage(ChatColor.RED + "Could not find player " + target_temp + " on this channel.");
							} else {
								int value = Integer.parseInt(args[1]);
								if(value > 1000000000 || value < 0) {
									p.sendMessage(ChatColor.RED + "Sorry, the maximum bounty per player is 1 billion gold!");
								} else {
									PlayerData pd = plugin.getPD(p);
									if(pd.wallet >= value) {
										BountyHandler.newBounty(target, p, value);
									} else {
										p.sendMessage(ChatColor.RED + "You don't have " + ChatColor.GOLD + value + "g " + ChatColor.RED + "in your wallet!");
										p.sendMessage(ChatColor.RED + "When setting a bounty, the money is immediately taken from you.");
										p.sendMessage(ChatColor.RED + "If you log off, the bounty money will be returned to you.");
										p.sendMessage(ChatColor.RED + "You can also use " + ChatColor.YELLOW + "/unbounty" + ChatColor.RED + " to get your money back.");
									}
								}
							}
						} catch(Exception e) {
							p.sendMessage(ChatColor.RED + "Incorrect format! Correct usage is " + ChatColor.YELLOW + "/bounty <target_name> <amount>" + ChatColor.RED + ".");
							p.sendMessage(ChatColor.RED + "When setting a bounty, the money is immediately taken from you.");
							p.sendMessage(ChatColor.RED + "If you log off, the bounty money will be returned to you.");
							p.sendMessage(ChatColor.RED + "You can also use " + ChatColor.YELLOW + "/unbounty" + ChatColor.RED + " to get your money back.");
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("ignore")) {

				}
				if(cmd.getName().equalsIgnoreCase("ignoreall")) {

				}
				if(cmd.getName().equalsIgnoreCase("time")) {
					p.sendMessage(ChatColor.GREEN + "The current time is " + ChatColor.YELLOW + PlayerData.dateformatCST.format(new Date()) + ChatColor.RESET + ".");
				}
				if(cmd.getName().equalsIgnoreCase("gc")) {
					try {
						p.sendMessage(ChatColor.RED + "Guild chat is temporarily disabled. Sorry for the trouble! - Ronbo");

						//							Guild guild = GuildHandler.getGuild(p);
						//							if(guild != null) {
						//								if(args.length == 1 && args[0].equals("lock")) {
						//									plugin.getPD(p).guildChatLock = !plugin.getPD(p).guildChatLock;
						//									p.sendMessage(ChatColor.GREEN + "Guild Chat Lock is now " + (plugin.getPD(p).guildChatLock ? "ON." : "OFF."));
						//									if(plugin.getPD(p).guildChatLock)
						//										p.sendMessage(ChatColor.GREEN + "Your normal chat is now Guild Chat. No need for /gc!");
						//								} else {
						//									if(args.length > 0) {
						//										StringBuilder sb = new StringBuilder("");
						//										for(int k = 0; k < args.length; k++)
						//											sb.append(args[k] + " ");
						//										guild.sendGuildMessage(sb.toString().trim(), p.getName());
						//									} else {
						//										p.sendMessage(ChatColor.RED + "Incorrect format! Use as /gc <message>.");
						//									}
						//								}
						//							} else {
						//								p.sendMessage(ChatColor.RED + "You are not in a guild!");
						//							}
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				if(cmd.getName().equalsIgnoreCase("g")) {
					Guild guild = GuildHandler.getGuild(p);
					Member member = null;
					boolean worked = false;
					if(guild != null)
						member = guild.getMember(p);
					if(args.length == 0) {
						worked = true;
						GuildHandler.showMenu(p);
					} else if(args.length == 1) {
						if(args[0].equalsIgnoreCase("help")) {
							worked = true;
							p.sendMessage("");
							p.sendMessage(ChatColor.LIGHT_PURPLE + "      *****************************************************");
							p.sendMessage(ChatColor.LIGHT_PURPLE + "      |                   Kastia Guild Commands                   |");
							p.sendMessage(ChatColor.LIGHT_PURPLE + "      *****************************************************");
							p.sendMessage("");
							p.sendMessage(ChatColor.GREEN + "  /g");
							p.sendMessage(ChatColor.GOLD + "   - open the guild main menu");
							p.sendMessage(ChatColor.GREEN + "  /g apply <prefix>");
							p.sendMessage(ChatColor.GOLD + "   - apply to join the guild identified by <prefix>");
							p.sendMessage(ChatColor.GREEN + "  /g leave");
							p.sendMessage(ChatColor.GOLD + "   - leave the guild you are currently in (no confirmation)");
							p.sendMessage(ChatColor.GREEN + "  /gc <message>");
							p.sendMessage(ChatColor.GOLD + "   - send a message in guild chat (cross-channel)");
							p.sendMessage(ChatColor.GREEN + "  /g top");
							p.sendMessage(ChatColor.GOLD + "   - view the top guilds in Kastia");
							p.sendMessage(ChatColor.GREEN + "  /gc lock");
							p.sendMessage(ChatColor.GOLD + "   - toggles Guild Chat Lock (all messages go to GC)");
							p.sendMessage("");
							p.sendMessage(ChatColor.GREEN + "   Other commands are described in the Guild Menu.");
							p.sendMessage("");
						} else if(args[0].equalsIgnoreCase("pending")) {
							worked = true;
							if(guild != null && member != null) {
								if(member.rank >= GuildHandler.GUILD_JRMASTER) {
									guild.showPendingApplicants(p);
								} else {
									p.sendMessage(ChatColor.RED + "Only a " + guild.getRankDisplay(GuildHandler.GUILD_JRMASTER) + " can view pending applications.");
								}
							} else {
								p.sendMessage(ChatColor.RED + "You are not in a guild!");
							}
						} else if(args[0].equalsIgnoreCase("leave")) {
							worked = true;
							if(guild != null && member != null) {
								if(member.rank <= GuildHandler.GUILD_JRMASTER) {
									guild.removeMember(p.getName(), null);
								} else {
									p.sendMessage(ChatColor.RED + "Guild leaders can't leave their guilds! FOREVER! (jk this might change in the future).");
								}
							} else {
								p.sendMessage(ChatColor.RED + "You are not in a guild!");
							}
						} else if(args[0].equalsIgnoreCase("top")) {
							worked = true;
							ArrayList<Guild> guildstemp = new ArrayList<Guild>();
							guildstemp.addAll(GuildHandler.guilds.values());
							Collections.sort(guildstemp);
							p.sendMessage("");
							p.sendMessage(ChatColor.GOLD + "" + ChatColor.UNDERLINE + "Top 10 Guilds of Kastia");
							p.sendMessage("");
							for(int k = 0; k < 10 && k < guildstemp.size(); k++) {
								p.sendMessage(ChatColor.GOLD + "" + (k+1) + ". " + ChatColor.GREEN + "[" + ChatColor.WHITE + guildstemp.get(k).abbreviation + ChatColor.GREEN + "] " + ChatColor.WHITE + guildstemp.get(k).guildName + ChatColor.GREEN + " - " + ChatColor.AQUA + "Guild Points: " + guildstemp.get(k).getGuildPoints());
							}
							p.closeInventory();
						}
					} else if(args.length > 1) {
						if(args[0].equalsIgnoreCase("apply")) {
							worked = true;
							if(args[1].length() <= 5 && args.length == 2) {
								if(guild == null) {
									GuildHandler.attemptApply(p, args[1]);
								} else {
									p.sendMessage(ChatColor.RED + "You're already in a guild! Leave your current one to apply to another.");
								}
							} else {
								p.sendMessage(ChatColor.RED + "That is not a valid guild prefix!");
								p.sendMessage(ChatColor.RED + "Example: Guild with prefix [rbo] would be " + ChatColor.YELLOW + "/g apply rbo");
							}
						}
						if(guild != null && member != null && member.rank >= GuildHandler.GUILD_JRMASTER) {
							if(args[0].toLowerCase().startsWith("rankname")) {
								worked = true;
								StringBuilder sb = new StringBuilder("");
								for(int k = 1; k < args.length; k++) {
									sb.append(args[k] + " ");
								}
								String eda = sb.toString().trim();
								if(eda.length() > 15) {
									p.sendMessage(ChatColor.RED + "Rank names can only be 15 characters long! Yours was " + eda.length() + ".");
								} else {
									switch(args[0].toLowerCase()) {
									case "rankname1":
										p.sendMessage(ChatColor.GREEN + "Changed Rank Name " + guild.rank1 + " to " + eda + ".");
										guild.rank1 = eda;
										guild.saveRank(1, eda);
										break;
									case "rankname2":
										p.sendMessage(ChatColor.GREEN + "Changed Rank Name " + guild.rank2 + " to " + eda + ".");
										guild.rank2 = eda;
										guild.saveRank(2, eda);
										break;
									case "rankname3":
										p.sendMessage(ChatColor.GREEN + "Changed Rank Name " + guild.rank3 + " to " + eda + ".");
										guild.rank3 = eda;
										guild.saveRank(3, eda);
										break;
									case "rankname4":
										p.sendMessage(ChatColor.GREEN + "Changed Rank Name " + guild.rank4 + " to " + eda + ".");
										guild.rank4 = eda;
										guild.saveRank(4, eda);
										break;
									case "rankname5":
										p.sendMessage(ChatColor.GREEN + "Changed Rank Name " + guild.rank5 + " to " + eda + ".");
										guild.rank5 = eda;
										guild.saveRank(5, eda);
										break;
									default:
										p.sendMessage(ChatColor.RED + "Incorrect format!");
										break;
									}
								}
							} else if(args[0].equalsIgnoreCase("accept")) {
								worked = true;
								if(args.length == 2) {
									guild.acceptApplicant(p, args[1]);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /accept <applicant_name>");
								}
							} else if(args[0].equalsIgnoreCase("reject")) {
								worked = true;
								if(args.length == 2) {
									guild.rejectApplicant(p, args[1]);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /reject <applicant_name>");
								}
							} else if(args[0].equalsIgnoreCase("promote")) {
								worked = true;
								if(args.length == 2) {
									guild.promote(args[1], p, member.rank);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /promote <name>");
								}
							} else if(args[0].equalsIgnoreCase("demote")) {
								worked = true;
								if(args.length == 2) {
									guild.demote(args[1], p, member.rank);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /demote <name>");
								}
							} else if(args[0].equalsIgnoreCase("expel")) {
								worked = true;
								if(args.length == 2) {
									guild.expel(args[1], p, member.rank);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /expel <name>");
								}
							} else if(args[0].equalsIgnoreCase("motd")) {
								worked = true;
								if(args.length >= 2) {
									StringBuilder sb = new StringBuilder("");
									for(int k = 1; k < args.length; k++)
										sb.append(args[k] + " ");
									guild.setMotd(sb.toString().trim(), p);
								} else {
									p.sendMessage(ChatColor.RED + "Incorrect format! Use as /motd <message>");
								}
							}
						}
					}
					if(!worked) {
						p.sendMessage(ChatColor.RED + "Invalid command! Use " + ChatColor.YELLOW + "/g help " + ChatColor.RED + "to see guild commands.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("kdr")) {
					p.sendMessage(ChatColor.GREEN + "Player Kills: " + plugin.getPD(p).playerKills);
					p.sendMessage(ChatColor.GREEN + "Mob Kills: " + plugin.getPD(p).mobKills);
					p.sendMessage(ChatColor.RED + "Deaths from Players: " + plugin.getPD(p).playerDeaths);
					p.sendMessage(ChatColor.RED + "Deaths from Mobs: " + plugin.getPD(p).mobDeaths);
					p.sendMessage(ChatColor.AQUA + "PvP KDR: " + (plugin.getPD(p).playerDeaths == 0 ? "Well, ya haven't died yet!" : String.format("%.3f", (double)(plugin.getPD(p).playerKills)/plugin.getPD(p).playerDeaths)));
				}
				if(cmd.getName().equalsIgnoreCase("pet")) {
					if(!RankManager.check(p, "knight") && (PetHandler.getPet(p) == null)) {
						p.sendMessage(ChatColor.RED + "You don't have a pet!");
						p.sendMessage(ChatColor.RED + "Knights and higher are able to buy 3 basic pets for 1,000 in-game gold.");
						p.sendMessage(ChatColor.RED + "Additional pets can be bought on our store at store.kastia.net.");
						p.sendMessage(ChatColor.RED + "Any pets that you buy can be used FOREVER, even if you aren't a Knight anymore!");
					} else {
						if(cmd.getName().equalsIgnoreCase("pet")) {
							try {
								if(args.length == 0) {
									PetHandler.showMainMenu(p);
								} else if (args.length == 1){
									if(args[0].toLowerCase().equals("menu")) {
										PetHandler.showMainMenu(p);
									} else {
										Pet pet = PetHandler.getPet(p);
										if(pet == null) {
											p.sendMessage(ChatColor.RED + "You don't have a pet yet! Use " + ChatColor.YELLOW + "/pet" + ChatColor.RED + " to buy a pet!"); 
										} else {
											switch(args[0].toLowerCase()) {
											case "call":
											case "here":
												if(pet.spawned) {
													pet.despawn();
													pet.spawn(p);
												} else {
													pet.spawn(p);
												}
												p.sendMessage(ChatColor.GREEN + "Your pet is now by your side!");
												break;
											case "hide":
											case "despawn":
												if(pet.spawned) {
													pet.despawn();
												}
												p.sendMessage(ChatColor.GREEN + "Your pet has gone into hiding.");
												break;
											case "ride":
												if(pet.spawned && pet.entity != null && pet.entity.isValid()) {
													if(p.getVehicle() != null)
														p.getVehicle().eject();
													pet.entity.teleport(p.getLocation());
													pet.entity.setPassenger(p);
												} else {
													if(p.getVehicle() != null)
														p.getVehicle().eject();
													pet.spawn(p);
													pet.entity.teleport(p.getLocation());
													pet.entity.setPassenger(p);
												}
												p.sendMessage(ChatColor.GREEN + "You're now riding your pet! Use WASD and Space Bar to control it!");
												break;
											case "unride":
												if(pet.spawned && pet.entity != null && pet.entity.isValid()) {
													pet.entity.eject();
												}
												p.sendMessage(ChatColor.GREEN + "You got off of your pet.");
												break;
											case "hat":
												if(pet.spawned && pet.entity != null && pet.entity.isValid()) {
													p.setPassenger(pet.entity);
												}
												p.sendMessage(ChatColor.GREEN + "Your pet is now floating above you!");
												break;
											case "unhat":
												if(pet.spawned && pet.entity != null && pet.entity.isValid()) {
													p.eject();
												}
												p.sendMessage(ChatColor.GREEN + "'Get down from there, silly!', you shouted. And so it did.");
												break;
											case "confirmname":
												if(plugin.getPD(p).proposedPetName != null && plugin.getPD(p).proposedPetName.length() > 0) {
													ItemStack item = null;
													for(ItemStack i : p.getInventory()) {
														if(EtcItem.getEtcType(i) == EtcItem.PET_NAME_CHANGE) {
															item = i;
															break;
														}
													}
													if(item == null) {
														p.sendMessage(ChatColor.RED + "Error! Your Pet Name Change item is no longer in your inventory!");
													} else {
														pet.name = plugin.getPD(p).proposedPetName;
														if(pet.spawned)
															pet.despawn();
														pet.spawn(p);
														p.sendMessage(ChatColor.GREEN + "Your pet's name is now " + ChatColor.AQUA + ChatColor.BOLD + pet.name + ChatColor.GREEN + "!");
														if(item.getAmount() > 1)
															item.setAmount(item.getAmount() - 1);
														else
															p.getInventory().removeItem(item);
														plugin.getPD(p).proposedPetName = null;
													}
												}
												break;
											default:
												p.sendMessage(ChatColor.RED + "Not a valid command. Use " + ChatColor.YELLOW + "/pet" + ChatColor.RED + " and click Pet Commands to view all commands.");	
												break;
											}
										}
									}
								} else {
									p.sendMessage(ChatColor.RED + "Not a valid command. Use " + ChatColor.YELLOW + "/pet" + ChatColor.RED + " and click Pet Commands to view all commands.");
								}
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("flyhorse")) {
					if(plugin.getPD(p).inDungeon) {
						p.sendMessage(ChatColor.RED + "Horses can't be used in dungeons, sorry!");
					} else {
						if(plugin.getPD(p).flyhorse) {
							Horse horse = (Horse) p.getWorld().spawnEntity(p.getLocation(), EntityType.HORSE);
							horse.setTamed(true);
							horse.setVariant(Variant.HORSE);
							horse.setColor(Color.WHITE);
							horse.setStyle(Style.WHITEFIELD);
							AttributeInstance attributes = ((EntityInsentient)((CraftLivingEntity)horse).getHandle()).getAttributeInstance(GenericAttributes.d);
							attributes.setValue(0.1125 + 0.0225 * 10);
							horse.setAdult();
							horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
							horse.getInventory().setArmor(new ItemStack(Material.GOLD_BARDING));
							horse.setPassenger(p);
							plugin.getPD(p).flyingHorse = true;
							p.sendMessage(ChatColor.GOLD + "You summon Pegasus, the flying horse. Spam jump key to fly.");
						} else {
							p.sendMessage(ChatColor.RED + "Sorry, but this command must be purchased separately from VIP in the Kastia Store.");
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("location")) {
					Location loc = p.getLocation();
					loc.setY(loc.getY() - 1);
					Block b = loc.getBlock();
					loc = b.getLocation();
					loc.setY(loc.getY() + 1);
					p.sendMessage("Your current location: " + (int)(loc.getX()) + ", " + (int)(loc.getY()) + ", " + (int)(loc.getZ()));
				}
				if(cmd.getName().equalsIgnoreCase("bank")) {
					if(RegionHandler.getWelcomeRegion(p.getLocation()).type.equals("secure")) {
						plugin.getPD(p).openBank();
					} else {
						p.sendMessage(ChatColor.RED + "/bank can only be used in secure regions.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("shop")) {
					if(RegionHandler.getWelcomeRegion(p.getLocation()).type.equals("secure")) {
						ShopHandler.openInventory(p);
					} else {
						p.sendMessage(ChatColor.RED + "/shop can only be used in secure regions.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("vote")) {
					p.sendMessage(ChatColor.GREEN + "You currently have " + plugin.getPD(p).votepoints + " Vote Points.");
					p.sendMessage(ChatColor.GREEN + "Use /votepoints to spend your Vote Points on cool rewards!");
					p.sendMessage("");
					p.sendMessage(ChatColor.GREEN + "CLICK THE LINK: " + ChatColor.GOLD + "www.kastia.net");
					p.sendMessage(ChatColor.GREEN + "Look for \"VOTE FOR REWARDS\" on the right side of the page.");
					p.sendMessage(ChatColor.GREEN + "You should know what to do after that! :D");
				}
				if(cmd.getName().equalsIgnoreCase("votepoints")) {
					p.sendMessage(ChatColor.GREEN + "You currently have " + plugin.getPD(p).votepoints + " Vote Points.");
					VoteHandler.openInventory(p);
				}
				if(cmd.getName().equalsIgnoreCase("navigate")) {
					if(args.length == 3) {
						int x = Integer.parseInt(args[0].replaceAll("[^0-9]", ""));
						int y = Integer.parseInt(args[1].replaceAll("[^0-9]", ""));
						int z = Integer.parseInt(args[2].replaceAll("[^0-9]", ""));
						p.setCompassTarget(new Location(p.getWorld(),x,y,z));
						p.sendMessage(ChatColor.GREEN + "Set Navigator's target to " + x + ", " + y + ", " + z + ".");
					} else {
						p.sendMessage(ChatColor.RED + "Error: Incorrect format! Correct format is " + ChatColor.YELLOW + "/navigate x y z" + ChatColor.RED + ".");
						p.sendMessage(ChatColor.RED + "(x,y,z) is the coordinates of your destination.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("channel")) {
					ChannelManager.showChannelMenu(p);
				}
				if(cmd.getName().equalsIgnoreCase("horse")) {
					if(plugin.getPD(p).inDungeon) {
						p.sendMessage(ChatColor.RED + "Horses can't be used in dungeons, sorry!");
					} else {
						if(p.getVehicle() != null && p.getVehicle() instanceof Horse) {
							p.sendMessage(ChatColor.RED + "You're already riding a horse, you silly pumpkin.");
						} else {
							if(HorseHandler.spawnHorse(p)) {
								PlayerData pd = plugin.getPD(p);
								p.sendMessage("");
								p.sendMessage(ChatColor.GREEN + "Press \"Sneak\" at any time to dismount your horse.");
								p.sendMessage(ChatColor.GREEN + "You are able to engage in combat while riding a horse.");
								p.sendMessage(ChatColor.GREEN + "You can ride " + pd.horseType.name + " for " + (int)(pd.timeLeftWithHorse / 1000.0 / 60.0) + " more minutes.");
								p.sendMessage(ChatColor.GREEN + "" + ChatColor.ITALIC + "Hint: The time left on your rent is only checked on dismounts.");
							} else {
								p.sendMessage("");
								p.sendMessage(ChatColor.RED + "You don't have an active horse to ride at the moment.");
								p.sendMessage(ChatColor.RED + "Head to the nearest Kastia Stables to rent a horse!");
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("leavedungeon")) {
					if(plugin.getPD(p).inDungeon) {
						DungeonHandler.leaveInstance(p);
					} else {
						p.sendMessage("You are not in a dungeon right now!");
					}
				}
				if(cmd.getName().equalsIgnoreCase("enchant")) {
					p.sendMessage(ChatColor.RED + "Enchanting is currently disabled while enchant scrolls are rebalanced.");
					//						EnchantHandler.openEnchantInventory(p);
				}
				if(cmd.getName().equalsIgnoreCase("options")) {
					try {
						OptionsHandler.openOptionsMenu(p);
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				if(cmd.getName().equalsIgnoreCase("minigames")) {
					MinigameHandler.openMinigames(p);
				}
				if(cmd.getName().equalsIgnoreCase("checklag")) {
					if(sender instanceof Player) {
						if(plugin.getPD(p).checkLagTaskId > -1) {
							p.sendMessage("You just sent this request!");
							return true;
						}
						TPSChecker tps = new TPSChecker(p);
						plugin.getPD(p).checkLagTaskId = SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, tps);
						//							final long started = System.currentTimeMillis();
						//							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						//								public int timesRun = 0;
						//								public void run() {
						//									long now = System.currentTimeMillis();
						//									timesRun++;
						//									if(timesRun >= 20) {
						//										if(!p2.isOnline() || p2 == null || plugin.getPD(p2) == null)
						//											return;
						//										p2.sendMessage("Ran 20 ticks in " + (now - started) + "ms.");
						//										p2.sendMessage("Latency of " + Math.abs((int)(now - started) - 1000) + "ms.");
						//									} else {
						//										SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 1);
						//									}
						//								}
						//							});
					}
				}
				if(cmd.getName().equalsIgnoreCase("party")) {
					PlayerData pd = plugin.getPD(p);
					try {
						switch(args[0].toLowerCase()) {
						case "create":
						case "c":
							if(pd.party == null) {
								pd.party = new Party(p);
								p.sendMessage("You have created a new party! Check out " + ChatColor.YELLOW + "/party help" + ChatColor.RESET + " for party commands");
							} else {
								p.sendMessage("You are already in a party... Leave your current one to create another.");
							}
							break;
						case "disband":
						case "d":
							if(pd.party != null) {
								if(pd.party.leader.equalsIgnoreCase(p.getName())) {
									pd.party.disband();
								} else {
									p.sendMessage("Only the party leader can disband the party!");
								}
							}
							break;
						case "join":
						case "j":
							if(pd.party == null) {
								String s = args[1];
								Player partyOwner = plugin.getServer().getPlayer(s);
								PlayerData pd2 = plugin.getPD(partyOwner);
								if(pd2.party != null) {
									pd2.party.joinRequest(p);
								} else {
									p.sendMessage(partyOwner.getName() + " is not in a party!");
								}
							}
							break;
						case "acceptrequest":
						case "a":
							if(pd.party != null) {
								pd.party.acceptPlayer(args[1]);
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "togglerequests":
							if(pd.party != null) {
								if(pd.party.leader.equalsIgnoreCase(p.getName())) {
									pd.party.toggleRequests();
								} else {
									p.sendMessage("Only the party leader can toggle party join requests.");
								}
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "lock":
							pd.partyChatLock = !pd.partyChatLock;
							p.sendMessage(ChatColor.GREEN + "Party Chat Lock is now " + (pd.partyChatLock ? "ON." : "OFF."));
							if(pd.partyChatLock)
								p.sendMessage(ChatColor.GREEN + "All your chat messages now go to party chat. No need for \\<message>!");
							break;
						case "info":
							if(pd.party != null) {
								pd.party.info(p);
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "invite":
						case "i":
							if(pd.party != null) {
								pd.party.invite(args[1], p);
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "acceptinvite":
							if(pd.party == null) {
								if(pd.invitedTo != null) {
									pd.invitedTo.joinParty(p);
								} else {
									p.sendMessage("You have not been invited to join a party.");
								}
							} else {
								p.sendMessage("You are already in a party.");
							}
							break;
						case "leave":
							if(pd.party != null) {
								pd.party.leaveParty(p);
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "makeleader":
							if(pd.party != null) {
								if(pd.party.leader.equalsIgnoreCase(p.getName())) {
									pd.party.changeLeader(args[1]);
								} else {
									p.sendMessage("Only the party leader can change leadership");
								}
							} else {
								p.sendMessage("You are not in a party.");
							}
							break;
						case "kick":
							if(pd.party != null) {
								if(pd.party.leader.equalsIgnoreCase(p.getName())) {
									pd.party.kick(args[1]);
								} else {
									p.sendMessage("Only the party leader can kick members!");
								}
							} else {
								p.sendMessage("You are not in a party.");
							}
						case "help":
							String[] partyHelp = new String[] {
									"",
									"Kastia Party System Commands",
									"",
									"/party help " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " show this help message",
									"/party create " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " create a new party",
									"/party disband " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " disband a party you are leading",
									"/party leave " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " leave your current party",
									"/party join <name> " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " request to join <name>'s party",
									"/party kick <name> " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " kick <name> from your party",
									"/party acceptrequest <name> " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " accept <name> to your party",
									"/party invite <name> " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " invite <name> to your party",
									"/party acceptinvite " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " accept your most recent invite",
									"/party makeleader <name>" + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " make <name> the party leader",
									"/party togglerequests " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " toggle player join requests",
									"/party info " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " displays some information on your current party",
									"/party lock " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " toggle Party Chat Lock",
									"\\<message> " + ChatColor.LIGHT_PURPLE + "-" + ChatColor.YELLOW + " send a <message> to your party",
									"",
									"You may also use /p as an abbreviation for /party.",
									"If you do not wish to accept an invite, just ignore it!"
							};
							for(String s : partyHelp)
								p.sendMessage(ChatColor.AQUA + s);
							break;
						default:
							p.sendMessage("Incorrect command usage! Check out " + ChatColor.YELLOW + "/party help" + ChatColor.RESET + " for party commands.");
							break;
						}
					} catch(Exception e) {
						p.sendMessage("Incorrect command usage! Check out " + ChatColor.YELLOW + "/party help" + ChatColor.RESET + " for party commands.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("stats")) {
					plugin.getPD(p).openStatsMenu();
				}
				if(cmd.getName().equalsIgnoreCase("skip")) {
					try {
						try {
							for(Integer i : plugin.getPD(p).autoTalkTask)
								plugin.getServer().getScheduler().cancelTask(i);
						} catch(Exception e) {

						}
						PlayerData pd = plugin.getPD(p);
						if(pd.lastVillager != null && pd.lastStage.quest != null) {
							int current = 0;
							int last = -1;
							current = pd.inProgressQuests.get(pd.lastStage.quest);
							do {
								last = pd.inProgressQuests.get(pd.lastStage.quest);
								pd.lastVillager.handleInteract(p);
								current = pd.inProgressQuests.get(pd.lastStage.quest);
							} while(current != last);
						}
					} catch(Exception e2) {

					}
				}
				if(cmd.getName().equalsIgnoreCase("trade")) {
					if(args.length == 1) {
						PlayerData pd1 = plugin.getPD(p);
						try {
							PlayerData pd2 = plugin.getPD(args[0]);
							pd1.toTrade = pd2.player.getName();
							if(pd2.player == p) {
								p.sendMessage("You silly pumpkin, you can\'t trade yourself!");
							} else {
								if(pd2.player.getLocation().distance(pd1.player.getLocation()) > 50) {
									p.sendMessage(ChatColor.RED + "You are too far away from " + pd2.player.getName() + " to start a trade!");
								} else {
									if(pd2.toTrade.equalsIgnoreCase(p.getName())) {
										TradeHandler.newTrade(p, pd2.player);
										pd1.toTrade = "";
										pd2.toTrade = "";
									} else {
										pd2.player.sendMessage(ChatColor.GREEN + p.getName() + " has sent you a trade request!");
										pd2.player.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/trade " + p.getName() + ChatColor.GREEN + " to open the trade window.");
										pd1.player.sendMessage(ChatColor.GREEN + "Sent a trade request to " + pd2.player.getName() + "...");
									}
								}
							}
						} catch(Exception e) {
							p.sendMessage("Could not find player " + args[0] + "!");
							pd1.toTrade = "";
						}
					} else {
						p.sendMessage("Incorrect format. Use as /trade <player_name>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("sell")) {
					SellerHandler.show(p);
				}
				if(cmd.getName().equalsIgnoreCase("unstuck")) {
					int count = 0;
					PlayerData stuck = plugin.getPD(p);
					if(System.currentTimeMillis() - stuck.lastUnstuckRequest > 10*1000) {
						stuck.lastUnstuckRequest = System.currentTimeMillis();
						for(PlayerData pd : plugin.players.values()) {
							if(RankManager.check(p, "helper")) {
								count++;
								SoundHandler.playSound(p, org.bukkit.Sound.EXPLODE);
								pd.player.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + p.getName() + " is stuck!");
								pd.player.sendMessage(ChatColor.AQUA + "As someone with access to /fly, /tpto, and /tphere, you should help them get out. Your assistance is appreciated!");
							}
						}
						if(count == 0)
							p.sendMessage(ChatColor.RED + "Sorry!!! It appears that there are no players online right now who have the commands to help you. Please use /spawn, or check back later.");
						else 
							p.sendMessage(ChatColor.GREEN + "Sent your /unstuck request to " + count + (count > 1 ? " people" : " person") + " online who " + (count > 1 ? "have" : "has")+ " commands to help you get out.");						
						p.sendMessage(ChatColor.GREEN + "Consider using /spawn if it's not too much of a hassle.");
						p.sendMessage(ChatColor.GREEN + "Please be patient, wait a minute and someone will come!");
					} else {
						p.sendMessage(ChatColor.RED + "You may only use /unstuck once every 10 seconds.");
					}
				}
				if(cmd.getName().equalsIgnoreCase("spawn")) {
					p.sendMessage(ChatColor.RED + "To prevent abuse, this command has a warmup of 15 seconds, after which you will"
							+ " be warped to Stonehelm. If you move during this time, the warp will be cancelled.");
					WarpHandler.warp(p, "Stonehelm", EtcItem.WARPSCROLL_STONEHELM, 15, false);
				}
				if(cmd.getName().equalsIgnoreCase("level")) {
					PlayerData pd = plugin.players.get(p.getName());
					p.sendMessage("You are currently level " + pd.level + ".");
				}
				if(cmd.getName().equalsIgnoreCase("region")) {
					Region r = RegionHandler.getWelcomeRegion(p.getLocation());
					r.sendWelcome(p, true);
				}
				if(cmd.getName().equalsIgnoreCase("checkworld")) {
					p.sendMessage("Currently in world " + p.getLocation().getWorld().getName());
				}
				if(cmd.getName().equalsIgnoreCase("help") || cmd.getName().equalsIgnoreCase("?")) {
					if(args.length == 1) {
						try {
							p.sendMessage(help[Integer.parseInt(args[0]) - 1]);
						} catch(Exception e) {
							p.sendMessage(help[0]);
						}
					} else {
						p.sendMessage(help[0]);
					}
				}
				if(cmd.getName().equalsIgnoreCase("vip")) {
					
				}
				if(cmd.getName().equalsIgnoreCase("players")) {
					StringBuilder sb = new StringBuilder("");
					for(Player p2 : plugin.getServer().getOnlinePlayers()) {
						sb.append(RankManager.getPrefix(p2.getName()) + p2.getName() + ", ");
					}
					p.sendMessage("");
					p.sendMessage(ChatColor.UNDERLINE + "Online Players (" + plugin.getServer().getOnlinePlayers().length + ")");
					p.sendMessage("");
					p.sendMessage(sb.toString().substring(0, sb.length() - 2));
				}
				if(cmd.getName().equalsIgnoreCase("staff")) {
					p.sendMessage("You can find the official staff list at www.kastia.net!");
				}
				if(cmd.getName().equalsIgnoreCase("alpha")) {
					//						plugin.getPD(p).rank = 9;
					//						plugin.getPD(p).save();
					//						p.sendMessage("Hello Alpha Tester! Gave you Owner rank.");
				}
				if(cmd.getName().equalsIgnoreCase("setqt")) {
					try {
						if(args.length == 2) {
							PlayerData pd = plugin.getPD(p);
							int slot = Integer.parseInt(args[0]);
							String name = args[1];
							if(name.matches(".*[^a-zA-Z0-9].*")) {
								p.sendMessage(ChatColor.RED + "Invalid QT Slot name! The name must be alphanumeric with NO SPACES. For example:");
								p.sendMessage(ChatColor.GREEN + "GOOD: " + ChatColor.WHITE + "Stonehelm, C00lPlac3, RonboIsAwesome");
								p.sendMessage(ChatColor.RED + "BAD: " + ChatColor.WHITE + "Stone helm, Yay!!, @@@fun@@!");
							} else {
								if(name.length() > 25) {
									p.sendMessage(ChatColor.RED + "Invalid QT Slot name! The name must be shorter than 25 characters!");
									p.sendMessage(ChatColor.GREEN + "GOOD: " + ChatColor.WHITE + "RonboIsASmarty");
									p.sendMessage(ChatColor.RED + "BAD: " + ChatColor.WHITE + "WowKastiaIsReallyFunRightYeahILoveIt");
								} else {
									if(!p.getLocation().getWorld().getName().equals("world")) {
										p.sendMessage(ChatColor.RED + "Invalid location! QT Slots can only be set in the main world.");
									} else {
										if(slot-1 < 0 || pd.QTLocs.get(slot-1) == null) {
											p.sendMessage(ChatColor.RED + "That is not a valid QT Slot!.");
										}
										pd.QTLocs.get(slot-1).name = name;
										pd.QTLocs.get(slot-1).loc = p.getLocation();
										p.sendMessage(ChatColor.GREEN + "Success! Saved QT Slot " + slot + " to be your current location.");
									}
								}
							}
						} else {
							p.sendMessage(ChatColor.RED + "Incorrect format! Use as " + ChatColor.YELLOW + "/setqt <Slot #> <Slot Nickname>");
						}
					} catch(Exception e) {
						p.sendMessage(ChatColor.RED + "Incorrect format! Use as " + ChatColor.YELLOW + "/setqt <Slot #> <Slot Nickname>");
					}
				}
				if(cmd.getName().equalsIgnoreCase("spiritpoints")) {
					int numSP = plugin.getPD(p).spiritPoints;
					p.sendMessage("");
					p.sendMessage(ChatColor.AQUA + "Spirit Points in Kastia let you keep your items when you die.");
					p.sendMessage(ChatColor.YELLOW + "You lose 1 Spirit Point when you die normally. You lose " + ChatColor.BOLD + "3" + ChatColor.YELLOW + 
							" Spirit Points when you die to a player, so be careful in PvP!");
					p.sendMessage(ChatColor.RED + "If you die and you lose more Spirit Points than you have, then each item you have has a chance of being dropped.");
					p.sendMessage(ChatColor.GREEN + "  - 40% chance of losing equipped armor");
					p.sendMessage(ChatColor.GREEN + "  - 40% chance of losing items in first 3 slots of inventory");
					p.sendMessage(ChatColor.RED + "  - 70% chance of losing other stuff");
					p.sendMessage(ChatColor.AQUA + "Players can have up to 10 Spirit Points. VIPs can have 15.");
					p.sendMessage((numSP > 0 ? ChatColor.GREEN : ChatColor.RED) + "You have " + numSP + " Spirit Points.");
				}
				if(cmd.getName().equalsIgnoreCase("wallet")) {
					p.sendMessage("");
					p.sendMessage(ChatColor.AQUA + "When you pick up gold in Kastia, it is stored in your wallet.");
					p.sendMessage(ChatColor.GREEN + "Your wallet is always with you, and you buy things using it.");
					p.sendMessage(ChatColor.RED + "When you die, you lose " + ChatColor.BOLD + "10-20%" + ChatColor.RED + " of the gold in your wallet.");
					p.sendMessage(ChatColor.GREEN + "Keep extra gold in your bank - it'll never be lost!");
					p.sendMessage(ChatColor.AQUA + "Withdraw banknotes from your bank to " + ChatColor.YELLOW + "/trade" + ChatColor.AQUA + " with players.");
					p.sendMessage(ChatColor.YELLOW + "Your wallet currently has " + ChatColor.GOLD + plugin.getPD(p).wallet + "g" + ChatColor.YELLOW + ".");
				}
				if(cmd.getName().equalsIgnoreCase("played")) {
					long time = plugin.getPD(p).minutesPlayed + (System.currentTimeMillis() - plugin.getPD(p).logonTime) / 1000 / 60;
					p.sendMessage("You have played Kastia for " + time/24/60 + " days, " + time/60%24 + " hours, and " + time%60 + " minutes.");
					p.sendMessage("You joined Kastia on " + plugin.getPD(p).joindate + ".");
				}
				if(cmd.getName().equalsIgnoreCase("motd")) {
					sendWelcomeMessage(p);
				}
				if(cmd.getName().equalsIgnoreCase("skiptutorial")) {
					//					p.getInventory().addItem(EtcItem.WARPSCROLL_STONEHELM.makeItems(1));
					p.sendMessage("You have chosen to skip the tutorial. Use the Warp Scroll to continue to Stonehelm.");
					p.sendMessage("Good luck in Kastia! If you are confused about anything because you skipped the tutorial, just check out the wiki at www.Kastia.net!");
					plugin.getPD(p).inProgressQuests.remove(QuestHandler.quests.get(6));
					plugin.getPD(p).completedQuests.add(QuestHandler.quests.get(6));
				}
				if(cmd.getName().equalsIgnoreCase("empty")) {
					if(args.length == 0) {
						p.sendMessage(ChatColor.RED + "Warning! This will PERMANENTLY delete your inventory and armor!");
						p.sendMessage(ChatColor.AQUA + "Use " + ChatColor.YELLOW + "/empty confirm" + ChatColor.AQUA + " if you are sure you want to delete your stuff!");
					} else {
						if(args[0].equals("confirm")) {
							p.sendMessage("Emptying your inventory and armor...");
							p.getInventory().clear();
							plugin.getPD(p).checkNavigator();
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("quests")) {
					plugin.getPD(p).giveQuestLog();
				}
				if(cmd.getName().equalsIgnoreCase("hub")) {
					p.sendMessage(ChatColor.GREEN + "Sending you to the Kastia Lobby...");
					ByteArrayOutputStream b = new ByteArrayOutputStream();
					DataOutputStream out = new DataOutputStream(b);
					try {
						out.writeUTF("Connect");
						out.writeUTF("hub");
					} catch (IOException e) {
						e.printStackTrace();
					}
					p.sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
				}
			} else {
				//Console commands
				if(cmd.getName().equalsIgnoreCase("countmobs")) {
					int count = 0;
					for(World w : plugin.getServer().getWorlds()) {
						for(Entity e : w.getEntities())
							if(MobHandler.spawnedMobs.containsKey(e.getUniqueId()))
								count++;
					}
					System.out.println("Counted " + count + " mobs across all worlds.");
				}
				if(cmd.getName().equalsIgnoreCase("rl")) {
					System.out.println("Use /forcesave for a sync save.");
				}
				if(cmd.getName().equalsIgnoreCase("checklag")) {
				}
				if(cmd.getName().equalsIgnoreCase("spawns")) {
					System.out.println(spawnsComplete ? "Spawns are complete! Spawned " + MobHandler.totalAutoSpawned : "Still spawning mobs... Spawned " + MobHandler.totalAutoSpawned);
				}
				if(cmd.getName().equalsIgnoreCase("debug")) {
					System.out.println(plugin.getServer().getScheduler().getPendingTasks().size() + " tasks running");
				}
				if(cmd.getName().equalsIgnoreCase("debug2")) {

				}
				if(cmd.getName().equalsIgnoreCase("players")) {
					if(plugin.getServer().getOnlinePlayers().length == 0) {
						System.out.println("No one is online.");
					} else {
						StringBuilder sb = new StringBuilder("");
						for(Player p2 : plugin.getServer().getOnlinePlayers()) {
							sb.append(RankManager.getPrefix(p2.getName()) + p2.getName() + ", ");
						}
						System.out.println();
						System.out.println("Online Players (" + plugin.getServer().getOnlinePlayers().length + ")");
						System.out.println(ChatColor.stripColor(sb.toString().substring(0, sb.length() - 2)));
					}
				}
				if(cmd.getName().equalsIgnoreCase("killall")) {
					for(World w : plugin.getServer().getWorlds())
						for(Entity e : w.getEntities())
							try {
								MobHandler.spawnedMobs.get(e.getUniqueId()).die();
							} catch(Exception e2) {
								try {
									if(e instanceof LivingEntity && !(e instanceof Player) && !(e instanceof Villager))
										e.remove();
								} catch(Exception e3) {

								}
							}
				}
			}
		}
		return true;
	}

	public static boolean spawnsComplete = false;

	public static class ChunkFixerTask implements Runnable {
		public void run() {
			p.sendMessage("Fixing block set " + ++count + ".");
			for(int k = 0; k < 16*16*5 && coords.size() > 0; k++) {
				Integer[] c = coords.remove(0);
				if(c[1] > highest) {
					p.sendMessage("Chunk fixing complete!");
					p.sendMessage("Fixed a total of " + numFixed + " blocks.");
					return;
				}
				Block blockToFix = copyTo.getBlock(c[0], c[1], c[2]);
				//				System.out.println("copying block " + Material.getMaterial(copyFrom.getBlockTypeId(c[0], c[1], c[2])) + " to " + blockToFix);
				blockToFix.setData((byte)copyFrom.getBlockData(c[0], c[1], c[2]));
				blockToFix.setType(Material.getMaterial(copyFrom.getBlockTypeId(c[0], c[1], c[2])));
				blockToFix.setBiome(plugin.getServer().getWorld("uncorrupted_world").getBiome(c[0], c[1]));
				numFixed++;
			}
			if(coords.size() <= 0) {
				p.sendMessage("Chunk fixing complete!");
				p.sendMessage("Fixed a total of " + numFixed + " blocks.");
			} else {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 5);
			}
		}
		public int numFixed = 0;
		public int count = 0;
		public ArrayList<Integer[]> coords;
		public Chunk copyTo;
		public ChunkSnapshot copyFrom;
		public Player p;
		public Location playerLoc;
		public int highest;
		public ChunkFixerTask(ArrayList<Integer[]> coords, Chunk copyTo, ChunkSnapshot copyFrom, Player p, int highest) {
			this.coords = coords;
			this.copyTo = copyTo;
			this.copyFrom = copyFrom;
			this.p = p;
			this.highest = highest;
		}
	}

	public ArrayList<Integer> checkLagID = new ArrayList<Integer>();

	public static void sendWelcomeMessage(final Player p) {
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage("");
		p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "                    Welcome to Kastia!");
		p.sendMessage("");
		p.sendMessage(ChatColor.AQUA + "" + "                     Please join the community at");
		p.sendMessage(ChatColor.AQUA + "" + "                             www.Kastia.net");
		p.sendMessage("");
		if(plugin.getServer().getOnlinePlayers().length > 1)
			p.sendMessage(ChatColor.GREEN + "              There are currently " + ChatColor.BOLD + plugin.getServer().getOnlinePlayers().length + ChatColor.GREEN + " players online!");
		else
			p.sendMessage(ChatColor.GREEN + "                There is currently " + ChatColor.BOLD + "1" + ChatColor.GREEN + " player online!");
		p.sendMessage("");
		p.sendMessage(ChatColor.GRAY + "" + ChatColor.ITALIC + "                  You are currently on " + ChannelManager.thisChannel.name + ".");
		p.sendMessage(ChatColor.GRAY + "" + ChatColor.ITALIC + "             Use /channel or /cc to change channels!");
		p.sendMessage("");
	}
	public static String[][] help = {
		{	
			"", 
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			ChatColor.LIGHT_PURPLE + "      |             Kastia Basic Guide (Page 1/5)               |",
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			"", 
			ChatColor.GOLD + "  Need help with commands? Use " + ChatColor.GREEN + "/help # " + ChatColor.GOLD + "to access ", 
			ChatColor.GOLD + "  a certain page of /help!", 
			"", 
			ChatColor.AQUA + "  Check out the wiki at www.Kastia.net! It provides great", 
			ChatColor.AQUA + "  documentation on the many features of Kastia.", 
			"", 
			ChatColor.GREEN + "  If you are just starting out, speak to Vorran on Tutorial", 
			ChatColor.GREEN + "  Island to begin! The rest should be easy to follow.",
			"", 
			ChatColor.BLUE + "  Looking for a good place to train? Check out the Kastia Wiki", 
			ChatColor.BLUE + "  for suggested training locations, or head to the forums", 
			ChatColor.BLUE + "  and ask around to see where other players like to train!", 
			"", 
			ChatColor.RED + "  Open the whole chat to",
			ChatColor.RED + "  see all of /help!"
		},
		{
			"", 
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			ChatColor.LIGHT_PURPLE + "      |             Kastia Basic Guide (Page 2/5)               |",
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			"", 
			ChatColor.GREEN + "  /spawn",
			ChatColor.GOLD + "   - warps you back to Stonehelm after 15 seconds",
			ChatColor.GREEN + "  /quests",
			ChatColor.GOLD + "   - receive a Quest Log with details on all quests",
			ChatColor.GREEN + "  /trade <Player_Name>",
			ChatColor.GOLD + "   - send a trade request to <Player_Name>",
			ChatColor.GREEN + "  /party help",
			ChatColor.GOLD + "   - view the Kastia Party System commands", 
			ChatColor.GREEN + "  /bank",
			ChatColor.GOLD + "   - open your bank to store items and gold", 
			ChatColor.GREEN + "  /shop",
			ChatColor.GOLD + "   - open the Kastia Player Market", 
			ChatColor.GREEN + "  /g",
			ChatColor.GOLD + "   - open the Kastia Guilds Menu", 
			"",
		},
		{
			"", 
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			ChatColor.LIGHT_PURPLE + "      |             Kastia Basic Guide (Page 3/5)               |",
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			"", 
			ChatColor.GREEN + "  !<message> - CURRENTLY DISABLED",
			ChatColor.GOLD + "   - send a global message visible to everyone", 
			ChatColor.GREEN + "  /kdr",
			ChatColor.GOLD + "   - view your kill and death count",
			ChatColor.GREEN + "  /pet",
			ChatColor.GOLD + "   - open the Kastia Pets Menu", 
			ChatColor.GREEN + "  /spiritpoints",
			ChatColor.GOLD + "   - view your current Spirit Points and learn what it is",
			ChatColor.GREEN + "  /sell",
			ChatColor.GOLD + "   - open an interface for selling your junk equips",
			ChatColor.GREEN + "  /options",
			ChatColor.GOLD + "   - open the options menu to change your settings",
			ChatColor.GREEN + "  /unstuck",
			ChatColor.GOLD + "   - alerts online staff members that you are stuck",
			"",
		},
		{
			"", 
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			ChatColor.LIGHT_PURPLE + "      |             Kastia Basic Guide (Page 4/5)               |",
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			"", 
			ChatColor.GREEN + "  /channel OR /cc",
			ChatColor.GOLD + "   - change to other channels of Kastia",
			ChatColor.GREEN + "  /motd",
			ChatColor.GOLD + "   - receive the welcome message again",
			ChatColor.GREEN + "  /skip",
			ChatColor.GOLD + "   - skip the dialogue of a quest and get the next objective",
			ChatColor.GREEN + "  /region",
			ChatColor.GOLD + "   - check the name and danger level of the region you are in",
			ChatColor.GREEN + "  /vip",
			ChatColor.GOLD + "   - receive information on how to upgrade to VIP",
			ChatColor.GREEN + "  /played",
			ChatColor.GOLD + "   - see how long you've played Kastia",
			ChatColor.GREEN + "  /vote",
			ChatColor.GOLD + "   - learn how to vote for Vote Points",
			"",
		},
		{
			"", 
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			ChatColor.LIGHT_PURPLE + "      |             Kastia Basic Guide (Page 5/5)               |",
			ChatColor.LIGHT_PURPLE + "      *****************************************************", 
			"", 
			ChatColor.GREEN + "  /navigate <x> <y> <z>",
			ChatColor.GOLD + "   - make your Navigator point to the given coordinates",
			ChatColor.GREEN + "  /horse",
			ChatColor.GOLD + "   - mount your horse rented from the Kastia Stables",
			ChatColor.GREEN + "  /enchant",
			ChatColor.GOLD + "   - open the enchanting interface",
			ChatColor.GREEN + "  /staff",
			ChatColor.GOLD + "   - view a list of all Kastia staff members",
			ChatColor.GREEN + "  /players",
			ChatColor.GOLD + "   - view a list of all online players",
			ChatColor.GREEN + "  /empty",
			ChatColor.GOLD + "   - empty your inventory and armor (use with caution!)",
			ChatColor.GREEN + "  /wallet",
			ChatColor.GOLD + "   - view some info on what your wallet is for",
			"",
		},
	};

	public static String[] commands = 
		{
		"test", "level", "setlevel", "debug", "broadcast", "testmenu", 
		"forcesave", "sethp", "setmaxhp", "stats","spawnmob", "generatedrops", "fly",
		"killall", "setexp", "addexp", "rl", "worlds", "changeworld", "setspawn", "region",
		"giveitem", "realregion", "location", "addgold",
		"checklag", "help", "players", "staff", "party", "teleport", "generateitems",
		"resetcooldown", "setclass", "blockloc", "tpto", "tphere", "alpha", "bank", "trade",
		"setwarp", "warp", "warplist", "deletewarp", "checkregion", "setquest", "completequest", "uncompletequest",
		"forcereload", "forceop", "minigames", "makechest", "?", "motd", "givereward", "generatemoblist",
		"options", "skiptutorial", "enchant", "fixlocations", "vip", "horse", "debug2", "leavedungeon",
		"forcegrow", "section", "channel", "flyspeed", "vote", "votepoints", "countmobs",
		"regionedit", "checkworld", "npcedit", "fixchunk", "deletechest", "unstuck", "skip",
		"spawn", "reloadnpcs", "sell", "killnearby", "empty", "quests", "forceparty", "setqt",
		"easyloc", "flyhorse", "spawns", "reflect", "copyinventory", "copybank", "softwipe",
		"spiritpoints", "played", "wallet", "navigate", "shop", "resetplayer", "pet", "me",
		"setinventory", "votekick", "forcestop", "g", "time", "gc", "kdr",
		"hide", "show", "setbank", "grapple", "hub", "reloadconfigs", "generatetier", "rename", "fake",
		"ignore", "bounty"
		};

}
