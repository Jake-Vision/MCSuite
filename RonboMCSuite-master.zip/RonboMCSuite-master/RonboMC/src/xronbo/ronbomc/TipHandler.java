package xronbo.ronbomc;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class TipHandler {
	
	public static RonboMC plugin;
	
	private TipHandler() {
		
	}
	
	public static String lastSent = "";
	
	public static final String[] TIPS = {
		"If you have suggestions, please post them on the forums. I read and respond to all well-written suggestions.",
		"Clerics are essential to any successful high-level party, so start making friends with clerics!",
		"Archers and Wizards are dangerous from a range, but quite fragile in melee combat.",
		"As an Assassin, consider \"loading\" several spells in a row for a massive burst of damage!",
		"If you can survive the initial spell damage from an Assassin, you can probably beat one in a fight - they have no damage reduction!",
		"Pick a good combination of Class Passives to give yourself a mixture of damage and survivability.",
		"Damage Reduction is essential in higher-level combat. Without any Damage Reduction, you will probably die within seconds in any fight.",
		"When training in a party, you will often gain EXP much faster, so try to find some friends to party with!",
		"Trading is a great way to meet new people and become one of the richest players in Kastia.",
		"Quests are totally optional! However, for some high-level content, you may need to have certain quests completed. Plus, they're really fun!",
		"Kastia is coded and owned by Ronbo! All hail the King ^_^",
		"Loot Chests in dangerous areas may have dangerously good loot in them. ;D But be careful! With great reward comes great risk!",
		"If you ever forget what to do next in a quest, just check your Quest Log with /quests!",
		"Don't feel like killing some mobs for loot or running around trying to sell things? Try out Activities such as Harvesting to earn some easy cash while exploring the world!",
		"Dungeons can be ridiculously hard to beat on your own. Try gathering a party to do them with you - the rewards for party and solo clears are the same!",
		"Kastia is a massive world. If you need to get somewhere fast, try buying a Warp Scroll for cities. For more obscure destinations, consider renting a horse from the Kastia Stables!",
		"The hardware required to keep Kastia running smoothly 24/7 is kind of, well, super expensive. Any and all purchases to support Kastia are always greatly appreciated!",
		"The Kastia lore is more expansive than you may think! Talk to all the NPCs you meet - even ones with no real function - to slowly unravel the mysteries of Kastia!",
		"You can change classes whenever you want, wherever you want. But, changing classes gets more expensive as you level up, so unless you're incredibly rich, try settling on your favorite class in your early levels!",
		"We spend a lot of time balancing classes, mobs, and items, but sometimes that's just not enough. If you think something is too strong or too weak, please, let us know!",
		"Enchanting can make your favorite weapons and armors stronger than before! But be warned! Make sure you are aware that your equipment can be destroyed by failed enchants under some conditions!",
		"Small Easter eggs are hidden throughout the world of Kastia. Feel free to share your finds with the community!",
		"Unfortunately, even the most adventurous soul may accidentally get stuck in some hole. If this happens to you, just use /unstuck!",
		"There is a DynMap of the Kastia world available at www.kastia.net/map, be sure to check it if you get lost!",
		"Want to help support Kastia? Buy VIP or something cool at store.kastia.net!",
		"Please join our website at www.kastia.net!",
		"Want to fly across the skies on a horse? Reach places never before seen by other players? Purchase Pegasus from our store today! store.kastia.net",
		"Got lost? Use the /quests command to give you a quest log to help you on your way!",
	};
	
	
	public static final String FORMAT = ChatColor.GREEN + "" + ChatColor.BOLD + " * Tip: " + ChatColor.RESET + "" + ChatColor.GOLD;
	
	public static void send() {
		String toSend = "";
		do {
			toSend = getRandom(TIPS);
		} while(toSend.equals(lastSent) || toSend.equals(""));
		lastSent = toSend;
		for(Player p : plugin.getServer().getOnlinePlayers())
			if(plugin.getPD(p) != null)
				if(plugin.getPD(p).options.checkOption("tips"))
					p.sendMessage(FORMAT + toSend);
	}
	
	public static String getRandom(String[] s) {
		return s[(int)(Math.random() * s.length)];
	}
}