package xronbo.ronbomc.listeners;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.SlimeSplitEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerShearEntityEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.WorldLoadEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.DungeonHandler;
import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.type.BlockBreak;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.entities.NPCHandler;
import xronbo.ronbomc.entities.VillagerData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;
import xronbo.ronbomc.pets.Pet;
import xronbo.ronbomc.pets.PetHandler;

public class GeneralListeners implements Listener{

		public static RonboMC plugin;

		@EventHandler
		public void onNewChunk(ChunkLoadEvent event) {
			if(event.isNewChunk())
				event.getChunk().unload(false, false);
		}

		public GeneralListeners(RonboMC pl) {
			plugin = pl;
		}

		@EventHandler
		public void onEntityDamageEvent(EntityDamageEvent event) {
			if(event.getCause() == DamageCause.VOID && event.getEntity() instanceof Player) {
				((Player)event.getEntity()).sendMessage(ChatColor.RED + "Woah! Careful there, pal!");
				event.getEntity().teleport(event.getEntity().getWorld().getSpawnLocation());
			}
		}
		
		@EventHandler
		public void onItemFrameEvent(PlayerInteractEntityEvent event) {
			if(event.getRightClicked() instanceof ItemFrame) {
				if(!RankManager.check(event.getPlayer(), "builder")) {
					event.setCancelled(true);
				} else {
					if(event.getPlayer().getGameMode() != GameMode.CREATIVE)
						event.setCancelled(true);
				}
			}
		}
		
		@EventHandler
		public void onPortalTravel(PlayerPortalEvent event) {
			if(event.getCause() == PlayerPortalEvent.TeleportCause.END_PORTAL) {
				event.setCancelled(true);
			}
		}
		
		@EventHandler
		public void onRegenHealth(EntityRegainHealthEvent event) {
			event.setCancelled(true);
		}
		
		public static ArrayList<String> fallingBlocks = new ArrayList<String>();
		
		@EventHandler
		public void onEntityChangeBlock(EntityChangeBlockEvent event) {
			if(fallingBlocks.contains(event.getEntity().getUniqueId().toString())) {
				event.setCancelled(true);
				fallingBlocks.remove(event.getEntity().getUniqueId().toString());
			}
		}
		
		@EventHandler
		public void onDestroyByEntity(HangingBreakByEntityEvent event) {
			if(event.getRemover() instanceof Player) {
				if(!RankManager.check((Player)event.getRemover(), "builder")) {
					event.setCancelled(true);
				} else {
					if(((Player)event.getRemover()).getGameMode() != GameMode.CREATIVE)
						event.setCancelled(true);
				}
			}
		}
		
		@EventHandler
		public void onDestroyByEntity(HangingPlaceEvent event) {
			if(!RankManager.check(event.getPlayer(), "builder")) {
				event.setCancelled(true);
			} else {
				if(event.getPlayer().getGameMode() != GameMode.CREATIVE)
					event.setCancelled(true);
			}
		}
		
		@EventHandler
		public void onAnvilOrEnchantInteract(PlayerInteractEvent event) {
			if(event.getClickedBlock() != null && (event.getClickedBlock().getType() == Material.ANVIL || 
					event.getClickedBlock().getType() == Material.ENCHANTMENT_TABLE ||
					event.getClickedBlock().getType() == Material.WORKBENCH ||
					event.getClickedBlock().getType() == Material.DISPENSER ||
					event.getClickedBlock().getType() == Material.FURNACE ||
					event.getClickedBlock().getType() == Material.BREWING_STAND ||
					event.getClickedBlock().getType() == Material.BURNING_FURNACE ||
					event.getClickedBlock().getType() == Material.TRAPPED_CHEST))
				event.setCancelled(true);
		}
		
		@EventHandler
		public void onServerPing(ServerListPingEvent event) {
			event.setMotd(ChatColor.RED + "" + ChatColor.BOLD + "Please connect through the main address!   --> play.kastia.net <--");
		}
		
		@EventHandler
	    public void onItemSpawn(ItemSpawnEvent e){
			if(e.getEntity().getItemStack().getType()==Material.EGG){
	        	if(e.getEntity().getVelocity().getY()*10==2){
	            	e.getEntity().remove();
	            }
	        }
		}
		
		@EventHandler
		public void onBlockFade(BlockFadeEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onBlockSpread(BlockSpreadEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onBlockForm(BlockFormEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onLeafDecay(LeavesDecayEvent event) {
			event.setCancelled(true);
		}
		
		public static HashMap<Block, Material> rebuildBlocksMaterial = new HashMap<Block, Material>();
		public static HashMap<Block, Byte> rebuildBlocksData = new HashMap<Block, Byte>();
		private static final Material[] breakable = {
			Material.LONG_GRASS,
			Material.YELLOW_FLOWER,
			Material.RED_ROSE,
			Material.RED_MUSHROOM,
			Material.BROWN_MUSHROOM,
			Material.DOUBLE_PLANT,
			Material.CROPS,
			Material.POTATO,
			Material.CARROT
		};
		
		@EventHandler
		public void onBlockBreak(BlockBreakEvent event) {
			if(!RankManager.check(event.getPlayer(), "builder")) {
				event.setCancelled(true);
			}
			if(event.getPlayer().getGameMode() != GameMode.CREATIVE) {
				event.setCancelled(true);
			}
			if(!RonboMC.DEV_MODE_ACTIVE && !event.isCancelled() && RankManager.check(event.getPlayer(), "admin")) {
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "You are not on the build server, Mr. Builder!");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "The build server is a new server set up dedicated for building, and there will be no monsters spawning on that server. This is to help protect against possible world corruption and griefing.");
				event.getPlayer().sendMessage("");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Desolée, mon ami. Tu n'es pas sur le serveur de build.");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Cet autre serveur c'est seulement pour faire des builds, et il n'y aura pas des monstres. J'ai crée cet autre serveur pour qu'il n'y aura pas des problèmes avec la corruption des fichiers du monde principal.");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Excusez mon grammaire pauvre, svp! - Ronbo");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Connectez à cette IP: play.kastia.net:24999");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "The IP is : play.kastia.net:24999");
				event.getPlayer().sendMessage("(open chat to see full message)");
				event.setCancelled(true);
			}
			for(Material m : breakable) {
				if(event.getBlock().getType() == m) {
					event.setCancelled(true);
					final Block b = event.getBlock();
					rebuildBlocksMaterial.put(b, b.getType());
					rebuildBlocksData.put(b, b.getData());
					b.getDrops().clear();
					EffectHolder holder = EffectCreator.createLocHolder(new HashSet<ParticleDetails>(), b.getLocation());
					@SuppressWarnings("unused")
					BlockBreak bb = new BlockBreak(holder, b.getTypeId(), b.getData());
					holder.setRunning(true);
					holder.update();
					holder.setRunning(false);
					b.setType(Material.AIR);
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							if(rebuildBlocksData.containsKey(b) && rebuildBlocksMaterial.containsKey(b)) {
								b.setType(rebuildBlocksMaterial.remove(b));
								b.setData(rebuildBlocksData.remove(b));
							}
						}
					}, (int)(20.0 * Math.random() * 20.0 + 5.0));
					break;
				}
			}
		}
		
		@EventHandler
		public void onBlockPlace(BlockPlaceEvent event) {
			if(!RankManager.check(event.getPlayer(), "builder")) {
				event.setCancelled(true);
			}
			if(event.getPlayer().getGameMode() != GameMode.CREATIVE) {
				event.setCancelled(true);
			}
			if(!RonboMC.DEV_MODE_ACTIVE && !event.isCancelled() && RankManager.check(event.getPlayer(), "admin")) {
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "You are not on the build server, Mr. Builder!");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "The build server is a new server set up dedicated for building, and there will be no monsters spawning on that server. This is to help protect against possible world corruption and griefing.");
				event.getPlayer().sendMessage("");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Desolée, mon ami. Tu n'es pas sur le serveur de build.");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Cet autre serveur c'est seulement pour faire des builds, et il n'y aura pas des monstres. J'ai crée cet autre serveur pour qu'il n'y aura pas des problèmes avec la corruption des fichiers du monde principal.");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Excusez mon grammaire pauvre, svp! - Ronbo");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Connectez à cette IP: play.kastia.net:24999");
				event.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "The IP is : play.kastia.net:24999");
				event.getPlayer().sendMessage("(open chat to see full message)");
				event.setCancelled(true);
			}
		}
		
		@EventHandler
		public void join(PlayerJoinEvent event) {
			Player p = event.getPlayer();
			plugin.loadPlayer(p);
			event.setJoinMessage("");
		}
		
		@EventHandler
		public void logout(final PlayerQuitEvent event) {
			event.setQuitMessage("");
			PlayerData pd = plugin.getPD(event.getPlayer());
			if(pd == null) {
				System.out.println("ERROR: Could not find rpg data for " + event.getPlayer().getName() + " upon logout.");
				return;
			}
			for(MobData md : new ArrayList<MobData>(pd.mobsSpawnedForPlayer)) {
				md.findNewOwner();
			}
			if(pd.inDungeon) {
				DungeonHandler.leaveInstance(event.getPlayer());
			}
			if(pd.party != null) {
				pd.party.leaveParty(event.getPlayer());
			}
			for(int i : pd.taskIds)
				plugin.getServer().getScheduler().cancelTask(i);
			try {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						plugin.players.remove(event.getPlayer().getName());	
					}
				}, 10);
			} catch(Exception e) {
				
			}
			pd.save(false);
		}
		
		@EventHandler
		public void onTeleport(PlayerTeleportEvent event) {
			try {
				if(plugin.getPD(event.getPlayer()).inDungeon && !plugin.getPD(event.getPlayer()).allowedToTeleport) {
					if(!DungeonHandler.checkIsDungeon(event.getTo()))
						DungeonHandler.leaveInstance(event.getPlayer());
				}
				Pet pet = PetHandler.getPet(event.getPlayer());
				if(pet != null) {
					if(pet.spawned && (!pet.entity.getLocation().getWorld().equals(event.getPlayer().getLocation().getWorld()) || 
							pet.entity.getLocation().distanceSquared(event.getPlayer().getLocation()) > 15*15)) {
						pet.despawn();
						pet.spawn(event.getPlayer());
					}
				}
			} catch(Exception e) {
				
			}
		}
		
		@EventHandler
		public void onEntityInteract(EntityInteractEvent event) {
			if (event.getBlock().getType() == Material.SOIL)
				event.setCancelled(true);
		}
		
		@EventHandler
		public void onPlayerInteractCrops(PlayerInteractEvent event) {
			if(event.getAction() == Action.PHYSICAL) {
				Block b = event.getClickedBlock();
				if(b.getType() == Material.SOIL) {
					event.setCancelled(true);
					b.setTypeIdAndData(b.getType().getId(), b.getData(), true);
				}
				if(b.getType() == Material.CROPS) {
					event.setCancelled(true);
					b.setTypeIdAndData(b.getType().getId(), b.getData(), true);
				}
			}
		}
		
		@EventHandler
		public void onProjectileHit(final ProjectileHitEvent event) {
			if(event.getEntity() instanceof Arrow)
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						event.getEntity().remove();
					}
				}, 10);
		}
		
		public static HashMap<ChunkCoord, HashSet<VillagerData>> villagersToReload = new HashMap<ChunkCoord, HashSet<VillagerData>>();
		
		public static void addVillagerToReload(VillagerData vd, Location loc) {
			ChunkCoord cc = new ChunkCoord(loc.getChunk());
			if(villagersToReload.containsKey(cc)) {
				villagersToReload.get(cc).add(vd);
			} else {
				HashSet<VillagerData> array = new HashSet<VillagerData>();
				array.add(vd);
				villagersToReload.put(cc, array);
			}
		}
		
		public static class ChunkCoord {
			public int x, z;
			public String world;
			public ChunkCoord(Chunk chunk) {
				x = chunk.getX();
				z = chunk.getZ();
				world = chunk.getWorld().getName().toString();
			}
			public Chunk toChunk() {
				World world = plugin.getServer().getWorld(this.world);
				return world.getChunkAt(x,z);
			}
			@Override
			public int hashCode() {
				final int prime = 31;
				int result = 1;
				result = prime * result + x;
				result = prime * result + z;
				return result;
			}
			@Override
			public boolean equals(Object obj) {
				if (this == obj)
					return true;
				if (obj == null)
					return false;
				if (getClass() != obj.getClass())
					return false;
				ChunkCoord other = (ChunkCoord) obj;
				if (x != other.x)
					return false;
				if (z != other.z)
					return false;
				if (!world.equals(other.world))
					return false;
				return true;
			}
			public String toString() {
				return "[" + x + "," + z + "]";
			}
		}
		
		@EventHandler
		public void onChunkUnload(ChunkUnloadEvent event) {
			for(Entity e : event.getChunk().getEntities()) {
				try {
					MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
					md.despawnedLoc = e.getLocation();
					md.entity = null;
					MobHandler.spawnedMobs.remove(e.getUniqueId());
					md.die();
					e.remove();
				} catch(Exception e2) {
					try {
						VillagerData vd = NPCHandler.villagerData.remove(e.getUniqueId());
						vd.toRespawnLocation = e.getLocation();
						vd.entity.getBukkitEntity().remove();
						vd.entity = null;
						addVillagerToReload(vd, e.getLocation());
						e.remove();
					} catch(Exception e3) {
						
					}
				}
				if(e instanceof LivingEntity && !(e instanceof Player))
					e.remove();
			}
		}
		
		@EventHandler
		public void slimeSplit(SlimeSplitEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
	    public void onCreatureSpawn(CreatureSpawnEvent event) {
	        if (event.getSpawnReason() != SpawnReason.CUSTOM) {
	            event.getEntity().setHealth(0);
	            event.getEntity().remove();
	        }
	    }
		
		@EventHandler
		public void onInventoryClose(InventoryCloseEvent event) {
			final InventoryCloseEvent e2 = event;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					PlayerData pd = plugin.getPD((Player)(e2.getPlayer()));
					if(pd != null) {
						pd.updateArmorStats();
					}
					if(ItemHandler.isWeapon(e2.getPlayer().getItemInHand().getType()))
						e2.getPlayer().setItemInHand(ItemHandler.removeAttributes(e2.getPlayer().getItemInHand()));
				}
			}, 1);
		}
		
		@EventHandler
		public void onChangeItemInHand(PlayerItemHeldEvent event) {
			final PlayerItemHeldEvent e2 = event;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					PlayerData pd = plugin.getPD(e2.getPlayer());
					if(pd != null)
						pd.updateArmorStats();
				}
			}, 1);
		}
		
		@EventHandler
		public void onBlockIgnite(BlockIgniteEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onEntityExplode(EntityExplodeEvent event) {
			event.setCancelled(true);
		}
		
		public static HashMap<String, PlayerData> clonedPDs = new HashMap<String, PlayerData>();
		
		@EventHandler
		public void onPlayerInteract(PlayerInteractEvent event) {
			if(event.getMaterial().equals(Material.WRITTEN_BOOK) && event.getItem().hasItemMeta() && event.getItem().getItemMeta().hasDisplayName() && event.getItem().getItemMeta().getDisplayName().contains("Ronbook")) {
				Action a = event.getAction();
				Player p = event.getPlayer();
				PlayerData pd = plugin.getPD(p);
				if(a.equals(Action.LEFT_CLICK_AIR) || a.equals(Action.LEFT_CLICK_BLOCK)) {
					if(p.isSneaking()) {
						pd.openStatsMenu();
					} else {
						if(pd.classType != null && !pd.classType.equals("")) {
							ClassHandler.getClassType(pd.classType).openClassPassivesMenu(p);
						} else {
							ClassHandler.openClassSelectionMenu(p);
						}
					}
				} else if (a.equals(Action.RIGHT_CLICK_AIR) || a.equals(Action.RIGHT_CLICK_BLOCK)) {
					if(clonedPDs.get(p.getName()) == null || clonedPDs.get(p.getName()).hasChanged(pd)) {
						pd.updateRonbook();
					}
				}
				return;
			} else if(event.getMaterial().equals(Material.WRITTEN_BOOK) && event.getItem().hasItemMeta() && event.getItem().getItemMeta().hasDisplayName() && event.getItem().getItemMeta().getDisplayName().contains("Quest Log")) {
				if(event.getAction().equals(Action.LEFT_CLICK_AIR) || event.getAction().equals(Action.LEFT_CLICK_BLOCK)) {
					plugin.getPD(event.getPlayer()).giveQuestLog();
				}
			}
			try {
				if(ItemHandler.Equip.WAND.isType(event.getItem()))
					event.setCancelled(true);
			} catch(Exception e) {
				
			}
			for(Equip a : ItemHandler.getArmors()) {
				for(Material m : a.materials) {
					if(m == event.getMaterial()) {
						final PlayerInteractEvent e2 = event;
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
							public void run() {
								PlayerData pd = plugin.getPD(e2.getPlayer());
								if(pd != null) {
									pd.updateArmorStats();
									pd.updateRonbook();
								}
							}
						}, 1);
					}
				}
			}
		}
		
		@EventHandler
		public void onPlayerPickup(PlayerPickupItemEvent event) {
			final PlayerPickupItemEvent e2 = event;
			if(event.getItem().getItemStack().getType() == Material.ARROW) {
				event.setCancelled(true);
			} else if(event.getItem().getItemStack().getType() == Material.GOLD_NUGGET) {
				event.setCancelled(true);
			} else {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						PlayerData pd = plugin.getPD(e2.getPlayer());
						if(pd != null)
							pd.updateArmorStats();
					}
				}, 1);
			}
		}
		
		@EventHandler
		public void onExpGain(PlayerExpChangeEvent event) {
			event.setAmount(0);
		}
		
		@EventHandler
		public void onWeatherChange(WeatherChangeEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onThunderChange(ThunderChangeEvent event) {
			event.setCancelled(true);
		}
		
		@EventHandler
		public void onWorldLoad(WorldLoadEvent event) {
			World w = event.getWorld();
			if(w.hasStorm())
				w.setStorm(false);
			if(w.isThundering())
				w.setThundering(false);
		}
		
		@EventHandler
		public void onBadInventoryClickType(InventoryClickEvent event) {
			switch(event.getClick()) {
				case CONTROL_DROP:
				case DOUBLE_CLICK:
				case DROP:
				case MIDDLE:
				case NUMBER_KEY:
				case UNKNOWN:
					event.setCancelled(true);
				default:
			}
		}
		
		@EventHandler
		public void onEntityCombust(EntityCombustEvent event) {
			event.getEntity().setFireTicks(0);
			event.setCancelled(true);
		}

		@EventHandler
		public void onEntityShear(PlayerShearEntityEvent event) {
//			System.out.println("called");
			event.setCancelled(true);
			if(MobHandler.spawnedMobs.containsKey(event.getEntity().getUniqueId())) {
				MobData md = MobHandler.spawnedMobs.get(event.getEntity().getUniqueId());
				md.despawnedLoc = event.getEntity().getLocation();
				event.getEntity().remove();
				md.newEntity();
			}
//			System.out.println(event.getEntity());
		}
		
		public static HashMap<String, ArrayList<Item>> dropped = new HashMap<String, ArrayList<Item>>();
		@EventHandler
		public void onLogoutDroppedItemsDisappear(PlayerQuitEvent event) {
			ArrayList<Item> items = dropped.remove(event.getPlayer().getName());
			if(items != null) {
				for(Item i : items) {
					if(i != null && i.isValid())
						i.remove();
				}
				items.clear();
			}
		}
		@EventHandler
		public void onDropItem(PlayerDropItemEvent event) {
			try {
				if(event.getItemDrop().getItemStack().getItemMeta().getDisplayName().contains("Ronbook")) {
					event.getPlayer().sendMessage(ChatColor.ITALIC + "You try to throw away the Ronbook, but it mysteriously flies back into your hand.");
					event.setCancelled(true);
				}
				if(event.getItemDrop().getItemStack().getItemMeta().getDisplayName().contains("The Navigator")) {
					event.getPlayer().sendMessage(ChatColor.ITALIC + "You try to throw away the Navigator, but it mysteriously flies back into your hand.");
					event.setCancelled(true);
				}
				if(!ItemHandler.isTradeable(event.getItemDrop().getItemStack())) {
					event.setCancelled(true);
				}
				if(!event.isCancelled()) {
					String name = event.getPlayer().getName();
					if(dropped.containsKey(name)) {
						dropped.get(name).add(event.getItemDrop());
					} else {
						event.getPlayer().sendMessage(ChatColor.RED + "WARNING: Items you drop will dissappear when you log out!");
						ArrayList<Item> d = new ArrayList<Item>();
						d.add(event.getItemDrop());
						dropped.put(name, d);
					}
				}
			} catch (Exception e) {
				//will give an error if the item doesn't have a meta or display name
			}
		}
		
		@EventHandler
		public void hungerDecay(FoodLevelChangeEvent event) {
			event.setCancelled(true);
		}
}
