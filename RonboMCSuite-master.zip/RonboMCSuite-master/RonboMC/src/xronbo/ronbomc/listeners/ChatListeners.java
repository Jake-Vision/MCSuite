package xronbo.ronbomc.listeners;

import java.util.Iterator;
import java.util.Set;

import me.ronbo.core.ranks.ChatManager;
import me.ronbo.core.ranks.RankManager;
import net.minecraft.server.v1_8_R1.ChatSerializer;
import net.minecraft.server.v1_8_R1.PacketPlayOutChat;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.bungee.ChannelManager;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.dungeons.DungeonHandler;
import xronbo.ronbomc.effects.ReflectionUtil;
import xronbo.ronbomc.guilds.Guild;
import xronbo.ronbomc.guilds.GuildHandler;
import xronbo.ronbomc.json.FancyMessage;
import xronbo.ronbomc.json.JSONUtil;

public class ChatListeners implements Listener {
	
	public RonboMC plugin;
	
	public ChatListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	public static final double CHAT_RANGE_DISTANCE = 100.0;
	
	public static String filter(String s) {
		String[] cusswords = {"2g1c","2 girls 1 cup","acrotomophilia","anal","anilingus","arsehole", "asshole","assmunch","auto erotic","autoerotic","babeland","baby batter","ball gag","ball gravy","ball kicking","ball licking","ball sack","ball sucking","bangbros","bareback","barely legal","barenaked","bastard","bastinado","bbw","bdsm","beaver cleaver","beaver lips","bestiality","bi curious","big black","big breasts","big knockers","big tits","bimbos","birdlock","bitch","black cock","blonde action","blonde on blonde action","blow j","blow your l","blue waffle","blumpkin","bollocks","bondage","booty call","brown showers","brunette action","bukkake","bulldyke","bullet vibe","bung hole","bunghole","busty","buttcheeks","butthole","camel toe","camgirl","camslut","camwhore","carpet muncher","carpetmuncher","chocolate rosebuds","circlejerk","cleveland steamer","clit","clitoris","clover clamps","clusterfuck","cock","cocks","coprolagnia","coprophilia","cornhole","cum","cumming","cunnilingus","cunt","darkie","date rape","daterape","deep throat","deepthroat","dick","dildo","dirty pillows","dirty sanchez","doggie style","doggiestyle","doggy style","doggystyle","dog style","dolcett","domination","dominatrix","dommes","donkey punch","double dong","double penetration","dp action","eat my ass","ecchi","ejaculation","erotic","erotism","escort","ethical slut","eunuch","faggot","fecal","felch","fellatio","feltch","female squirting","femdom","figging","fingering","fisting","foot fetish","footjob","frotting","fuck","fuck buttons","fudge packer","fudgepacker","futanari","gang bang","gay sex","genitals","giant cock","girl on","girl on top","girls gone wild","goatcx","goatse","gokkun","golden shower","goodpoop","goo girl","goregasm","grope","group sex","g-spot","guro","hand job","handjob","homoerotic","honkey","hooker","hot chick","how to kill","how to murder","huge fat","humping","incest","intercourse","jack off","jail bait","jailbait","jerk off","jigaboo","jiggaboo","jiggerboo","jizz","juggs","kike","kinbaku","kinkster","kinky","knobbing","leather restraint","leather straight jacket","lemon party","lolita","lovemaking","make me come","male squirting","masturbate","menage a trois","milf","missionary position","motherfucker","mound of venus","mr hands","muff diver","muffdiving","nambla","nawashi","negro","neonazi","nigga","nigger","nig nog","nimphomania","nipple","nipples","nsfw images","nude","nudity","nympho","nymphomania","octopussy","omorashi","one cup two girls","one guy one jar","orgasm","orgy","paedophile","panties","panty","pedobear","pedophile","pegging","penis","phone sex","piece of shit","pissing","piss pig","pisspig","playboy","pleasure chest","pole smoker","ponyplay","poop chute","poopchute","porn","porno","pornography","prince albert piercing","pthc","pubes","pussy","queaf","raghead","raging boner","rape","raping","rapist","rectum","reverse cowgirl","rimjob","rimming","rosy palm","rosy palm and her 5 sisters","rusty trombone","sadism","scat","schlong","scissoring","semen","sex","sexo","sexy","shaved beaver","shaved pussy","shemale","shibari","shit","shota","shrimping","slanteye","slut","s&m","smut","snatch","snowballing","sodomize","sodomy","spic","spooge","spread legs","strap on","strapon","strappado","strip club","style doggy","suicide girls","sultry women","swastika","swinger","tainted love","taste my","tea bagging","threesome","throating","tied up","tight white","tongue in a","topless","tosser","towelhead","tranny","tribadism","tub girl","tubgirl","tushy","twat","twink","twinkie","two girls one cup","undressing","upskirt","urethra play","urophilia","vagina","venus mound","vibrator","violet blue","violet wand","vorarephilia","voyeur","vulva","wank","wetback","wet dream","white power","women rapping","wrapping men","wrinkled starfish" ,"xxx","yellow showers","yiffy","zoophilia"};
		String filler = "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
		String s3 = "";
		if(s.contains("{\"text\":")) {
			int index = s.indexOf("{\"text\":");
			index = s.indexOf(":", "{\"text\":".length());
			index = s.indexOf(":", index + 1);
			if(index >= 0) {
				s3 = s.substring(0, index);
				s = s.substring(index);
			}
		}
		String lowercase = s.toLowerCase();
		for(String s2 : cusswords) {
			if(lowercase.contains(s2))
				lowercase = lowercase.replaceAll(s2, filler.substring(0, s2.length()));
		}
		if(!lowercase.equals(s.toLowerCase()))
			s = lowercase;
		return s3 + s;
	}
	
	@EventHandler
	public void dungeonChatListenerBecauseImTooLazyTooMakeANewClassForIt(AsyncPlayerChatEvent event) {
		final String message = event.getMessage();
		final PlayerData pd = plugin.getPD(event.getPlayer());
		if(pd.waitingForDungeonEnter) {
			event.setCancelled(true);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					if(pd.waitingForDungeonEnter) {
						if(message.toLowerCase().contains("enter")) {
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									DungeonHandler.enterInstance(pd.player, pd.dungeonToEnter);
									pd.waitingForDungeonEnter = false;
									pd.dungeonToEnter = "";
								}
							}, 1);
						} else {
							pd.player.sendMessage("You choose to not enter " + pd.dungeonToEnter +".");
							pd.waitingForDungeonEnter = false;
							pd.dungeonToEnter = "";
						}
					}
				}
			});
		}
	}
	
	@EventHandler(priority = EventPriority.MONITOR)
	public void chatManager(final AsyncPlayerChatEvent event) {
		final String finalMessage = event.getMessage();
		final PlayerData pd = plugin.getPD(event.getPlayer());
		final boolean cancelledFinal = event.isCancelled();
		final String playerName = pd.player.getName();
		event.setCancelled(true);
		if(pd.fullyLoaded) {
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					boolean cancelled = cancelledFinal;
					String message = finalMessage;
					boolean globalChatActive = false;
					if(pd.guildChatLock) {
						if(GuildHandler.getGuild(pd) != null) {
							GuildHandler.getGuild(pd).sendGuildMessage(message, playerName);
						}
					} else {
						if(message.startsWith("!")) {
							if(RankManager.check(pd.player, "lord") ||
									System.currentTimeMillis() - pd.lastGlobalChat > (RankManager.check(pd.player, "knight") ? 15*1000 : 120*1000)) {
								message = message.substring(1);
								globalChatActive = true;
								pd.lastGlobalChat = System.currentTimeMillis();
								if(!RankManager.check(pd.player, "mod")) {
									pd.player.sendMessage(ChatColor.RED + "Warning: Abuse of Global Chat will NOT be tolerated!");
									pd.player.sendMessage(ChatColor.RED + "If a staff member asks you to stop doing something in global, then stop.");
									pd.player.sendMessage(ChatColor.RED + "This applies to normal AND VIP players!");
								}
							} else {
								pd.player.sendMessage(ChatColor.RED + "You can only global chat once every " + (RankManager.check(pd.player, "knight") ? 15 : 120) + " seconds.");
								int timeToWait = (int)(((RankManager.check(pd.player, "knight") ? 15*1000 : 120*1000)-(System.currentTimeMillis()-pd.lastGlobalChat))/1000.0);
								pd.player.sendMessage(ChatColor.RED + "Wait " + (timeToWait > 0 ? timeToWait : 1) + " more seconds.");
								if(!RankManager.check(pd.player, "knight"))
									pd.player.sendMessage(ChatColor.RED + "Upgrade to Knight to decrease this limit to once every 15 seconds!");
							}
						}
						if(!globalChatActive) {
							Set<Player> receivers = (event.getRecipients());
							Iterator<Player> i = receivers.iterator();
							while(i.hasNext()) {
								Player p = i.next();
								try {
									if((plugin.getPD(p).options.checkOption("chatrange") && p.getLocation().distance(event.getPlayer().getLocation()) > CHAT_RANGE_DISTANCE) || (pd.options.checkOption("chatrange") && p.getLocation().distance(event.getPlayer().getLocation()) > CHAT_RANGE_DISTANCE)) {
										i.remove();
									}
								} catch(Exception e) {
									i.remove();
								}
							}
						}
						if(message.startsWith("\\") || pd.partyChatLock) {
							if(pd.party != null) {
								if(! pd.partyChatLock)
									message = message.substring(1);
								pd.party.partyChat(pd.player, message);
								System.out.println("(Party Chat) " + pd.player.getName() + ": " + message);
							} else {
								pd.player.sendMessage("You are not in a party. \\<message> is for chatting with party members.");
							}
							cancelled = true;
						}
						if(!cancelled) {
							Iterator<Player> i = event.getRecipients().iterator();
							FancyMessage fm = new FancyMessage("");
							if(globalChatActive) {
								fm.then("[" + ChannelManager.thisChannel.abbreviation + "] ")
								.color(ChatColor.GRAY)
								.tooltip(ChatColor.WHITE + "This player is on " + ChannelManager.thisChannel.name + ". Use " + ChatColor.YELLOW + "/cc" + ChatColor.WHITE + " to join them!");
							}
							fm.then("[" + pd.level + "] ")
				            .color(ChatColor.GRAY)
				            .tooltip(ChatColor.YELLOW + pd.classType + ChatColor.AQUA + " | " + ChatColor.YELLOW + "Spirit Points: " + (pd.spiritPoints > 0 ? ChatColor.GREEN + "" + pd.spiritPoints : ChatColor.RED + "" + pd.spiritPoints));
				            try {
				            	if(GuildHandler.getGuild(pd.player) != null) {
					            	Guild guild = GuildHandler.getGuild(pd.player);
					            	fm.then(guild.getBracketColor(pd.player) + "[" + ChatColor.WHITE + guild.abbreviation + guild.getBracketColor(pd.player) + "] ")
					            	.tooltip(ChatColor.GOLD + guild.guildName + ChatColor.AQUA + " | " + ChatColor.GREEN + "Total Guild Points: " + guild.guildPointsTotal + ChatColor.AQUA + " | " + ChatColor.YELLOW + pd.player.getName() + "'s Rank: " + guild.getRankDisplay(guild.getMember(pd.player).rank));
					            }
				            } catch(Exception e) {
				            	
				            }
				            String messageToSend = ChatManager.makeMessage(pd.player, message);
							String actualMessage = JSONUtil.toJSON(messageToSend.replace("\\", "\\\\").replace("\"", "\\\""));
							PacketPlayOutChat chat = new PacketPlayOutChat(ChatSerializer.a(fm.toJSONString()).addSibling(ChatSerializer.a(actualMessage)));
//							if(globalChatActive) {
//								ChannelManager.broadcastGlobal(filtered.toJSONString());
//							} else {
							while(i.hasNext()) {
								Player p = i.next();
								ReflectionUtil.sendPacket(p, chat);
							}
							fm.then(messageToSend).send(plugin.getServer().getConsoleSender());
//							}
						}
					}
				}
			});
		} 
	}
	
	public ChatColor[] colors = {
		ChatColor.GREEN,
		ChatColor.RED,
		ChatColor.YELLOW,
		ChatColor.WHITE,
		ChatColor.GOLD,
		ChatColor.AQUA,
		ChatColor.LIGHT_PURPLE,
		ChatColor.BLUE
	};
	
	public String rainbow(String s) {
		StringBuilder sb = new StringBuilder();
		for(int k = 0; k < s.length(); k++) {
			sb.append(colors[(int)(Math.random() * colors.length)] + "" + s.charAt(k));
		}
		return sb.toString();
	}
	
	
}