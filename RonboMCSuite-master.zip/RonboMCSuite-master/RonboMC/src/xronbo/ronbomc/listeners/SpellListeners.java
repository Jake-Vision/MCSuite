package xronbo.ronbomc.listeners;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;

public class SpellListeners implements Listener {
	
	public RonboMC plugin;
	
	public SpellListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	@EventHandler
	public void playerInteract(PlayerInteractEvent event) {
		if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
			Block b = event.getClickedBlock();
			boolean act = true;
			if(b != null) {
				if(b.getType() == Material.ENDER_CHEST || b.getType() == Material.CHEST) {
					act = false;
				}
			}
			if(act) {
				ItemStack i = event.getPlayer().getItemInHand();
				if(ItemHandler.items.containsKey(i)) {
					ItemData id = ItemHandler.items.get(i);
					if(id.spell != null)
						id.spell.castSpell(event);
				}
			}
		}
	}
	
	@EventHandler
	public void onEntityDamage(EntityDamageEvent event) {
		
	}
}