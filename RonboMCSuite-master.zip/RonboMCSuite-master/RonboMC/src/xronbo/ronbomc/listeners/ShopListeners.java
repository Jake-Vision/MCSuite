package xronbo.ronbomc.listeners;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.entities.NPCHandler;
import xronbo.ronbomc.entities.Store;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.SpecialItem;


public class ShopListeners implements Listener {
	
	public RonboMC plugin;
	
	public ShopListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	@EventHandler
	public void onShopInteract(InventoryClickEvent event) {
    	if(NPCHandler.stores == null)
    		return;
    	ItemStack clickedItem = event.getCurrentItem();
    	Inventory inventory = event.getInventory();
    	if(clickedItem != null) {
    		ItemMeta im = clickedItem.getItemMeta();
    		if(im != null) {
	            Player p = (Player)(event.getWhoClicked());
	            PlayerData pd = plugin.getPD(p);
		    	String clickedItemName = ChatColor.stripColor((im.hasDisplayName() ? im.getDisplayName() : "")).toLowerCase().trim();
		    	for(Store store : NPCHandler.stores.values()) {
		    		if(store.store.getTitle().equals(inventory.getTitle())) {
	            		event.setCancelled(true);
	    				if(RonboMC.TESTING_INVENTORY_CANCELS)
	    					System.out.println("Cancelling here. " + this.getClass().getName());
			            if(im.hasLore()) {
				            for(String s : im.getLore()) {
				            	if(s.contains("Price: ") && s.contains("g")) {
				            		String price_string = ChatColor.stripColor(s).substring("Price: ".length());
				            		int price = Integer.parseInt(price_string.substring(0, price_string.indexOf("g")));
				            		if(pd.wallet >= price) {
				            			pd.takeGold(price);
				            			p.sendMessage(ChatColor.GREEN + "Purchased a " + ChatColor.stripColor(im.getDisplayName()) + " for " + price + "g.");
					            		for(SpecialItem si : ItemHandler.specialItems.values()) {
					            			if(si.name.equalsIgnoreCase(clickedItemName)) {
					            				p.getInventory().addItem(si.generateItem());
					            				p.closeInventory();
					            				return;
					            			}
					            		}
					            		for(EtcItem ei : EtcItem.values()) {
					            			if(ei.name.equals(clickedItem.getItemMeta().getDisplayName())) {
					            				p.getInventory().addItem(ei.makeItems(1));
					            				p.closeInventory();
					            				return;
					            			}
					            		}
					            		p.closeInventory();
					            	} else {
				            			p.sendMessage(ChatColor.RED + "You don't have enough gold with you to buy this! You need " + price + "g.");
			            				p.closeInventory();
				            		}
			            		} 
				            }
			            }
	            		break;
		    		}
		    	}
    			
    		}
    	}
    }
	
}