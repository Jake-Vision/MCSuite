package xronbo.ronbomc.listeners;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;

public class RegionListeners implements Listener {
	
	public RonboMC plugin;
	
	public RegionListeners(RonboMC plugin) {
		this.plugin = plugin;
	}

	@EventHandler
	public void checkChangeRegion(PlayerMoveEvent event) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		if(pd == null || pd.sendingRegionChange)
			return;
		pd.sendingRegionChange = true;
		pd.movedDuringAFKCheck = true;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(pd != null && pd.player.isOnline() && !pd.player.isDead()) {
					pd.sendingRegionChange = false;
					if(pd.region != null) {
						Region currentRegion = RegionHandler.getRegion(pd.player.getLocation());
						if(currentRegion.type.equals("perilous") && pd.player.getVehicle() != null) {
							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
								public void run() {
									if(pd.player != null && pd.player.isOnline())
										pd.player.sendMessage(ChatColor.RED + "You cannot ride pets or horses in perilous zones!");
									pd.player.getVehicle().eject();
									pd.player.eject();
								}
							}, 10);
						}
						if(currentRegion != pd.region) {
							if(!(currentRegion.welcome))
								pd.preUnwelcomedRegion = pd.region;
							pd.region = currentRegion;
							pd.region.sendWelcome(pd.player, false);
						}
					}
				}
			}
		}, 1);
	}
	
}