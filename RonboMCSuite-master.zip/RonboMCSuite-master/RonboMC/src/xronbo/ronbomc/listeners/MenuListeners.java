package xronbo.ronbomc.listeners;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.classes.ClassHandler;


public class MenuListeners implements Listener {
	
	public RonboMC plugin;
	
	public MenuListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	@EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
    	String inventoryName = ChatColor.stripColor(event.getInventory().getName().toLowerCase().trim());
    	ItemStack clickedItem = event.getCurrentItem();
    	if(clickedItem != null) {
    		ItemMeta im = clickedItem.getItemMeta();
    		if(im != null) {
	            Player p = (Player)(event.getWhoClicked());
	            PlayerData pd = plugin.getPD(p);
		    	String optionName = ChatColor.stripColor((im.hasDisplayName() ? im.getDisplayName() : "")).toLowerCase().trim();
		    	if(inventoryName.toLowerCase().contains("assign your stat points!")) {
					if(RonboMC.TESTING_INVENTORY_CANCELS)
						System.out.println("Cancelling here. " + this.getClass().getName());
		    		event.setCancelled(true);
		            if(pd.sp <= 0) {
		            	pd.sp = 0;
		            	p.sendMessage(ChatColor.RED + "You have no SP!");
		            } else {
		            	boolean confirmed = false;
		            	if(event.getRawSlot() < 9 * 5) {
		            		if(event.getClick() == ClickType.LEFT || event.getClick() == ClickType.RIGHT) {
					    		if(optionName.contains("available")) {
					            	p.sendMessage(ChatColor.GREEN + "[Tip] SP is gained from leveling up.");
					            } else if(optionName.contains("strength")) {
					            	if(pd.sp - pd.SP_assigned > 0) {
					            		pd.strength_assigned += 1;
					            		pd.SP_assigned += 1;
					            	} else {
					            		p.sendMessage(ChatColor.RED + "You are out of SP!");
					            	}
					            } else if(optionName.contains("dexterity")) {
					            	if(pd.sp - pd.SP_assigned > 0) {
					            		pd.dexterity_assigned += 1;
					            		pd.SP_assigned += 1;
					            	} else {
					            		p.sendMessage(ChatColor.RED + "You are out of SP!");
					            	}
					            } else if(optionName.contains("intelligence")) {
					            	if(pd.sp - pd.SP_assigned > 0) {
					            		pd.intelligence_assigned += 1;
					            		pd.SP_assigned += 1;
					            	} else {
					            		p.sendMessage(ChatColor.RED + "You are out of SP!");
					            	}
					            } else if(optionName.contains("luck")) {
					            	if(pd.sp - pd.SP_assigned > 0) {
					            		pd.luck_assigned += 1;
					            		pd.SP_assigned += 1;
					            	} else {
					            		p.sendMessage(ChatColor.RED + "You are out of SP!");
					            	}
					            } else if(optionName.contains("click to confirm")) {
					            	if(pd.sp < pd.SP_assigned) {
					            		p.sendMessage(ChatColor.RED + "You have somehow assigned more SP than you have!");
					            	} else {
						            	pd.strength += pd.strength_assigned;
						            	pd.dexterity += pd.dexterity_assigned;
						            	pd.luck += pd.luck_assigned;
						            	pd.intelligence += pd.intelligence_assigned;
						            	pd.sp -= pd.SP_assigned;
						            	p.sendMessage(ChatColor.YELLOW + "Your Stat Points have been updated! You have " + pd.sp + " SP remaining.");
										pd.strength_assigned = 0;
										pd.dexterity_assigned = 0;
										pd.intelligence_assigned = 0;
										pd.luck_assigned = 0;
										pd.SP_assigned = 0;
						            	p.closeInventory();
						            	confirmed = true;
					            	}
					            } else if(optionName.contains("click to cancel")) {
									pd.strength_assigned = 0;
									pd.dexterity_assigned = 0;
									pd.intelligence_assigned = 0;
									pd.luck_assigned = 0;
									pd.SP_assigned = 0;
					            }
		            		}
		            	}
//		            	p.closeInventory();
		            	if(!confirmed)
		            		pd.updateStatsMenu(event.getInventory());
			            pd.updateRonbook();
		            }
	    		} else if(inventoryName.toLowerCase().contains("class passives")) {
	    			event.setCancelled(true);
	    			int allowed = ClassHandler.ClassType.getNumberPassivesAllowed(pd.level);
	    			if(allowed > pd.activePassives.length) {
	    				int[][] expandedPassives = new int[allowed][2];
	    				for(int k = 0; k < pd.activePassives.length; k++) {
	    					expandedPassives[k][0] = pd.activePassives[k][0];
	    					expandedPassives[k][1] = pd.activePassives[k][1];
	    				}
	    				pd.activePassives = expandedPassives;
	    			}
    				int slot = event.getRawSlot();
    				int tier = (int)(slot / 9.0);
    				int number = slot - (tier * 9);
    				if(slot >= 9 && slot % 9 != 0 && event.getCurrentItem() != null && event.getCurrentItem().getType() == Material.STAINED_GLASS_PANE) {
    					if(ClassHandler.ClassType.tierAvailable(pd, tier)) {
    	    				boolean setNew = false;
    	    				boolean deactivated = false;
    	    				for(int[] i : pd.activePassives) {
    	    					if(i[0] == tier && i[1] == number) {
        							i[0] = 0;
        							i[1] = 0;
        							deactivated = true;
        	    				}
    	    				}
    	    				if(!deactivated) {
    	    					for(int[] i : pd.activePassives) {
    		    					if(i[0] == 0 || i[1] == 0) {
    		    						i[0] = tier;
    		    						i[1] = number;
    		    						setNew = true;
    		    						break;
    		    					}
    		    				}
    	    				}
    	    				if(deactivated) {
    	    					p.sendMessage(ChatColor.GREEN + "Deactivated passive \"" + ClassHandler.getClassType(pd.classType).getPassiveName(tier, number) + "\"");
        	    			} else if(setNew) {
        	    				p.sendMessage(ChatColor.GREEN + "Activated passive \"" + ClassHandler.getClassType(pd.classType).getPassiveName(tier, number) + "\"");   		    				
        	    			} else {
    		    				p.sendMessage(ChatColor.RED + "You have already assigned your maximum of " + allowed + " passives!");
    		    				p.sendMessage(ChatColor.RED + "De-activate one of your active passives to choose another.");
        	    			}
    					} else {
    						p.sendMessage(ChatColor.RED + "You cannot access Tier " + tier + " passives yet!");
    					}
    				} else if(optionName.equalsIgnoreCase("change class")) {
    					ClassHandler.openClassSelectionMenu(p);
    				}
    				ClassHandler.getClassType(pd.classType).updateClassPassivesMenu(event.getInventory(), p);
    				pd.updateArmorStats();
	    		} else if(inventoryName.toLowerCase().contains("class selection menu")) {
					if(RonboMC.TESTING_INVENTORY_CANCELS)
						System.out.println("Cancelling here3. " + this.getClass().getName());
	    			event.setCancelled(true);
	    			if(event.getCurrentItem() != null && event.getCurrentItem().hasItemMeta() && event.getRawSlot() < 9) {
	    				ItemMeta im2 = event.getCurrentItem().getItemMeta();
	    				String name = ChatColor.stripColor(im2.getDisplayName());
	    				if(name.equalsIgnoreCase("confirm class selection")) {
	    					if(pd.selectedClass.equalsIgnoreCase(pd.classType)) {
	    						p.sendMessage(ChatColor.RED + "You are already a " + pd.selectedClass + "!");
	    						p.closeInventory();
	    					} else {
	    						if(ClassHandler.getClassType(pd.classType) == null) {
	    							pd.classType = pd.selectedClass;
	    							p.sendMessage(ChatColor.GREEN + "You are now a " + pd.classType + "!");
	    						} else {
	    							if(pd.wallet >= ClassHandler.ClassType.getClassChangeCost(pd.level)) {
	    								pd.takeGold(ClassHandler.ClassType.getClassChangeCost(pd.level));
		    							pd.classType = pd.selectedClass;
		    							pd.activePassives = new int[ClassHandler.ClassType.getNumberPassivesAllowed(pd.level)][2];
		    							p.sendMessage(ChatColor.GREEN + "You are now a " + pd.classType + "!");
	    							} else {
	    								p.sendMessage(ChatColor.RED + "You don't have enough gold to change your class!");
	    								p.sendMessage(ChatColor.RED + "You need " + ClassHandler.ClassType.getClassChangeCost(pd.level) + " gold.");
	    							}
	    						}
	    					}
	    					pd.selectedClass = "";
	        				p.closeInventory();
	    				} else {
	    					pd.selectedClass = name;
	        				ClassHandler.updateClassSelectionMenu(event.getInventory(), p);
	    				}
	    			}
	    		}
	    	}
		}
	}
}