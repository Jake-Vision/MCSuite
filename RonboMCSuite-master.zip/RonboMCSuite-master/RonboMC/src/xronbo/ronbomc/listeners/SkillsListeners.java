package xronbo.ronbomc.listeners;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.skills.harvesting.HarvestingHandler;
import xronbo.ronbomc.skills.harvesting.HarvestingHandler.Basket;

public class SkillsListeners implements Listener {
	
	public RonboMC plugin;
	
	public SkillsListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	/*
	 * HARVESTING
	 */
	
	@EventHandler
	public void onPlayerBlockInteract(PlayerInteractEvent event) {
		Player p = event.getPlayer();
		Block b = event.getClickedBlock();
		if(event.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if(b != null && (b.getType() == Material.CROPS || b.getType() == Material.POTATO || b.getType() == Material.CARROT)) {
				if(p.getItemInHand() != null && p.getItemInHand().getType() == Material.FLOWER_POT_ITEM) {
					int data = b.getData();
					if(data >= 6) {
						HarvestingHandler.harvestBlock(p, b);
					} else {
						if(plugin.getPD(p).options.checkOption("harvesting"))
							p.sendMessage(ChatColor.RED + "This crop is not yet ready to be harvested!");
					}
				}
			}
		}
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		Inventory inventory = event.getInventory();
		Player p = (Player)(event.getWhoClicked());
		if(inventory.getName().equals(ChatColor.BLACK + "The Harvest Begins!")) {
			if(RonboMC.TESTING_INVENTORY_CANCELS)
				System.out.println("Cancelling here. " + this.getClass().getName());
			event.setCancelled(true);
			if(event.getRawSlot() < 9) {
				try {
					ItemStack i = event.getCurrentItem();
					for(Basket b : Basket.values()) {
						if(b.name.equals(i.getItemMeta().getDisplayName())) {
							HarvestingHandler.buyBasket(b, p);
							break;
						}
					}
					if(i.getItemMeta().getDisplayName().equals(ChatColor.GREEN + "" + ChatColor.UNDERLINE + "Click to learn about Harvesting!")) {
						p.closeInventory();
						String[] info = new String[] {
							"Harvesting is a great way to earn some quick cash.",
							"Start by buying a basket from the Crop Harvester.",
							"Then, simply bring your basket with you as you explore the world, and harvest any Wheat, Potatoes, or Carrots you see.",
							"To harvest a crop, simply right-click on it with your basket.",
							"Wheat is worth " + HarvestingHandler.WHEAT_PRICE + "g, potatoes are worth " + HarvestingHandler.POTATO_PRICE + "g, and carrots are worth a whopping " + HarvestingHandler.CARROT_PRICE + "g.",
							"When your basket is full, bring it back to a Crop Harvester and sell it for some sweet gold!",
							"Have fun!"
						};
						boolean green = false;
						for(String s : info)
							p.sendMessage(((green = !green) ? ChatColor.GREEN : ChatColor.AQUA) + s);
					}
				} catch(Exception e) {
					
				}
			} else {
				try {
					ItemStack i = event.getCurrentItem();
					for(Basket b : Basket.values()) {
						if(b.name.equals(i.getItemMeta().getDisplayName())) {
							HarvestingHandler.sellBasket(i, p);
							break;
						}
					}
				} catch(Exception e) {
					
				}
			}
		}
	}
	
}