package xronbo.ronbomc.listeners;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.debug.SuperDebugger;


public class BankListeners implements Listener {
	
	public RonboMC plugin;
	
	public BankListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	@EventHandler
	public void checkGoldDeposited(InventoryCloseEvent event) {
		final InventoryCloseEvent e2 = event;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				try {
					if(e2.getInventory().getName().contains("s Bank")) {
						plugin.getPD((Player)(e2.getPlayer())).checkBankGold();
					}
				} catch (Exception e) {
					
				}
			}
		}, 1);
	}

	@EventHandler
	public void openBank(PlayerInteractEvent event) {
		Block b = event.getClickedBlock();
		if(b != null) {
			if(b.getType() == Material.ENDER_CHEST && event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
				plugin.getPD(event.getPlayer()).openBank();
				event.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void bankChatCommands(AsyncPlayerChatEvent event) {
		final String finalMessage = event.getMessage();
		final PlayerData pd = plugin.getPD(event.getPlayer());
		if(pd.awaitingBankBanknoteWithdrawValue || pd.awaitingBankGoldWithdrawValue || pd.awaitingBankSizeIncreaseConfirmation) {
			event.setCancelled(true);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					String message = finalMessage;
					if(pd.awaitingBankBanknoteWithdrawValue) {
						try {
							if(message.endsWith("g"))
								message = message.substring(0, message.length() - 1);
							int banknote = Integer.parseInt(message);
							if(banknote <= pd.bankGold && banknote > 0) {
								if(pd.player.getInventory().firstEmpty() == -1) {
									pd.player.sendMessage(ChatColor.RED + "You don't have any space in your inventory for that!");
								} else {
									pd.player.sendMessage(ChatColor.GREEN + "Received banknote worth " + ChatColor.GOLD + banknote + "g" + ChatColor.GREEN + ".");
									pd.giveBanknote(banknote);
									pd.bankGold -= banknote;
								}
							} else {
								pd.player.sendMessage(ChatColor.RED + "You don't have " + ChatColor.GOLD + banknote + "g" + ChatColor.RED + " in your bank!");
							}
						} catch(Exception e) {
							if(message.equals("cancel")) {
								pd.player.sendMessage(ChatColor.RED + "Canceled banknote withdraw request.");
							} else {
								pd.player.sendMessage(ChatColor.RED + "Invalid number format!");
							}
						}
						pd.awaitingBankBanknoteWithdrawValue = false;
					} else if(pd.awaitingBankGoldWithdrawValue) {
						try {
							if(message.endsWith("g"))
								message = message.substring(0, message.length() - 1);
							int gold = Integer.parseInt(message);
							if(gold <= pd.bankGold && gold > 0) {
								pd.bankGold -= gold;
								pd.wallet += gold;
								pd.updateRonbook();
								pd.player.sendMessage(ChatColor.GREEN + "Withdrew " + ChatColor.GOLD + gold + "g" + ChatColor.GREEN + " into wallet.");
							} else {
								pd.player.sendMessage(ChatColor.RED + "You don't have " + ChatColor.GOLD + gold + "g" + ChatColor.RED + " in your bank!");
							}
						} catch(Exception e) {
							if(message.equals("cancel")) {
								pd.player.sendMessage(ChatColor.RED + "Canceled gold withdraw request.");
							} else {
								pd.player.sendMessage(ChatColor.RED + "Invalid number format!");
							}
						}
						pd.awaitingBankGoldWithdrawValue = false;
					} else if(pd.awaitingBankSizeIncreaseConfirmation) {
						if(message.equalsIgnoreCase("confirm")) {
							if(pd.bankGold < pd.getBankExpansionCost()) {
			    				pd.player.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "You need " + ChatColor.GOLD + pd.getBankExpansionCost() + "g" + ChatColor.GREEN + " in your bank to expand!");
							} else {
								pd.bankGold -= pd.getBankExpansionCost();
								pd.banklines++;
								pd.loadBank();
								pd.player.sendMessage("Increased your bank size! You now have " + (pd.banklines * 9 - 1) + " storage spaces.");
							}
						} else {
							pd.player.sendMessage(ChatColor.RED + "Canceled bank expansion request.");
						}
						pd.awaitingBankSizeIncreaseConfirmation = false;
					}
				}
			});
		}
	}
	
	@EventHandler
    public void clickGoldBalanceIcon(InventoryClickEvent event) {
		ItemStack clickedItem = event.getCurrentItem();
    	if(clickedItem != null) {
    		ItemMeta im = clickedItem.getItemMeta();
    		if(im != null) {
	            Player p = (Player)(event.getWhoClicked());
	            PlayerData pd = plugin.getPD(p);
            	if(ChatColor.stripColor(im.hasDisplayName() ? im.getDisplayName() : "").equalsIgnoreCase("Gold Balance")) {
    				if(RonboMC.TESTING_INVENTORY_CANCELS)
    					System.out.println("Cancelling here. " + this.getClass().getName());
	    			event.setCancelled(true);
	            	ClickType ct = event.getClick();
	            	switch(ct) {
	            		case LEFT:
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "How much gold would you like to withdraw?");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type value in chat - Max " + pd.bankGold + "g");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "Type \"cancel\" to cancel request.");
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			pd.awaitingBankGoldWithdrawValue = true;
	            			break;
	            		case RIGHT:
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "How much gold do you want the banknote to hold?");
	            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type value in chat - Max " + pd.bankGold + "g");
	            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "Type \"cancel\" to cancel request.");
	            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
	            			pd.awaitingBankBanknoteWithdrawValue = true;
	            			break;
	            		case SHIFT_RIGHT:
	            			int amount = 0;
	            			ArrayList<ItemStack> toRemove = new ArrayList<ItemStack>();
	            			for(ItemStack i : p.getInventory()) {
	            				if(i != null) {
	            					if(i.getType() == Material.PAPER) {
	            						ItemMeta im2 = i.getItemMeta();
	            						if(im2 != null) {
	            							if(im2.hasDisplayName() && im2.getDisplayName().contains("Bank Note")) {
	            								String name = ChatColor.stripColor(im2.getDisplayName());
	            								try {
	            									amount += Integer.parseInt(name.replaceAll("[^0-9]", ""));
		            								toRemove.add(i);
	            								} catch(Exception e) {
	            									
	            								}
	            							}
	            						}
	            					}
	            				}
	            			}
	            			p.getInventory().removeItem(toRemove.toArray(new ItemStack[toRemove.size()]));
	            			p.closeInventory();
	            			amount += pd.wallet;
	            			pd.wallet = 0;
	            			pd.bankGold += amount;
	            			if(amount > 0)
	            				p.sendMessage(ChatColor.GREEN + "Stored " + ChatColor.GOLD + amount + "g" + ChatColor.GREEN + " in your bank! You now have " + ChatColor.GOLD + pd.bankGold + "g" + ChatColor.GREEN + ".");
	            			break;
	            		case SHIFT_LEFT:
	            			if(pd.banklines >= 6) {
	            				p.sendMessage(ChatColor.RED + "Your bank is already at its maximum size! (Wow, you're very rich!)");
	            			} else {

		            			if(pd.bankGold >= pd.getBankExpansionCost()) {
			            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
			            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "It will cost you " + pd.getBankExpansionCost() + "g to expand your bank by 9 slots!");
			            			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + "Type \"confirm\" if you want to spend " + pd.getBankExpansionCost() + "g to expand your bank.");
			            			p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "Type \"cancel\" to cancel request.");
			            			p.sendMessage(ChatColor.GRAY + "----------------------------------------------------");
			            			pd.awaitingBankSizeIncreaseConfirmation = true;
		            			} else {
		            				p.sendMessage(ChatColor.RED + "" + ChatColor.ITALIC + "You need " + pd.getBankExpansionCost() + "g in your bank to expand!");
		            			}
	            			}
	            			break;
	            		default:
	            			break;
	            	}
	            	p.closeInventory();
	            	return;
	            }
    		}
    	}
    }
}