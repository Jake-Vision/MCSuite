package xronbo.ronbomc.listeners;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import net.minecraft.server.v1_8_R1.EntityWitherSkull;
import net.minecraft.server.v1_8_R1.World;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R1.CraftWorld;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;
import xronbo.ronbomc.regions.Region;
import xronbo.ronbomc.regions.RegionHandler;

public class CombatListeners implements Listener {
	
	public RonboMC plugin;
	
	public CombatListeners(RonboMC plugin) {
		this.plugin = plugin;
	}
	
	public HashMap<String, Long> lastSentFrozen = new HashMap<String, Long>();
	
	@EventHandler
	public void onPlayerMove(PlayerMoveEvent event) {
		if(plugin.getPD(event.getPlayer()) == null)
			return;
		if(plugin.getPD(event.getPlayer()).frozen) {
			event.setCancelled(true);
			if(lastSentFrozen.containsKey(event.getPlayer().getName())) {
				if(System.currentTimeMillis() - lastSentFrozen.get(event.getPlayer().getName()) > 1000) {
					event.getPlayer().sendMessage(ChatColor.RED + "You are frozen, and cannot move!");
					lastSentFrozen.put(event.getPlayer().getName(), System.currentTimeMillis());
				}
			} else {
				event.getPlayer().sendMessage(ChatColor.RED + "You are frozen, and cannot move!");
				lastSentFrozen.put(event.getPlayer().getName(), System.currentTimeMillis());
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onEntityDamage(EntityDamageEvent event) {
		double originalDamage = event.getDamage();
		event.setDamage(0);
		if(event.getCause() == DamageCause.FIRE || event.getCause() == DamageCause.FIRE_TICK || event.getCause() == DamageCause.LAVA)
			event.getEntity().setFireTicks(1);
		if(event.getEntity() instanceof Villager) {
			event.setCancelled(true);
		} else if(event.getCause() == DamageCause.ENTITY_EXPLOSION || event.getCause() == DamageCause.BLOCK_EXPLOSION) {
			event.setCancelled(true);
		} else {
			boolean disableDamage = false;
			if(event.getEntity() instanceof LivingEntity) {
				if(event instanceof EntityDamageByEntityEvent) {
					final EntityDamageByEntityEvent e = (EntityDamageByEntityEvent)event;
					if(e.getEntity() instanceof LivingEntity) {
						if(MobHandler.spawnedMobs.get(e.getEntity().getUniqueId()) == null) {
							try {
								if(((LivingEntity)e.getEntity()).getCustomName().contains("[Lv.") 
									|| ((LivingEntity)e.getEntity()).getCustomName().contains("EXP")
									|| ChatColor.stripColor(((LivingEntity)e.getEntity()).getCustomName()).contains("[|||")) {
									e.getEntity().remove();
									return;
								}
							} catch(Exception e2) {
								
							}
						} else {
							try {
								if(MobHandler.spawnedMobs.get(e.getEntity().getUniqueId()).hp == 0) {
									e.getEntity().remove();
									MobHandler.spawnedMobs.get(e.getEntity().getUniqueId()).die();
								}
							} catch(Exception e2) {
								
							}
						}
					}
					Region r = RegionHandler.getRegion(event.getEntity().getLocation());
					if(e.getEntity() instanceof Player) {
						if(e.getDamager() instanceof Projectile) {
							if(((Projectile)(e.getDamager())).getShooter() instanceof Player) {
								if(!r.type.equals("perilous"))
									disableDamage = true;
							}
							if(e.getDamager() instanceof WitherSkull) {
								if(e.getEntity() instanceof Player) {
									SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
										public void run() {
											((Player)(e.getEntity())).removePotionEffect(PotionEffectType.WITHER);
										}
									}, 1);
								}
							}
						} else if(e.getDamager() instanceof Player) {
							if(!r.type.equals("perilous"))
								disableDamage = true;
						}
					}
					if(r.type.equals("secure") && e.getEntity() instanceof Player)
						disableDamage = true;
				}
			}
			if(!disableDamage) {
				if(event instanceof EntityDamageByEntityEvent) {
					EntityDamageByEntityEvent e = (EntityDamageByEntityEvent)event;
					if(e.getEntity().getPassenger() != null && e.getEntity().getPassenger() instanceof Player)
						CombatHandler.entityAttackEntity(e.getDamager(), e.getEntity().getPassenger());
					if (event.getEntity() instanceof LivingEntity) {
						LivingEntity le = (LivingEntity)(event.getEntity());
						if (le.getNoDamageTicks() > le.getMaximumNoDamageTicks() / 2.0F) {
							event.setCancelled(true);
						}
					}
					boolean mobHitOtherMob = false;
					if(e.getDamager() instanceof Projectile) {
						Projectile a = (Projectile)(e.getDamager());
						LivingEntity shooter = a.getShooter();
						if(event.getEntity() == shooter)
							event.setCancelled(true);
						if(!(shooter instanceof Player)) {
							if(!(event.getEntity() instanceof Player)) {
								mobHitOtherMob = true;
								event.setCancelled(true);
							}
						}
					}
					boolean sameParty = false;
					if(e.getEntity() instanceof Player) {
						PlayerData pd = plugin.getPD((Player)(e.getEntity()));
						if(pd.party != null) {
							if(e.getDamager() instanceof Player) {
								if(pd.party == plugin.getPD((Player)(e.getDamager())).party)
									sameParty = true;
							} else if(e.getDamager() instanceof Projectile) {
								if(((Projectile)(e.getDamager())).getShooter() instanceof Player)
									if(pd.party == plugin.getPD((Player)(((Projectile)(e.getDamager())).getShooter())).party)
										sameParty = true;
							}
						}
					}
					if(!mobHitOtherMob && !sameParty) {
						if(CombatHandler.entityAttackEntity(e.getDamager(), e.getEntity())) {
							final LivingEntity entityToReset = (LivingEntity)(e.getEntity());
							SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									entityToReset.setNoDamageTicks(0);
								}
							}, 1);
						}
					} else {
						event.setCancelled(true);
					}
					if(event.getEntity() instanceof Player) {
						if(plugin.getPD((Player)(event.getEntity())).intervention_buff)
							event.setCancelled(true);
						if(plugin.getPD((Player)(event.getEntity())).chantOfNecessarius_buff)
							event.setCancelled(true);
					}
				} else if(event.getEntity() instanceof Player) {
					Player p = (Player)(event.getEntity());
					PlayerData pd = plugin.getPD(p);
					if(pd != null) {
						if(event.getCause() == DamageCause.LAVA) {
							int damage = (int)(Math.ceil(pd.hp * 0.015));
							if(damage > 200)
								damage = 200;
							pd.damage(damage, null, true); 
						} else if(event.getCause() == DamageCause.FALL) {
							if(!(p.getVehicle() != null && p.getVehicle() instanceof Horse && pd.flyingHorse)) {
								double percentage = originalDamage / 60.0;
								if(percentage > 0.5)
									percentage = 0.5;
								int damage = (int)(Math.ceil(pd.hp * (0.10 + percentage)));
								if(damage > 200)
									damage = 200;
								pd.damage(damage, null, true); 
							}
						} else {
							event.setCancelled(true);
						}
					}
				} else {
					event.setCancelled(true);
				}
				if(event.getEntity() instanceof Player)
					if(((Player)event.getEntity()).isDead())
						event.setCancelled(true);
			}
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void shootProjectile(PlayerInteractEvent event) {
		Action a = event.getAction();
		Player p = (Player)(event.getPlayer());
		ItemStack i = p.getItemInHand();
		if(a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK) {
			if(Equip.BOW.isType(i)) {
				PlayerData pd = plugin.getPD(p);
				long delay = pd.getBowDelay();
				if(pd.shootingSpeed_buff > 1)
					delay /= pd.shootingSpeed_buff;
				if(System.nanoTime() - pd.lastProjectileShot > delay) {
					Projectile proj = plugin.getPD(p).shootArrow();
					SoundHandler.playSound(p, Sound.SHOOT_ARROW);
					proj.setBounce(false);
					proj.setShooter(p);
					proj.setVelocity(proj.getVelocity().multiply(2));
					pd.lastProjectileShot = System.nanoTime();
				}
				event.setCancelled(true);
			} else if(Equip.WAND.isType(i)) {
				final ArrayList<Location> boltLocs = new ArrayList<Location>();
				final ArrayList<Integer> tasks = new ArrayList<Integer>();
				final Player player = p;
				final PlayerData pd = plugin.getPD(p);
				long delay = pd.getWandDelay();
				ItemData id = ItemHandler.items.get(p.getItemInHand());
				if(id == null) {
					if(ItemHandler.loadItem(p.getItemInHand())) {
						id = ItemHandler.items.get(p.getItemInHand());
					}
				}
				if(id != null) {
					if(System.nanoTime() - pd.lastProjectileShot > delay) {
						Vector v = p.getEyeLocation().getDirection().normalize();
						Location loc = p.getEyeLocation();
						for(int k = 0; k < Values.WAND_RANGE; k++) {
							loc.add(v.toLocation(loc.getWorld()));
							if(MobHandler.isAirlike(loc.getBlock().getType()))
								boltLocs.add(loc.clone());
							else
								break;
						}
						SoundHandler.playSound(p, Sound.FIREWORK_LAUNCH);
						for(int k = 0; k < boltLocs.size(); k+=2) {
							final int current = k;
							tasks.add(SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
								public void run() {
									Location loc = boltLocs.get(current);
									HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
									particles.add(new ParticleDetails(pd.getWandEffect()));
									EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
									holder.setRunning(true);
									holder.update();
									holder.setRunning(false);
									Entity e = loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
									Entity e3 = null;
									if(current + 1 < boltLocs.size())
										e3 = loc.getWorld().spawnEntity(boltLocs.get(current + 1), EntityType.FIREWORK);
									List<Entity> toHit = (e3 != null ? e3 : e).getNearbyEntities(0.5, 0.5, 0.5);
									for(Entity e2 : toHit) {
										if(!(e2 instanceof LivingEntity))
											continue;
									    World world = ((CraftWorld)player.getWorld()).getHandle();
									    net.minecraft.server.v1_8_R1.Entity launch = new EntityWitherSkull(world);
									    Projectile proj = (Projectile) launch.getBukkitEntity();
										Player shooter = (Player) player;
										proj.setBounce(false);
										proj.setShooter(shooter);
										boolean hit = CombatHandler.entityAttackEntity(proj, e2, true, toHit.size());
										proj.remove();
										if(hit) {
											for(Integer i : tasks)
												plugin.getServer().getScheduler().cancelTask(i);
										}
									}
									e.remove();
									if(e3 != null)
										e3.remove();
								}
							}, k * 1));
						}
						pd.lastProjectileShot = System.nanoTime();
					}
				}
				event.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void onEntityTarget(EntityTargetEvent event) {
		if(event.getTarget() instanceof Player) {
			if(plugin.getPD((Player)(event.getTarget())) != null)
				if(plugin.getPD((Player)(event.getTarget())).invisible)
					event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onEntityDeath(EntityDeathEvent event) {
		//ENTITY DEATHS ARE NOW HANDLED IN MOBDATA.DIE()
		event.setDroppedExp(0);
		if(!(event.getEntity() instanceof Player)) {
			event.getDrops().clear();
			MobHandler.spawnedMobs.remove(event.getEntity().getUniqueId());
		}
	}
	
	@EventHandler
	public void playerDeath(PlayerDeathEvent event) {
		//PLAYER DEATHS ARE NOW HANDLED IN PLAYERDATA.DIE()
		event.setDroppedExp(0);
	}
}