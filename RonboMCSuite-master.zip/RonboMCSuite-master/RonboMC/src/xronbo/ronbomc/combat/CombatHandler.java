package xronbo.ronbomc.combat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.MetadataValue;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.guilds.GuildHandler;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.items.ItemHandler.Equip;


public class CombatHandler {
	
	public static RonboMC plugin;
	public static HashMap<UUID, ArrayList<String>> enqueuedMessages = new HashMap<UUID, ArrayList<String>>();
	
	public static void enqueueMessage(Player p, String message) {
		if(enqueuedMessages.get(p.getUniqueId()) != null) {
			enqueuedMessages.get(p.getUniqueId()).add(message);
		} else {
			ArrayList<String> toAdd = new ArrayList<String>();
			toAdd.add(message);
			enqueuedMessages.put(p.getUniqueId(), toAdd);
		}
	}
	
	public static boolean entityAttackEntity(Entity attacker, Entity damaged, boolean isSpell) {
		return entityAttackEntity(attacker, damaged, isSpell, 1);
	}
	
	public static boolean entityAttackEntity(Entity attacker, Entity damaged, boolean isSpell, int enemiesHit) {
		if(attacker == damaged) {
			enqueuedMessages.remove(attacker.getUniqueId());
			return false;
		}
		if(attacker instanceof Projectile)
			if(((Projectile)attacker).getShooter() == damaged) {
				enqueuedMessages.remove(((Projectile)attacker).getShooter().getUniqueId());
				return false;
			}
		if(attacker instanceof Player) {
			Player p1 = (Player)attacker;
			p1.getItemInHand().setDurability((short)0);
			PlayerData pd1 = plugin.getPD(p1);
			ItemStack i = p1.getItemInHand();
			ItemData id = ItemHandler.items.get(i);
			if(id == null) {
				if(ItemHandler.loadItem(i)) {
					id = ItemHandler.items.get(i);
				}
			}
			if(id == null) { //fists
				int damageToDeal = 1;
				damageToDeal += damageToDeal * pd1.strength / 100.0;
				if(damaged instanceof Player) {
					Player p2 = (Player)damaged;
					PlayerData pd2 = plugin.getPD(p2);
					pd2.damage(damageToDeal, p1, isSpell);
				} else {
					MobData md = MobHandler.spawnedMobs.get(damaged.getUniqueId());
					if(md == null) {
						enqueuedMessages.remove(p1.getUniqueId());
						return false;
					}
					md.damage(damageToDeal, p1, isSpell);
				}
				return false;
			}
			int damageToDeal = 0;
			if(id == null || (pd1.attack == 0)) {
				damageToDeal = 1;
			} else {
				damageToDeal = rollDamage(pd1);
			}
			
			if(Equip.SWORD.isType(i)) {
				if(ClassHandler.checkPassive("Sword Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 3;
					enqueueMessage(p1, "Sword Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Sword Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal += 10;
					enqueueMessage(p1, "Sword Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Sword Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.1;
					enqueueMessage(p1, "Sword Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Knight's Legacy", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.2;
					enqueueMessage(p1, "Knight's Legacy - [" + original + " -> " + damageToDeal + "]");;
				}
				if(ClassHandler.checkPassive("Combat Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.1;
					enqueueMessage(p1, "Combat Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Combat Master", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.15;
					enqueueMessage(p1, "Combat Master - [" + original + " -> " + damageToDeal + "]");
				}
			} else if(Equip.AXE.isType(i)) {
				if(ClassHandler.checkPassive("Axe Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 4;
					enqueueMessage(p1, "Axe Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Rage", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.1;
					enqueueMessage(p1, "Rage - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Axe Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.15;
					enqueueMessage(p1, "Axe Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Reckless", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.15;
					enqueueMessage(p1, "Reckless - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Berserk", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.20;
					enqueueMessage(p1, "Berserk - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Dangerous Game", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.30;
					enqueueMessage(p1, "Dangerous Game - [" + original + " -> " + damageToDeal + "]");
				}
			} else if(Equip.MACE.isType(i)) {
				if(ClassHandler.checkPassive("Mace Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 2;
					enqueueMessage(p1, "Mace Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Mace Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal += 8;
					enqueueMessage(p1, "Mace Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Valiant", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.05;
					enqueueMessage(p1, "Valiant - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Mace Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.10;
					enqueueMessage(p1, "Mace Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Holy Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.10;
					enqueueMessage(p1, "Holy Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Heaven's Hammer", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.20;
					enqueueMessage(p1, "Heaven's Hammer - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Transcendent", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.15;
					enqueueMessage(p1, "Transcendent - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Citadel", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.20;
					enqueueMessage(p1, "Citadel - [" + original + " -> " + damageToDeal + "]");
				}
			} else if(Equip.STAVE.isType(i)) {
				if(ClassHandler.checkPassive("Stave Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 3;
					enqueueMessage(p1, "Stave Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Stave Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal += 10;
					enqueueMessage(p1, "Stave Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Stave Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.18;
					enqueueMessage(p1, "Stave Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Legendary Stave", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.30;
					enqueueMessage(p1, "Legendary Stave - [" + original + " -> " + damageToDeal + "]");
				}
			} else if(Equip.DAGGER.isType(i)) {
				if(ClassHandler.checkPassive("Dagger Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 4;
					enqueueMessage(p1, "Dagger Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Dagger Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal += 13;
					enqueueMessage(p1, "Dagger Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Dagger Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.13;
					enqueueMessage(p1, "Dagger Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Dagger Legend", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.22;
					enqueueMessage(p1, "Dagger Legend - [" + original + " -> " + damageToDeal + "]");
				}
			} else if(Equip.BONE.isType(i)) {
				if(ClassHandler.checkPassive("Bone Prowess", pd1)) {
					int original = damageToDeal;
					damageToDeal += 10;
					enqueueMessage(p1, "Bone Prowess - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Bone Mastery", pd1)) {
					int original = damageToDeal;
					damageToDeal += 15;
					enqueueMessage(p1, "Bone Mastery - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Bone Champion", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.10;
					enqueueMessage(p1, "Bone Champion - [" + original + " -> " + damageToDeal + "]");
				}
				if(ClassHandler.checkPassive("Brute Force", pd1)) {
					int original = damageToDeal;
					damageToDeal *= 1.20;
					enqueueMessage(p1, "Brute Force - [" + original + " -> " + damageToDeal + "]");
				}
			}

			if(pd1.doubleHit_buff) {
				pd1.doubleHit_buff = false;
				pd1.doubleHitMultiplier_buff = 1;
				if(ItemHandler.Equip.DAGGER.isType(i)) {
					p1.sendMessage(ChatColor.ITALIC + "You viciously stab two more times at your opponent.");
					entityAttackEntity(attacker, damaged, true);
					entityAttackEntity(attacker, damaged, true);
				} else {
					p1.sendMessage(ChatColor.ITALIC + "You try to do a double stab, but find it difficult to do so without a dagger.");
				}
				isSpell = true;
			}
			if(pd1.ambush_buff) {
				if(pd1.ambushHits_buff > 0) {
					pd1.doubleHitMultiplier_buff = 1;
					if(ItemHandler.Equip.DAGGER.isType(p1.getItemInHand())) {
						p1.sendMessage(ChatColor.ITALIC + "You feel that this blow is strengthed.");
						enqueueMessage(p1, "Ambush - [" + damageToDeal + " -> " + (int)(damageToDeal * pd1.ambushMultiplier_buff) + "]");
						damageToDeal *= pd1.ambushMultiplier_buff;
					} else {
						p1.sendMessage(ChatColor.ITALIC + "You try to ambush the enemy, but find it difficult to do so without a dagger.");
						pd1.ambushHits_buff = 0;
					}
					isSpell = true;
					pd1.ambushHits_buff--;
				}
				if(pd1.ambushHits_buff <= 0)
					pd1.ambush_buff = false;
			}
			if(pd1.sneakAttack_buff) {
				enqueueMessage(p1, "Sneak Attack - [" + damageToDeal + " -> " + (int)(damageToDeal * pd1.sneakAttackMultipler_buff) + "]");
				damageToDeal *= pd1.sneakAttackMultipler_buff;
				pd1.sneakAttack_buff = false;
				pd1.sneakAttackMultipler_buff = 1;
			}
			if(pd1.invisible)
				pd1.makeVisible();
			if(pd1.powerStrike_buff) {
				enqueueMessage(p1, "Power Strike - [" + damageToDeal + " -> " + (int)(damageToDeal * pd1.powerStrikeMultiplier_buff) + "]");
				damageToDeal *= pd1.powerStrikeMultiplier_buff;
				pd1.powerStrike_buff = false;
				pd1.powerStrikeMultiplier_buff = 1.0;
			}
			if(pd1.bless_buff) {
				enqueueMessage(p1, "Bless - [" + damageToDeal + " -> " + (int)(damageToDeal * (1 + pd1.blessMultiplier_buff)) + "]");
				damageToDeal += damageToDeal * pd1.blessMultiplier_buff;
			}
			if(pd1.focus_buff) {
				enqueueMessage(p1, "Focus - [" + damageToDeal + " -> " + (int)(damageToDeal * (1 + pd1.focusMultiplier_buff)) + "]");
				damageToDeal += damageToDeal * pd1.focusMultiplier_buff;
			}
			if(pd1.wildSwing_buff) {
				enqueueMessage(p1, "Wild Swing - [" + damageToDeal + " -> " + (int)(damageToDeal * pd1.wildSwingMultiplier_buff) + "]");
				enqueueMessage(p1, "Wild Swing recoil dmg - [" + (int)(damageToDeal * pd1.wildSwingRecoil_buff) + "]");
				int recoil =(int)(damageToDeal * pd1.wildSwingRecoil_buff);
				if(recoil > pd1.hp * .90)
					recoil = (int)(pd1.hp * .9);
				pd1.damage(recoil, p1, true);
				damageToDeal += damageToDeal * pd1.wildSwingMultiplier_buff;
				pd1.wildSwing_buff = false;
				pd1.wildSwingMultiplier_buff = 1;
				pd1.wildSwingRecoil_buff = 0;
			}
			if(pd1.sacrifice_buff) {
				enqueueMessage(p1, "Sacrifice - [" + damageToDeal + " -> " + (int)(damageToDeal + pd1.sacrificeValue_buff) + "]");
				damageToDeal += pd1.sacrificeValue_buff;
				pd1.sacrifice_buff = false;
				pd1.sacrificeValue_buff = 0;
			}
			if(pd1.divineShield_buff) {
				pd1.addShield(damageToDeal * pd1.divineShieldMultiplier_buff);
				enqueueMessage(p1, "Divine Shield value of " + pd1.shield);
				pd1.divineShield_buff = false;
				pd1.divineShieldMultiplier_buff = 0;
			}
			
			if(Equip.WAND.isType(i) || Equip.BOW.isType(i)) {
				double whackMultiplier = 0.5;
				if(ClassHandler.getClassType(pd1.classType) == ClassType.ARCHER) {
					if(ClassHandler.checkPassive("physical training", pd1)) {
						whackMultiplier = 0.75;
					}
					if(ClassHandler.checkPassive("combat expert", pd1)) {
						whackMultiplier = 1;
					}
				}
				if(whackMultiplier < 1) {
					enqueueMessage(p1, "Whacking damage deduction - [" + damageToDeal + " -> " + (int)(damageToDeal * whackMultiplier) + "]");
					damageToDeal *= whackMultiplier;
				}
			}
			
			if(Equip.SWORD.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Crusader")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Wizard") || pd1.classType.equalsIgnoreCase("Archer") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.AXE.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Berserker")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Wizard") || pd1.classType.equalsIgnoreCase("Archer") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.MACE.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Paladin")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Wizard") || pd1.classType.equalsIgnoreCase("Archer") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.STAVE.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Cleric")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.WAND.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Wizard")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Crusader") || pd1.classType.equalsIgnoreCase("Berserker") || pd1.classType.equalsIgnoreCase("Paladin") || pd1.classType.equalsIgnoreCase("Cleric") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.BOW.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Archer")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Crusader") || pd1.classType.equalsIgnoreCase("Berserker") || pd1.classType.equalsIgnoreCase("Paladin") || pd1.classType.equalsIgnoreCase("Cleric") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.DAGGER.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Crusader") || pd1.classType.equalsIgnoreCase("Berserker") || pd1.classType.equalsIgnoreCase("Paladin") || pd1.classType.equalsIgnoreCase("Cleric") || pd1.classType.equalsIgnoreCase("Wizard") || pd1.classType.equalsIgnoreCase("Archer") || pd1.classType.equalsIgnoreCase("Assassin")) {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			} else if(Equip.BONE.isType(i)) {
				if(pd1.classType.equalsIgnoreCase("Barbarian")) {
					enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
					damageToDeal *= 1.2;
				} else {
					enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
					damageToDeal *= 0.3;
				}
			}
			
			if(damaged instanceof Player) {
				Player p2 = (Player)damaged;
				PlayerData pd2 = plugin.getPD(p2);
				if(pd1.puncture_buff) {
					int original = damageToDeal;
					damageToDeal += pd2.hp * pd1.punctureMultiplier_buff;
					if(damageToDeal > pd1.punctureMaxDamage_buff)
						damageToDeal = pd1.punctureMaxDamage_buff;
					enqueueMessage(p1, "Puncture - [" + original + " -> " + damageToDeal + "]");
					pd1.puncture_buff = false;
					pd1.punctureMultiplier_buff = 0;
					pd1.punctureMaxDamage_buff = 0;
					isSpell = true;
				}
				if(pd1.cleave_buff) {
					enqueueMessage(p1, "Cleave - [" + damageToDeal + " -> " + ((int)(damageToDeal + (pd2.maxHP + pd2.maxHP_temp) * pd1.cleaveMultiplier_buff) > pd1.cleaveMaxDamage_buff ? pd1.cleaveMaxDamage_buff : (int)(damageToDeal + (pd2.maxHP + pd2.maxHP_temp) * pd1.cleaveMultiplier_buff)) + "]");
					damageToDeal += (pd2.maxHP + pd2.maxHP_temp) * pd1.cleaveMultiplier_buff;
					if(damageToDeal > pd1.cleaveMaxDamage_buff)
						damageToDeal = pd1.cleaveMaxDamage_buff;
					pd1.cleave_buff = false;
					pd1.cleaveMultiplier_buff = 0;
					isSpell = true;
				}
				if(pd1.disable_buff) {
					pd2.applyDisable(pd1.disableDuration_buff);
					pd1.disable_buff = false;
					pd1.disableDuration_buff = 0;
					p1.sendMessage("You disabled " + pd2.player.getName() + "\'s HP regeneration!");
				}
				if(Equip.AXE.isType(i)) {
					if(ClassHandler.checkPassive("vicious strikes", pd1)) {
						int valueToAdd = (int)((pd2.hp) * 0.03);
						if(valueToAdd > 5000)
							valueToAdd = 5000;
						enqueueMessage(p1, "Vicious Strikes - [" + damageToDeal + " -> " + (damageToDeal + valueToAdd) + "]");
						damageToDeal += valueToAdd;
					}
				}
				if(Equip.DAGGER.isType(i)) {
					if(ClassHandler.checkPassive("Assassin's Creed", pd1)) {
						int buff = (int)((pd2.maxHP + pd2.maxHP_temp) * 0.04);
						if(buff > 50000)
							buff = 50000;
						enqueueMessage(p1, "Assassin's Creed - [" + damageToDeal + " -> " + (damageToDeal + buff) + "]");
						damageToDeal += buff;
					}
				}
				if(Equip.BONE.isType(i)) {
					if(ClassHandler.checkPassive("ferocity", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.15;
						enqueueMessage(p1, "Ferocity - [" + original + " -> " + damageToDeal + "]");
					}
				}
				if(pd1.goldenTouch_buff) {
					enqueueMessage(p1, "Received " + ((int)(Math.ceil(damageToDeal * pd1.goldenTouchMultiplier_buff))) + " gold from Golden Touch");
					int amount = (int)(Math.ceil(damageToDeal * pd1.goldenTouchMultiplier_buff));
					pd1.wallet += amount;
					pd1.goldenTouch_buff = false;
					pd1.goldenTouchMultiplier_buff = 1;
				}
				pd2.damage(damageToDeal, p1, isSpell);
			} else {
				MobData md = MobHandler.spawnedMobs.get(damaged.getUniqueId());
				if(md == null) {
					enqueuedMessages.remove(attacker.getUniqueId());
					return false;
				}
				if(pd1.puncture_buff) {
					int original = damageToDeal;
					damageToDeal += md.hp * pd1.punctureMultiplier_buff;
					if(damageToDeal > pd1.punctureMaxDamage_buff)
						damageToDeal = pd1.punctureMaxDamage_buff;
					enqueueMessage(p1, "Puncture - [" + original + " -> " + damageToDeal + "]");
					pd1.puncture_buff = false;
					pd1.punctureMultiplier_buff = 0;
					pd1.punctureMaxDamage_buff = 0;
					isSpell = true;
				}
				if(pd1.cleave_buff) {
					enqueueMessage(p1, "Cleave - [" + damageToDeal + " -> " + ((int)(damageToDeal + md.mobType.hp * pd1.cleaveMultiplier_buff) > pd1.cleaveMaxDamage_buff ? pd1.cleaveMaxDamage_buff : (int)(damageToDeal + md.mobType.hp * pd1.cleaveMultiplier_buff)) + "]");
					damageToDeal += md.mobType.hp * pd1.cleaveMultiplier_buff;
					if(damageToDeal > pd1.cleaveMaxDamage_buff)
						damageToDeal = pd1.cleaveMaxDamage_buff;
					pd1.cleave_buff = false;
					pd1.cleaveMultiplier_buff = 0;
					isSpell = true;
				}
				if(Equip.AXE.isType(i)) {
					if(ClassHandler.checkPassive("vicious strikes", pd1)) {
						int valueToAdd = (int)((md.hp) * 0.03);
						if(valueToAdd > 5000)
							valueToAdd = 5000;
						enqueueMessage(p1, "Vicious Strikes - [" + damageToDeal + " -> " + (damageToDeal + valueToAdd) + "]");
						damageToDeal += valueToAdd;
					}
				}
				if(Equip.DAGGER.isType(i)) {
					if(ClassHandler.checkPassive("Assassin's Creed", pd1)) {
						int buff = (int)(md.mobType.hp * 0.04);
						if(buff > 50000)
							buff = 50000;
						enqueueMessage(p1, "Assassin's Creed - [" + damageToDeal + " -> " + (damageToDeal + buff) + "]");
						damageToDeal += buff;
					}
				}
				if(pd1.goldenTouch_buff) {
					enqueueMessage(p1, "Received " + ((int)(Math.ceil(damageToDeal * pd1.goldenTouchMultiplier_buff))) + " gold from Golden Touch");
					int amount = (int)(Math.ceil(damageToDeal * pd1.goldenTouchMultiplier_buff));
					pd1.wallet += amount;
					pd1.goldenTouch_buff = false;
					pd1.goldenTouchMultiplier_buff = 1;
				}
				md.damage(damageToDeal, p1, isSpell);
			}
			
		} else if (attacker instanceof Projectile) {
			Projectile projectile = ((Projectile)attacker);
			if(projectile.getShooter() instanceof Player) {
				Player p1 = (Player)(projectile.getShooter());
				p1.getItemInHand().setDurability((short)0);
				PlayerData pd1 = plugin.getPD(p1);
				ItemStack i = p1.getItemInHand();
				if(!(Equip.BOW.isType(i) || Equip.WAND.isType(i))) {
					enqueuedMessages.remove(p1.getUniqueId());
					return false;
				}
				ItemData id = ItemHandler.items.get(i);
				if(id == null) {
					if(ItemHandler.loadItem(i)) {
						id = ItemHandler.items.get(i);
					}
				}
				if(id == null)
					return false;
				int damageToDeal = 0;
				if(id == null || (pd1.attack == 0)) {
					damageToDeal = 1;
				} else {
					damageToDeal = rollDamage(pd1);
				}
				
				if(Equip.WAND.isType(i)) {
					if(enemiesHit > 1)
						damageToDeal /= enemiesHit;
					if(ClassHandler.checkPassive("Wand Prowess", pd1)) {
						int original = damageToDeal;
						damageToDeal += 5;
						enqueueMessage(p1, "Wand Prowess - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Wand Mastery", pd1)) {
						int original = damageToDeal;
						damageToDeal += 10;
						enqueueMessage(p1, "Wand Mastery - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Wand Champion", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.10;
						enqueueMessage(p1, "Wand Champion - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Wand of Legends", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.20;
						enqueueMessage(p1, "Wand of Legends - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("True Wizardry", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.25;
						enqueueMessage(p1, "True Wizardry - [" + original + " -> " + damageToDeal + "]");
					}
				} else if(Equip.BOW.isType(i)) {
					if(ClassHandler.checkPassive("Bow Prowess", pd1)) {
						int original = damageToDeal;
						damageToDeal += 4;
						enqueueMessage(p1, "Bow Prowess - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Bow Mastery", pd1)) {
						int original = damageToDeal;
						damageToDeal += 12;
						enqueueMessage(p1, "Bow Mastery - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Bow Champion", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.15;
						enqueueMessage(p1, "Bow Champion - [" + original + " -> " + damageToDeal + "]");
					}
					if(ClassHandler.checkPassive("Railgun", pd1)) {
						int original = damageToDeal;
						damageToDeal *= 1.35;
						enqueueMessage(p1, "Railgun - [" + original + " -> " + damageToDeal + "]");
					}
				}
				if(pd1.invisible)
					pd1.makeVisible();
				if(projectile.hasMetadata("damageMultiplier")) {
					for(MetadataValue mv : projectile.getMetadata("damageMultiplier")) {
						if(mv.value() instanceof Double) {
							isSpell = true;
							enqueueMessage(p1, "Spell modified base damage - ["+ damageToDeal + " -> " + (int)(damageToDeal * (Double)(mv.value())) + "]");
							damageToDeal *= (Double)(mv.value());
						}
					}
				}
				if(projectile.hasMetadata("knockback")) {
					for(MetadataValue mv : projectile.getMetadata("knockback")) {
						if(mv.value() instanceof Integer) {
							isSpell = true;
							int knockback = (Integer)(mv.value());
							damaged.setVelocity(damaged.getLocation().toVector().subtract(p1.getLocation().toVector()).normalize().multiply(knockback));
						}
					}
				}
				if(pd1.bless_buff) {
					enqueueMessage(p1, "Bless modified dmg - [" + damageToDeal + " -> " + (int)(damageToDeal * (1 + pd1.blessMultiplier_buff)) + "]");
					damageToDeal += damageToDeal * pd1.blessMultiplier_buff;
				}

				if(Equip.WAND.isType(i)) {
					if(pd1.classType.equalsIgnoreCase("Wizard")) {
						enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
						damageToDeal *= 1.2;
					} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Crusader") || pd1.classType.equalsIgnoreCase("Berserker") || pd1.classType.equalsIgnoreCase("Paladin") || pd1.classType.equalsIgnoreCase("Cleric") || pd1.classType.equalsIgnoreCase("Assassin")) {
						enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
						damageToDeal *= 0.3;
					}
				} else if(Equip.BOW.isType(i)) {
					if(pd1.classType.equalsIgnoreCase("Archer")) {
						enqueueMessage(p1, "Class Specialty - [" + damageToDeal + " -> " + (int)(damageToDeal * 1.2) + "]");
						damageToDeal *= 1.2;
					} else if(pd1.classType.equalsIgnoreCase("Barbarian") || pd1.classType.equalsIgnoreCase("Crusader") || pd1.classType.equalsIgnoreCase("Berserker") || pd1.classType.equalsIgnoreCase("Paladin") || pd1.classType.equalsIgnoreCase("Cleric") || pd1.classType.equalsIgnoreCase("Assassin")) {
						enqueueMessage(p1, "Class Weakness - [" + damageToDeal + " -> " + (int)(damageToDeal * 0.5) + "]");
						damageToDeal *= 0.3;
					}
				}
				
				if(damaged instanceof Player) {
					Player p2 = (Player)damaged;
					PlayerData pd2 = plugin.getPD(p2);
					double knockback = 0.2;
					if(isSpell && Equip.WAND.isType(i))
						knockback = 0.05;
					pd2.damage(damageToDeal, p1, isSpell, knockback);
				} else {
					MobData md = MobHandler.spawnedMobs.get(damaged.getUniqueId());
					if(md == null) {
						enqueuedMessages.remove(p1.getUniqueId());
						return false;
					}
					double knockback = 0.2;
					if(isSpell && Equip.WAND.isType(i))
						knockback = 0.05;
					md.damage(damageToDeal, p1, isSpell, knockback);
				}
			} else {
				LivingEntity shooter = ((Projectile) attacker).getShooter();
				Player p1 = (Player)damaged;
				PlayerData pd = plugin.getPD(p1);
				MobData md = null;
				try {
					md = MobHandler.spawnedMobs.get(shooter.getUniqueId());
				} catch(Exception e) {
					return false;
				}
				if(md == null) {
					return false;
				}
				int damageToDeal = Values.randInt(md.mobType.minDamage, md.mobType.maxDamage);
				if(projectile.hasMetadata("damageMultiplier")) {
					for(MetadataValue mv : projectile.getMetadata("damageMultiplier")) {
						if(mv.value() instanceof Double) {
							isSpell = true;
							enqueueMessage(p1, "Spell modified base damage - ["+ damageToDeal + " -> " + (int)(damageToDeal * (Double)(mv.value())) + "]");
							damageToDeal *= (Double)(mv.value());
						}
					}
				}
				if(projectile.hasMetadata("knockback")) {
					for(MetadataValue mv : projectile.getMetadata("knockback")) {
						if(mv.value() instanceof Integer) {
							isSpell = true;
							int knockback = (Integer)(mv.value());
							damaged.setVelocity(damaged.getLocation().toVector().subtract(p1.getLocation().toVector()).normalize().multiply(knockback));
						}
					}
				}
				pd.damage(damageToDeal, shooter, isSpell, 0.7);
			}
			if(projectile instanceof Arrow)
				projectile.getWorld().playSound(projectile.getLocation(), Sound.ARROW_HIT, 1, 1);
			projectile.remove();
		} else if (attacker instanceof LivingEntity) {
			if(damaged instanceof Player) {
				Player p1 = (Player)damaged;
				PlayerData pd = plugin.getPD(p1);
				LivingEntity e = (LivingEntity)attacker;
				MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
				if(md == null)
					return false;
				int damageToDeal = Values.randInt(md.mobType.minDamage, md.mobType.maxDamage);
				pd.damage(damageToDeal, e, isSpell);
			} else {
				//non-players cannot attack non-players. may need to add something here once familiars/pets exist, but not now.
			}
		}
		if(attacker instanceof Projectile)
			enqueuedMessages.remove(((Projectile)attacker).getShooter().getUniqueId());
		else
			enqueuedMessages.remove(attacker.getUniqueId());
		return isSpell;
	}
	
	public static boolean entityAttackEntity(Entity attacker, Entity damaged) {
		return entityAttackEntity(attacker, damaged, false);
	}
	
	
	public static int rollDamage(int attack, PlayerData pd) {
		double primaryStat = pd.getPrimaryStat();
		double secondaryStat = pd.getSecondaryStat();
		if(pd.classType != null && pd.classType.equalsIgnoreCase("barbarian")) {
			primaryStat = (pd.strength + pd.strength_temp + pd.dexterity + pd.dexterity_temp + 
					pd.intelligence + pd.intelligence_temp + pd.luck + pd.luck_temp + pd.level * 8)/2.2;
			secondaryStat = primaryStat * 0.5;
		}
		int maxDamage = (int)(Math.ceil(3.35 * primaryStat + 1.15 * secondaryStat) * (attack / 80.0));
		int minDamage = (int)((0.30 + secondaryStat/primaryStat > 0.85 ? 0.85 : 0.30 + secondaryStat/primaryStat) * maxDamage);
		int value = Values.randInt(minDamage, maxDamage);
		if(pd.damageBooster > 0) {
			plugin.db(pd.player, "DMG BOOST: Base DMG " + value + " -> " + (int)(value * pd.damageBooster));
			value *= pd.damageBooster;
		}
		if(GuildHandler.checkBuff(pd.player, "damage")) {
			plugin.db(pd.player, "GUILD BOOST: Base DMG " + value + " -> " + (int)(value * 1.1));
			value *= 1.1;
		}
		return value;
	}
	
	public static int rollDamage(PlayerData pd) {
		return rollDamage(pd.attack, pd);
	}
	
	public static int rollDamage(Player p) {
		return rollDamage(plugin.getPD(p));
	}
	
	private CombatHandler() {
		
	}
	
}