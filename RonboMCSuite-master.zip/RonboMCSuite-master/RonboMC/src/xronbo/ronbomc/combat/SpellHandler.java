package xronbo.ronbomc.combat;

import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.spells.AxeBloodCallSpell;
import xronbo.ronbomc.combat.spells.AxeSacrificeSpell;
import xronbo.ronbomc.combat.spells.AxeWildSwingSpell;
import xronbo.ronbomc.combat.spells.BoneFallingBlockSpell;
import xronbo.ronbomc.combat.spells.BoneJumpSmashSpell;
import xronbo.ronbomc.combat.spells.BoneSelfBuffSpell;
import xronbo.ronbomc.combat.spells.BowArrowRainSpell;
import xronbo.ronbomc.combat.spells.BowBluntArrowSpell;
import xronbo.ronbomc.combat.spells.BowDoubleShotSpell;
import xronbo.ronbomc.combat.spells.BowEmpoweredShotSpell;
import xronbo.ronbomc.combat.spells.BowHawkeyeSpell;
import xronbo.ronbomc.combat.spells.BowHurricaneSpell;
import xronbo.ronbomc.combat.spells.BowQuadShotSpell;
import xronbo.ronbomc.combat.spells.BowRapidFireSpell;
import xronbo.ronbomc.combat.spells.BowTripleShotSpell;
import xronbo.ronbomc.combat.spells.DaggerAmbushSpell;
import xronbo.ronbomc.combat.spells.DaggerDisableSpell;
import xronbo.ronbomc.combat.spells.DaggerDoubleStabSpell;
import xronbo.ronbomc.combat.spells.DaggerGoldenTouchSpell;
import xronbo.ronbomc.combat.spells.DaggerPunctureSpell;
import xronbo.ronbomc.combat.spells.DaggerSneakAttackSpell;
import xronbo.ronbomc.combat.spells.DaggerStealthSpell;
import xronbo.ronbomc.combat.spells.MaceChantOfNecessariusSpell;
import xronbo.ronbomc.combat.spells.MaceDivineShieldSpell;
import xronbo.ronbomc.combat.spells.MaceIndomitableSpell;
import xronbo.ronbomc.combat.spells.MaceSmashSpell;
import xronbo.ronbomc.combat.spells.SpecialSpiritStormSpell;
import xronbo.ronbomc.combat.spells.Spell;
import xronbo.ronbomc.combat.spells.StaveBlessSpell;
import xronbo.ronbomc.combat.spells.StaveInterventionSpell;
import xronbo.ronbomc.combat.spells.StavePartyHealSpell;
import xronbo.ronbomc.combat.spells.StaveSelfHealSpell;
import xronbo.ronbomc.combat.spells.SwordChargeSpell;
import xronbo.ronbomc.combat.spells.SwordCleaveSpell;
import xronbo.ronbomc.combat.spells.SwordFocusSpell;
import xronbo.ronbomc.combat.spells.SwordJudgementSpell;
import xronbo.ronbomc.combat.spells.SwordPowerStrikeSpell;
import xronbo.ronbomc.combat.spells.WandAuraDrainAuraSpell;
import xronbo.ronbomc.combat.spells.WandAuraFireAuraSpell;
import xronbo.ronbomc.combat.spells.WandBoltFireBoltSpell;
import xronbo.ronbomc.combat.spells.WandBoltMagicBarrageSpell;
import xronbo.ronbomc.combat.spells.WandBoltMagicBurstSpell;
import xronbo.ronbomc.combat.spells.WandBoltTripleBoltSpell;

public class SpellHandler {
	
	public static RonboMC plugin;
	
	private SpellHandler() {
		
	}
	
	public static Object[][] spells = new Object[][] {
		/* Bow Spells */
		//Tier 1
		new Object[] {"Double Shot I", new BowDoubleShotSpell(7, 1.20), "Shoots two arrows dealing 120% damage each"},
		new Object[] {"Double Shot II", new BowDoubleShotSpell(6, 1.40), "Shoots two arrows dealing 140% damage each"},
		new Object[] {"Double Shot III", new BowDoubleShotSpell(5, 1.60), "Shoots two arrows dealing 160% damage each"},
		new Object[] {"Empowered Shot I", new BowEmpoweredShotSpell(5, 1.75), "Shoots a powerful arrow dealing 175% damage"},
		new Object[] {"Triple Shot I", new BowTripleShotSpell(5, 0.8), "Shoots three arrows dealing 80% damage each"},
		new Object[] {"Triple Shot II", new BowTripleShotSpell(5, 1.0), "Shoots three arrows dealing 100% damage each"},
		new Object[] {"Hawkeye I", new BowHawkeyeSpell(120, 25, 30), "Increases critical chance by 25% for 30 seconds"},
		new Object[] {"Blunt Arrow I", new BowBluntArrowSpell(15, 0, 1), "Shoots a blunt arrow that knocks enemies hit a short distance away."},
		//Tier 2
		new Object[] {"Double Shot IV", new BowDoubleShotSpell(5, 1.80), "Shoots two arrows dealing 180% damage each"},
		new Object[] {"Empowered Shot II", new BowEmpoweredShotSpell(5, 2.25), "Shoots a powerful arrow dealing 225% damage"},
		new Object[] {"Empowered Shot III", new BowEmpoweredShotSpell(5, 2.75), "Shoots a powerful arrow dealing 275% damage"},
		new Object[] {"Triple Shot III", new BowTripleShotSpell(4, 1.2), "Shoots three arrows dealing 120% damage each"},
		new Object[] {"Hurricane I", new BowHurricaneSpell(30, 0.25, 15), "Shoots a stream of 15 arrows dealing 25% damage each"},
		new Object[] {"Hurricane II", new BowHurricaneSpell(30, 0.25, 20), "Shoots a stream of 20 arrows dealing 25% damage each"},
		new Object[] {"Hurricane III", new BowHurricaneSpell(30, 0.3, 20), "Shoots a stream of 20 arrows dealing 30% damage each"},
		new Object[] {"Hawkeye II", new BowHawkeyeSpell(120, 35, 30), "Increases critical chance by 35% for 30 seconds"},
		new Object[] {"Rapid Fire I", new BowRapidFireSpell(180, 2, 30), "Doubles shooting speed for 30 seconds"},
		new Object[] {"Quad Shot I", new BowQuadShotSpell(5, 1.0), "Shoots four arrows dealing 100% damage each"},
		new Object[] {"Arrow Rain I", new BowArrowRainSpell(15, 0.85), "A rain of arrows flies down from the sky dealing 85% damage each"},
		new Object[] {"Blunt Arrow II", new BowBluntArrowSpell(10, 0, 2), "Shoots a blunt arrow that knocks enemies hit a medium distance away."},
		//Tier 3
		new Object[] {"Hurricane IV", new BowHurricaneSpell(25, 0.35, 30), "Shoots a stream of 25 arrows dealing 30% damage each"},
		new Object[] {"Hurricane V", new BowHurricaneSpell(30, 0.35, 40), "Shoots a stream of 25 arrows dealing 35% damage each"},
		new Object[] {"Triple Shot IV", new BowTripleShotSpell(3, 1.4), "Shoots three arrows dealing 140% damage each"},
		new Object[] {"Empowered Shot IV", new BowEmpoweredShotSpell(4, 3.25), "Shoots a powerful arrow dealing 325% damage"},
		new Object[] {"Empowered Shot V", new BowEmpoweredShotSpell(3, 3.75), "Shoots a powerful arrow dealing 375% damage"},
		new Object[] {"Hawkeye III", new BowHawkeyeSpell(120, 60, 30), "Increases critical chance by 60% for 30 seconds"},
		new Object[] {"Rapid Fire II", new BowRapidFireSpell(180, 2, 60), "Doubles shooting speed for 60 seconds"},
		new Object[] {"Rapid Fire III", new BowRapidFireSpell(180, 3, 60), "Triples shooting speed for 60 seconds"},
		new Object[] {"Quad Shot II", new BowQuadShotSpell(5, 1.2), "Shoots four arrows dealing 120% damage each"},
		new Object[] {"Quad Shot III", new BowQuadShotSpell(5, 1.4), "Shoots four arrows dealing 140% damage each"},
		new Object[] {"Arrow Rain II", new BowArrowRainSpell(15, 1.0), "A rain of arrows flies down from the sky dealing 100% damage each"},
		new Object[] {"Blunt Arrow III", new BowBluntArrowSpell(5, 0, 4), "Shoots a blunt arrow that knocks enemies hit a long distance away."},
		/* Dagger Spells */
		//Tier 1
		new Object[] {"Double Stab I", new DaggerDoubleStabSpell(5, 0.6), "Quickly stabs two times on the next attack dealing 60% damage each stab"},
		new Object[] {"Double Stab II", new DaggerDoubleStabSpell(5, 0.7), "Quickly stabs two times on the next attack dealing 70% damage each stab"},
		new Object[] {"Puncture I", new DaggerPunctureSpell(15, 0.1, 15000), "Deals an extra 10% of the target's current health with the next attack for a maximum of 15000 damage"},
		new Object[] {"Sneak Attack I", new DaggerSneakAttackSpell(20, 1.2, 10), "Stealth for 10 seconds and deal 120% damage with the next attack"},
		new Object[] {"Sneak Attack II", new DaggerSneakAttackSpell(20, 1.35, 15), "Stealth for 15 seconds and deal 135% damage with the next attack"},
		new Object[] {"Stealth I", new DaggerStealthSpell(120, 0, 60), "Become completely invisible for 60 seconds"},
		new Object[] {"Golden Touch I", new DaggerGoldenTouchSpell(5, 0.01), "The next attack gives 1% of dealt damage back as gold"},
		//Tier 2
		new Object[] {"Double Stab III", new DaggerDoubleStabSpell(5, 1.0), "Quickly stabs two times on the next attack dealing 100% damage each stab"},
		new Object[] {"Double Stab IV", new DaggerDoubleStabSpell(5, 1.1), "Quickly stabs two times on the next attack dealing 110% damage each stab"},
		new Object[] {"Puncture II", new DaggerPunctureSpell(15, 0.15, 50000), "Deals an extra 15% of the target's current health with the next attack for a maximum of 50000 damage"},
		new Object[] {"Sneak Attack III", new DaggerSneakAttackSpell(25, 1.6, 20), "Stealth for 20 seconds and deal 160% damage with the next attack"},
		new Object[] {"Stealth II", new DaggerStealthSpell(120, 0, 80), "Become completely invisible for 80 seconds"},
		new Object[] {"Golden Touch II", new DaggerGoldenTouchSpell(5, 0.02), "The next attack gives 2% of dealt damage back as gold"},
		new Object[] {"Ambush I", new DaggerAmbushSpell(60, 1.2, 3, 3), "Stealths for 3 seconds and teleports to deal 120% damage on each of the next 3 attacks"},
		new Object[] {"Disable I", new DaggerDisableSpell(30, 3), "Disables enemy player's HP regeneration for 3 seconds"},
		new Object[] {"Disable II", new DaggerDisableSpell(30, 6), "Disables enemy player's HP regeneration for 6 seconds"},
		//Tier 3
		new Object[] {"Double Stab V", new DaggerDoubleStabSpell(4, 1.4), "Quickly stabs two times on the next attack dealing 140% damage each stab"},
		new Object[] {"Double Stab VI", new DaggerDoubleStabSpell(5, 1.8), "Quickly stabs two times on the next attack dealing 180% damage each stab"},
		new Object[] {"Puncture III", new DaggerPunctureSpell(15, 0.25, 150000), "Deals an extra 25% of the target's current health with the next attack for a maximum of 150000 damage"},
		new Object[] {"Puncture IV", new DaggerPunctureSpell(10, 0.2, 200000), "Deals an extra 20% of the target's current health with the next attack for a maximum of 200000 damage"},
		new Object[] {"Sneak Attack IV", new DaggerSneakAttackSpell(35, 2.0, 30), "Stealth for 30 seconds and deal 200% damage with the next attack"},
		new Object[] {"Stealth III", new DaggerStealthSpell(120, 0, 100), "Become completely invisible for 100 seconds"},
		new Object[] {"Golden Touch III", new DaggerGoldenTouchSpell(5, 0.03), "The next attack gives 3% of dealt damage back as gold"},
		new Object[] {"Golden Touch IV", new DaggerGoldenTouchSpell(7, 0.04), "The next attack gives 4% of dealt damage back as gold"},
		new Object[] {"Ambush II", new DaggerAmbushSpell(60, 1.5, 5, 5), "Stealths for 5 seconds and teleports to deal 150% damage on each of the next 5 attacks"},
		new Object[] {"Ambush III", new DaggerAmbushSpell(60, 2.0, 5, 5), "Stealths for 5 seconds and teleports to deal 200% damage on each of the next 5 attacks"},
		new Object[] {"Disable III", new DaggerDisableSpell(30, 10), "Disables enemy player's HP regeneration for 10 seconds"},
		/* Stave Spells */
		//Tier 1
		new Object[] {"Self Heal I", new StaveSelfHealSpell(6, 0.35), "Heals self for 35% of the stave's damage"},
		new Object[] {"Self Heal II", new StaveSelfHealSpell(6, 0.45), "Heals self for 45% of the stave's damage"},
		new Object[] {"Party Heal I", new StavePartyHealSpell(7, 0.2), "Heals all party members for 20% of the stave's damage"},
		new Object[] {"Party Heal II", new StavePartyHealSpell(7, 0.3), "Heals all party members for 30% of the stave's damage"},
		new Object[] {"Bless I", new StaveBlessSpell(10, 0.2, 5), "Increases the damage of all party members by 20% for 5 seconds"},
		//Tier 2
		new Object[] {"Self Heal III", new StaveSelfHealSpell(6, 0.65), "Heals self for 65% of the stave's damage"},
		new Object[] {"Self Heal IV", new StaveSelfHealSpell(6, 0.75), "Heals self for 75% of the stave's damage"},
		new Object[] {"Party Heal III", new StavePartyHealSpell(7, 0.4), "Heals all party members for 40% of the stave's damage"},
		new Object[] {"Party Heal IV", new StavePartyHealSpell(7, 0.5), "Heals all party members for 50% of the stave's damage"},
		new Object[] {"Bless II", new StaveBlessSpell(10, 0.3, 5), "Increases the damage of all party members by 30% for 5 seconds"}, 
		new Object[] {"Bless III", new StaveBlessSpell(10, 0.4, 6), "Increases the damage of all party members by 40% for 6 seconds"},
		new Object[] {"Intervention I", new StaveInterventionSpell(10, 0, 3), "Prevents all party members from being damaged for 3 seconds"}, 
		//Tier 3
		new Object[] {"Self Heal V", new StaveSelfHealSpell(5, 1.25), "Heals self for 125% of the stave's damage"},
		new Object[] {"Self Heal VI", new StaveSelfHealSpell(3, 1.60), "Heals self for 160% of the stave's damage"},
		new Object[] {"Party Heal V", new StavePartyHealSpell(6, 0.9), "Heals all party members for 90% of the stave's damage"},
		new Object[] {"Party Heal VI", new StavePartyHealSpell(5, 1.0), "Heals all party members for 100% of the stave's damage"},
		new Object[] {"Bless IV", new StaveBlessSpell(10, 0.5, 7), "Increases the damage of all party members by 50% for 7 seconds"}, 
		new Object[] {"Bless V", new StaveBlessSpell(10, 0.6, 8), "Increases the damage of all party members by 60% for 8 seconds"}, 
		new Object[] {"Intervention II", new StaveInterventionSpell(10, 0, 4), "Prevents all party members from being damaged for 4 seconds"},
		new Object[] {"Intervention III", new StaveInterventionSpell(10, 0, 5), "Prevents all party members from being damaged for 5 seconds"},
		/* Sword Spells */
		//Tier 1
		new Object[] {"Power Strike I", new SwordPowerStrikeSpell(3, 1.2), "Strikes powerfully on the next attack to deal 120% damage"},
		new Object[] {"Charge I", new SwordChargeSpell(15, 0), "Immediately dash forward (best used mid-jump)"},
		new Object[] {"Focus I", new SwordFocusSpell(30, 0.1, 10), "Enter a state of intense concentration for 10 seconds to deal a bonus 10% damage every attack"},
		new Object[] {"Focus II", new SwordFocusSpell(30, 0.1, 15), "Enter a state of intense concentration for 15 seconds to deal a bonus 10% damage every attack"},
		new Object[] {"Cleave I", new SwordCleaveSpell(15, 0.15, 3000), "Cuts through armor on the next attack to deal an extra 10% of the target's maximum health for a maximum of 3000 damage"},
		//Tier 2
		new Object[] {"Power Strike II", new SwordPowerStrikeSpell(3, 1.5), "Strikes powerfully on the next attack to deal 150% damage"},
		new Object[] {"Charge II", new SwordChargeSpell(7, 0), "Immediately dash forward (best used mid-jump)"},
		new Object[] {"Judgement I", new SwordJudgementSpell(60, 1.5, 10), "Instantly deals 150% damage to all enemies less than 10 blocks away"},
		new Object[] {"Focus III", new SwordFocusSpell(30, 0.15, 20), "Enter a state of intense concentration for 20 seconds to deal a bonus 15% damage every attack"},
		new Object[] {"Cleave II", new SwordCleaveSpell(15, 0.15, 15000), "Cuts through armor on the next attack to deal an extra 15% of the target's maximum health for a maximum of 15000 damage"},
		//Tier 3
		new Object[] {"Power Strike III", new SwordPowerStrikeSpell(3, 2), "Strikes powerfully on the next attack to deal 200% damage"},
		new Object[] {"Power Strike IV", new SwordPowerStrikeSpell(3, 2.5), "Strikes powerfully on the next attack to deal 250% damage"},
		new Object[] {"Charge III", new SwordChargeSpell(3, 0), "Immediately dash forward (best used mid-jump)"},
		new Object[] {"Judgement II", new SwordJudgementSpell(60, 2, 15), "Instantly deals 200% damage to all enemies less than 15 blocks away"},
		new Object[] {"Judgement III", new SwordJudgementSpell(60, 2.5, 20), "Instantly deals 250% damage to all enemies less than 20 blocks away"},
		new Object[] {"Focus IV", new SwordFocusSpell(30, 0.2, 25), "Enter a state of intense concentration for 25 seconds to deal a bonus 20% damage every attack"},
		new Object[] {"Focus V", new SwordFocusSpell(30, 0.3, 25), "Enter a state of intense concentration for 25 seconds to deal a bonus 30% damage every attack"},
		new Object[] {"Cleave III", new SwordCleaveSpell(15, 0.25, 35000), "Cuts through armor on the next attack to deal an extra 25% of the target's maximum health for a maximum of 35000 damage"},
		new Object[] {"Cleave IV", new SwordCleaveSpell(15, 0.20, 70000), "Cuts through armor on the next attack to deal an extra 20% of the target's maximum health for a maximum of 70000 damage"},
		/* Axe Spells */
		//Tier 1
		new Object[] {"Wild Swing I", new AxeWildSwingSpell(6, 1.4, 0.3), "Deal 140% damage on the next hit but receive 30% damage in return"},
		new Object[] {"Wild Swing II", new AxeWildSwingSpell(6, 1.8, 0.3), "Deal 180% damage on the next hit but receive 30% damage in return"},
		new Object[] {"Sacrifice I", new AxeSacrificeSpell(10, 0.3), "Instantly convert 30% of current health to damage on the next hit"},
		new Object[] {"Blood Call I", new AxeBloodCallSpell(30, 8, 15), "Gain 8% Lifesteal for 15 seconds"},
		//Tier 2
		new Object[] {"Wild Swing III", new AxeWildSwingSpell(6, 2.2, 0.5), "Deal 220% damage on the next hit but receive 50% damage in return"},
		new Object[] {"Wild Swing IV", new AxeWildSwingSpell(6, 2.5, 0.5), "Deal 250% damage on the next hit but receive 50% damage in return"},
		new Object[] {"Sacrifice II", new AxeSacrificeSpell(10, 0.4), "Instantly convert 40% of current health to damage on the next hit"},
		new Object[] {"Blood Call II", new AxeBloodCallSpell(30, 14, 20), "Gain 14% Lifesteal for 20 seconds"},
		//Tier 3
		new Object[] {"Wild Swing V", new AxeWildSwingSpell(6, 3.0, 1.0), "Deal 300% damage on the next hit but receive 100% damage in return"},
		new Object[] {"Wild Swing VI", new AxeWildSwingSpell(6, 3.5, 2.0), "Deal 350% damage on the next hit but receive 200% damage in return"},
		new Object[] {"Wild Swing VII", new AxeWildSwingSpell(6, 4.0, 3.0), "Deal 400% damage on the next hit but receive 300% damage in return"},
		new Object[] {"Sacrifice III", new AxeSacrificeSpell(10, 0.5), "Instantly convert 50% of current health to damage on the next hit"},
		new Object[] {"Sacrifice IV", new AxeSacrificeSpell(10, 0.6), "Instantly convert 60% of current health to damage on the next hit"},
		new Object[] {"Blood Call III", new AxeBloodCallSpell(30, 21, 25), "Gain 21% Lifesteal for 25 seconds"},
		new Object[] {"Blood Call IV", new AxeBloodCallSpell(30, 30, 25), "Gain 30% Lifesteal for 25 seconds"},
		/* Mace Spells */
		//Tier 1
		new Object[] {"Smash I", new MaceSmashSpell(10, 1.2), "Smashes the ground to deal 120% damage to all targets hit by the blast"},
		new Object[] {"Smash II", new MaceSmashSpell(10, 1.3), "Smashes the ground to deal 130% damage to all targets hit by the blast"},
		new Object[] {"Indomitable I", new MaceIndomitableSpell(10, 20, 5), "Reduces all damage taken by 20% for 5 seconds"},
		new Object[] {"Divine Shield I", new MaceDivineShieldSpell(10, 0.3), "30% of the next attack is converted into a shield that absorbs damage"},
		//Tier 2
		new Object[] {"Smash III", new MaceSmashSpell(8, 1.5), "Smashes the ground to deal 150% damage to all targets hit by the blast"},
		new Object[] {"Smash IV", new MaceSmashSpell(8, 1.6), "Smashes the ground to deal 160% damage to all targets hit by the blast"},
		new Object[] {"Indomitable II", new MaceIndomitableSpell(10, 25, 6), "Reduces all damage taken by 25% for 6 seconds"},
		new Object[] {"Indomitable III", new MaceIndomitableSpell(10, 30, 7), "Reduces all damage taken by 30% for 7 seconds"},
		new Object[] {"Divine Shield II", new MaceDivineShieldSpell(8, 0.4), "40% of the next attack is converted into a shield that absorbs damage"},
		new Object[] {"Divine Shield III", new MaceDivineShieldSpell(6, 0.5), "50% of the next attack is converted into a shield that absorbs damage"},
		new Object[] {"Chant of Necessarius I", new MaceChantOfNecessariusSpell(60, 3), "All damage taken in the next 3 seconds is nullified and converted to a shield"},
		//Tier 3
		new Object[] {"Smash V", new MaceSmashSpell(6, 2), "Smashes the ground to deal 200% damage to all targets hit by the blast"},
		new Object[] {"Smash VI", new MaceSmashSpell(6, 2.2), "Smashes the ground to deal 220% damage to all targets hit by the blast"},
		new Object[] {"Indomitable IV", new MaceIndomitableSpell(10, 40, 8), "Reduces all damage taken by 40% for 8 seconds"},
		new Object[] {"Indomitable V", new MaceIndomitableSpell(10, 45, 9), "Reduces all damage taken by 45% for 9 seconds"},
		new Object[] {"Divine Shield IV", new MaceDivineShieldSpell(5, 0.6), "60% of the next attack is converted into a shield that absorbs damage"},
		new Object[] {"Divine Shield V", new MaceDivineShieldSpell(5, 0.7), "70% of the next attack is converted into a shield that absorbs damage"},
		new Object[] {"Chant of Necessarius II", new MaceChantOfNecessariusSpell(60, 5), "All damage taken in the next 5 seconds is nullified and converted to a shield"},
		/* Wand Spells */
		//Tier 1
		new Object[] {"Fire Bolt I", new WandBoltFireBoltSpell(5, 1.2), "Shoot out a Fire Bolt that deals 120% damage"},
		new Object[] {"Fire Bolt II", new WandBoltFireBoltSpell(5, 1.5), "Shoot out a Fire Bolt that deals 150% damage"},
		new Object[] {"Triple Bolt I", new WandBoltTripleBoltSpell(5, 0.5), "Shoot out a spread of three Magic Bolts that deal 50% damage each"},
		new Object[] {"Triple Bolt II", new WandBoltTripleBoltSpell(5, 1.0), "Shoot out a spread of three Magic Bolts that deal 100% damage each"},
		new Object[] {"Magic Burst I", new WandBoltMagicBurstSpell(10, 0.3), "Shoot out Magic Bolts in all directions that deal 30% damage each"},
		new Object[] {"Magic Barrage I", new WandBoltMagicBarrageSpell(15, 0.10, 10), "Shoot out a rapid chain of 10 Magic Bolts that deal 10% damage each"},
		new Object[] {"Fire Aura I", new WandAuraFireAuraSpell(10, 0.07, 1), "Summon a Flame Aura that deals 7% damage per second to all enemies in its radius"},
		new Object[] {"Fire Aura II", new WandAuraFireAuraSpell(10, 0.10, 2), "Summon a Flame Aura that deals 10% damage per second to all enemies in its radius"},
		new Object[] {"Drain Aura I", new WandAuraDrainAuraSpell(10, 0.01, 1), "Summon a Drain Aura that drains 1% damage per second from all enemies in its radius"},
		new Object[] {"Drain Aura II", new WandAuraDrainAuraSpell(10, 0.02, 2), "Summon a Drain Aura that drains 2% damage per second from all enemies in its radius"},
		//Tier 2
		new Object[] {"Fire Bolt III", new WandBoltFireBoltSpell(5, 1.8), "Shoot out a Fire Bolt that deals 180% damage"},
		new Object[] {"Fire Bolt IV", new WandBoltFireBoltSpell(5, 2.5), "Shoot out a Fire Bolt that deals 250% damage"},
		new Object[] {"Triple Bolt III", new WandBoltTripleBoltSpell(5, 1.5), "Shoot out a spread of three Magic Bolts that deal 150% damage each"},
		new Object[] {"Triple Bolt IV", new WandBoltTripleBoltSpell(5, 2.0), "Shoot out a spread of three Magic Bolts that deal 200% damage each"},
		new Object[] {"Magic Burst II", new WandBoltMagicBurstSpell(10, 0.8), "Shoot out Magic Bolts in all directions that deal 80% damage each"},
		new Object[] {"Magic Barrage II", new WandBoltMagicBarrageSpell(15, 0.13, 15), "Shoot out a rapid chain of 15 Magic Bolts that deal 13% damage each"},
		new Object[] {"Magic Barrage III", new WandBoltMagicBarrageSpell(15, 0.17, 20), "Shoot out a rapid chain of 20 Magic Bolts that deal 16% damage each"},
		new Object[] {"Fire Aura III", new WandAuraFireAuraSpell(10, 0.13, 3), "Summon a Flame Aura that deals 13% damage per second to all enemies in its radius"},
		new Object[] {"Fire Aura IV", new WandAuraFireAuraSpell(10, 0.16, 4), "Summon a Flame Aura that deals 16% damage per second to all enemies in its radius"},
		new Object[] {"Drain Aura III", new WandAuraDrainAuraSpell(10, 0.03, 3), "Summon a Drain Aura that drains 3% damage per second from all enemies in its radius"},
		new Object[] {"Drain Aura IV", new WandAuraDrainAuraSpell(10, 0.04, 4), "Summon a Drain Aura that drains 4% damage per second from all enemies in its radius"},
		//Tier 3
		new Object[] {"Fire Bolt V", new WandBoltFireBoltSpell(5, 3.5), "Shoot out a Fire Bolt that deals 350% damage"},
		new Object[] {"Fire Bolt VI", new WandBoltFireBoltSpell(4, 4.0), "Shoot out a Fire Bolt that deals 400% damage"},
		new Object[] {"Triple Bolt V", new WandBoltTripleBoltSpell(5, 2.5), "Shoot out a spread of three Magic Bolts that deal 250% damage each"},
		new Object[] {"Triple Bolt VI", new WandBoltTripleBoltSpell(5, 3.0), "Shoot out a spread of three Magic Bolts that deal 300% damage each"},
		new Object[] {"Magic Burst III", new WandBoltMagicBurstSpell(10, 1.5), "Shoot out Magic Bolts in all directions that deal 150% damage each"},
		new Object[] {"Magic Barrage IV", new WandBoltMagicBarrageSpell(15, 0.19, 25), "Shoot out a rapid chain of 25 Magic Bolts that deal 19% damage each"},
		new Object[] {"Magic Barrage V", new WandBoltMagicBarrageSpell(15, 0.22, 30), "Shoot out a rapid chain of 30 Magic Bolts that deal 22% damage each"},
		new Object[] {"Fire Aura V", new WandAuraFireAuraSpell(10, 0.19, 5), "Summon a Flame Aura that deals 19% damage per second to all enemies in its radius"},
		new Object[] {"Fire Aura VI", new WandAuraFireAuraSpell(10, 0.22, 6), "Summon a Flame Aura that deals 22% damage per second to all enemies in its radius"},
		new Object[] {"Drain Aura V", new WandAuraDrainAuraSpell(10, 0.05, 5), "Summon a Drain Aura that drains 5% damage per second from all enemies in its radius"},
		new Object[] {"Drain Aura VI", new WandAuraDrainAuraSpell(10, 0.06, 6), "Summon a Drain Aura that drains 6% damage per second from all enemies in its radius"},
		/* Bone Spells */
		//Tier 1
		new Object[] {"MMBLARG I", new BoneFallingBlockSpell(10, 1.2, 8), "Summon an avalanche of dirt and stone, dealing 120% damage to all enemies hit"},
		new Object[] {"MMBLARG II", new BoneFallingBlockSpell(9, 1.3, 9), "Summon an avalanche of dirt and stone, dealing 130% damage to all enemies hit"},
		new Object[] {"BOHAAAHA I", new BoneSelfBuffSpell(10, 0, 5, 0, 0), "Instill yourself with the power of the skies, receiving a 5 second boost in speed and jump"},
		new Object[] {"UNNHG I", new BoneJumpSmashSpell(12, 1.4), "Leap into the air and smash into the ground, dealing 140% damage to enemies nearby"},
		new Object[] {"UNNHG II", new BoneJumpSmashSpell(12, 1.5), "Leap into the air and smash into the ground, dealing 150% damage to enemies nearby"},
		//Tier 2
		new Object[] {"MMBLARG III", new BoneFallingBlockSpell(8, 1.4, 10), "Summon an avalanche of dirt and stone, dealing 140% damage to all enemies hit"},
		new Object[] {"MMBLARG IV", new BoneFallingBlockSpell(7, 1.5, 11), "Summon an avalanche of dirt and stone, dealing 150% damage to all enemies hit"},
		new Object[] {"BOHAAAHA II", new BoneSelfBuffSpell(10, 0, 6, 1, 1), "Instill yourself with the power of the skies, receiving a 6 second boost in speed and jump"},
		new Object[] {"BOHAAAHA III", new BoneSelfBuffSpell(10, 0, 7, 1, 1), "Instill yourself with the power of the skies, receiving a 7 second boost in speed and jump"},
		new Object[] {"UNNHG III", new BoneJumpSmashSpell(9, 1.7), "Leap into the air and smash into the ground, dealing 170% damage to enemies nearby"},
		new Object[] {"UNNHG IV", new BoneJumpSmashSpell(9, 1.9), "Leap into the air and smash into the ground, dealing 190% damage to enemies nearby"},
		//Tier 3
		new Object[] {"MMBLARG V", new BoneFallingBlockSpell(6, 1.8, 12), "Summon an avalanche of dirt and stone, dealing 180% damage to all enemies hit"},
		new Object[] {"MMBLARG VI", new BoneFallingBlockSpell(5, 2, 13), "Summon an avalanche of dirt and stone, dealing 200% damage to all enemies hit"},
		new Object[] {"MMBLARG VII", new BoneFallingBlockSpell(5, 2.3, 15), "Summon an avalanche of dirt and stone, dealing 230% damage to all enemies hit"},
		new Object[] {"BOHAAAHA IV", new BoneSelfBuffSpell(10, 0, 8, 2, 2), "Instill yourself with the power of the skies, receiving an 8 second boost in speed and jump"},
		new Object[] {"BOHAAAHA V", new BoneSelfBuffSpell(10, 0, 9, 2, 2), "Instill yourself with the power of the skies, receiving a 9 second boost in speed and jump"},
		new Object[] {"UNNHG V", new BoneJumpSmashSpell(7, 2.2), "Leap into the air and smash into the ground, dealing 220% damage to enemies nearby"},
		new Object[] {"UNNHG VI", new BoneJumpSmashSpell(7, 2.5), "Leap into the air and smash into the ground, dealing 250% damage to enemies nearby"},
	};
	
	public static Object[][] specialSpells = new Object[][] {
		new Object[] {"Spirit Storm", new SpecialSpiritStormSpell(5, 2.50, 50), "Call upon the Spirits to unleash their fury from above."},
	};
	
	public static String getCooldown(String s) {
		Spell spell = getSpell(s);
		if(spell == null) {
			System.out.println("ERROR: Unable to find spell with name " + s);
			return "Cooldown: 600s";
		}
		return "Cooldown: " + spell.cooldownInSec + "s";
	}
	
	public static Spell getSpell(String s) {
		for(Object[] o : spells) {
			if(((String)o[0]).equalsIgnoreCase(s))
				return (Spell)o[1];
		}
		for(Object[] o : specialSpells) {
			if(((String)o[0]).equalsIgnoreCase(s))
				return (Spell)o[1];
		}
		return null;
	}
	
	public static String[] getDescription(String s) {
		String description = "";
		for(Object[] o : spells) {
			if(((String)o[0]).equalsIgnoreCase(s))
				description = (String)o[2];
		}
		for(Object[] o : specialSpells) {
			if(((String)o[0]).equalsIgnoreCase(s))
				description = (String)o[2];
		}
		return Values.stringToLore(description);
	}
	
}