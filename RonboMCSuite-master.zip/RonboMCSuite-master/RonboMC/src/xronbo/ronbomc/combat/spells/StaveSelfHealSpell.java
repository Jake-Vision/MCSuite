package xronbo.ronbomc.combat.spells;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;


public class StaveSelfHealSpell extends Spell {
	
	public StaveSelfHealSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You quickly heal yourself.";
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		try {
			pd.heal((int)(spellValue * CombatHandler.rollDamage(pd)));
		} catch(Exception e) {
			
		}
	}
	
}