package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.SoundHandler;

public abstract class Spell {
	
	public static RonboMC plugin;
	
	public int[] valueRange;
	public long cooldown; //in nanoseconds
	public double cooldownInSec;
	public Double spellValue;
	public String onActivate;
	public Sound sound;
	
	public Spell(int cooldownInSec, final double spellValue) {
		this.cooldownInSec = cooldownInSec;
		this.cooldown = convertSecondsToNano(cooldownInSec);
		this.spellValue = spellValue;
	}
	
	public static long convertSecondsToNano(double i) {
		return ((long)i) * 1000000000;
	}
	
	public static int convertSecondsToTicks(double i) {
		return (int)(i * 20);
	}
	
	public void castSpell(PlayerInteractEvent e) {
		PlayerData pd = plugin.getPD(e.getPlayer());
		pd.makeVisible();
		if(pd.canCastSpell()) {
			if(sound != null)
				SoundHandler.playSound(pd.player, sound);
			int cdMult = pd.checkSpellCooldownMultiplier();
			double spV = spellValue;
			if(cdMult == 2) {
				e.getPlayer().sendMessage(ChatColor.RED + "Because the weapon you used isn't your Class Specialty, the cooldown is 2x longer and the spell is weaker.");
				spV /= 3;
			}
			if(cdMult == 3) {
				e.getPlayer().sendMessage(ChatColor.RED + "Because the weapon you used is your Class Weakness, the cooldown is 3x longer and the spell is weaker.");
				spV /= 4;
			}
			handleSpell(e, spV);
			pd.registerCooldown(cooldown * cdMult, false);
			if(onActivate != null && !onActivate.equals("")) {
				e.getPlayer().sendMessage(ChatColor.ITALIC + onActivate);
			}
		} else {
			double i = pd.getRemainingCooldownInSeconds();
			if(i < 1)
				i = 1;
			e.getPlayer().sendMessage(ChatColor.RED + "You cannot cast another spell for " + String.format("%.1f", i) + " seconds.");
		}
	}
	
	abstract void handleSpell(PlayerInteractEvent e, final Double spellValue);
	
	
	public int rollValue() {
		if(valueRange.length != 2) {
			return 0;
		} else {
			return ((int)(Math.random() * valueRange[1] + (valueRange[1] - valueRange[0])));
		}
	}
	
	public String toString() {
		return this.getClass().getName();
	}
	
}