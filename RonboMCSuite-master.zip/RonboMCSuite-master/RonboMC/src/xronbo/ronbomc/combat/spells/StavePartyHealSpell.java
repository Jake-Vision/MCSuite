package xronbo.ronbomc.combat.spells;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;


public class StavePartyHealSpell extends Spell {
	
	public StavePartyHealSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You heal all the members of your party.";
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		if(pd.party == null) {
			p.sendMessage("You are not in a party, so you heal yourself instead!");
			int healValue = (int)(spellValue * CombatHandler.rollDamage(pd));
			pd.heal(healValue);
			return;
		}
		try {
			int healValue = (int)(spellValue * CombatHandler.rollDamage(pd));
			for(final Player p2 : pd.party.getMembers()) {
				plugin.getPD(p2).heal(healValue);
				if(p2 != p)
					p2.sendMessage("You have been healed by " + p.getName() + ".");
			}
		} catch(Exception e) {
			
		}
	}
	
}