package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;

public class AxeBloodCallSpell extends Spell {
	
	public int durationTicks;
	
	public AxeBloodCallSpell(int cooldownInSeconds, double d, int duration) {
		super(cooldownInSeconds, d);
		onActivate = "You feel a sudden thirst for blood.";
		sound = Sound.ENDERDRAGON_GROWL;
		durationTicks = convertSecondsToTicks(duration);
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.lifesteal_buff += spellValue;
		pd.updateArmorStats();
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.lifesteal_buff -= spellValue;
				pd.updateArmorStats();
				pd.player.sendMessage("You have quenched your thirst for blood.");
			}
		}, durationTicks);
	}
	
}