package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class AxeWildSwingSpell extends Spell {
	
	public double recoil;
	
	public AxeWildSwingSpell(int cooldownInSeconds, double d, double recoil) {
		super(cooldownInSeconds, d);
		onActivate = "You feel a surge of wildness flow towards your weapon.";
		this.recoil = recoil;
		sound = Sound.WITHER_SHOOT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.wildSwing_buff = true;
		pd.wildSwingMultiplier_buff = spellValue;
		pd.wildSwingRecoil_buff = recoil;
	}
	
}