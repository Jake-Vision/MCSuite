package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class MaceIndomitableSpell extends Spell {
	
	public int durationTicks;
	
	public MaceIndomitableSpell(int cooldownInSeconds, double d, int durationInSeconds) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationInSeconds);
		onActivate = "You ready yourself for all incoming attacks...";
		sound = Sound.AMBIENCE_THUNDER;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.indomitable_buff = true;
		pd.indomitableValue_buff = spellValue.intValue();
		pd.updateArmorStats();
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(pd != null) {
					pd.indomitable_buff = false;
					pd.updateArmorStats();
					pd.player.sendMessage(ChatColor.ITALIC + "You feel your damage reduction fading away...");
				}
			}	
		}, durationTicks);
	}
	
}