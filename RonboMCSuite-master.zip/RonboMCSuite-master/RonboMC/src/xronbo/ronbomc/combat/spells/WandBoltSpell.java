package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;
import java.util.HashSet;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.effects.EffectCreator;
import xronbo.ronbomc.effects.EffectHolder;
import xronbo.ronbomc.effects.ParticleDetails;
import xronbo.ronbomc.effects.ParticleType;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.items.ItemData;
import xronbo.ronbomc.items.ItemHandler;

public abstract class WandBoltSpell extends Spell{

	public WandBoltSpell(int cooldownInSec, final double spellValue) {
		super(cooldownInSec, spellValue);
	}
	
	public abstract ParticleType getBoltType(Player p);
	
	public abstract ArrayList<Vector> getVectors(Player p);
	
	public void fireBolt(final int attack, final Player p, final ParticleType pt) {
		int count = 0;
		for(final Vector v : getVectors(p)) {
			if(getDelay(p) > 1) {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						shootBolt(attack, v, p, pt);
					}
				}, getDelay(p) * count);
			} else {
				shootBolt(attack, v, p, pt);
			}
			count++;
		}
	}
	
	public int getDelay(Player p) {
		return 1;
	}
	
	public void shootBolt(final int attack, final Vector v, final Player p, final ParticleType pt) {
		final ArrayList<Integer> tasks = new ArrayList<Integer>();
		final ArrayList<Location> boltLocs = new ArrayList<Location>();
		final PlayerData pd = plugin.getPD(p);
		Location loc = p.getEyeLocation();
		SoundHandler.playSound(p, Sound.FIREWORK_LAUNCH);
		for(int k = 0; k < Values.WAND_RANGE + 10; k++) {
			loc.add(v.toLocation(loc.getWorld()));
			if(MobHandler.isAirlike(loc.getBlock().getType()))
				boltLocs.add(loc.clone());
			else
				break;
		}
		for(int k = 0; k < boltLocs.size(); k+=2) {
			final int current = k;
			tasks.add(SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					Location loc = boltLocs.get(current);
					HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
					particles.add(new ParticleDetails(pt));
					EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
					holder.setRunning(true);
					holder.update();
					holder.setRunning(false);
					Entity e = loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
					Entity e3 = null;
					if(current + 1 < boltLocs.size())
						e3 = loc.getWorld().spawnEntity(boltLocs.get(current + 1), EntityType.FIREWORK);
					for(Entity e2 : (e3 != null ? e3 : e).getNearbyEntities(1, 1, 1)) {
						if(e2 instanceof LivingEntity && e2 != p) {
							LivingEntity le = (LivingEntity)e2;
							int damageValue = (int)(CombatHandler.rollDamage(attack, pd) * spellValue);
							int originalValue = damageValue;
							if(damageValue < 1)
								damageValue = 1;
							boolean hit = false;
							if(le instanceof Player) {
								if(plugin.getPD((Player)le).damage(damageValue, p, true, 0.5)) {
									plugin.db(p, "Spell changed DMG - [" + originalValue + " -> " + damageValue + "]");
									hit = true;
								}
							} else {
								MobData md = MobHandler.spawnedMobs.get(le.getUniqueId());
								if(md != null) {
									if(md.damage(damageValue, p, true, 0.5)) {
										plugin.db(p, "Spell changed DMG - [" + originalValue + " -> " + damageValue  + "]");
										hit = true;
									}
								}
							}
							if(hit)
								for(Integer i : tasks)
									plugin.getServer().getScheduler().cancelTask(i);
						}
					}
					e.remove();
					if(e3 != null)
						e3.remove();
				}
			}, k * 1));
		}
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player player = event.getPlayer();
		ItemData id = ItemHandler.items.get(player.getItemInHand());
		if(id == null) {
			if(ItemHandler.loadItem(player.getItemInHand())) {
				id = ItemHandler.items.get(player.getItemInHand());
			}
		}
		fireBolt(plugin.getPD(event.getPlayer()).attack, event.getPlayer(), getBoltType(event.getPlayer()));
	}
	
}
