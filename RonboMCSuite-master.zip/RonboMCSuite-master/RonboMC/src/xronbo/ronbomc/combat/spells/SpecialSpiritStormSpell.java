package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;


public class SpecialSpiritStormSpell extends Spell {
	
	public int range;
	
	public SpecialSpiritStormSpell(int cooldownInSeconds, double d, int range) {
		super(cooldownInSeconds, d);
		onActivate = "Bolts of lightning rush down from the skies to destroy your enemies.";
		this.range = range;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		p.playSound(p.getLocation(), Sound.EXPLODE, 20, 1);
		for(Entity e : p.getNearbyEntities(range, range, range)) {
			try {
				int damageValue = (int)(spellValue * CombatHandler.rollDamage(pd));
				if(e instanceof Player) {
					PlayerData pd2 = plugin.getPD((Player)e);
					pd2.damage(damageValue, p, true);
					p.getWorld().strikeLightning(e.getLocation());
					p.getWorld().strikeLightning(e.getLocation());
					p.getWorld().strikeLightning(e.getLocation());
				} else {
					MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
					if(md != null) {
						md.damage(damageValue, p, true);
						p.getWorld().strikeLightning(e.getLocation());
						p.getWorld().strikeLightning(e.getLocation());
						p.getWorld().strikeLightning(e.getLocation());
					}
				}
			} catch(Exception exception) {
				//this will occur often, since many entities have no health values
			}
		}
	}
	
}