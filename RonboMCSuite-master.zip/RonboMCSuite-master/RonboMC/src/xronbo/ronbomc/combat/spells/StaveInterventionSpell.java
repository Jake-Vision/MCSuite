package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.debug.SuperDebugger;


public class StaveInterventionSpell extends Spell {
	
	public int durationTicks;
	
	public StaveInterventionSpell(int cooldownInSeconds, double d, int durationInSec) {
		super(cooldownInSeconds, d);
		onActivate = "You cast Intervention everyone in your party.";
		durationTicks = convertSecondsToTicks(durationInSec);
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		if(pd.party == null) {
			p.sendMessage("You are not in a party, so you cast Intervention on yourself instead!");
			if(System.currentTimeMillis() - pd.lastIntervention < 10000) {
				pd.player.sendMessage(ChatColor.RED + "Intervention was not cast on you because it can only be activated for a player once every 10 seconds.");
			} else {
				pd.intervention_buff = true;
				pd.lastIntervention = System.currentTimeMillis();
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						pd.intervention_buff = false;
						SoundHandler.playSound(p, Sound.AMBIENCE_RAIN);
						p.sendMessage("You sense the Intervention wearing off.");
					}
				}, durationTicks);
			}
			return;
		}
		try {
			for(final Player p2 : pd.party.getMembers()) {
				final PlayerData pd2 = plugin.getPD(p2);
				if(System.currentTimeMillis() - pd2.lastIntervention < 10000) {
					pd2.player.sendMessage(ChatColor.RED + "Intervention was not cast on you because it can only be activated for a player once every 10 seconds.");
				} else {
					pd2.intervention_buff = true;
					pd2.lastIntervention = System.currentTimeMillis();
					SoundHandler.playSound(p2, Sound.AMBIENCE_RAIN);
					if(p2 != p) {
						p2.sendMessage("You feel an Intervention preventing you from taking any damage!");
					}
					SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
						public void run() {
							pd2.intervention_buff = false;
							p2.sendMessage("You sense the Intervention wearing off.");
						}
					}, durationTicks);
				}
			}
		} catch(Exception e) {
			
		}
	}
	
}