package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class DaggerDisableSpell extends Spell {
	
	public DaggerDisableSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You ready your next attack to be strong enough to disable HP Regeneration.";
		sound = Sound.IRONGOLEM_HIT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.disable_buff = true;
		pd.disableDuration_buff = convertSecondsToTicks(spellValue.intValue());
	}
	
}