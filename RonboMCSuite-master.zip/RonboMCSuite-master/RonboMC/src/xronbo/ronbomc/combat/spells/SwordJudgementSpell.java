package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.regions.RegionHandler;


public class SwordJudgementSpell extends Spell {
	
	public int range;
	
	public SwordJudgementSpell(int cooldownInSeconds, double d, int range) {
		super(cooldownInSeconds, d);
		onActivate = "Judgement has fallen upon those around you.";
		this.range = range;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		boolean pvp = RegionHandler.getRegion(p.getLocation()).type.equals("perilous");
		p.playSound(p.getLocation(), Sound.EXPLODE, 20, 1);
		for(Entity e : p.getNearbyEntities(range, range, range)) {
			try {
				int damageValue = (int)(spellValue * CombatHandler.rollDamage(pd));
				if(pvp && e instanceof Player) {
					PlayerData pd2 = plugin.getPD((Player)e);
					pd2.damage(damageValue, p, true);
					p.getWorld().strikeLightning(e.getLocation());
				} else {
					MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
					if(md != null) {
						md.damage(damageValue, p, true);
						p.getWorld().strikeLightning(e.getLocation());
					}
				}
			} catch(Exception exception) {
				//this will occur often, since many entities have no health values
			}
		}
	}
	
}