package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.BlockIterator;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class DaggerAmbushSpell extends Spell {
	
	public int durationTicks;
	public int numHits;
	
	public DaggerAmbushSpell(int cooldownInSeconds, double d, int durationSec, int numHits) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationSec);
		this.numHits = numHits;
		onActivate = "You teleport through the shadows and remain hidden, ready to strike.";
		sound = Sound.WITHER_SHOOT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		p.getWorld().playEffect(p.getLocation(), Effect.SMALL_SMOKE, 1);
		final PlayerData pd = plugin.getPD(p);
		pd.makeInvisible(durationTicks);
		pd.ambush_buff = true;
		pd.ambushMultiplier_buff = spellValue;
		pd.ambushHits_buff = numHits;
		
		BlockIterator bi = new BlockIterator(p, 100);
		Block b = null;
		while(bi.hasNext()) {
			b = bi.next();
			if(b.getType() != Material.AIR)
				break;
		}
		if(b != null && b.getType() != Material.AIR) {
			Location loc = b.getLocation().setDirection(p.getLocation().getDirection()).add(0.5, 1, 0.5);
			int count = 0;
			while(loc.getBlock().getType() != Material.AIR) {
				loc.add(0,1,0);
				count++;
				if(count > 30)
					break;
			}
			if(count > 30)
				p.sendMessage(ChatColor.RED + "You fail to teleport, but turn invisible nevertheless. You cannot teleport up that high!");
			else {
				pd.allowedToTeleport = true;
				p.teleport(loc);
				pd.allowedToTeleport = false;
			}
		} else {
			p.sendMessage(ChatColor.RED + "You fail to teleport, but turn invisible nevertheless. You can only teleport within 100 blocks!");
		}
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.makeVisible();
			}
		}, durationTicks);
	}
	
}