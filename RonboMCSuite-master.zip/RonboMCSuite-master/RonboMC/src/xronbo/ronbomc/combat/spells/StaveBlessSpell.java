package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.debug.SuperDebugger;


public class StaveBlessSpell extends Spell {
	
	public int durationTicks;
	
	public StaveBlessSpell(int cooldownInSeconds, double d, int durationInSec) {
		super(cooldownInSeconds, d);
		onActivate = "You bless everyone in your party.";
		durationTicks = convertSecondsToTicks(durationInSec);
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		if(pd.party == null) {
			p.sendMessage("You are not in a party, so you bless yourself instead!");
			pd.bless_buff = true;
			pd.blessMultiplier_buff = spellValue;
			SoundHandler.playSound(p, Sound.AMBIENCE_RAIN);
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					pd.bless_buff = false;
					pd.blessMultiplier_buff = 0;
					p.sendMessage("Your Bless is wearing off.");
				}
			}, durationTicks);
			return;
		}
		try {
			for(final Player p2 : pd.party.getMembers()) {
				final PlayerData pd2 = plugin.getPD(p2);
				pd2.bless_buff = true;
				pd2.blessMultiplier_buff = spellValue;
				SoundHandler.playSound(p2, Sound.AMBIENCE_RAIN);
				if(p != p2)
					p2.sendMessage("You have been Blessed to deal more damage!");
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						pd2.bless_buff = false;
						pd2.blessMultiplier_buff = 0;
						if(p != p2)
							p2.sendMessage("Your Bless is wearing off.");
					}
				}, durationTicks);
			}
		} catch(Exception e) {
			
		}
	}
	
}