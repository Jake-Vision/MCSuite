package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class DaggerPunctureSpell extends Spell {

	public int maxDamage;
	
	public DaggerPunctureSpell(int cooldownInSeconds, double d, int maxDamage) {
		super(cooldownInSeconds, d);
		this.maxDamage = maxDamage;
		onActivate = "You quickly sharpen your dagger to a deadly sharp point.";
		sound = Sound.IRONGOLEM_HIT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.puncture_buff = true;
		pd.punctureMultiplier_buff = spellValue;
		pd.punctureMaxDamage_buff = maxDamage;
	}
	
}