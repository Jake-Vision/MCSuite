package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class MaceDivineShieldSpell extends Spell {
	
	public MaceDivineShieldSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You prepare for an attack blessed by divine spirits.";
		sound = Sound.WITHER_SPAWN;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.divineShield_buff = true;
		pd.divineShieldMultiplier_buff = spellValue;
	}
	
}