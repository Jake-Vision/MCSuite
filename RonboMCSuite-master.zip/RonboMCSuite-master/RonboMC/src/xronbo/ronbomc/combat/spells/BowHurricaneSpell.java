package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Projectile;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;

import xronbo.ronbomc.SoundHandler;
import xronbo.ronbomc.debug.SuperDebugger;


public class BowHurricaneSpell extends Spell {
	
	public int numberOfArrows;
	
	public BowHurricaneSpell(int cooldownInSeconds, double d, int numArrows) {
		super(cooldownInSeconds, d);
		onActivate = "A hurricane of arrows begins flying out from your bow.";
		numberOfArrows = numArrows;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		for(int k = 0; k < numberOfArrows; k++) {
			final int temp = k;
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					if(temp % 5 == 0) {
						SoundHandler.playSound(event.getPlayer(), Sound.SHOOT_ARROW);
					}
					Projectile p = plugin.getPD(event.getPlayer()).shootArrow();
					p.setMetadata("damageMultiplier", new FixedMetadataValue(plugin, spellValue));
				}	
			}, k * 3);
		}
	}
	
}