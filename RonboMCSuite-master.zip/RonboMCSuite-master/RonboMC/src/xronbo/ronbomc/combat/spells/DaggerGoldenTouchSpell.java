package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class DaggerGoldenTouchSpell extends Spell {
	
	public DaggerGoldenTouchSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You suddenly have a feeling that your next attack will get you some gold.";
		sound = Sound.ORB_PICKUP;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.goldenTouch_buff = true;
		pd.goldenTouchMultiplier_buff = spellValue;
	}
	
}