package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class DaggerSneakAttackSpell extends Spell {
	
	public int durationTicks;
	
	public DaggerSneakAttackSpell(int cooldownInSeconds, double d, int durationSec) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationSec);
		onActivate = "You shift into the shadows, and prepare for a deadly sneak attack.";
		sound = Sound.CAT_HISS;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.makeInvisible(durationTicks);
		pd.sneakAttack_buff = true;
		pd.sneakAttackMultipler_buff = spellValue;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.makeVisible();
			}
		}, durationTicks);
	}
	
}