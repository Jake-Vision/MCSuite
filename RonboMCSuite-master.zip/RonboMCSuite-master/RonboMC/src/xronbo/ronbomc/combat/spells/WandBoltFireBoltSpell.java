package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import xronbo.ronbomc.effects.ParticleType;

public class WandBoltFireBoltSpell extends WandBoltSpell{

	public WandBoltFireBoltSpell(int cooldownInSec, final double spellValue) {
		super(cooldownInSec, spellValue);
		onActivate = "You shoot out a bolt of fire.";
	}
	
	public ParticleType getBoltType(Player p) {
		return ParticleType.FIRE;
	}
	
	public ArrayList<Vector> getVectors(Player p) {
		ArrayList<Vector> vectors = new ArrayList<Vector>();
		Vector v = p.getEyeLocation().getDirection();
		vectors.add(v);
		return vectors;
	}
	
}
