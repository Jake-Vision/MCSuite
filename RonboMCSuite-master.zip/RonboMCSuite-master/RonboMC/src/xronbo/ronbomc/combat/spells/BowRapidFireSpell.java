package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class BowRapidFireSpell extends Spell {
	
	public int numberOfArrows;
	public int durationTicks;
	
	public BowRapidFireSpell(int cooldownInSeconds, double d, int durationInSeconds) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationInSeconds);
		onActivate = "You feel energized and suddenly begin to fire your bow faster.";
		sound = Sound.WITHER_IDLE;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.shootingSpeed_buff = spellValue.intValue();
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(pd != null) {
					pd.shootingSpeed_buff = 1;
					pd.player.sendMessage(ChatColor.ITALIC + "You feel your shooting speed slow down...");
				}
			}	
		}, durationTicks);
	}
	
}