package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class BowHawkeyeSpell extends Spell {
	
	public int numberOfArrows;
	public int durationTicks;
	
	public BowHawkeyeSpell(int cooldownInSeconds, double d, int durationInSeconds) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationInSeconds);
		onActivate = "The blessing of Hawkeye descends upon you, increasing your critical chance rate.";
		sound = Sound.WITHER_IDLE;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.critChance_buff += spellValue;
		pd.updateArmorStats();
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(pd != null) {
					pd.critChance_buff -= spellValue;
					if(pd.critChance_buff < 0)
						pd.critChance_buff = 0;
					pd.updateArmorStats();
					pd.player.sendMessage(ChatColor.ITALIC + "You feel the blessing of Hawkeye fading away...");
				}
			}	
		}, durationTicks);
	}
	
}