package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class SwordCleaveSpell extends Spell {
	
	public int maxDamage;
	
	public SwordCleaveSpell(int cooldownInSeconds, double d, int maxDamage) {
		super(cooldownInSeconds, d);
		this.maxDamage = maxDamage;
		onActivate = "You prepare to cleave your enemy on the next attack.";
		sound = Sound.ZOMBIE_METAL;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.cleave_buff = true;
		pd.cleaveMultiplier_buff = spellValue;
		pd.cleaveMaxDamage_buff = maxDamage;
	}
	
}