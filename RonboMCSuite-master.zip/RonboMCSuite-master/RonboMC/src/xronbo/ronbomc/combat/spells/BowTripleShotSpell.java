package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Projectile;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;

import xronbo.ronbomc.debug.SuperDebugger;


public class BowTripleShotSpell extends Spell {
	
	public BowTripleShotSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You quickly shoot three arrows from your bow.";
		sound = Sound.SHOOT_ARROW;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		for(int k = 0; k < 3; k++) {
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					Projectile p = plugin.getPD(event.getPlayer()).shootArrow();
					p.setMetadata("damageMultiplier", new FixedMetadataValue(plugin, spellValue));
				}	
			}, k * 3);
		}
	}
	
}