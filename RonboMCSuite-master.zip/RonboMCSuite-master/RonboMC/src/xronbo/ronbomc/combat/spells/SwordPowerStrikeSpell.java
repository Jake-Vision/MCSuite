package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class SwordPowerStrikeSpell extends Spell {
	
	public SwordPowerStrikeSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You prepare for a powerful strike on your next attack.";
		sound = Sound.IRONGOLEM_HIT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.powerStrike_buff = true;
		pd.powerStrikeMultiplier_buff = spellValue;
	}
	
}