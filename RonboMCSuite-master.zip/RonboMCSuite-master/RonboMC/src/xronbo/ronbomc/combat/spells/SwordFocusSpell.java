package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class SwordFocusSpell extends Spell {
	
	public int durationTicks;
	
	public SwordFocusSpell(int cooldownInSeconds, double d, int duration) {
		super(cooldownInSeconds, d);
		onActivate = "You become incredibly focused.";
		durationTicks = convertSecondsToTicks(duration);
		sound = Sound.WITHER_IDLE;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.focus_buff = true;
		pd.focusMultiplier_buff = spellValue;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.focus_buff = false;
				pd.focusMultiplier_buff = 0;
				pd.player.sendMessage("You feel less focused than before.");
			}
		}, durationTicks);
	}
	
}