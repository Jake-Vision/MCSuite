package xronbo.ronbomc.combat.spells;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;


public class MaceSmashSpell extends Spell {
	
	public MaceSmashSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You smash the ground at your feet with a powerful blow.";
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Location loc = event.getPlayer().getLocation();
		loc.getWorld().createExplosion(loc.getX(), loc.getY(), loc.getZ(), 4, false, false);
		for(Entity e : event.getPlayer().getNearbyEntities(5, 5, 5)) {
			try {
				int damageValue = (int)(spellValue * CombatHandler.rollDamage(event.getPlayer()));
				if(e instanceof Player) {
					PlayerData pd2 = plugin.getPD((Player)e);
					pd2.damage(damageValue, event.getPlayer(), true);
				} else {
					MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
					if(md != null) {
						md.damage(damageValue, event.getPlayer(), true);
					}
				}
			} catch(Exception exception) {
				//this will occur often, since many entities have no health values
			}
		}
	}
	
}