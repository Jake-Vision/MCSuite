package xronbo.ronbomc.combat.spells;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;

public class WandAuraDrainAuraSpell extends WandAuraSpell {
	
	public WandAuraDrainAuraSpell(int cooldownInSeconds, double d, int tier) {
		super(cooldownInSeconds, d);
		onActivate = "You activate your Drain Aura.";
		this.tier = tier;
	}

	public void applyAuraEffect(LivingEntity le, PlayerInteractEvent event) {
		int damageValue = (int)(spellValue * CombatHandler.rollDamage(event.getPlayer()));
		if(damageValue < 1)
			damageValue = 1;
		if(le instanceof Player) {
			if(plugin.getPD((Player)le).damage(damageValue, event.getPlayer(), true, 0.2))
				plugin.getPD(event.getPlayer()).heal(damageValue);
		} else {
			MobData md = MobHandler.spawnedMobs.get(le.getUniqueId());
			if(md != null) {
				if(md.damage(damageValue, event.getPlayer(), true, 0.2))
					plugin.getPD(event.getPlayer()).heal(damageValue);
			}
		}
	}
	
}