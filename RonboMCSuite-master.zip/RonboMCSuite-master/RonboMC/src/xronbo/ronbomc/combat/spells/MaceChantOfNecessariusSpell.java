package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class MaceChantOfNecessariusSpell extends Spell {
	
	public int durationTicks;
	
	public MaceChantOfNecessariusSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You begin reciting the Chant of Necessarius, and feel the world warping around you...";
		durationTicks = convertSecondsToTicks((int)d);
		sound = Sound.ENDERDRAGON_DEATH;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.chantOfNecessarius_buff = true;
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.chantOfNecessarius_buff = false;
				p.sendMessage(ChatColor.ITALIC + "You finish your chant and gain a shield of " + pd.chantOfNecessariusValue_buff + ".");
				pd.addShield(pd.chantOfNecessariusValue_buff);
				plugin.db(p, "Shield value is now " + pd.shield);
			}
		}, durationTicks);
	}
	
}