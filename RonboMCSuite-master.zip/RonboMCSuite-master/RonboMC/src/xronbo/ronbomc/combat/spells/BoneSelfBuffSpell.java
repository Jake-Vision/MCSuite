package xronbo.ronbomc.combat.spells;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffectType;

public class BoneSelfBuffSpell extends Spell {
	
	public int speed,jump;
	public int durationSec;
	
	public BoneSelfBuffSpell(int cooldownInSeconds, double d, int durationSec, int speed, int jump) {
		super(cooldownInSeconds, d);
		onActivate = "BOHAAAHA!!!!!";
		this.speed = speed;
		this.jump = jump;
		this.durationSec = durationSec;
	}
	
	public Material[] materials = {Material.DIRT, Material.STONE, Material.COBBLESTONE};
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final Player p = event.getPlayer();
		p.getWorld().strikeLightningEffect(p.getLocation());
		p.addPotionEffect(PotionEffectType.SPEED.createEffect(durationSec * 20, speed));
		p.addPotionEffect(PotionEffectType.JUMP.createEffect(durationSec * 20, jump));
	}
	
}