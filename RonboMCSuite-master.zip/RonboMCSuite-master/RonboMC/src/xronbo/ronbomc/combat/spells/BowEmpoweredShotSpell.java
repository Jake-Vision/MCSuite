package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Projectile;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;


public class BowEmpoweredShotSpell extends Spell {
	
	public BowEmpoweredShotSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "A powerful arrow is shot from your bow.";
		sound = Sound.SHOOT_ARROW;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Projectile p = plugin.getPD(event.getPlayer()).shootArrow();
		p.setMetadata("damageMultiplier", new FixedMetadataValue(plugin, spellValue));
	}
	
}