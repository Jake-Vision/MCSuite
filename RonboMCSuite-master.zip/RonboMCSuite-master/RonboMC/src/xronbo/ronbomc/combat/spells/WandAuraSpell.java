package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;

import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;
import xronbo.ronbomc.debug.SuperDebugger;

public abstract class WandAuraSpell extends Spell{

	public int tier = 0;
	
	public WandAuraSpell(int cooldownInSec, final double spellValue) {
		super(cooldownInSec, spellValue);
		sound = Sound.WITHER_IDLE;
	}
	
	public abstract void applyAuraEffect(final LivingEntity le, final PlayerInteractEvent event);
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		final int taskId = SuperDebugger.scheduleSyncRepeatingTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				if(event.getPlayer() == null || !event.getPlayer().isOnline())
					return;
				for(LivingEntity le : getNearby(event.getPlayer())) {
					applyAuraEffect(le, event);
				}
			}
		}, 0, 20);
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				plugin.getServer().getScheduler().cancelTask(taskId);
			}
		}, 20 * 10);
	}

	public ArrayList<LivingEntity> getNearby(Player p) {
		int range = 0;
		switch(tier) {
			case 1:
				range = 3;
				break;
			case 2:
				range = 4;
				break;
			case 3:
				range = 5;
				break;
			case 4:
				range = 6;
				break;
			case 5:
				range = 8;
				break;
			case 6:
				range = 10;
				break;
		}
		PlayerData pd = plugin.getPD(p);
		if(ClassHandler.getClassType(pd.classType) == ClassType.WIZARD) {
			if(ClassHandler.checkPassive("aura augmentation", pd)) {
				range *= 1.25;
			}
			if(ClassHandler.checkPassive("aura amplification", pd)) {
				range *= 1.5;
			}
			if(ClassHandler.checkPassive("aura awakening", pd)) {
				range *= 1.75;
			}
		}
		ArrayList<LivingEntity> nearbyEntities = new ArrayList<LivingEntity>();
		for(Entity e : p.getNearbyEntities(range, range, range))
			if(e instanceof LivingEntity)
				if(!((LivingEntity)e).isDead())
				nearbyEntities.add((LivingEntity)e);
		return nearbyEntities;
	}
}
