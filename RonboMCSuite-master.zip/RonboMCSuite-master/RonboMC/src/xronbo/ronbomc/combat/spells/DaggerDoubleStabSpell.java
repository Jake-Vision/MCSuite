package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class DaggerDoubleStabSpell extends Spell {
	
	public DaggerDoubleStabSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You ready yourself, prepared to quickly strike twice on your next hit.";
		sound = Sound.PISTON_EXTEND;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.doubleHit_buff = true;
		pd.doubleHitMultiplier_buff = spellValue;
	}
	
}