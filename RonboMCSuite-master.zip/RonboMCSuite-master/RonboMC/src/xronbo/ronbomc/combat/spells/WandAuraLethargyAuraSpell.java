package xronbo.ronbomc.combat.spells;

import org.bukkit.ChatColor;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import xronbo.ronbomc.classes.ClassHandler;
import xronbo.ronbomc.classes.ClassHandler.ClassType;

public class WandAuraLethargyAuraSpell extends WandAuraSpell {
	
	public WandAuraLethargyAuraSpell(int cooldownInSeconds, double d, int tier) {
		super(cooldownInSeconds, d);
		onActivate = "You activate your Lethargy Aura.";
		this.tier = tier;
	}

	public void applyAuraEffect(LivingEntity le, PlayerInteractEvent event) {
		if(le instanceof Player) {
			Player p = (Player)le;
			if(Math.random() < 0.5 && ClassHandler.getClassType(plugin.getPD(p).classType) == ClassType.BARBARIAN && ClassHandler.checkPassive("Willpower", plugin.getPD(p))) {
				p.sendMessage(ChatColor.GOLD + "ROARRRR!! You scream your defiance, and ignore the enemy's slow.");
			} else {
				le.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, tier / 2));
			}
		} else {
			le.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, tier / 2));
		}
	}
	
}