package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import xronbo.ronbomc.effects.ParticleType;

public class WandBoltMagicBurstSpell extends WandBoltSpell{

	public WandBoltMagicBurstSpell(int cooldownInSec, final double spellValue) {
		super(cooldownInSec, spellValue);
		onActivate = "You shoot out a burst of magic bolts.";
	}
	
	public ParticleType getBoltType(Player p) {
		return plugin.getPD(p).getWandEffect();
	}
	
	public ArrayList<Vector> getVectors(Player p) {
		ArrayList<Vector> vectors = new ArrayList<Vector>();
		Vector v = p.getEyeLocation().getDirection().normalize();
		v.setY(0);
		vectors.add(v);
		double z = v.getZ();
		double x = v.getX();
		double radians = Math.atan(z/x);
		if(x < 0)
			radians += Math.PI;
		for(int k = 1; k < 24; k ++) {
			Vector v2 = new Vector();
			v2.setY(v.getY());
			v2.setX(Math.cos(radians + k*Math.PI/12));
			v2.setZ(Math.sin(radians + k*Math.PI/12));
			vectors.add(v2.normalize());
		}
		return vectors;
	}
	
}
