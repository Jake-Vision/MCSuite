package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;


public class SwordChargeSpell extends Spell {
	
	public SwordChargeSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You jump forward into the battle.";
		sound = Sound.WITHER_SHOOT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		p.setVelocity(p.getEyeLocation().getDirection().normalize().multiply(2).setY(0).add(new Vector(0, 0.5, 0)));
	}
	
}