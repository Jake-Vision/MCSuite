package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.effects.ParticleType;

public class WandBoltMagicBarrageSpell extends WandBoltSpell{

	public int numShots = 0;
	
	public WandBoltMagicBarrageSpell(int cooldownInSec, final double spellValue, int numShots) {
		super(cooldownInSec, spellValue);
		this.numShots = numShots;
		onActivate = "You shoot out a barrage of magical bolts.";
	}
	
	public int getDelay(Player p) {
		double duration = 5.0;
		return (int)(20.0/(numShots/duration));
	}
	
	public ParticleType getBoltType(Player p) {
		return plugin.getPD(p).getWandEffect();
	}

	@Override
	public ArrayList<Vector> getVectors(Player p) {
		ArrayList<Vector> vectors = new ArrayList<Vector>();
		Vector v = p.getEyeLocation().getDirection().normalize();
		vectors.add(v);
		for(int k = 0; k < numShots; k++) {
			vectors.add(v.clone());
		}
		return vectors;
	}

	public void fireBolt(final int attack, final Player p, final ParticleType pt) {
		int count = 0;
		for(int k = 0; k < getVectors(p).size(); k++) {
			if(getDelay(p) > 1) {
				SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
					public void run() {
						shootBolt(attack, p.getEyeLocation().getDirection(), p, pt);
					}
				}, getDelay(p) * count);
			}
			count++;
		}
	}
	
}
