package xronbo.ronbomc.combat.spells;

import org.bukkit.entity.LivingEntity;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class WandAuraConfusionAuraSpell extends WandAuraSpell {
	
	public WandAuraConfusionAuraSpell(int cooldownInSeconds, double d, int tier) {
		super(cooldownInSeconds, d);
		onActivate = "You activate your Confusion Aura.";
		this.tier = tier;
	}

	public void applyAuraEffect(LivingEntity le, PlayerInteractEvent event) {
		le.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, tier * 2));
		le.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 60, tier * 2));
	}
	
}