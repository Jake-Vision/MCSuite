package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.debug.SuperDebugger;


public class DaggerStealthSpell extends Spell {
	
	public int durationTicks;
	
	public DaggerStealthSpell(int cooldownInSeconds, double d, int durationSec) {
		super(cooldownInSeconds, d);
		durationTicks = convertSecondsToTicks(durationSec);
		onActivate = "You conceal yourself in shadows as you continue on your path.";
		sound = Sound.CAT_HISS;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.makeInvisible(durationTicks);
		SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
			public void run() {
				pd.makeVisible();
			}
		}, durationTicks);
	}
	
}