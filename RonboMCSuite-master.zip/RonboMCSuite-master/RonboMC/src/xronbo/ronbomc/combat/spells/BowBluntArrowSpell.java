package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Projectile;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;


public class BowBluntArrowSpell extends Spell {
	
	public Integer strength;
	
	public BowBluntArrowSpell(int cooldownInSeconds, double d, int strength) {
		super(cooldownInSeconds, d);
		this.strength = strength;
		onActivate = "You shoot a blunt arrow that can knockback enemies.";
		sound = Sound.SHOOT_ARROW;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Projectile p = plugin.getPD(event.getPlayer()).shootArrow();
		p.setMetadata("damageMultiplier", new FixedMetadataValue(plugin, spellValue));
		p.setMetadata("knockback", new FixedMetadataValue(plugin, strength));
	}
	
}