package xronbo.ronbomc.combat.spells;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Projectile;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.util.Vector;


public class BowArrowRainSpell extends Spell {
	
	public BowArrowRainSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "A rain of arrows showers down from the heavens.";
		sound = Sound.PISTON_EXTEND;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Location loc = event.getPlayer().getTargetBlock(null, 0).getLocation();
		for(int x = -3; x <= 3; x++) {
			for(int z = -3; z <= 3; z++) {
				Location currentLoc = loc.clone();
				currentLoc.setX(loc.getX() + x - 1);
				currentLoc.setZ(loc.getZ() + z);
				currentLoc.setY(loc.getY() + 6);
				Projectile p = ((Projectile)(loc.getWorld().spawnEntity(currentLoc, EntityType.ARROW)));
				Location loc2 = loc.clone();
				loc2.setX(loc.getX() + x);
				loc2.setZ(loc.getZ() + z);
				Vector v = loc2.toVector().subtract(currentLoc.toVector()).normalize();
				p.setVelocity(v);
				p.setShooter(event.getPlayer());
				p.setMetadata("damageMultiplier", new FixedMetadataValue(plugin, spellValue));
			}
		}
	}
	
}