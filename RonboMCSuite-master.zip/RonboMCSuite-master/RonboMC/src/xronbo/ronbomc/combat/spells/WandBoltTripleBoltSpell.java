package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import xronbo.ronbomc.effects.ParticleType;

public class WandBoltTripleBoltSpell extends WandBoltSpell{

	public WandBoltTripleBoltSpell(int cooldownInSec, final double spellValue) {
		super(cooldownInSec, spellValue);
		onActivate = "You shoot out a spread of three bolts.";
	}
	
	public ParticleType getBoltType(Player p) {
		return plugin.getPD(p).getWandEffect();
	}
	
	public ArrayList<Vector> getVectors(Player p) {
		ArrayList<Vector> vectors = new ArrayList<Vector>();
		Vector v = p.getEyeLocation().getDirection().normalize();
		vectors.add(v);
		Vector v2 = new Vector();
		v2.setY(v.getY());
		Vector v3 = new Vector();
		v3.setY(v.getY());
		double z = v.getZ();
		double x = v.getX();
		double radians = Math.atan(z/x);
		if(x < 0)
			radians += Math.PI;
		v2.setX(Math.cos(radians - Math.PI/6));
		v2.setZ(Math.sin(radians - Math.PI/6));
		v3.setX(Math.cos(radians + Math.PI/6));
		v3.setZ(Math.sin(radians + Math.PI/6));
		vectors.add(v2.normalize());
		vectors.add(v3.normalize());
		return vectors;
	}
	
}
