package xronbo.ronbomc.combat.spells;

import java.util.ArrayList;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.combat.CombatHandler;
import xronbo.ronbomc.debug.SuperDebugger;
import xronbo.ronbomc.entities.MobData;
import xronbo.ronbomc.entities.MobHandler;
import xronbo.ronbomc.listeners.GeneralListeners;

public class BoneFallingBlockSpell extends Spell {
	
	public int number;
	
	public BoneFallingBlockSpell(int cooldownInSeconds, double d, int number) {
		super(cooldownInSeconds, d);
		onActivate = "MMBLARG!!!!!";
		sound = Sound.EXPLODE;
		this.number = number;
	}
	
	public Material[] materials = {Material.DIRT, Material.STONE, Material.COBBLESTONE};
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Location loc = event.getPlayer().getLocation();
		final Player p = event.getPlayer();
		ArrayList<int[]> coords = new ArrayList<int[]>();
		for(int k = 0; k < number; k++) {
			coords.add(new int[] {(int)(Math.random() * 11 - 5), (int)(Math.random() * 11 - 5)});
		}
		final ArrayList<UUID> damaged = new ArrayList<UUID>();
		for(int[] i : coords) {
			int x = i[0];
			int z = i[1];
			Location currentLoc = loc.clone();
			currentLoc.setX(loc.getX() + x);
			currentLoc.setZ(loc.getZ() + z);
			currentLoc.setY(loc.getY() + 6);
			final FallingBlock fb = currentLoc.getWorld().spawnFallingBlock(currentLoc, materials[(int)(Math.random() * materials.length)], (byte) 1);
			GeneralListeners.fallingBlocks.add(fb.getUniqueId().toString());
			fb.setDropItem(false);
			final int damageValue = (int)(spellValue * CombatHandler.rollDamage(p));
			SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, new Runnable() {
				public void run() {
					boolean hit = false;
					if(fb == null || !fb.isValid() || fb.isDead())
						return;
					for(Entity e : fb.getNearbyEntities(1, 1, 1)) {
						try {
							if(damaged.contains(e.getUniqueId()))
								continue;
							if(e instanceof Player && e != p) {
								PlayerData pd2 = plugin.getPD((Player)e);
								pd2.damage(damageValue, event.getPlayer(), true);
								damaged.add(pd2.player.getUniqueId());
							} else {
								MobData md = MobHandler.spawnedMobs.get(e.getUniqueId());
								if(md != null) {
									md.damage(damageValue, event.getPlayer(), true);
									damaged.add(md.entity.getUniqueId());
								}
							}
						} catch(Exception exception) {
							//this will occur often, since many entities have no health values
						}
					}
					if(!hit)
						SuperDebugger.scheduleSyncDelayedTask(this.getClass(), plugin, this, 2);
				}
			}, 2);
		}
	}
	
}