package xronbo.ronbomc.combat.spells;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import xronbo.ronbomc.PlayerData;


public class AxeSacrificeSpell extends Spell {
	
	public AxeSacrificeSpell(int cooldownInSeconds, double d) {
		super(cooldownInSeconds, d);
		onActivate = "You transfer your blood energy into your weapon.";
		sound = Sound.WITHER_HURT;
	}
	
	public void handleSpell(final PlayerInteractEvent event, final Double spellValue) {
		Player p = event.getPlayer();
		final PlayerData pd = plugin.getPD(p);
		pd.sacrifice_buff = true;
		pd.sacrificeValue_buff = (int)(pd.hp * spellValue);
		pd.damage((int)(pd.hp * spellValue), p, true);
	}
	
}