package xronbo.ronbomc.options;

import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;

public class OptionsHandler implements Listener {
	
	public static RonboMC plugin;

	@EventHandler
    public void clickGoldBalanceIcon(InventoryClickEvent event) {
    	ItemStack clickedItem = event.getCurrentItem();
    	Inventory inventory = event.getInventory();
    	String name = inventory.getName();
    	if(name.equals(getName((Player)(event.getWhoClicked())))) {
			if(RonboMC.TESTING_INVENTORY_CANCELS)
				System.out.println("Cancelling here. " + this.getClass().getName());
			event.setCancelled(true);
        	if(clickedItem != null) {
        		ItemMeta im = clickedItem.getItemMeta();
        		if(im != null) {
    	            Player p = (Player)(event.getWhoClicked());
    	            PlayerData pd = plugin.getPD(p);
    	            if(im.hasDisplayName()) {
    	            	String optionName = "";
    	            	switch(ChatColor.stripColor(im.getDisplayName()).toLowerCase()) {
    	            		case "debug messages":
    	            			optionName = "debug";
    	            			break;
    	            		case "chat ranges":
    	            			optionName = "chatrange";
    	            			break;
    	            		case "heart particles":
    	            			optionName = "healhearts";
    	            			break;
    	            		case "tips":
    	            			optionName = "tips";
    	            			break;
    	            		case "damage messages":
    	            			optionName = "damage";
    	            			break;
    	            		case "background music":
    	            			optionName = "music";
    	            			break;
    	            		case "spell shouts":
    	            			optionName = "entityspell";
    	            			break;
    	            		case "harvesting messages":
    	            			optionName = "harvesting";
    	            			break;
    	            		case "party invites":
    	            			optionName = "partyinvites";
    	            			break;
    	            		case "tier warning":
    	            			optionName = "tierwarning";
    	            			break;
    	            		case "hp display":
    	            			optionName = "hpdisplay";
    	            		default:
    	            	}
    	            	if(!optionName.equals("")) {
    	            		pd.options.toggleOption(optionName);
    	            		updateOptionsMenu(event.getInventory(), pd.player);
    	            	}
    	            }
        		}
        	}
    	}
    }
	
	public static Object[][] defaults = new Object[][] {
		{"debug", false},
		{"chatrange", false},
		{"healhearts", true},
		{"tips", true},
		{"damage", false},
		{"music", true},
		{"entityspell", true},
		{"harvesting", true},
		{"partyinvites", true},
		{"tierwarning", true},
		{"hpdisplay", false},
	};
	
	public static OptionList getDefaults() {
		OptionList ol = new OptionList();
		for(Object[] o : defaults)
			ol.addOption((String)o[0], (boolean)o[1]);
		return ol;
	}
	
	public static void openOptionsMenu(Player p) {
		Inventory inventory = Bukkit.createInventory(p, 9 * 2, getName(p));
		updateOptionsMenu(inventory, p);
		p.openInventory(inventory);
	}
	
	public static void updateOptionsMenu(Inventory inventory, Player p) {
		OptionList ol = plugin.getPD(p).options;
		
		ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("debug") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		ItemMeta im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("debug") ? ChatColor.GREEN : ChatColor.RED) + "Debug Messages");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggle whether debug messages are sent to you.",
				ChatColor.LIGHT_PURPLE + "A lot of info about damage calculation in combat",
				ChatColor.LIGHT_PURPLE + "related to spells and stats is in debug messages.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("debug") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(0, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("chatrange") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("chatrange") ? ChatColor.GREEN : ChatColor.RED) + "Chat Ranges");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggle a chat message range of 100 blocks.",
				ChatColor.LIGHT_PURPLE + "If this is on, you will not see chat from",
				ChatColor.LIGHT_PURPLE + "anyone more than 100 blocks away from you.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Global messages will still be received.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("chatrange") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(1, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("healhearts") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("healhearts") ? ChatColor.GREEN : ChatColor.RED) + "Heart Particles");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggle hearts appearing when you are healed.",
				ChatColor.LIGHT_PURPLE + "If you turn this off, you will still see the",
				ChatColor.LIGHT_PURPLE + "hearts of other players who are healing and",
				ChatColor.LIGHT_PURPLE + "have this option toggled on for themselves.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("healhearts") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(2, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("tips") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("tips") ? ChatColor.GREEN : ChatColor.RED) + "Tips");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Receive useful tips broadcasted from time to",
				ChatColor.LIGHT_PURPLE + "time. Recommended for newer players.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("tips") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(3, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("damage") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("damage") ? ChatColor.GREEN : ChatColor.RED) + "Damage Messages");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Show debug messages related to damage values.",
				ChatColor.LIGHT_PURPLE + "This includes HP values, damage dealt, damage",
				ChatColor.LIGHT_PURPLE + "received, and critical hits. Normal debugs",
				ChatColor.LIGHT_PURPLE + "and damage calculations are not included.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("damage") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(4, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("music") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("music") ? ChatColor.GREEN : ChatColor.RED) + "Background Music");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggles playing music in the background.",
				ChatColor.LIGHT_PURPLE + "Music is turned off after the current",
				ChatColor.LIGHT_PURPLE + "song finishes.",
				ChatColor.LIGHT_PURPLE + "Music is turned on after next logon.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("music") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(5, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("entityspell") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("entityspell") ? ChatColor.GREEN : ChatColor.RED) + "Spell Shouts");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggles whether monsters will say something",
				ChatColor.LIGHT_PURPLE + "when they use a spell (like FEAR ME! or FREEZE!)",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("entityspell") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(6, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("harvesting") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("harvesting") ? ChatColor.GREEN : ChatColor.RED) + "Harvesting Messages");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Harvesting can be spammy for your chat window.",
				ChatColor.LIGHT_PURPLE + "Turn those annoying messages off!",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("harvesting") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(7, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("partyinvites") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("partyinvites") ? ChatColor.GREEN : ChatColor.RED) + "Party Invites");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Toggles whether you receive party",
				ChatColor.LIGHT_PURPLE + "invites from other players.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("partyinvites") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(8, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("tierwarning") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("tierwarning") ? ChatColor.GREEN : ChatColor.RED) + "Tier Warning");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Receive a message when you are",
				ChatColor.LIGHT_PURPLE + "trying to use equipment that is a",
				ChatColor.LIGHT_PURPLE + "higher tier than what you can use.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("tierwarning") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(9, i);
		
		i = new ItemStack(Material.STAINED_GLASS_PANE, 1, ol.checkOption("hpdisplay") ? DyeColor.LIME.getData() : DyeColor.RED.getData());
		im = i.getItemMeta();
		im.setDisplayName((ol.checkOption("hpdisplay") ? ChatColor.GREEN : ChatColor.RED) + "HP Display");
		im.setLore(Arrays.asList(new String[] {
				ChatColor.LIGHT_PURPLE + "Always show your HP as a percentage",
				ChatColor.LIGHT_PURPLE + "in the action bar. Normally you only",
				ChatColor.LIGHT_PURPLE + "receive warnings at low HP.",
				ChatColor.LIGHT_PURPLE + "",
				ChatColor.LIGHT_PURPLE + "Current State: " + (ol.checkOption("hpdisplay") ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"),
				}));
		i.setItemMeta(im);
		inventory.setItem(10, i);
	}
	
	public static String getName(Player p) {
		return ChatColor.BLACK + "Options - " + p.getName();
	}
	
	public OptionsHandler(RonboMC plugin) {
		OptionsHandler.plugin = plugin;
	}
	
}