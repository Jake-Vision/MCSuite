package xronbo.ronbomc.options;

import java.util.ArrayList;

public class OptionList {
	
	public ArrayList<Option> options;
	
	public OptionList() {
		options = new ArrayList<Option>();
	}
	
	public boolean checkOption(String name) {
		for(Option o : options) {
			if(o.name.equalsIgnoreCase(name)) {
				return o.state;
			}
		}
		for(Object[] o : OptionsHandler.defaults) {
			if(((String)o[0]).equalsIgnoreCase(name)) {
				addOption((String)o[0], (boolean)o[1]);
				return (boolean)o[1];
			}
		}
		System.out.println("Checked for option " + name + " but could not find it!");
		return false;
	}
	
	public boolean toggleOption(String name) {
		for(Option o : options) {
			if(o.name.equalsIgnoreCase(name)) {
				o.state = !o.state;
				return o.state;
			}
		}
		for(Object[] o : OptionsHandler.defaults) {
			if(((String)o[0]).equalsIgnoreCase(name)) {
				addOption((String)o[0], (boolean)o[1]);
				return !(boolean)o[1];
			}
		}
		System.out.println("Tried to toggle option " + name + " but could not find it!");
		return false;
	}
	
	public void addOption(String name, boolean state) {
		addOption(new Option(name.toLowerCase(), state));
	}
	
	public void addOption(Option o) {
		options.add(o);
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		for(Option o : options)
			sb.append(o.name + ":" + o.state + " ");
		return sb.substring(0, sb.length() - 1).toString();
	}
	
}