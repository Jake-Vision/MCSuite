package xronbo.ronbomc.options;

public class Option {
	public String name;
	public boolean state;
	public Option(String name, boolean state) {
		this.name = name;
		this.state = state;
	}
	public String toString() {
		return name + ":" + state;
	}
}