package xronbo.ronbomc.votes;

import org.bukkit.ChatColor;
import org.bukkit.Material;

import xronbo.ronbomc.PlayerData;

public class VoteReward {
	
	public String name;
	public String desc;
	public int cost;
	public Material material;
	public VoteRewardAction action;
	
	public void reward(PlayerData pd) {
		action.reward(pd);
	}
	
	public VoteReward(String name, String desc, int cost, Material item, VoteRewardAction action) {
		this.name = ChatColor.AQUA + name;
		this.desc = desc;
		this.cost = cost;
		this.material = item;
		this.action = action;
	}
	
	public static interface VoteRewardAction {
		void reward(PlayerData pd);
	}
}