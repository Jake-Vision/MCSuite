package xronbo.ronbomc.votes;

import java.util.ArrayList;
import java.util.Arrays;

import me.ronbo.core.ranks.RankManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import xronbo.ronbomc.PlayerData;
import xronbo.ronbomc.RonboMC;
import xronbo.ronbomc.Values;
import xronbo.ronbomc.items.EtcItem;
import xronbo.ronbomc.items.ItemHandler;
import xronbo.ronbomc.votes.VoteReward.VoteRewardAction;

public class VoteHandler implements Listener {
	
	public static Inventory inventory;
	
	public static VoteReward[] rewards = new VoteReward[] {
		new VoteReward("1 Spirit Point", "Get 1 Spirit Point! /spiritpoints", 1, Material.NETHER_STAR, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				if(RankManager.check(pd.player, "knight")) {
					if(pd.spiritPoints >= 15) {
						pd.votepoints++;
						pd.player.sendMessage(ChatColor.RED + "You already have your maximum of 15 Spirit Points. Don't worry, you got your Vote Point back.");
					} else {
						pd.spiritPoints++;
						pd.player.sendMessage("You have received 1 Spirit Point for voting! You now have " + pd.spiritPoints + " Spirit Points.");
					}
				} else {
					if(pd.spiritPoints >= 10) {
						pd.votepoints++;
						pd.player.sendMessage(ChatColor.RED + "You already have your maximum of 10 Spirit Points. Don't worry, you got your Vote Point back.");
						pd.player.sendMessage(ChatColor.RED + "Upgrade to VIP to be able to have up to 15 Spirit Points at once!");
					} else {
						pd.spiritPoints++;
						pd.player.sendMessage("You have received 1 Spirit Point for voting! You now have " + pd.spiritPoints + " Spirit Points.");
					}
				}
			}
		}),
		new VoteReward("1 Ronbon", "So delicious! Instant full heal.", 1, Material.BREAD, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.RONBON, 1);
			}
		}),
		new VoteReward("1 Stat Point Reset", "Use this to get all of your SP back and re-assign them.", 15, Material.PAPER, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.STAT_POINT_RESET, 20);
			}
		}),
		new VoteReward("+30% EXP Booster (10 min)", "Get a booster which can be used for 30% bonus EXP from all sources for 10 minutes!", 15, Material.EXP_BOTTLE, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.EXP_BOOSTER_30, 15);
			}
		}),
		new VoteReward("+50% EXP Booster (10 min)", "Get a booster which can be used for 50% bonus EXP from all sources for 10 minutes!", 25, Material.EXP_BOTTLE, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.EXP_BOOSTER_50, 25);
			}
		}),
		new VoteReward("+100% EXP Booster (10 min)", "Get a booster which can be used for 100% bonus EXP from all sources for 10 minutes!", 65, Material.EXP_BOTTLE, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.EXP_BOOSTER_100, 65);
			}
		}),
		new VoteReward("+10% Damage Booster (10 min)", "Get a booster which can be used for 10% bonus damage for 10 minutes!", 5, Material.IRON_SWORD, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.DAMAGE_BOOSTER_10, 5);
			}
		}),
		new VoteReward("+15% Damage Booster (15 min)", "Get a booster which can be used for 15% bonus damage for 15 minutes!", 15, Material.IRON_SWORD, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.DAMAGE_BOOSTER_15, 15);
			}
		}),
		new VoteReward("+20% Damage Booster (20 min)", "Get a booster which can be used for 20% bonus damage for 20 minutes!", 50, Material.IRON_SWORD, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.DAMAGE_BOOSTER_20, 50);
			}
		}),
		new VoteReward("Kargoff Warp Scroll", "Warp Scroll to Kargoff", 3, Material.PORTAL, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.WARPSCROLL_KARGOFF, 3);
			}
		}),
		new VoteReward("Elven Stronghold Warp Scroll", "Warp Scroll to Elven Stronghold", 3, Material.PORTAL, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.WARPSCROLL_ELVENSTRONGHOLD, 3);
			}
		}),
		new VoteReward("Orc Mines Warp Scroll", "Warp Scroll to Orc Mines", 3, Material.PORTAL, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.WARPSCROLL_AJAX, 3);
			}
		}),
		new VoteReward("Gwyneth Warp Scroll", "Warp Scroll to Gwyneth", 3, Material.PORTAL, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.WARPSCROLL_GWYNETH, 3);
			}
		}),
		new VoteReward("Speed Booster (5 min)", "Get a booster which will give you super speed for 5 minutes!", 5, Material.PAPER, new VoteRewardAction() {
			public void reward(PlayerData pd) {
				giveItem(pd, EtcItem.SPEED_BOOSTER, 5);
			}
		}),
//		new VoteReward("Dirty Ronbox", "A mysterious Ronbox filled with items!", 10, Material.CHEST, new VoteRewardAction() {
//			public void reward(PlayerData pd) {
//				giveItem(pd, EtcItem.RONBOX_1, 10);
//			}
//		}),
//		new VoteReward("Shiny Ronbox", "A mysterious Ronbox filled with items!", 30, Material.CHEST, new VoteRewardAction() {
//			public void reward(PlayerData pd) {
//				giveItem(pd, EtcItem.RONBOX_2, 30);
//			}
//		}),
//		new VoteReward("Lnlopxjntej Ronbox", "A mysterious Ronbox filled with items!", 120, Material.CHEST, new VoteRewardAction() {
//			public void reward(PlayerData pd) {
//				giveItem(pd, EtcItem.RONBOX_3, 100);
//			}
//		}),
	};
	
	public static void giveItem(PlayerData pd, EtcItem ei, int cost) {
		if(pd.player.getInventory().firstEmpty() == -1) {
			pd.player.sendMessage(ChatColor.RED + "Your inventory was full! You have been refunded " + cost + " Vote Point" + (cost > 1 ? "s" : "") + ".");
			pd.votepoints += cost;
		} else {
			ItemStack item = ei.makeItems(1)[0];
			ItemHandler.makeUntradeable(item);
			pd.player.getInventory().addItem(item);
		}
	}
	
	public static void loadInventory() {
		inventory = Bukkit.createInventory(null, (int)(Math.ceil(rewards.length/9.0))*9, ChatColor.BLACK + "Kastia Vote Points Shop");
		ItemStack i;
		ItemMeta im;
		int slot = 0;
		for(VoteReward vr : rewards) {
			i = new ItemStack(vr.material, 1);
			im = i.getItemMeta();
			im.setDisplayName(vr.name);
			ArrayList<String> lore = new ArrayList<String>();
			lore.addAll(Arrays.asList(Values.stringToLore(vr.desc, ChatColor.GREEN)));
			lore.add("");
			lore.add(ChatColor.GOLD + "Cost: " + vr.cost + " Vote Points");
			im.setLore(lore);
			i.setItemMeta(im);
			inventory.setItem(slot++, ItemHandler.removeAttributes(i));
		}
	}
	
	public static void openInventory(Player p) {
		if(inventory == null)
			loadInventory();
		p.openInventory(inventory);
	}

	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		try {
			if(event.getInventory().getName().equals(inventory.getName())) {
				event.setCancelled(true);
				if(RonboMC.TESTING_INVENTORY_CANCELS)
					System.out.println("Cancelling here. " + this.getClass().getName());
				for(VoteReward vr : rewards) {
					if(vr.name.equals(event.getCurrentItem().getItemMeta().getDisplayName())) {
						PlayerData pd = plugin.getPD((Player)(event.getWhoClicked()));
						if(pd.votepoints >= vr.cost) {
							vr.reward(pd);
							pd.votepoints -= vr.cost;
							pd.player.sendMessage(ChatColor.GREEN + "You spent " + vr.cost + " Vote Points on " + ChatColor.stripColor(vr.name) + ". You have " + pd.votepoints + " Vote Points left.");
							pd.player.closeInventory();
						} else {
							pd.player.sendMessage(ChatColor.RED + "You don't have enough Vote Points for that!");
							pd.player.sendMessage(ChatColor.RED + "You currently have " + pd.votepoints + " Vote Points.");
						}
						break;
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	public static RonboMC plugin;
	
	public VoteHandler(RonboMC plugin) {
		VoteHandler.plugin = plugin;
	}
	
}