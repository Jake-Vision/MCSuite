package xronbo.common;

import me.ronbo.core.RonboCore;
import me.ronbo.core.ranks.ChatManager;
import me.ronbo.core.ranks.RankManager;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import xronbo.ronbofactions.RonboFactions;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.struct.ChatMode;
import com.massivecraft.factions.struct.Relation;

public class OverriddenChatManager implements Listener {
	
	@EventHandler(priority = EventPriority.LOWEST)
	public void onPlayerChat(AsyncPlayerChatEvent event) {
		event.setCancelled(true);
		for(String filtered : RonboCore.plugin.filter) {
			if(event.getMessage().toLowerCase().contains(filtered)) {
				event.getPlayer().sendMessage(ChatColor.RED + "Your message was removed by Kastia's automated chat filter.");
				return;
			}
		}
		if(RonboCore.plugin.nochat.contains(event.getPlayer().getName())) {
			event.getPlayer().sendMessage(ChatColor.RED + "You must move before chatting!");
			return;
		}
		if(RonboCore.plugin.globalmute) {
			if(!RankManager.check(event.getPlayer(), "helper")) {
				event.getPlayer().sendMessage(ChatColor.RED + "Kastia is currently in silent mode - only staff can chat.");
				return;
			}
		}
		FPlayer fplayer = ((FPlayer)FPlayers.i.get(event.getPlayer()));
		Faction factionobj = fplayer.getFaction();
	    String faction = fplayer.getTag();
	    if(fplayer.getChatMode() == ChatMode.PUBLIC) {
			String s = ((faction != null) && (faction.length() > 0) && !faction.equals("Wilderness") ? "[" + faction + "] " : "") + ChatManager.makeMessage(event.getPlayer(), event.getMessage());
			for(Player p : RonboCore.plugin.getServer().getOnlinePlayers()) {
					p.sendMessage(s);
			}
			System.out.println(s);
	    } else if(fplayer.getChatMode() == ChatMode.ALLIANCE) {
			String s = ((faction != null) && (faction.length() > 0) && !faction.equals("Wilderness") ? "[" + faction + "] " : "") + ChatManager.makeMessage(event.getPlayer(), event.getMessage());
			s = ChatColor.LIGHT_PURPLE + "[Alliance Chat] " + s;
			factionobj.sendMessage(s);
			for (FPlayer fplayer2 : FPlayers.i.getOnline()) {
				if (factionobj.getRelationTo(fplayer2) == Relation.ALLY) {
					fplayer2.sendMessage(s);
				}
			}
			System.out.println(s);
	    } else if(fplayer.getChatMode() == ChatMode.FACTION) {
			String s = ((faction != null) && (faction.length() > 0) && !faction.equals("Wilderness") ? "[" + faction + "] " : "") + ChatManager.makeMessage(event.getPlayer(), event.getMessage());
			s = ChatColor.GREEN + "[Faction Chat] " + s;
			factionobj.sendMessage(s);
			System.out.println(s);
	    }
	}
	
	public static RonboFactions plugin;
	public OverriddenChatManager(RonboFactions plugin) {
		OverriddenChatManager.plugin = plugin;
	}
}
