package xronbo.ronbofactions;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import me.ronbo.core.RonboCore;
import me.ronbo.core.SQLManager;
import me.ronbo.core.ranks.RankManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.HorseJumpEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import xronbo.common.OverriddenChatManager;

public class RonboFactions extends JavaPlugin implements CommandExecutor, Listener {

	public int left = 30 * 7 + (int)(Math.random() * 60);
	public void onEnable() {
		plugin = this;
		Stats.plugin = this;
		getServer().getPluginManager().registerEvents(this, this);
		getServer().getPluginManager().registerEvents(new OverriddenChatManager(this), this);
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		RonboCore.overrideChat();
		RonboCore.overrideRanks();
		loadPerms();
		for(String s : commands)
			try {	
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				e.printStackTrace();
			}
		init();
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public int lastupdate = 0;
			public void run() {
				StringBuilder sb = new StringBuilder();
				if(lastupdate % 2 == 0) {
					for(Player p : plugin.getServer().getOnlinePlayers())
						if(RankManager.check(p, "helper"))
							sb.append(ChatColor.getLastColors(RankManager.getPrefix(p.getName())) + p.getName() + " ");
				}
				SQLManager.execute("replace into bungee values ('" + RonboCore.serverName + "', " + plugin.getServer().getOnlinePlayers().length + ", " + lastupdate++ + ", 1, 0, '" + sb.toString().trim() + "')");
			}
		}, 20 * 5, 20 * 5);
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public void run() {
				left--;
				if(left <= 0) {
					plugin.getServer().broadcastMessage(ChatColor.RED + "Server is automatically restarting NOW!");
					plugin.getServer().shutdown();
				} else if(left % 60 == 0 && left > 0) {
					int hours = left/60;
					plugin.getServer().broadcastMessage(ChatColor.RED + "This server will be automatically restarting in " + ChatColor.YELLOW + ChatColor.BOLD + hours + ChatColor.RED + " hour" + (hours > 1 ? "s" : "") + ".");
				} else if(left % 10 == 0 && left > 0 && left < 60) {
					plugin.getServer().broadcastMessage(ChatColor.RED + "This server will be automatically restarting in " + ChatColor.YELLOW + ChatColor.BOLD + left + ChatColor.RED + " minute" + (left > 1 ? "s" : "") + ".");
				} else if(left < 10) {
					plugin.getServer().broadcastMessage(ChatColor.RED + "This server will be automatically restarting in " + ChatColor.YELLOW + ChatColor.BOLD + left + ChatColor.RED + " minute" + (left > 1 ? "s" : "") + ".");
				}
			}
		}, 20 * 60, 20 * 60);
		getLogger().info("Loaded Ronbo Factions");
	}
	
	
	
	public void loadPerms() {
		for(File f : plugin.getDataFolder().listFiles()) {
			if(f.getName().endsWith(".perms")) {
				String rank = f.getName().substring(0, f.getName().indexOf(".perms"));
				Scanner scan = null;
				try {
					scan = new Scanner(f);
					ArrayList<String> p = new ArrayList<String>();
					while(scan.hasNextLine()) {
						p.add(scan.nextLine());
					}
					Stats.perms.put(rank, p);
				} catch(Exception e) {
					e.printStackTrace();
				} finally {
					if(scan != null)
						scan.close();
				}
			}
		}
	}
	
	public void init() {
		for(Player p : plugin.getServer().getOnlinePlayers())
			loadPlayer(p);
	}
	
	@EventHandler
	public void onfalldamage(EntityDamageEvent event) {
		if(event.getCause() == DamageCause.FALL && event.getEntity() instanceof Player && ((Player)event.getEntity()).hasPermission("ronbo.nofall"))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void quit(PlayerQuitEvent event) {
		if(stats.containsKey(event.getPlayer().getName())) {
			stats.remove(event.getPlayer());
		}
	}
	
	public static HashMap<String, Stats> stats = new HashMap<String, Stats>();
	public HashMap<String, Integer> taskids = new HashMap<String, Integer>();
	public void loadPlayer(final Player p) {
		final String uuid = p.getUniqueId().toString();
		stats.put(p.getName().toLowerCase(), new Stats(p.getName(), uuid));
		final String name = p.getName();
		if(taskids.containsKey(name))
			plugin.getServer().getScheduler().cancelTask(taskids.get(name));
		taskids.put(name, plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public Scoreboard board;
			public Team noobs;
			public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
			public void run() {
				Player p = plugin.getServer().getPlayerExact(name);
				if(p == null || !p.isOnline())
					return;
				if(board == null)
					board = plugin.getServer().getScoreboardManager().getNewScoreboard();
				p.setScoreboard(board);
				if((noobs = board.getTeam("znoobs")) == null) {
					noobs = board.registerNewTeam("znoobs");
				}
				noobs.setPrefix(ChatColor.GRAY + "");
				for(Player p2 : plugin.getServer().getOnlinePlayers()){
					Team t = board.getPlayerTeam(p);
					if(t != null)
						t.removePlayer(p2);
					if(RankManager.check(p2, "knight")) {
						Team temp = null;
						if((temp = board.getTeam(ALPHABET.charAt(ALPHABET.length() - RankManager.getRankPower(p2.getName())) + RankManager.getRank(p2.getName()))) == null) {
							temp = board.registerNewTeam(ALPHABET.charAt(ALPHABET.length() - RankManager.getRankPower(p2.getName())) + RankManager.getRank(p2.getName()));
						}
						String rank_pre = RankManager.getPrefix(p2.getName());
						String rank_col = ChatColor.getLastColors(rank_pre);
						if(RankManager.checkEqualsExact(p2, "lord")) {
							rank_pre = ChatColor.YELLOW + "" + ChatColor.BOLD + "LORD";
							rank_col = ChatColor.GOLD + "";
						}
						String prefix = rank_pre + rank_col + " ";
						if(prefix.length() > 15)
							prefix = prefix.substring(0, 16);
						temp.setPrefix(prefix);
						temp.addPlayer(p2);
					} else {
						noobs.addPlayer(p2);
					}
				}
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
			}
		}, 40));
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		loadPlayer(event.getPlayer());
		event.setJoinMessage("");
		event.getPlayer().sendMessage(ChatColor.RED + "This server will be automatically restarting in " + ChatColor.YELLOW + ChatColor.BOLD + left + ChatColor.RED + " minute" + (left > 1 ? "s." : "."));
	}
	
	@EventHandler
	public void onPlayerLeave(PlayerQuitEvent event) {
		event.setQuitMessage("");
	}

	@EventHandler
	public void onVehicleExit(VehicleExitEvent event) {
		if(event.getExited() instanceof Player) {
			Player p = (Player)event.getExited();
			if(flyingHorse.contains(p.getName())) {
				flyingHorse.remove(p.getName());
				if(event.getVehicle() instanceof Horse) {
					event.getVehicle().remove();
					p.setMetadata("nofall", new FixedMetadataValue(plugin, 1));
					p.sendMessage(ChatColor.GREEN + "You gracefully dismount Pegasus.");
				}
			}
		}
	}
	
	public HashSet<String> flyingHorse = new HashSet<String>();
	public HashMap<String, Long> lastRide = new HashMap<String, Long>();
	
	@EventHandler
	public void onHorseJump(HorseJumpEvent event) {
		final Horse h = event.getEntity();
		if(h.getPassenger() != null && h.getPassenger() instanceof Player) {
			if(flyingHorse.contains(((Player)h.getPassenger()).getName())) {
				if(event.getPower() > 0.9)
					h.setVelocity(h.getPassenger().getLocation().getDirection().setY(1));
				else
					h.setVelocity(h.getPassenger().getLocation().getDirection().setY(0.75));
				for(int k = 0; k < 10; k++) {
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							if(h != null && h.getWorld() != null && h.isValid())
								h.getWorld().playEffect(h.getLocation(), Effect.SPELL, 1);
						}
					}, k*2);
				}
			}
		}
	}
	
	@EventHandler
	public void oninvopen(InventoryOpenEvent event) {
		if(flyingHorse.contains(event.getPlayer().getName())) {
			event.setCancelled(true);
		}
	}

	@EventHandler
	public void oninvopen(InventoryClickEvent event) {
		if(flyingHorse.contains(event.getWhoClicked().getName())) {
			event.setCancelled(true);
		}
	}

	@EventHandler
	public void onfall(EntityDamageEvent event) {
		if((event.getEntity().hasMetadata("nofall") || (event.getEntity() instanceof Player && flyingHorse.contains(((Player)event.getEntity()).getName()))) && event.getCause() == DamageCause.FALL) {
			event.setCancelled(true);
			event.getEntity().removeMetadata("nofall", plugin);
		}
		if(event.getEntity().hasMetadata("pegasus"))
			event.setCancelled(true);
	}

	public static HashSet<Horse> horses = new HashSet<Horse>();
	public static HashSet<String> returning = new HashSet<String>();
	
	public static String[] commands = {
		"db", "donate", "sendmessage", "hub", "giveperm", "pegasus", "reloadperms", "checkperms", "setfactionsrank", "postpone"
	};
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("postpone")) {
					if(RankManager.check(p, "owner")) {
						try {
							left += Integer.parseInt(args[0]);
							plugin.getServer().broadcastMessage(ChatColor.GREEN + "Postponed auto-restart by " + args[0] + " minutes. Restart will now be in " + left + " minutes.");
						} catch(Exception e) {
							p.sendMessage("Use as /postpone <minutes>. Ex: /postpone 30");
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("reloadperms")) {
					if(RankManager.check(p, "owner")) {
						loadPerms();
						for(Stats s : stats.values()) {
							s.loadPerms();
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("checkperms")) {
					if(RankManager.check(p, "owner")) {
						for(PermissionAttachmentInfo pai : p.getEffectivePermissions()) {
							try {
								p.sendMessage(pai.getPermission() + ": " + pai.getValue() + " [" + pai.getAttachment().getPlugin().getName() + "]");
							} catch(Exception e) {
								p.sendMessage(pai.getPermission() + ": " + pai.getValue() + " [default]");
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("setfactionsrank")) {
					if(RankManager.check(p, "owner")) {
						String player = args[0].toLowerCase();
						String rank = args[1].toLowerCase();
						if(!RankManager.rankPowers.containsKey(rank)) {
							p.sendMessage(ChatColor.RED + "Could not find a rank named '" + rank + "'.");
						} else {
							RankManager.ranks.put(player.toLowerCase(), rank);
							SQLManager.execute("update playerdata set factionsrank = '" + rank.toLowerCase() + "' where name = '" + player + "'");
							p.sendMessage(ChatColor.GREEN + "Set " + player + "'s rank to " + RankManager.coloredRanks.get(rank) + ChatColor.GREEN + "!");
							if(stats.containsKey(player)) {
								stats.get(player).factionsRankString = rank;
								stats.get(player).loadPerms();
							}
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("pegasus")) {
//					if(RankManager.check(p, "noble")) {
//						boolean canRide = true;
//						if(lastRide.containsKey(p.getName ())) {
//							if(System.currentTimeMillis() - lastRide.get(p.getName()) < 1000 * 60 * 5) {
//								canRide = false;
//							}
//						}
//						if(canRide) {
//							flyingHorse.add(p.getName());
//							lastRide.put(p.getName(), System.currentTimeMillis());
//							final Horse horse = (Horse)p.getWorld().spawnEntity(p.getLocation(), EntityType.HORSE);
//							horses.add(horse);
//							horse.setTamed(true);
//							horse.setVariant(Variant.HORSE);
//							horse.setColor(Color.WHITE);
//							horse.setStyle(Style.WHITEFIELD);
//							horse.setAdult();
//							horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
//							horse.getInventory().setArmor(new ItemStack(Material.GOLD_BARDING));
//							horse.setMetadata("pegasus", new FixedMetadataValue(plugin, 1));
//							horse.setPassenger(p);
//							p.sendMessage(ChatColor.GOLD + "You summon Pegasus, the flying horse. Spam jump key to fly.");
//							p.sendMessage(ChatColor.GOLD + "Warning: Pegasus cannot be used in no-mob zones!");
//							p.sendMessage(ChatColor.GOLD + "As a Noble, you can ride Pegasus once every 5 minutes, for up to 30 seconds at a time!");
//							final String name = p.getName();
//							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
//								public void run() {
//									Player p = plugin.getServer().getPlayerExact(name);
//									if(p != null && p.isValid() && p.isOnline()) {
//										p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Your Pegasus will disappear in 10 seconds! Land quick!");
//									}
//								}
//							}, 20 * 20);
//							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
//								public void run() {
//									flyingHorse.remove(name);
//									Player p = plugin.getServer().getPlayerExact(name);
//									if(p != null && p.isValid() && p.isOnline()) {
//										if(p.getVehicle() != null && p.getVehicle() instanceof Entity && flyingHorse.contains(p.getName())) {
//											p.sendMessage(ChatColor.RED + "Pegasus mysteriously fades away...");
//											p.setMetadata("nofall", new FixedMetadataValue(plugin, 1));
//											p.getVehicle().eject();
//											p.getVehicle().remove();
//										}
//										try {
//											horse.remove();
//										} catch(Exception e) {
//											
//										}
//									}
//								}
//							}, 30 * 20);
//						} else {
//							p.sendMessage(ChatColor.RED + "As a Noble you can only ride Pegasus once every 5 minutes!");
//							p.sendMessage(ChatColor.RED + "You must wait " + (5*60 - ((System.currentTimeMillis() - lastRide.get(p.getName()))/1000)) + " more seconds to use /pegasus.");
//							p.sendMessage(ChatColor.GOLD + "Royals" + ChatColor.RED + " can use Pegasus more often!");
//						}
//					} else if(RankManager.check(p, "royal")) {
//						boolean canRide = true;
//						if(lastRide.containsKey(p.getName())) {
//							if(System.currentTimeMillis() - lastRide.get(p.getName()) < 1000 * 60 * 2) {
//								canRide = false;
//							}
//						}
//						if(canRide) {
//							flyingHorse.add(p.getName());
//							lastRide.put(p.getName(), System.currentTimeMillis());
//							final Horse horse = (Horse)p.getWorld().spawnEntity(p.getLocation(), EntityType.HORSE);
//							horses.add(horse);
//							horse.setTamed(true);
//							horse.setVariant(Variant.HORSE);
//							horse.setColor(Color.WHITE);
//							horse.setStyle(Style.WHITEFIELD);
//							horse.setAdult();
//							horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
//							horse.getInventory().setArmor(new ItemStack(Material.GOLD_BARDING));
//							horse.setMetadata("pegasus", new FixedMetadataValue(plugin, 1));
//							horse.setPassenger(p);
//							p.sendMessage(ChatColor.GOLD + "You summon Pegasus, the flying horse. Spam jump key to fly.");
//							p.sendMessage(ChatColor.GOLD + "Warning: Pegasus cannot be used in no-mob zones!");
//							p.sendMessage(ChatColor.GOLD + "As a Royal, you can ride Pegasus once every 2 minutes, for up to 1 minute at a time!");
//							final String name = p.getName();
//							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
//								public void run() {
//									Player p = plugin.getServer().getPlayerExact(name);
//									if(p != null && p.isValid() && p.isOnline()) {
//										p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Your Pegasus will disappear in 10 seconds! Land quick!");
//									}
//								}
//							}, 50 * 20);
//							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
//								public void run() {
//									flyingHorse.remove(name);
//									Player p = plugin.getServer().getPlayerExact(name);
//									if(p != null && p.isValid() && p.isOnline()) {
//										if(p.getVehicle() != null && p.getVehicle() instanceof Entity && flyingHorse.contains(p.getName())) {
//											p.sendMessage(ChatColor.RED + "Pegasus mysteriously fades away...");
//											p.setMetadata("nofall", new FixedMetadataValue(plugin, 1));
//											p.getVehicle().eject();
//											p.getVehicle().remove();
//										}
//										try {
//											horse.remove();
//										} catch(Exception e) {
//											
//										}
//									}
//								}
//							}, 60 * 20);
//						} else {
//							p.sendMessage(ChatColor.RED + "As a Royal you can only ride Pegasus once every 2 minutes!");
//							p.sendMessage(ChatColor.RED + "You must wait " + (2*60 - ((System.currentTimeMillis() - lastRide.get(p.getName()))/1000)) + " more seconds to use /pegasus.");
//						}
//					} else {
//						p.sendMessage(ChatColor.RED + "Sorry, but Pegasus only lets Nobles or higher ride him!");
//					}
				}
				if(cmd.getName().equalsIgnoreCase("hub")) {
					if(returning.contains(p.getName())) 
						return true;
					p.removeMetadata("id", plugin);
					returning.add(p.getName());
					p.sendMessage("");
					p.sendMessage(ChatColor.RED + "Returning to the Kastia Lobby in 5 seconds...");
					final String name = p.getName();
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							try {
								Player p = plugin.getServer().getPlayerExact(name);
								if(p != null) {
									p.sendMessage(ChatColor.GREEN + "Returning to the Kastia Lobby now!");
									ByteArrayOutputStream b = new ByteArrayOutputStream();
									DataOutputStream out = new DataOutputStream(b);
									try {
										out.writeUTF("Connect");
										out.writeUTF("hub");
									} catch (IOException e) {
										e.printStackTrace();
									}
									p.sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
								}
							} catch(Exception e) {
								e.printStackTrace();
							}
							returning.remove(name);
						}
					}, 5 * 20);
				}
				if(cmd.getName().equalsIgnoreCase("db")) {
					System.out.println(p.getUniqueId());
				}
				if(cmd.getName().equalsIgnoreCase("giveperm")) {
					if(RankManager.check(p, "owner")) {
						String name = args[0].toLowerCase();
						String perm = args[1];
						if(stats.containsKey(name)) {
							stats.get(name).extraperms.add(perm);
							stats.get(name).loadPerms();
						}
						SQLManager.execute("update playerdata set factionsperms = concat_ws('', factionsperms, ' " + perm + "') where name = '" + name + "'");
						System.out.println("Gave permission " + perm + " to " + name + ".");
					}
				}
				if(cmd.getName().equalsIgnoreCase("donate")) {
					if(RankManager.check(p, "owner")) {
						String name = args[0];
						StringBuilder sb = new StringBuilder("");
						for(int k = 1; k < args.length; k++)
							sb.append(args[k] + " ");
						String item = sb.toString().trim();
						plugin.getServer().broadcastMessage(ChatColor.AQUA + " ");
						plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', 
								"&7Thank you to &6&l" + name + "&r &7for purchasing &c" + item + "&7."));
						plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', 
								"&7Help support &eKastia&7 at &e&nstore.kastia.net&7!"));
						plugin.getServer().broadcastMessage(ChatColor.AQUA + " ");
					}
				}
			} else {
				if(cmd.getName().equalsIgnoreCase("setfactionsrank")) {
					String player = args[0].toLowerCase();
					String rank = args[1].toLowerCase();
					if(!RankManager.rankPowers.containsKey(rank)) {
						System.out.println(ChatColor.RED + "Could not find a rank named '" + rank + "'.");
					} else {
						RankManager.ranks.put(player.toLowerCase(), rank);
						SQLManager.execute("update playerdata set factionsrank = '" + rank.toLowerCase() + "' where name = '" + player + "'");
						System.out.println(ChatColor.GREEN + "Set " + player + "'s rank to " + RankManager.coloredRanks.get(rank) + ChatColor.GREEN + "!"); 
						if(stats.containsKey(player)) {
							stats.get(player).factionsRankString = rank;
							stats.get(player).loadPerms();
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("donate")) {
					String name = args[0];
					StringBuilder sb = new StringBuilder("");
					for(int k = 1; k < args.length; k++)
						sb.append(args[k] + " ");
					String item = sb.toString().trim();
					plugin.getServer().broadcastMessage(ChatColor.AQUA + " ");
					plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', 
							"&7Thank you to &6&l" + name + "&r &7for purchasing &c" + item + "&7."));
					plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', 
							"&7Help support &eKastia&7 at &e&nstore.kastia.net&7!"));
					plugin.getServer().broadcastMessage(ChatColor.AQUA + " ");
				}
				if(cmd.getName().equalsIgnoreCase("sendmessage")) {
					StringBuilder sb = new StringBuilder("");
					for(String s : args)
						sb.append(s + " ");
					String s = ChatColor.translateAlternateColorCodes('&', sb.toString().trim());
					for(Player p : plugin.getServer().getOnlinePlayers())
						p.sendMessage(s);
				}
				if(cmd.getName().equalsIgnoreCase("giveperm")) {
					String name = args[0].toLowerCase();
					String perm = args[1];
					if(stats.containsKey(name)) {
						stats.get(name).extraperms.add(perm);
						stats.get(name).loadPerms();
					}
					SQLManager.execute("update playerdata set factionsperms = concat_ws('', factionsperms, ' " + perm + "') where name = '" + name + "'");
					System.out.println("Gave permission " + perm + " to " + name + ".");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void onDisable() {
		plugin.getServer().getScheduler().cancelAllTasks();
		for(Horse h : horses)
			h.remove();
		getLogger().info("Disabling Ronbo Factions...");
	}
	
	public static RonboFactions plugin;
	
}
