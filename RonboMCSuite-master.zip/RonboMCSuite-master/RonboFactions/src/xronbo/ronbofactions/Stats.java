package xronbo.ronbofactions;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import me.ronbo.core.SQLManager;
import me.ronbo.core.ranks.RankManager;

import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.permissions.PermissionAttachmentInfo;

public class Stats {
	public final String uuid;
	public final String name;
	public String factionsRankString = "member";
	public String realRankString = "member";
	public HashSet<String> extraperms = new HashSet<String>();
	
	public static HashMap<String, ArrayList<String>> perms = new HashMap<String, ArrayList<String>>();
	
	public PermissionAttachment pa = null;
	public void loadPerms() {
		Player p = plugin.getServer().getPlayerExact(name);
		if(p != null && p.isOnline() && p.isValid()) {
			if(pa != null) {
				p.removeAttachment(pa);
			}
			pa = p.addAttachment(plugin);
			ArrayList<String> list = perms.get(factionsRankString.toLowerCase());
			if(list == null)
				list = perms.get("member");
			if(list != null) {
				for(String s : list) {
					for(PermissionAttachmentInfo pai : p.getEffectivePermissions())
						try {
							if(pai.getPermission().equalsIgnoreCase(s))
								pai.getAttachment().setPermission(pai.getPermission(), false);
						} catch(Exception e) {
							
						}
					if(s.startsWith("-")) {
						pa.unsetPermission(s.substring(1));
						pa.setPermission(s.substring(1), false);
					} else {
						pa.unsetPermission(s);
						pa.setPermission(s, true);
					}
				}
			}
			list = perms.get(realRankString.toLowerCase());
			if(list != null) {
				for(String s : list) {
					for(PermissionAttachmentInfo pai : p.getEffectivePermissions())
						try {
							if(pai.getPermission().equalsIgnoreCase(s))
								pai.getAttachment().setPermission(pai.getPermission(), false);
						} catch(Exception e) {
							
						}
					if(s.startsWith("-")) {
						pa.unsetPermission(s.substring(1));
						pa.setPermission(s.substring(1), false);
					} else {
						pa.unsetPermission(s);
						pa.setPermission(s, true);
					}
				}
			}
			for(String s : extraperms) {
				pa.unsetPermission(s);
				pa.setPermission(s, true);
			}
		}
	}
	
	private void load() {
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				try {
					ResultSet rs = SQLManager.executeQuery("select rankString, factionsrank, factionsperms, playTime from playerdata where uuid = '" + uuid + "'");
					if(rs.next()) {
						try {
							realRankString = rs.getString("rankString");
							boolean useFactionsRank = true;
							if(realRankString != null) {
								if(RankManager.rankPowers.get(realRankString) >= RankManager.rankPowers.get("vip") || realRankString.equalsIgnoreCase("lord")) {
									useFactionsRank = false;
								}
							} else {
								realRankString = "member";
							}
							factionsRankString = rs.getString("factionsrank");
							if(factionsRankString == null)
								factionsRankString = "member";
							String permsString = rs.getString("factionsperms");
							if(permsString != null)
							extraperms.addAll(Arrays.asList(permsString.trim().split(" ")));
							if(!useFactionsRank && realRankString != null) {
								RankManager.ranks.put(name.toLowerCase(), realRankString);	
							} else if(factionsRankString != null) {
								RankManager.ranks.put(name.toLowerCase(), factionsRankString);	
							}
							RankManager.playTime.put(name.toLowerCase(), rs.getInt("playTime"));
							System.out.println("Factions rank for player " + name + " is " + RankManager.rankPowers.get(name.toLowerCase()) + " (power: " + RankManager.getRankPower(name) + ")");
						} catch(Exception e) {
							e.printStackTrace();
						}
					}
					loadPerms();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Stats(String player, String uuid) {
		this.name = player;
		this.uuid = uuid;
		load();
	}
	
	public static RonboFactions plugin;
}