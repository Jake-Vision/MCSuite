package xronbo.ronbosg;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import me.ronbo.core.GemManager;
import me.ronbo.core.ranks.RankManager;
import net.minecraft.server.v1_7_R4.TileEntityChest;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

import xronbo.common.effects.EffectCreator;
import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.ParticleDetails;
import xronbo.common.effects.ParticleType;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;
import xronbo.common.other.SoundHandler;

public class SGGame extends Game {
	
	@Override
	public String getGameName() {
		return "Survival Games";
	}
	
	@Override
	public String[][] getWorldNames() {
		return new String[][] {
			{"highfield", "The Highfield Estates"},
			{"sg4", "Survival Games 4"},
			{"holiday", "Holiday Resort"},
			{"highway", "The Highway"},
			{"breeze", "Breeze 2"},
			{"future", "Futuristic City"},
			{"drybone", "Drybone Valley"},
			{"howling", "Howling Mountains"},
		};
	}
	
	public static HashMap<String, String> builders = new HashMap<String, String>();
	static {
		builders.put("highfield", "bentomkeke and Gibby_MC");
		builders.put("sg4", "Vareide");
		builders.put("holiday", "Simey");
		builders.put("highway", "static_nightmare");
		builders.put("breeze", "xBayani, static_nightmare, and cameron224");
		builders.put("future", "Teweran");
		builders.put("drybone", "Teweran");
		builders.put("howling", "Teweran");
	}
	
	@Override
	public int getPlayersToStart() {
		return 6;
	}

	@Override
	public int getCountdownLength() {
		return 60;
	}

	@Override
	public boolean getJoinableAfterStart() {
		return false;
	}

	@Override
	public int getGameCount() {
		return 3;
	}

	@Override
	public int getMaxPlayers() {
		return 24;
	}

	@Override
	public boolean getTerrainChangeable() {
		return false;
	}
	
	@Override
	public boolean getLeaveOnDeath() {
		return true;
	}

	@Override
	public boolean getShowDeathMessage() {
		return true;
	}
	
	@EventHandler
	public void ondielol(PlayerDeathEvent event) {
		if(world != null && world.equals(event.getEntity().getWorld())) {
			event.getEntity().sendMessage(ChatColor.GOLD + "Aww, you died! You get Blops for playing though!");
			GemManager.giveGems(event.getEntity(), 1);
		}
	}
	
	@EventHandler
	public void ondeathmatchteleport(PlayerTeleportEvent event) {
		
		if(deathmatchStarting && event.getCause() == TeleportCause.ENDER_PEARL) {
			event.setCancelled(true);
			Player p = event.getPlayer();
			p.teleport(doubleArrayToLoc(getSpawnLoc(p)));
			p.sendMessage(ChatColor.RED + "Your teleport was cancelled because the Deathmatch is coming.");
		}
	}
	
	public boolean ended = false;
	public boolean checkEndCondition() {
		if(ended) {
			ended = false;
			return true;
		} else {
			if(getRemainingPlayers() <= 1) {
				trimPlayers();
				if(players.size() > 0) {
					message("");
					final String name = players.iterator().next();
					message(ChatColor.GREEN + "" + ChatColor.BOLD + name + " just won the Survival Games!");
					if(plugin.getServer().getPlayerExact(name) != null) {
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public int count = 10;
							public void run() {
								if(plugin.getServer().getPlayerExact(name) != null) {
									plugin.getServer().getPlayerExact(name).getWorld().spawnEntity(plugin.getServer().getPlayerExact(name).getLocation(), EntityType.FIREWORK);
								}
								if(count-- > 0) {
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 5);
								}
							}
						});
						plugin.getServer().getPlayerExact(name).sendMessage(ChatColor.GOLD + "You get Blops for winning a match of Survival Games!");
						GemManager.giveGems(plugin.getServer().getPlayerExact(name), 10);
					}
				}
				deathmatchStarting = false;
				ended = true;
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						checkEndCondition();
					}
				}, 20 * 5);
			}
			return false;
		}
	}
	
	protected static final double[][] spawnLocs_highfield = {
		{27, 58, 15, -237.30008, 9.749997},
		{22, 58, 22, -224.25008, 12.000005},
		{15, 58, 26, -210.45013, 6.899994},
		{8, 58, 30, -194.85011, 11.400003},
		{0, 58, 31, -178.20004, 5.249998},
		{-8, 58, 30, -161.55003, 6.4500003},
		{-15, 58, 27, -148.95003, 8.85001},
		{-22, 58, 21, -135.45009, 10.050011},
		{-27, 58, 15, -117.30007, 9.450005},
		{-30, 58, 8, -102.90008, 10.800004},
		{-31, 58, 0, -88.95009, 10.350003},
		{-30, 58, -8, -72.6001, 9.600001},
		{-27, 58, -15, -60.000076, 10.05},
		{-22, 58, -22, -46.65004, 9.150002},
		{-15, 58, -27, -27.450068, 9.600003},
		{-8, 58, -30, -14.5500555, 10.950006},
		{1, 58, -31, -1.9500624, 11.250003},
		{8, 58, -30, 17.849936, 8.250005},
		{15, 58, -27, 32.399937, 13.950009},
		{22, 58, -22, 44.549957, 8.700008},
		{27, 58, -15, 61.49995, 8.699999},
		{30, 58, -8, 74.24994, 10.649999},
		{31, 58, 0, 88.34996, 8.0999975},
		{30, 58, 8, 106.19995, 7.199999},
	};
	
	protected static final double[][] spawnLocs_future = {
		{119, 91, -1190, -269.24985, -6.4500103},
		{118, 91, -1195, -284.54977, 5.249986},
		{116, 91, -1200, -299.99973, -4.3500104},
		{113, 91, -1204, -314.2498, -4.6500125},
		{109, 91, -1207, -329.24982, -1.9499955},
		{104, 91, -1209, -343.79968, 1.9499961},
		{99, 91, -1210, -358.49966, -4.8000145},
		{94, 91, -1209, -15.899597, -5.55},
		{89, 91, -1207, -31.199554, -7.4999995},
		{85, 91, -1204, -43.04962, -4.9499907},
		{82, 91, -1200, -60.89966, -3.1499891},
		{80, 91, -1195, -70.04944, -0.5999757},
		{79, 91, -1190, -91.19928, -5.9999595},
		{80, 91, -1185, -109.34924, -11.849954},
		{82, 91, -1180, -119.09918, -6.1499457},
		{85, 91, -1176, -134.24933, -6.449932},
		{89, 91, -1173, -150.44943, 2.250076},
		{94, 91, -1171, -165.4494, -6.5999246},
		{99, 91, -1170, -177.89935, -3.8999221},
		{104, 91, -1171, -191.99957, -2.399932},
		{109, 91, -1173, -208.04962, -10.949935},
		{113, 91, -1176, -222.29968, -5.0999327},
		{116, 91, -1180, -238.04968, -9.749925},
		{118, 91, -1185, -250.94989, -4.049916},
	};

	protected static final double[][] spawnLocs_breeze = {
		{16, 67, 49, -177.89996, -5.100018},
		{22, 67, 48, -185.85007, 3.749942},
		{27, 67, 46, -207.90007, 1.9499551},
		{32, 67, 42, -220.20012, -1.3500636},
		{36, 67, 37, -237.4502, -4.200077},
		{38, 67, 32, -256.0502, -9.567737E-5},
		{39, 67, 26, -271.6503, 1.0498521},
		{38, 67, 20, -284.4004, -0.30017865},
		{36, 67, 15, -299.70047, -1.6501783},
		{32, 67, 10, -307.35037, -4.800182},
		{27, 67, 6, -334.5002, -3.3001933},
		{22, 67, 4, -347.7001, -8.400197},
		{16, 67, 3, -2.7001343, -4.950208},
		{10, 67, 4, -16.199982, 0.44977298},
		{5, 67, 6, -30.899933, -5.4002213},
		{0, 67, 10, -41.85013, -3.1502388},
		{-4, 67, 15, -56.250214, 9.149713},
		{-6, 67, 20, -62.850067, -0.3003054},
		{-7, 67, 26, -88.95007, -3.9003108},
		{-6, 67, 32, -101.39996, -2.8503246},
		{-4, 67, 37, -121.9498, -7.95036},
		{0, 67, 42, -134.70004, -1.8003644},
		{5, 67, 46, -152.99994, -5.7003617},
		{10, 67, 48, -162.60004, -4.0503745},
	};

	protected static final double[][] spawnLocs_highway = {
		{26, 65, 41, -72.15006, 10.950016},
		{25, 65, 46, -90.4501, 9.900006},
		{26, 65, 51, -100.35011, 7.9499955},
		{28, 65, 56, -124.95011, 9.449993},
		{31, 65, 60, -130.65012, -1.350003},
		{35, 65, 63, -148.05016, 7.9500027},
		{40, 65, 65, -165.30016, 11.100007},
		{45, 65, 66, -182.7002, 13.500024},
		{50, 65, 65, -196.3502, 11.250024},
		{55, 65, 63, -210.45016, 8.550025},
		{59, 65, 60, -224.55022, 11.85002},
		{62, 65, 56, -237.60013, 10.3500185},
		{64, 65, 51, -249.15002, 10.0500145},
		{65, 65, 46, -268.9501, 7.9500213},
		{64, 65, 41, -286.65018, 12.450022},
		{62, 65, 36, -298.2003, 11.850008},
		{59, 65, 32, -315.60028, 10.950002},
		{55, 65, 29, -332.25027, 10.950009},
		{50, 65, 27, -345.00034, 12.600012},
		{45, 65, 26, -358.3503, 7.5000167},
		{40, 65, 27, -15.000244, 4.5000076},
		{35, 65, 30, -35.40027, 11.999997},
		{31, 65, 32, -43.800293, 10.200002},
		{28, 65, 36, -59.85034, 8.549997},
	};
	
	protected static final double[][] spawnLocs_drybone = {
		{-1204, 18, 351, 178.35, 1.3499889},
		{-1199, 18, 350, -191.54997, 0.900007},
		{-1194, 18, 348, -213.75002, 0.30000913},
		{-1190, 18, 345, -215.85002, 5.400006},
		{-1187, 18, 341, -240.00003, 1.8000116},
		{-1185, 18, 336, -253.80002, -1.2000021},
		{-1184, 18, 331, -270.44995, 4.9499955},
		{-1185, 18, 326, -283.79993, 3.5999928},
		{-1187, 18, 321, -297.89993, 3.2999842},
		{-1190, 18, 317, -317.09988, 8.24998},
		{-1194, 18, 314, -325.80005, 4.6499825},
		{-1199, 18, 312, -345.74994, 1.3499846},
		{-1204, 18, 311, -358.95007, 0.4499811},
		{-1209, 18, 312, -15.600067, 4.7999783},
		{-1214, 18, 314, -28.200165, 4.3499703},
		{-1218, 18, 317, -45.60013, 1.4999615},
		{-1221, 18, 321, -59.55008, 2.399945},
		{-1223, 18, 326, -71.40018, 7.799954},
		{-1224, 18, 331, -85.80029, 3.29996},
		{-1223, 18, 336, -104.09994, 1.9500185},
		{-1221, 18, 341, -119.99992, 1.9500157},
		{-1218, 18, 345, -131.24992, 3.7500002},
		{-1214, 18, 348, -146.09991, 4.949994},
		{-1209, 18, 350, -165.89989, 8.0999975},
	};
	
	protected static final double[][] spawnLocs_holiday = {
		{-10, 72, 25, -179.40002, -4.499998},
		{-5, 72, 24, -191.84998, -3.2999797},
		{0, 72, 22, -208.79996, -3.8999827},
		{4, 72, 19, -224.54997, -9.599987},
		{7, 72, 15, -234.59999, 0.9000107},
		{9, 72, 10, -251.84988, -0.8999919},
		{10, 72, 5, -269.09982, 1.6499934},
		{9, 72, 0, -285.44977, 1.7999911},
		{7, 72, -5, -297.14963, 0.5999919},
		{4, 72, -9, -312.29947, -3.9000182},
		{0, 72, -12, -325.34946, 7.4999733},
		{-5, 72, -14, -344.84952, -0.4500192},
		{-10, 72, -15, -358.79944, 0.14999643},
		{-15, 72, -14, -15.749481, 1.2000113},
		{-20, 72, -12, -30.149323, -2.0999906},
		{-24, 72, -9, -43.04947, -0.89999074},
		{-27, 72, -5, -62.399475, -0.5999882},
		{-29, 72, 0, -71.54932, -2.9999743},
		{-30, 72, 5, -86.24927, 1.0500351},
		{-29, 72, 10, -103.049286, 4.5618413E-5},
		{-27, 72, 15, -123.14938, -1.9499657},
		{-24, 72, 19, -132.44943, -1.0499661},
		{-20, 72, 22, -146.39932, -0.14996208},
		{-15, 72, 24, -164.39929, 1.8000417},
	};
	
	protected static final double[][] spawnLocs_howling = {
		{489, 13, 737, -224.24727, 5.99991},
		{492, 13, 733, -241.7973, 0.7499698},
		{494, 13, 728, -253.64723, 5.5500236},
		{495, 13, 723, -270.8972, 1.5000715},
		{494, 13, 718, -285.8972, 3.0000749},
		{492, 13, 713, -302.69702, 3.3000758},
		{489, 13, 709, -314.99698, 4.800063},
		{485, 13, 706, -327.59683, -1.7999138},
		{480, 13, 704, -343.79675, 0.15007278},
		{475, 13, 703, -0.14666748, -0.7499098},
		{470, 13, 704, -13.646759, -1.7999152},
		{465, 13, 706, -31.0466, 3.1500938},
		{461, 13, 709, -44.9964, 4.8001},
		{458, 13, 713, -56.546356, 3.0000849},
		{456, 13, 718, -72.89615, -2.249912},
		{455, 13, 723, -87.14618, -1.3499104},
		{456, 13, 728, -102.746124, -0.29992315},
		{458, 13, 733, -115.49603, -0.29991147},
		{461, 13, 737, -133.94586, -1.649909},
		{465, 13, 740, -149.99594, 0.60008985},
		{470, 13, 742, -164.99579, -0.44990873},
		{475, 13, 743, -181.64563, 1.6500942},
		{480, 13, 742, -195.59564, -3.4499044},
		{485, 13, 740, -211.64551, 4.3500977},
	};
	
	protected static final double[][] spawnLocs_sg4 = {
		{-8, 30, 12, -145.20044, 2.2498665},
		{-4, 30, 14, -166.65045, -0.45015568},
		{0, 30, 14, -179.70044, 0.8998369},
		{4, 30, 14, -193.50061, 1.1998421},
		{8, 30, 12, -210.45062, 1.0498576},
		{12, 30, 9, -226.50061, 0.14983879},
		{15, 30, 5, -237.30072, -4.3501573},
		{17, 30, 1, -253.65088, -3.3001564},
		{17, 30, -3, -266.8509, 0.74983704},
		{17, 30, -7, -282.75128, -4.6501565},
		{15, 30, -11, -298.65143, 0.14985055},
		{12, 30, -15, -317.25122, 0.7498422},
		{8, 30, -18, -331.95148, 4.649836},
		{4, 30, -20, -348.6015, -1.3501492},
		{0, 30, -20, -0.45141602, -1.0501724},
		{-4, 30, -20, -11.251648, -4.350154},
		{-8, 30, -18, -34.801697, 4.3498735},
		{-12, 30, -15, -48.30182, -4.20015},
		{-15, 30, -11, -62.851746, -0.90015364},
		{-17, 30, -7, -72.601685, -0.90015554},
		{-17, 30, -3, -88.50195, -2.8501425},
		{-17, 30, 1, -104.55176, 1.1998527},
		{-15, 30, 5, -120.00189, -2.4001513},
		{-12, 30, 9, -134.40222, 0.59984314},
	};
	
	public int index_highfield = (int)(Math.random() * spawnLocs_highfield.length);
	public int index_future = (int)(Math.random() * spawnLocs_future.length);
	public int index_breeze = (int)(Math.random() * spawnLocs_breeze.length);
	public int index_highway = (int)(Math.random() * spawnLocs_highway.length);
	public int index_drybone = (int)(Math.random() * spawnLocs_drybone.length);
	public int index_holiday = (int)(Math.random() * spawnLocs_holiday.length);
	public int index_howling = (int)(Math.random() * spawnLocs_howling.length);
	public int index_sg4 = (int)(Math.random() * spawnLocs_sg4.length);
	
	@Override
	protected double[] getSpawnLoc(Player p) {
		/*
		 * 
			{"sg4", "Survival Games 4"},
			{"holiday", "Holiday Resort"},
			{"drybone", "Howling Mountains"},
			{"howling", "Howling Mountains"},
		 */
		String name = world.getName().toLowerCase();
		double[] d = null;
		String type = "";
		if(name.contains("highfield")) {
			type = "highfield";
		} else if(name.contains("future")) {
			type = "future";
		} else if(name.contains("sg4")) {
			type = "sg4";
		} else if(name.contains("breeze")) {
			type = "breeze";
		} else if(name.contains("highway")) {
			type = "highway";
		} else if(name.contains("howling")) {
			type = "howling";
		} else if(name.contains("drybone")) {
			type = "drybone";
		} else if(name.contains("holiday")) {
			type = "holiday";
		}
		try {
			type = type.trim();
			Field array = SGGame.class.getDeclaredField("spawnLocs_" + type);
			Field index = SGGame.class.getDeclaredField("index_" + type);
			double[][] ar = (double[][])array.get(this);
			int in = (int)index.get(this);
			if(in >= ar.length) {
				in = 0;
			}
			d = ar[in++].clone();
			index.set(this, in);
		} catch(Exception e) {
			System.out.println("Error for world: " + name);
			e.printStackTrace();
		}
		if(d != null) {
			d[0] += 0.5;
			d[1] += 1;
			d[2] += 0.5;
		}
		return d == null ? locToDoubleArray(world.getSpawnLocation()) : d;
	}
	
	@Override
	public void postJoin(Player p) {
		p.sendMessage(ChatColor.AQUA + "This match will be played on " + ChatColor.BOLD + currentMapDisplayName + ChatColor.AQUA + ".");
		if(builders.containsKey(currentMapWorldTemplateName))
			p.sendMessage(ChatColor.AQUA + "" + ChatColor.ITALIC + currentMapDisplayName + " was built by " + builders.get(currentMapWorldTemplateName) + ".");
	}
	
	public SGGame(int id) {
		super(id);
	}
	
	protected int objectiveTask() {
		return -1;
	}

	@Override
	protected void postWorldLoad() {
		if(world != null)
			world.setGameRuleValue("doFireTick", "false");
	}
	
	public HashMap<String, String> compassLast = new HashMap<String, String>();
	
//	public long gracebegin;
//	@EventHandler
//	public void ondmggrace(EntityDamageByEntityEvent event) {
//		if(world != null && world.equals(event.getEntity().getWorld())) {
//			if(System.currentTimeMillis() - gracebegin < 15000)
//				event.setCancelled(true);
//		}
//	}
	
	@EventHandler
	public void onChangeTarget(PlayerInteractEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(!GameManager.spectators.contains(event.getPlayer().getName()) && event.getPlayer().getItemInHand() != null && event.getPlayer().getItemInHand().getType() == Material.COMPASS) {
					trimPlayers();
					ArrayList<String> players = new ArrayList<String>(this.players);
					Collections.shuffle(players);
					String name = event.getPlayer().getName();
					String last = compassLast.containsKey(name) ? compassLast.get(name) : "";
					for(int k = 0; k < players.size(); k++) {
						if(!players.get(k).equals(name) && !players.get(k).equals(last) && !spectators.contains(players.get(k)) &&
								plugin.getServer().getPlayerExact(players.get(k)) != null && world != null && 
								plugin.getServer().getPlayerExact(players.get(k)).getWorld().equals(world)) {
							last = players.get(k);
							break;
						}
					}
					compassLast.put(name, last);
					event.getPlayer().sendMessage(ChatColor.GREEN + "Changed compass target to " + last + ".");
				}
			}
		}
	}

	
	@Override
	public void postLeave(Player p) {
		if(getRemainingPlayers() == 2) {
			scheduleDeathMatch();
		}
	}
	
	public HashMap<String, ArrayList<ItemStack>> sponsorItems = new HashMap<String, ArrayList<ItemStack>>();
	public HashMap<String, HashMap<Material, Integer>> sponsorReceived = new HashMap<String, HashMap<Material, Integer>>();
	
	@Override
	public void postRespawn(Player p) {
		final String name = p.getName();
		sponsorItems.remove(p.getName());
		p.getInventory().clear();
		p.getInventory().setContents(new ItemStack[p.getInventory().getSize()]);
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		leave(p);
		if(RankManager.check(p, "knight")) {
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					Player p = plugin.getServer().getPlayerExact(name);
					if(p != null && inProgress) {
						GameManager.spectate(p, id);
						ItemStack item;
						ItemMeta im;
						ArrayList<ItemStack> items = new ArrayList<ItemStack>();
						item = new ItemStack(Material.ENDER_PEARL);
						items.add(item);
						item = new ItemStack(Material.BOW);
						items.add(item);
						item = new ItemStack(Material.ARROW, 8);
						items.add(item);
						item = new ItemStack(Material.GOLDEN_APPLE);
						items.add(item);
						item = new ItemStack(Material.STONE_SWORD);
						items.add(item);
						item = new ItemStack(Material.IRON_INGOT, 2);
						items.add(item);
						item = new ItemStack(Material.COOKED_BEEF, 5);
						items.add(item);
						item = new ItemStack(Material.MUSHROOM_SOUP);
						items.add(item);
						item = new ItemStack(Material.CHAINMAIL_CHESTPLATE);
						items.add(item);
						sponsorItems.put(p.getName(), items);
						p.sendMessage("");
						p.sendMessage(ChatColor.RED + "You died! But, as a VIP, you can sponsor one player!");
						p.sendMessage(ChatColor.AQUA + "Click with your " + ChatColor.GOLD + ChatColor.BOLD + "Chest" + ChatColor.AQUA + " to sponsor someone.");
						p.sendMessage(ChatColor.RED + "Type " + ChatColor.YELLOW + "/hub" + ChatColor.RED + " if you don't want to sponsor anyone.");
						item = new ItemStack(Material.CHEST);
						im = item.getItemMeta();
						im.setDisplayName(ChatColor.DARK_AQUA + "" + ChatColor.BOLD + "Click to Sponsor!");
						item.setItemMeta(im);
						p.getInventory().addItem(item);
					} else {
						leave(p);
					}
				}
			}, 10);
		} else {
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					Player p = plugin.getServer().getPlayerExact(name);
					if(p != null && inProgress) {
						GameManager.spectate(p, id);
					}
				}
			}, 10);
		}
	}
	
	@EventHandler
	public void onsponsor(PlayerInteractEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(event.getPlayer().getItemInHand() != null && event.getPlayer().getItemInHand().getType() == Material.CHEST && GameManager.spectators.contains(event.getPlayer().getName())) {
				Inventory inventory = Bukkit.createInventory(event.getPlayer(), 6*9, ChatColor.BLACK + "        " + ChatColor.UNDERLINE + "Sponsor Someone!");
				trimPlayers();
				for(String s : players) {
					ItemStack item = new ItemStack(Material.COMPASS);
					ItemMeta im = item.getItemMeta();
					im.setDisplayName(ChatColor.GREEN + s);
					im.setLore(Arrays.asList(new String[] {ChatColor.GRAY + "Click to sponsor me!"}));
					item.setItemMeta(im);
					inventory.addItem(item);
				}
				event.getPlayer().openInventory(inventory);
			}
		}
	}
	
	@EventHandler
	public void selectsponsor(InventoryClickEvent event) {
		try {
			if(world != null && world.equals(event.getWhoClicked().getWorld())) {
				if(event.getInventory().getName().contains("Sponsor Someone!")) {
					if(event.getCurrentItem().getType() == Material.COMPASS) {
						String toSponsor = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
						Player p = (Player)event.getWhoClicked();
						ItemMeta im;
						if(sponsorItems.containsKey(p.getName())) {
							if(sponsorItems.get(p.getName()).size() == 0) {
								sponsorItems.remove(p.getName());
								p.getInventory().remove(Material.CHEST);
							} else {
								int count = 0;
								Inventory inventory = Bukkit.createInventory(event.getWhoClicked(), 9, ChatColor.BLACK + "Sponsor " + toSponsor + "!");
								for(ItemStack item : sponsorItems.get(p.getName())) {
									im = item.getItemMeta();
									boolean maxed = false;
									if(sponsorReceived.containsKey(toSponsor)) {
										if(sponsorReceived.get(toSponsor).containsKey(item.getType()) && sponsorReceived.get(toSponsor).get(item.getType()) >= 2) {
											maxed = true;
										}
									}
									if(maxed) {
										im.setLore(Arrays.asList(ChatColor.RED + toSponsor + " cannot receive any more of this!"));
									} else {
										im.setLore(Arrays.asList(ChatColor.GRAY + "Click to sponsor " + toSponsor + " with this!"));
									}
									item.setItemMeta(im);
									inventory.setItem(count++, item);
								}
								event.getWhoClicked().openInventory(inventory);
							}
						} else {
							p.getInventory().remove(Material.CHEST);
						}
					}
				} else if(event.getInventory().getName().startsWith(ChatColor.BLACK + "Sponsor ")) {
					ItemStack item = event.getCurrentItem();
					if(item != null) {
						item = new ItemStack(item.getType(), item.getAmount());
						String toSponsor = ChatColor.stripColor(event.getInventory().getName()).trim();
						toSponsor = toSponsor.substring("Sponsor ".length(), toSponsor.lastIndexOf("!")).trim();
						Player sponsored = plugin.getServer().getPlayerExact(toSponsor);
						Player sponsor = (Player)event.getWhoClicked();
						sponsor.closeInventory();
						if(!players.contains(toSponsor) || sponsored == null) {
							sponsor.sendMessage(ChatColor.RED + "That player is no longer in this game!");
						} else {
							ArrayList<ItemStack> remaining = sponsorItems.get(sponsor.getName());
							if(sponsor.getInventory().contains(Material.CHEST)) {
								if(remaining != null) {
									HashMap<Material, Integer> mats = sponsorReceived.get(sponsored.getName());
									if(mats == null)
										mats = new HashMap<Material, Integer>();
									if(mats.containsKey(item.getType()) && mats.get(item.getType()) >= 2) {
										sponsor.sendMessage(ChatColor.RED + sponsored.getName() + " has already received the maximum of 2 of that item!");
									} else {
										Iterator<ItemStack> iter = remaining.iterator();
										while(iter.hasNext()) {
											ItemStack i = iter.next();
											if(i.getType() == item.getType() && i.getAmount() == item.getAmount()) {
												if(mats.containsKey(item.getType()))
													mats.put(item.getType(), mats.get(item.getType()) + 1);
												else
													mats.put(item.getType(), 1);
												iter.remove();
												SoundHandler.playSound(sponsored, Sound.ORB_PICKUP);
												sponsored.sendMessage(ChatColor.GREEN + sponsor.getName() + " just sponsored you " + item.getAmount() + " " + item.getType().toString().replace("_", " ").toLowerCase() + (item.getAmount() > 1 ? "s" : "") + ".");
												if(sponsored.getInventory().firstEmpty() == -1) {
													sponsored.sendMessage(ChatColor.GREEN + "Your inventory is full!");
													sponsored.sendMessage(ChatColor.GREEN + "Look around on the ground for your item!");
													sponsored.getWorld().dropItem(sponsored.getLocation(), item);
												} else {
													sponsored.sendMessage(ChatColor.GREEN + "Check your inventory for your new item!");
													sponsored.getInventory().addItem(item);
												}
												sponsor.sendMessage(ChatColor.GREEN + "You just sponsored " + sponsored.getName() + "!");
												if(remaining.size() > 0) {
													sponsorItems.put(sponsor.getName(), remaining);
												} else {
													sponsor.sendMessage(ChatColor.RED + "You are out of items to sponsor!");
													sponsorItems.remove(sponsor.getName());
													sponsor.getInventory().remove(Material.CHEST);
												}
												break;
											}
										}
									}
									sponsorReceived.put(sponsored.getName(), mats);
								} else {
									sponsor.getInventory().remove(Material.CHEST);
								}
							}
						}
					}
				}
			}
		} catch(Exception e) {
			
		}
	}
	
	@Override
	public void postEnd() {
		for(int i : deathmatchTasks)
			plugin.getServer().getScheduler().cancelTask(i);
	}
	
	public HashMap<String, Integer> lastDecay = new HashMap<String, Integer>();
	@EventHandler
	public void onFoodLevelChange(FoodLevelChangeEvent event) {
		if(event.getFoodLevel() < ((Player)event.getEntity()).getFoodLevel()) {
			boolean decay = true;
			int value = 0;
			if(lastDecay.containsKey(event.getEntity().getName())) {
				if(lastDecay.get(event.getEntity().getName()) % 3 != 0) {
					decay = false;
				}
				value = lastDecay.get(event.getEntity().getName()) + 1;
			}
			lastDecay.put(event.getEntity().getName(), value);
			if(!decay)
				event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onTakeItemFrame(EntityDamageByEntityEvent event) {
		if (event.getEntityType() == EntityType.ITEM_FRAME) {
			if (event.getEntityType() == EntityType.ITEM_FRAME) {
		    	event.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onTakeItemFrame2(HangingBreakByEntityEvent event) {
		if (event.getEntity().getType() == EntityType.ITEM_FRAME) {
			if (event.getEntity().getType() == EntityType.ITEM_FRAME) {
		    	event.setCancelled(true);
			}
		}
	}

	public boolean deathmatchStarting = false;
	public boolean deathmatch = false;
	public ArrayList<Integer> deathmatchTasks = new ArrayList<Integer>();
	public void scheduleDeathMatch() {
		if(deathmatchStarting || !inProgress)
			return;
		deathmatchStarting = true;
		message(ChatColor.RED + "" + ChatColor.BOLD + "The Deathmatch will begin in 1 minute!");
		message(ChatColor.RED + "Prepare yourselves!");
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(deathmatchStarting) {
					if(inProgress) {
						message(ChatColor.RED + "" + ChatColor.BOLD + "The Deathmatch will begin in 30 seconds!");
					}
				}
			}
		}, 20 * 30));
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(deathmatchStarting) {
					if(inProgress) {
						message(ChatColor.RED + "" + ChatColor.BOLD + "The Deathmatch will begin in 10 seconds!");
					}
				}
			}
		}, 20 * 50));
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(deathmatchStarting) {
					if(inProgress) {
						deathmatch = true;
						message(ChatColor.RED + "The Deathmatch has begun! You will be unfrozen in 10 seconds!");
						for(Player p : getPlayers()) {
							p.teleport(doubleArrayToLoc(getSpawnLoc(p)));
							freeze.put(p.getName(), p.getLocation());
						}
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public int count = 9;
							public void run() {
								if(count <= 5)
									for(Player p : getPlayers())
										SoundHandler.playSound(p, Sound.ORB_PICKUP);
								if(count > 0)
									message(ChatColor.RED + "You will be unfrozen in " + count + " second" + (count > 1 ? "s" : "") + "!");
								count--;
								if(count < 0) {
									freeze.clear();
									message(ChatColor.RED + "You have been unfrozen! Fight for your lives!");
									message(ChatColor.AQUA + "" + ChatColor.BOLD + "You cannot run away from the Deathmatch!");
									for(Player p : getPlayers())
										SoundHandler.playSound(p, Sound.FIREWORK_BLAST);
								} else {
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20);
								}
							}
						}, 20);
					}
				}
			}
		}, 20 * 60));
	}
	
	@EventHandler
	public void onMoveDM(PlayerMoveEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(deathmatch && world != null && players.contains(event.getPlayer().getName())) {
				if(Math.abs(event.getTo().getX() - world.getSpawnLocation().getX()) > 30 || Math.abs(event.getTo().getZ() - world.getSpawnLocation().getZ()) > 30) {
					event.setCancelled(true);
					event.getPlayer().sendMessage(ChatColor.RED + "There's no escaping from the Deathmatch!");
					event.getPlayer().teleport(event.getFrom());
				}
			}
		}
	}
	
	@EventHandler
	public void onDamageFrozen(EntityDamageEvent event) {
		if(event.getEntity() instanceof Player) {
			if(world != null && world.equals(event.getEntity().getWorld())) {
				if(freeze.containsKey(((Player)event.getEntity()).getName())) {
					event.setCancelled(true);
				}
			}
		}
	}
	
	@Override
	protected void postAllEnter() {
		loaded.clear();
		sponsorReceived.clear();
		sponsorItems.clear();
		deathmatch = false;
		deathmatchStarting = false;
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int count = 15;
			public void run() {
				if(!inProgress)
					return;
				if(count > 0 && (count % 5 == 0 || count <= 5))
					message(ChatColor.GREEN + "Players will be unfrozen in " + count + " second" + (count > 0 ? "s" : "") + "!");
				if(count <= 5)
					for(Player p : getPlayers())
						SoundHandler.playSound(p, Sound.ORB_PICKUP);
				count--;
				if(count < 0) {
					freeze.clear();
					message(ChatColor.AQUA + "" + ChatColor.BOLD + "You can move now!");
					for(Player p : getPlayers())
						SoundHandler.playSound(p, Sound.FIREWORK_BLAST);
				} else {
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20);
				}
			}
		});
		final Game me = this;
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(inProgress) {
					message(ChatColor.RED + "5 minutes have passed!");
					deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 5*20*60));
				}
			}
		}, 5 * 20 * 60));
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(inProgress) {
					message(ChatColor.RED + "The Hunting Phase has begun!");
					message(ChatColor.RED + "Check your inventory for a \"Player Compass\"!");
					message(ChatColor.RED + "If your inventory is full, check the ground around you!");
					for(Player p : getPlayers()) {
						if(compass == null) {
							compass = new ItemStack(Material.COMPASS);
							ItemMeta im = compass.getItemMeta();
							im.setDisplayName(ChatColor.AQUA + "Player Compass");
							im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Points at a nearby player. Right-click to switch target."}));
							compass.setItemMeta(im);
						}
						final String name = p.getName();
						p.getInventory().addItem(compass.clone());
						if(!p.getInventory().contains(Material.COMPASS))
							p.getWorld().dropItem(p.getLocation(), compass.clone());
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public void run() {
								try {
									String last = null;
									if(compassLast.containsKey(name))
										last = compassLast.get(name);
									if(last == null || spectators.contains(last) || GameManager.spectators.contains(last) || plugin.getServer().getPlayerExact(last) == null || GameManager.getGame(plugin.getServer().getPlayerExact(last)) != me) {
										ArrayList<String> temp = new ArrayList<String>(players);
										Iterator<String> iter = temp.iterator();
										while(iter.hasNext()) {
											last = iter.next();
											if(!last.equals(name) && plugin.getServer().getPlayerExact(last) != null && world != null && plugin.getServer().getPlayerExact(last).getWorld().equals(world))
												break;
										}
									}
									compassLast.put(name, last);
									Player p = plugin.getServer().getPlayerExact(name);
									if(p.getItemInHand().getType() == Material.COMPASS) {
										ItemStack item = new ItemStack(Material.COMPASS);
										ItemMeta im = item.getItemMeta();
										try  {
											double distance = plugin.getServer().getPlayerExact(last).getLocation().distance(p.getLocation());
											im.setDisplayName(ChatColor.DARK_AQUA + "" + ChatColor.BOLD + "Target Player: " + ChatColor.AQUA + last + ChatColor.DARK_GREEN + ChatColor.BOLD + " Distance: " + ChatColor.GREEN + String.format("%.1f", distance) + " blocks");
											im.setLore(Arrays.asList(new String[] {ChatColor.YELLOW + "Points at another player."}));
											item.setItemMeta(im);
										} catch(Exception e) {
											
										}
										p.setItemInHand(item);
									}
									p.setCompassTarget(plugin.getServer().getPlayerExact(last).getLocation());
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
								} catch(Exception e) {
									
								}
							}
						});
					}
				}
			}
		}, 20 * 60 * 9));
		deathmatchTasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int count = 0;
			public void run() {
				if(getRemainingPlayers() <= 4 || count++ == 6)
					scheduleDeathMatch();
				else
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20 * 5);
			}
		}, 20 * 60 * 9));
	}
	
	
	public static class Coord {
		public int x,y,z;
		public String world;
		@Override
		public boolean equals(Object other) {
			if(other instanceof Coord) {
				return ((Coord)other).x == x && ((Coord)other).y == y && ((Coord)other).z == z && ((Coord)other).world.equals(this.world);
			}
			return false;
		}
		public Coord(int a, int b, int c, String world) {
			x = a;
			y = b;
			z = c;
			this.world = world;
		}
	}
	
	public HashMap<String, String> lastDamager = new HashMap<String, String>();
	@EventHandler
	public void lastDamage(EntityDamageByEntityEvent event) {
		if(event.getEntity() instanceof Player) {
			if(world != null && world.equals(event.getEntity().getWorld())) {
				if(event.getDamager() instanceof Player) {
					lastDamager.put(((Player)event.getEntity()).getName(), ((Player)(event.getDamager())).getName());
				} else if(event.getDamager() instanceof Projectile) {
					Projectile proj = (Projectile)event.getDamager();
					if(proj.getShooter() != null && proj.getShooter() instanceof Player) {
						lastDamager.put(((Player)event.getEntity()).getName(), ((Player)(proj.getShooter())).getName());
					}
				}
			}
		}
	}
	
	@EventHandler
	public void getKill(final PlayerDeathEvent event) {
		if(world != null && world.equals(event.getEntity().getWorld())) {
			if(lastDamager.containsKey(event.getEntity().getName())) {
				String s = lastDamager.get(event.getEntity().getName());
				if(s != null && plugin.getServer().getPlayerExact(s) != null)
					GemManager.giveGems(plugin.getServer().getPlayerExact(s), 1);
			}
			if(getRemainingPlayers() > 1) {
				for(Player p : getPlayers())
					SoundHandler.playSound(p, Sound.EXPLODE, 3, 1);
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						message(ChatColor.RED + "There are " + ChatColor.YELLOW + ChatColor.BOLD + getRemainingPlayers() + ChatColor.RED + " players left!");
					}
				}, 5);
			}
		}
	}
	
	public ArrayList<Coord> loaded = new ArrayList<Coord>();
	
	@EventHandler
	public void onopenchest(PlayerInteractEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			Block b = event.getClickedBlock();
			if(b != null) {
				if(b.getType() == Material.CHEST) {
					Coord coord = new Coord(b.getX(), b.getY(), b.getZ(), b.getWorld().getName());
					if(!loaded.contains(coord)) {
						loaded.add(coord);
						Chest c = (Chest)b.getState();
			            Inventory inventory = c.getInventory();
			            Player p = event.getPlayer();
			            try {
			                Field inventoryField = c.getClass().getDeclaredField("chest");
			                inventoryField.setAccessible(true);
			                TileEntityChest teChest = ((TileEntityChest) inventoryField.get(c));
			                teChest.a("Tier 2 Chest");
			            } catch (Exception e) {
			                 e.printStackTrace();
			            }
			            if(inventory.contains(Material.GOLD_BLOCK)) {
			            	inventory.clear();
			            	for(ItemStack i : generateTier(2)) {
			            		inventory.setItem((int)(Math.random() * inventory.getSize()), i);
			            	}
			            } else {
			            	inventory.clear();
			            	if(Math.random() < (RankManager.check(p, "knight") ? 0.04 : 0.02)) {
				            	for(ItemStack i : generateTier(3)) {
						            try {
						                Field inventoryField = c.getClass().getDeclaredField("chest");
						                inventoryField.setAccessible(true);
						                TileEntityChest teChest = ((TileEntityChest) inventoryField.get(c));
						                teChest.a("Tier 3 Chest");
						            } catch (Exception e) {
						                 e.printStackTrace();
						            }
				            		inventory.setItem((int)(Math.random() * inventory.getSize()), i);
				            	}
			            	} else {
					            try {
					                Field inventoryField = c.getClass().getDeclaredField("chest");
					                inventoryField.setAccessible(true);
					                TileEntityChest teChest = ((TileEntityChest) inventoryField.get(c));
					                teChest.a("Tier 1 Chest");
					            } catch (Exception e) {
					                 e.printStackTrace();
					            }
				            	for(ItemStack i : generateTier(1)) {
				            		inventory.setItem((int)(Math.random() * inventory.getSize()), i);
				            	}
			            	}
			            }
					}
				}
			}
		}
	}
	
	@EventHandler
	public void onDrinkSoup(PlayerInteractEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(event.getPlayer().getItemInHand() != null && event.getPlayer().getItemInHand().getType() == Material.MUSHROOM_SOUP) {
					event.setCancelled(true);
					event.getPlayer().addPotionEffect(PotionEffectType.HEAL.createEffect(1, 0));
					SoundHandler.playSound(event.getPlayer(), Sound.DRINK);
					event.getItem().setAmount(0);
					event.getPlayer().setItemInHand(new ItemStack(Material.AIR));
					event.getPlayer().updateInventory();
				}
			}
		}
	}
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(event.getBlock() != null) {
				if(!event.getBlock().getWorld().getName().equals("world")) {
					switch(event.getBlock().getType()) {
						case LEAVES:
						case RED_MUSHROOM:
						case BROWN_MUSHROOM:
						case CARROT:
						case WHEAT:
						case POTATO:
						case CROPS:
						case LONG_GRASS:
						case RED_ROSE:
						case YELLOW_FLOWER:
						case SUGAR_CANE_BLOCK:
							event.setCancelled(false);
						default:
							break;
					}
				}
			}
		}
	}
	
	public static ItemStack[] tier1 = {
		new ItemStack(Material.RED_MUSHROOM),
		new ItemStack(Material.RED_MUSHROOM, 2),
		new ItemStack(Material.BROWN_MUSHROOM),
		new ItemStack(Material.BROWN_MUSHROOM, 2),
		new ItemStack(Material.BOWL),
		new ItemStack(Material.LEATHER_HELMET),
		new ItemStack(Material.LEATHER_CHESTPLATE),
		new ItemStack(Material.LEATHER_LEGGINGS),
		new ItemStack(Material.LEATHER_BOOTS),
		new ItemStack(Material.WOOD_SWORD),
		new ItemStack(Material.FISHING_ROD),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.FEATHER, 2),
		new ItemStack(Material.FEATHER, 4),
		new ItemStack(Material.STRING, 5),
		new ItemStack(Material.STICK),
		new ItemStack(Material.STICK),
		new ItemStack(Material.FLINT, 3),
		new ItemStack(Material.GOLD_INGOT, 2),
		new ItemStack(Material.COOKED_BEEF, 1),
		new ItemStack(Material.COOKED_CHICKEN, 1),
		new ItemStack(Material.COOKED_FISH, 1),
		new ItemStack(Material.COOKED_BEEF, 2),
		new ItemStack(Material.COOKED_CHICKEN, 2),
		new ItemStack(Material.COOKED_FISH, 2),
		new ItemStack(Material.GOLD_HELMET),
		new ItemStack(Material.GOLD_BOOTS),
		new ItemStack(Material.CHAINMAIL_HELMET),
		new ItemStack(Material.CHAINMAIL_BOOTS),
		new ItemStack(Material.GOLD_HELMET),
		new ItemStack(Material.GOLD_CHESTPLATE),
		new ItemStack(Material.GOLD_LEGGINGS),
		new ItemStack(Material.GOLD_BOOTS),
	};
	
	public static ItemStack[] tier2 = {
		new ItemStack(Material.RED_MUSHROOM, 2),
		new ItemStack(Material.RED_MUSHROOM, 3),
		new ItemStack(Material.BROWN_MUSHROOM, 2),
		new ItemStack(Material.BROWN_MUSHROOM, 3),
		new ItemStack(Material.BOWL),
		new ItemStack(Material.BOWL),
		new ItemStack(Material.WOOD_SWORD),
		new ItemStack(Material.WOOD_SWORD),
		new ItemStack(Material.WOOD_SWORD),
		new ItemStack(Material.WOOD_AXE),
		new ItemStack(Material.WOOD_AXE),
		new ItemStack(Material.FEATHER, 2),
		new ItemStack(Material.FEATHER, 4),
		new ItemStack(Material.STRING, 5),
		new ItemStack(Material.STICK),
		new ItemStack(Material.STICK),
		new ItemStack(Material.FLINT, 4),
		new ItemStack(Material.GOLD_INGOT, 2),
		new ItemStack(Material.COOKED_BEEF, 1),
		new ItemStack(Material.COOKED_CHICKEN, 1),
		new ItemStack(Material.COOKED_FISH, 1),
		new ItemStack(Material.COOKED_BEEF, 2),
		new ItemStack(Material.COOKED_CHICKEN, 2),
		new ItemStack(Material.COOKED_FISH, 2),
		new ItemStack(Material.STONE_SWORD),
		new ItemStack(Material.STONE_SWORD),
		new ItemStack(Material.STONE_AXE),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.BOW),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.IRON_INGOT, 1),
		new ItemStack(Material.IRON_INGOT, 2),
		new ItemStack(Material.CHAINMAIL_HELMET),
		new ItemStack(Material.CHAINMAIL_CHESTPLATE),
		new ItemStack(Material.CHAINMAIL_LEGGINGS),
		new ItemStack(Material.CHAINMAIL_BOOTS),
		new ItemStack(Material.GOLD_HELMET),
		new ItemStack(Material.GOLD_CHESTPLATE),
		new ItemStack(Material.GOLD_LEGGINGS),
		new ItemStack(Material.GOLD_BOOTS),
		new ItemStack(Material.IRON_HELMET),
		new ItemStack(Material.IRON_CHESTPLATE),
		new ItemStack(Material.IRON_LEGGINGS),
		new ItemStack(Material.IRON_BOOTS),
		new ItemStack(Material.DIAMOND, 1),
	};
	
	public static ItemStack[] tier3 = {
		new ItemStack(Material.RED_MUSHROOM, 3),
		new ItemStack(Material.RED_MUSHROOM, 5),
		new ItemStack(Material.BROWN_MUSHROOM, 3),
		new ItemStack(Material.BROWN_MUSHROOM, 5),
		new ItemStack(Material.BOWL),
		new ItemStack(Material.BOWL),
		new ItemStack(Material.STICK),
		new ItemStack(Material.STICK),
		new ItemStack(Material.FEATHER, 2),
		new ItemStack(Material.FEATHER, 4),
		new ItemStack(Material.STRING, 5),
		new ItemStack(Material.FLINT, 4),
		new ItemStack(Material.GOLD_INGOT, 2),
		new ItemStack(Material.COOKED_BEEF, 1),
		new ItemStack(Material.COOKED_CHICKEN, 1),
		new ItemStack(Material.COOKED_FISH, 1),
		new ItemStack(Material.COOKED_BEEF, 2),
		new ItemStack(Material.COOKED_CHICKEN, 2),
		new ItemStack(Material.COOKED_FISH, 2),
		new ItemStack(Material.STONE_SWORD),
		new ItemStack(Material.STONE_SWORD),
		new ItemStack(Material.STONE_AXE),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.ARROW, 8),
		new ItemStack(Material.BOW),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.MUSHROOM_SOUP),
		new ItemStack(Material.IRON_INGOT, 1),
		new ItemStack(Material.IRON_INGOT, 2),
		new ItemStack(Material.IRON_INGOT, 3),
		new ItemStack(Material.IRON_INGOT, 4),
		new ItemStack(Material.CHAINMAIL_HELMET),
		new ItemStack(Material.CHAINMAIL_CHESTPLATE),
		new ItemStack(Material.CHAINMAIL_LEGGINGS),
		new ItemStack(Material.CHAINMAIL_BOOTS),
		new ItemStack(Material.IRON_HELMET),
		new ItemStack(Material.IRON_CHESTPLATE),
		new ItemStack(Material.IRON_LEGGINGS),
		new ItemStack(Material.IRON_BOOTS),
		new ItemStack(Material.GOLDEN_APPLE),
		new ItemStack(Material.GOLDEN_APPLE, 2),
		new ItemStack(Material.IRON_SWORD),
		new ItemStack(Material.IRON_SWORD),
		new ItemStack(Material.IRON_SWORD),
		new ItemStack(Material.IRON_AXE),
		new ItemStack(Material.DIAMOND, 1),
		new ItemStack(Material.DIAMOND, 2),
		new ItemStack(Material.DIAMOND_BOOTS, 1),
	};
	
	@EventHandler
	public void onOpenEnder(PlayerInteractEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			try {
				if(event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock().getType() == Material.ENDER_CHEST)
					event.setCancelled(true);
			} catch(Exception e) {
				
			}
		}
	}
	
	public static ItemStack[] generateTier(int tier) {
		ArrayList<ItemStack> items = new ArrayList<ItemStack>();
		int numItems = (int)(Math.random() * (2 * tier) + 4);
		for(int k = 0; k < numItems; k++) {
			switch(tier) {
				case 1:
					items.add(tier1[(int)(Math.random() * tier1.length)].clone());
					break;
				case 2:
					items.add(tier2[(int)(Math.random() * tier2.length)].clone());
					break;
				case 3:
					items.add(tier3[(int)(Math.random() * tier3.length)].clone());
					break;
			}
		}
		return items.toArray(new ItemStack[items.size()]);
	}
	
	public static ItemStack compass = null;
	
	public HashMap<String, Location> freeze = new HashMap<String, Location>();
	
	@EventHandler
	public void onfreezemove(PlayerMoveEvent event) {
		if(world != null && world.equals(event.getPlayer().getWorld())) {
			if(freeze.containsKey(event.getPlayer().getName())) {
				if(Math.abs(event.getPlayer().getLocation().getX() - freeze.get(event.getPlayer().getName()).getX()) > 0.8 || 
						Math.abs(event.getPlayer().getLocation().getZ() - freeze.get(event.getPlayer().getName()).getZ()) > 0.8) {
					event.getPlayer().teleport(freeze.get(event.getPlayer().getName()));
				}
			}
		}
	}
	
	@EventHandler
	public void onProjHit(ProjectileHitEvent event) {
		if(world != null && world.equals(event.getEntity().getWorld())) {
			if(event.getEntity() instanceof Snowball) {
				if(event.getEntity().getShooter() instanceof Player) {
					Player p = (Player)event.getEntity().getShooter();
					if(p != null && RankManager.check(p, "knight")) {
						HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
						particles.add(new ParticleDetails(ParticleType.SMOKE));
						particles.add(new ParticleDetails(ParticleType.CLOUD));
						particles.add(new ParticleDetails(ParticleType.CRITICAL));
						particles.add(new ParticleDetails(ParticleType.FIRE));
						particles.add(new ParticleDetails(ParticleType.EMBER));
						particles.add(new ParticleDetails(ParticleType.FIREWORKSPARK));
						particles.add(new ParticleDetails(ParticleType.POTION));
						event.getEntity().getWorld().playSound(event.getEntity().getLocation(), Sound.EXPLODE, 1, 1);
						Location loc = event.getEntity().getLocation();
						for(Entity e : event.getEntity().getNearbyEntities(5.0, 5.0, 5.0)) {
							if(e instanceof Player && e != p) {
								((Player)e).addPotionEffect(PotionEffectType.SLOW.createEffect(20*7, 0));
								((Player)e).addPotionEffect(PotionEffectType.CONFUSION.createEffect(20*7, 0));
								((Player)e).addPotionEffect(PotionEffectType.BLINDNESS.createEffect(20*5, 0));
							}
						}
						for(int dx = -2; dx <= 2; dx++) {
							for(int dz = -2; dz <= 2; dz++) {
								for(int dy = -2; dy <= 2; dy++) {
									final EffectHolder holder = EffectCreator.createLocHolder(particles, loc.clone().add(dx,dy,dz));
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
										public int count = 3;
										public void run() {
											if(Math.random() < 0.2) {
												holder.setRunning(true);
												holder.update();
												holder.setRunning(false);
											}
											if(count-- > 0) {
												plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20);
											}
										}
									});
								}
							}
						}
					}
				}
			}
		}
	}
	
	@Override
	protected void postEnter(Player p) {
		freeze.put(p.getName(), p.getLocation());
		p.setWalkSpeed(0.2f);
//		if(plugin.getRank(p) >= Values.RANK_KNIGHT) {
//			ItemStack item = new ItemStack(Material.SNOW_BALL);
//			ItemMeta im = item.getItemMeta();
//			im.setDisplayName(ChatColor.DARK_AQUA + "VIP Escape Bomb");
//			im.setLore(Arrays.asList(new String[]{ChatColor.YELLOW + "Throw it and run!", ChatColor.YELLOW + "Only works for VIPs."}));
//			item.setItemMeta(im);
//			switch(plugin.getRank(p)) {
//				case Values.RANK_KNIGHT:
//					item.setAmount(2);
//					break;
//				case Values.RANK_NOBLE:
//					item.setAmount(4);
//					break;
//				default:
//					item.setAmount(6);
//					break;
//			}
//			p.getInventory().addItem(item);
//		}
	}

	@Override
	protected void preJoin(Player p) {
		// TODO Auto-generated method stub
		
	}
	
}
