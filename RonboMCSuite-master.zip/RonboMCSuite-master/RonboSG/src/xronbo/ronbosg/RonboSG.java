package xronbo.ronbosg;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import xronbo.common.MinigamePlugin;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;

public class RonboSG extends MinigamePlugin implements CommandExecutor, Listener {

	@Override
	public Class<? extends Game> getGameClass() {
		return SGGame.class;
	}
	
	public void onEnable() {
		super.onEnable();
		for(String s : commands) {
			try {
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void init() {
		plugin.getServer().broadcastMessage(ChatColor.RED + "Server reloading... Sending all players back to hub.");
		plugin.getServer().broadcastMessage(ChatColor.RED + "Sorry for any inconvenience.");
		for(Player p : plugin.getServer().getOnlinePlayers())
			GameManager.returnToHub(p);
	}
	
	public String[] commands = {
		"db", 
	};
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(super.onCommand(sender, cmd, label, args)) //default commands
				return true;
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("db")) {
					p.sendMessage("hi");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public String[] getExtraInfo(Game g) {
		return new String[] {"Map: " + g.currentMapDisplayName, "Spectators: " + g.spectators.size()};
	}
	
}
