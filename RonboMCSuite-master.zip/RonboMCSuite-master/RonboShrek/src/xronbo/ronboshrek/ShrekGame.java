package xronbo.ronboshrek;

import java.util.ArrayList;

import net.minecraft.server.v1_7_R3.EntityInsentient;

import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_7_R3.entity.CraftLivingEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.DisplaySlot;

import xronbo.common.SQLManager;
import xronbo.common.SoundHandler;
import xronbo.common.entitytypes.CustomZombie;
import xronbo.common.games.Game;

public class ShrekGame extends Game {

	public ShrekGame(int id) {
		super(id);
	}

	@Override
	protected double[] getSpawnLoc(Player p) {
		Location loc = findValidLocation();
		System.out.println("found location 1" + loc);
		return locToDoubleArray(loc);
	}
	
	public Location findValidLocation() {
		int count = 0;
		while(count++ < 30) {
			int x = (int)(Math.random() * (269 - 187 + 1) + 187);
			int y = 14;
			int z = (int)(Math.random() * (126 - 36 + 1) + 36);
			if(getWorld().getBlockAt(x,y,z).getType() == Material.AIR)
				return getWorld().getBlockAt(x,y,z).getLocation().add(0.5,0.3,0.5);
		}
		return new Location(getWorld(), 269, 14, 126, (float)-229.94867, (float)9.000034);
	}

	@EventHandler
	public void onfoodchange(FoodLevelChangeEvent event) {
		event.setFoodLevel(20);
	}
	
	@Override
	protected void postWorldLoad() {
		getWorld().setTime(13000);
	}

	public void createShrek(Location loc) {
		final LivingEntity le = RonboShrek.createLivingEntity(CustomZombie.class, loc);
		le.setCustomName(ChatColor.DARK_GREEN+ "" + ChatColor.BOLD + "Shrek");
		le.setCustomNameVisible(true);
		EntityEquipment ee = le.getEquipment();
		ItemStack helmet = new ItemStack(Material.LEATHER_HELMET);
		ItemMeta im = helmet.getItemMeta();
		((LeatherArmorMeta)im).setColor(Color.GREEN);
		helmet.setItemMeta(im);
		ItemStack chestplate = new ItemStack(Material.LEATHER_CHESTPLATE);
		im = chestplate.getItemMeta();
		((LeatherArmorMeta)im).setColor(Color.GREEN);
		chestplate.setItemMeta(im);
		ItemStack leggings = new ItemStack(Material.LEATHER_LEGGINGS);
		im = leggings.getItemMeta();
		((LeatherArmorMeta)im).setColor(Color.GREEN);
		leggings.setItemMeta(im);
		ItemStack boots = new ItemStack(Material.LEATHER_BOOTS);
		im = boots.getItemMeta();
		((LeatherArmorMeta)im).setColor(Color.GREEN);
		boots.setItemMeta(im);
		ee.setArmorContents(new ItemStack[] {helmet, chestplate, leggings, boots});
		ee.setItemInHandDropChance(0);
		ee.setHelmetDropChance(0);
		ee.setChestplateDropChance(0);
		ee.setLeggingsDropChance(0);
		ee.setBootsDropChance(0);
		le.setMetadata("invincible", new FixedMetadataValue(plugin, 1));
		le.setMaxHealth(100000.0);
		le.setHealth(100000.0);
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public String target = "";
			public long lastNewTarget = 0;
			public void run() {
				if(!inProgress) {
					le.remove();
					return;
				}
				Location loc = null;
				if(players.size() > 0 && System.currentTimeMillis() - lastNewTarget > 30000 || plugin.getServer().getPlayerExact(target) == null || !plugin.getServer().getPlayerExact(target).getWorld().equals(le.getWorld()))
					target = players.get((int)(Math.random() * players.size()));
				loc = plugin.getServer().getPlayerExact(target).getLocation();
				ItemStack helmet = new ItemStack(Material.LEATHER_HELMET);
				ItemMeta im = helmet.getItemMeta();
				((LeatherArmorMeta)im).setColor(Color.GREEN);
				helmet.setItemMeta(im);
				le.getEquipment().setHelmet(helmet);
				for(Entity e : le.getNearbyEntities(10, 10, 10)) {
					if(!(e instanceof Player))
						continue;
					if(!e.hasMetadata("lastmessage") || (e.hasMetadata("lastmessage") && System.currentTimeMillis() - e.getMetadata("lastmessage").get(0).asLong() > 5000)) {
						((Player)e).sendMessage(ChatColor.RED + "Oh no! There is a Shrek near you. Run!!!");
					}
					((Player)e).addPotionEffect(PotionEffectType.SLOW.createEffect(12 * 20, 2));
					if(Math.random() < 0.1)
						SoundHandler.playSound((Player)e, Sound.ZOMBIE_IDLE);
					e.setMetadata("lastmessage", new FixedMetadataValue(plugin, System.currentTimeMillis()));
				}
				for(Entity e : le.getNearbyEntities(5, 5, 5)) {
					if(!(e instanceof Player))
						continue;
					if(Math.random() < 0.1)
						SoundHandler.playSound((Player)e, Sound.ZOMBIE_WALK);
					((Player)e).addPotionEffect(PotionEffectType.CONFUSION.createEffect(12 * 20, 2));
				}
				for(Entity e : le.getNearbyEntities(0.3, 0.3, 0.3)) {
					if(e instanceof Player) {
						shrek((Player)e);
					}
				}
				if(loc != null) {
					((EntityInsentient) ((CraftLivingEntity) le).getHandle()).getNavigation().a(loc.getX(), loc.getY(), loc.getZ(), 1.3f);
				}
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 3);
			}
		});
	}
	
	@EventHandler
	public void ondamage(EntityDamageEvent event) {
		if(event.getEntity() instanceof Zombie)
			event.getEntity().setFireTicks(0);
	}
	
	@EventHandler
	public void onmove(PlayerMoveEvent event) {
		if(event.getPlayer().hasMetadata("shrekt"))
			event.setCancelled(true);
	}
	
	public ArrayList<String> shrekt = new ArrayList<String>();
	public void shrek(Player p) {
		if(shrekt.contains(p.getName()))
			return;
		shrekt.add(p.getName());
		message(ChatColor.RED + p.getName() + " just got Shrekt!");
		p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Hello, " + p.getName() + ". It's all ogre now...");
		p.setMetadata("shrekt", new FixedMetadataValue(plugin, 0));
		p.addPotionEffect(PotionEffectType.SLOW.createEffect(200000, 5));
		final String name = p.getName();
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				if(plugin.getServer().getPlayerExact(name) == null || plugin.getServer().getPlayerExact(name).isDead())
					return;
				plugin.getServer().getPlayerExact(name).damage(2.0);
				if(!plugin.getServer().getPlayerExact(name).isDead())
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
				else
					plugin.getServer().getPlayerExact(name).removeMetadata("shrekt", plugin);
			}
		});
	}
	
	protected int numshreks = 0;
	
	@Override
	protected void postAllEnter() {
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				message(ChatColor.RED + "" + ChatColor.BOLD + "5 NEW SHREKS HAVE COME! RUN!");
				if(!inProgress)
					return;
				for(int k = 0; k < 5; k++)
					createShrek(findValidLocation());
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20 * 30);
			}
		}, 20 * 2);
	}

	@Override
	protected void postEnter(Player p) {
		p.removeMetadata("shrekt", plugin);
		p.addPotionEffect(PotionEffectType.BLINDNESS.createEffect(200000, 1));
		p.getWorld().playEffect(p.getLocation(), Effect.RECORD_PLAY, Material.RECORD_11.getId());
		final String name = p.getName();
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				Player p = plugin.getServer().getPlayerExact(name);
				if(p == null)
					return;
				p.getWorld().playEffect(p.getLocation(), Effect.RECORD_PLAY, Material.RECORD_11.getId());
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20*(1*60+11));
			}
		}, 20*(1*60+11));
	}

	@Override
	protected boolean checkEndCondition() {
		if(players.size() <= 1) {
			if(players.size() > 0) {
				Player p = plugin.getServer().getPlayerExact(players.get(0));
				if(p != null) {
					p.sendMessage(ChatColor.GOLD + "Congratulations! You get 10 BP for winning a game of Shrekt!");
				}
				SQLManager.execute("update ronbo set points = points + 10 where name = '" + players.get(0) + "'");
			}
		}
		return players.size() <= 1;
	}

	@Override
	protected void objectiveTask() {
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public void run() {
				if(side!= null)
					side.unregister();
				side = board.registerNewObjective("players", "dummy");
				side.setDisplayName("Players Left");
				side.setDisplaySlot(DisplaySlot.SIDEBAR);
				for(String s : players)
					side.getScore(s).setScore(1);
			}
		}, 20, 20);
	}
	
}
