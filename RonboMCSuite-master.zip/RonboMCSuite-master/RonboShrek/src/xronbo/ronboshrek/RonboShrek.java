package xronbo.ronboshrek;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.server.v1_7_R3.EntityLiving;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_7_R3.CraftWorld;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import xronbo.common.ChatManager;
import xronbo.common.GeneralManager;
import xronbo.common.SQLManager;
import xronbo.common.TipHandler;
import xronbo.common.Values;
import xronbo.common.entitytypes.CustomEntityType;
import xronbo.common.games.Game;
import xronbo.common.games.GameManager;
import xronbo.common.hpbar.HPBar;

public class RonboShrek extends JavaPlugin implements CommandExecutor, Listener {
	
	public static final boolean FAST_MODE = true;
	
	public static GameManager gm;
	public void onEnable() {
		plugin = this;
		CustomEntityType.registerEntities();
		SQLManager.loadSQLConnection(this);
		getServer().getPluginManager().registerEvents(this, this);
		getServer().getPluginManager().registerEvents(new HPBar(this), this);
		getServer().getPluginManager().registerEvents(new GeneralManager(this), this);
		getServer().getPluginManager().registerEvents(new ChatManager(this), this);
		getServer().getPluginManager().registerEvents(gm = new GameManager(this), this);
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "MinigameInfo");
		Bukkit.getMessenger().registerIncomingPluginChannel(this, "MinigameTransfer", gm);
		TipHandler.plugin = this;
		for(String s : commands)
			try {
				getCommand(s).setExecutor(this);
			} catch(Exception e) {
				e.printStackTrace();
			}
//		loadWorlds();
		init();
		getLogger().info("Loaded Ronbo Shrek");
	}
	
	public static long startTime;
	
	public void init() {
		plugin.getServer().broadcastMessage(ChatColor.RED + "Server reloading... Sending all players back to hub.");
		plugin.getServer().broadcastMessage(ChatColor.RED + "Sorry for any inconvenience.");
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				for(Player p : plugin.getServer().getOnlinePlayers()) {
					loadPlayer(p);
					GameManager.add(p, 0, false);
				}
			}
		}, 50);
	}

	public void loadWorlds() {
		for(File f : new File("./").listFiles()) {
			if(f.isDirectory()) {
				boolean isWorld = false;
				for(File f2 : f.listFiles()) {
					if(f2.getPath().toString().contains("session.lock")) {
						isWorld = true;
						break;
					}
				}
				if(isWorld) {
					getServer().createWorld(new WorldCreator(f.toPath().toString().substring(f.toPath().toString().lastIndexOf(File.separator) + 1)));
				}
			}
		}
		System.out.println("Loaded " + getServer().getWorlds().size() + " worlds.");
	}
	
	public static ConcurrentHashMap<String, Integer> ranks = new ConcurrentHashMap<String, Integer>();
	
	public static final boolean TEST_MODE = false;
	public int getRank(Player p) {
		if(TEST_MODE)
			return Values.RANK_OWNER;
		if(ranks.containsKey(p.getName()))
			return ranks.get(p.getName());
		else
			return 1;
	}
	
	public void loadPlayer(final Player p) {
		final String uuid = p.getUniqueId().toString();
		final String name = p.getName();
		p.teleport(plugin.getServer().getWorld("world").getSpawnLocation().add((int)(Math.random() * 7 - 3), 0, (int)(Math.random() * 7 - 3)));
		p.getInventory().clear();
		p.setScoreboard(plugin.getServer().getScoreboardManager().getMainScoreboard());
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				try {
					ResultSet rs = SQLManager.executeQuery("select rankString from ronbo where uuid = '" + uuid + "'");
					if(rs.next())
						ranks.put(name, ChatManager.getRankFromString(rs.getString("rankString")));
					else
						ranks.put(name, 1);
					plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
						public void run() {
							if(getRank(p) < Values.RANK_ADMIN) {
								p.setAllowFlight(false);
								p.setGameMode(GameMode.SURVIVAL);
								p.setOp(false);
							}
						}
					});
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
		p.sendMessage(ChatColor.GREEN + "");
		p.sendMessage(ChatColor.GOLD + "Welcome to Shrekt!");
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		loadPlayer(event.getPlayer());
		event.setJoinMessage("");
	}
	
	@EventHandler
	public void onPlayerLeave(PlayerQuitEvent event) {
		Player p = event.getPlayer();
		ranks.remove(p.getName());
		event.setQuitMessage("");
	}
	
	public static LivingEntity createLivingEntity(Class<?> type, Location loc) {
		net.minecraft.server.v1_7_R3.World world = ((CraftWorld)(loc.getWorld())).getHandle();
		net.minecraft.server.v1_7_R3.EntityLiving e = null;
		try {
			e = (EntityLiving) (type.getDeclaredConstructor(net.minecraft.server.v1_7_R3.World.class).newInstance(world));
		} catch(Exception e2) {
			e2.printStackTrace();
		}
		e.setPosition(loc.getX(), loc.getY(), loc.getZ());
		world.addEntity(e, SpawnReason.CUSTOM);
		LivingEntity le = (LivingEntity)(((net.minecraft.server.v1_7_R3.Entity)e).getBukkitEntity());
		le.setRemoveWhenFarAway(false);
		return le;
	}
	
	
	public static String[] commands = {
		"db", "teleport", "changeworld", "hub", "loc", "setspawn", "spawn", "fly", "speed", "killall", "checkworld", "stats"
	};
	
	public static ArrayList<String> switchedToVip = new ArrayList<String>();
	
	public static void sendToHub(Player p) {
		p.sendMessage(ChatColor.GREEN + "Sending you to the Kastia Lobby...");
		ByteArrayOutputStream b = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(b);
		try {
			out.writeUTF("Connect");
			out.writeUTF("hub");
		} catch (IOException e) {
			e.printStackTrace();
		}
		p.sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
	}
	
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		try {
			if(sender instanceof Player) {
				final Player p = (Player)sender;
				if(cmd.getName().equalsIgnoreCase("db")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						
					}
				}
				if(cmd.getName().equalsIgnoreCase("killall")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						for(Entity e : p.getWorld().getEntities())
							if(!(e instanceof Player))
								e.remove();
					}
				}
				if(cmd.getName().equalsIgnoreCase("teleport")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						try {
							int x = Integer.parseInt(args[0]);
							int y = Integer.parseInt(args[1]);
							int z = Integer.parseInt(args[2]);
							Location loc = new Location(p.getWorld(), x, y, z);
							p.teleport(loc);
						} catch(Exception e) {
							p.sendMessage("Use as /teleport x y z");
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("changeworld")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						if(args.length > 0) {
							World w = null;
							StringBuilder worldName = new StringBuilder("");
							for(String s : args)
								worldName.append(s + " ");
							worldName = new StringBuilder(worldName.substring(0, worldName.length() - 1));
							for(World w2 : plugin.getServer().getWorlds()) {
								if(w2.getName().equalsIgnoreCase(worldName.toString()))
									w = w2;
							}
							if(w == null) {
								p.sendMessage(ChatColor.RED + "Invalid world name! (" + worldName.toString() + ")");
								StringBuilder sb = new StringBuilder("Valid world names: ");
								for(World w2 : plugin.getServer().getWorlds())
									if(!w2.getName().contains("+di+"))
										sb.append(w2.getName() + ", ");
								p.sendMessage(sb.substring(0, sb.length() - 2));
								return true;
							}
							p.teleport(w.getSpawnLocation());
						} else {
							StringBuilder sb = new StringBuilder("Valid world names: ");
							for(World w2 : plugin.getServer().getWorlds())
									sb.append(w2.getName() + ", ");
							p.sendMessage(sb.substring(0, sb.length() - 2));
						}
					}
				}
				if(cmd.getName().equalsIgnoreCase("hub")) {
					sendToHub(p);
				}
				if(cmd.getName().equalsIgnoreCase("loc")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						String s = (int)p.getLocation().getBlockX() + ", " + (int)p.getLocation().getBlockY() + ", " + (int)p.getLocation().getBlockZ() + ", " + p.getLocation().getYaw() + ", " + p.getLocation().getPitch();
						p.sendMessage(s);
						StringSelection selection = new StringSelection(s);
						Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
						clipboard.setContents(selection, selection);
					}
				}
				if(cmd.getName().equalsIgnoreCase("checkworld")) {
					p.sendMessage(p.getWorld().getName());
				}
				if(cmd.getName().equalsIgnoreCase("setspawn")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						p.getWorld().setSpawnLocation(p.getLocation().getBlockX(), p.getLocation().getBlockY(), p.getLocation().getBlockZ());
						p.sendMessage("set spawn to " + p.getWorld().getSpawnLocation());
					}
				}
				if(cmd.getName().equalsIgnoreCase("spawn")) {
					if(p.getWorld().getName().equals("world") || getRank(p) >= Values.RANK_ADMIN)
						p.teleport(p.getWorld().getSpawnLocation());
				}
				if(cmd.getName().equalsIgnoreCase("fly")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						p.setAllowFlight(!p.getAllowFlight());
						p.teleport(p.getLocation().add(0,2,0));
						if(p.getAllowFlight())
							p.setFlying(true);
						p.sendMessage("flying " + (p.getAllowFlight() ? "enabled" : "disabled"));
					}
				}
				if(cmd.getName().equalsIgnoreCase("speed")) {
					if(getRank(p) >= Values.RANK_ADMIN) {
						p.setFlySpeed(Float.parseFloat(args[0]));
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void onDisable() {
		CustomEntityType.unregisterEntities();
		plugin.getServer().getScheduler().cancelAllTasks();
		for(Game g : GameManager.games.values())
			g.deleteWorld(true);
		getLogger().info("Disabling Ronbo Sky...");
	}
	
	public static RonboShrek plugin;
	
}
