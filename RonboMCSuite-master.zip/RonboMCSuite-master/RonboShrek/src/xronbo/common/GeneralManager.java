package xronbo.common;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.WorldLoadEvent;

import xronbo.ronboshrek.RonboShrek;

public class GeneralManager implements Listener {
	
	@EventHandler
	public void onCreatureSpawn(CreatureSpawnEvent event) {
		if(event.getSpawnReason() != SpawnReason.CUSTOM) {
			event.setCancelled(true);
			event.getEntity().remove();
		}
	}

	@EventHandler
	public void onEntityDamageEvent(EntityDamageEvent event) {
		if(event.getCause() == DamageCause.VOID && event.getEntity() instanceof Player && event.getEntity().getWorld().equals(plugin.getServer().getWorld("world"))) {
			((Player)event.getEntity()).sendMessage(ChatColor.RED + "Woah! Careful there, pal!");
			event.getEntity().setFallDistance(0);
			event.getEntity().teleport(event.getEntity().getWorld().getSpawnLocation());
		}
	}
	
	@EventHandler
	public void onBlockCombust(BlockIgniteEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockFire(BlockBurnEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onSpread(BlockSpreadEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onWeatherChange(WeatherChangeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onThunderChange(ThunderChangeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onWorldLoad(WorldLoadEvent event) {
		World w = event.getWorld();
		if(w.hasStorm())
			w.setStorm(false);
		if(w.isThundering())
			w.setThundering(false);
	}
	
	@EventHandler
	public void onLeafDecay(LeavesDecayEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockFade(BlockFadeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockForm(BlockFormEvent event) {
		event.setCancelled(true);
	}
	
	public static RonboShrek plugin;
	public GeneralManager(RonboShrek plugin) {
		GeneralManager.plugin = plugin;
	}
}
