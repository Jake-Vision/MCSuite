package xronbo.common;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import xronbo.ronboshrek.RonboShrek;

public class TipHandler {
	
	public static RonboShrek plugin;
	
	private TipHandler() {
		
	}
	
	public static String lastSent = "";
	
	public static final String[] TIPS = {
		"Use /lobby to return to the Kastia Lobby!",
		"The Grandmaster wanders throughout the castle!",
		"Careful, the Wall Squad attacks from behind!",
		"You can't hurt your teammates.",
		"Keep a group of players near the Grandmaster.",
		"Watch out for those sneaky Dagger wielders.",
	};
	
	public static final String FORMAT = ChatColor.GREEN + "" + ChatColor.BOLD + " * Tip: " + ChatColor.RESET + "" + ChatColor.GOLD;
	
	public static void send() {
		String toSend = "";
		do {
			toSend = getRandom(TIPS);
		} while(toSend.equals(lastSent) || toSend.equals(""));
		lastSent = toSend;
		for(Player p : plugin.getServer().getOnlinePlayers())
			p.sendMessage(FORMAT + toSend);
	}
	
	public static String getRandom(String[] s) {
		return s[(int)(Math.random() * s.length)];
	}
}