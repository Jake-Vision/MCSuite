package xronbo.common;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChatEvent;

import xronbo.ronboshrek.RonboShrek;

public class ChatManager implements Listener {
	
	public String filter(String s) {
		String[] cusswords = {"2g1c","2 girls 1 cup","acrotomophilia","anal","anilingus","arsehole", "asshole","assmunch","auto erotic","autoerotic","babeland","baby batter","ball gag","ball gravy","ball kicking","ball licking","ball sack","ball sucking","bangbros","bareback","barely legal","barenaked","bastard","bastinado","bbw","bdsm","beaver cleaver","beaver lips","bestiality","bi curious","big black","big breasts","big knockers","big tits","bimbos","birdlock","bitch","black cock","blonde action","blonde on blonde action","blow j","blow your l","blue waffle","blumpkin","bollocks","bondage","booty call","brown showers","brunette action","bukkake","bulldyke","bullet vibe","bung hole","bunghole","busty","buttcheeks","butthole","camel toe","camgirl","camslut","camwhore","carpet muncher","carpetmuncher","chocolate rosebuds","circlejerk","cleveland steamer","clit","clitoris","clover clamps","clusterfuck","cock","cocks","coprolagnia","coprophilia","cornhole","cum","cumming","cunnilingus","cunt","darkie","date rape","daterape","deep throat","deepthroat","dick","dildo","dirty pillows","dirty sanchez","doggie style","doggiestyle","doggy style","doggystyle","dog style","dolcett","domination","dominatrix","dommes","donkey punch","double dong","double penetration","dp action","eat my ass","ecchi","ejaculation","erotic","erotism","escort","ethical slut","eunuch","faggot","fecal","felch","fellatio","feltch","female squirting","femdom","figging","fingering","fisting","foot fetish","footjob","frotting","fuck","fuck buttons","fudge packer","fudgepacker","futanari","gang bang","gay sex","genitals","giant cock","girl on","girl on top","girls gone wild","goatcx","goatse","gokkun","golden shower","goodpoop","goo girl","goregasm","grope","group sex","g-spot","guro","hand job","handjob","homoerotic","honkey","hooker","hot chick","how to kill","how to murder","huge fat","humping","incest","intercourse","jack off","jail bait","jailbait","jerk off","jigaboo","jiggaboo","jiggerboo","jizz","juggs","kike","kinbaku","kinkster","kinky","knobbing","leather restraint","leather straight jacket","lemon party","lolita","lovemaking","make me come","male squirting","masturbate","menage a trois","milf","missionary position","motherfucker","mound of venus","mr hands","muff diver","muffdiving","nambla","nawashi","negro","neonazi","nigga","nigger","nig nog","nimphomania","nipple","nipples","nsfw images","nude","nudity","nympho","nymphomania","octopussy","omorashi","one cup two girls","one guy one jar","orgasm","orgy","paedophile","panties","panty","pedobear","pedophile","pegging","penis","phone sex","piece of shit","pissing","piss pig","pisspig","playboy","pleasure chest","pole smoker","ponyplay","poop chute","poopchute","porn","porno","pornography","prince albert piercing","pthc","pubes","pussy","queaf","raghead","raging boner","rape","raping","rapist","rectum","reverse cowgirl","rimjob","rimming","rosy palm","rosy palm and her 5 sisters","rusty trombone","sadism","scat","schlong","scissoring","semen","sex","sexo","sexy","shaved beaver","shaved pussy","shemale","shibari","shit","shota","shrimping","slanteye","slut","s&m","smut","snatch","snowballing","sodomize","sodomy","spic","spooge","spread legs","strap on","strapon","strappado","strip club","style doggy","suicide girls","sultry women","swastika","swinger","tainted love","taste my","tea bagging","threesome","throating","tied up","tight white","tongue in a","topless","tosser","towelhead","tranny","tribadism","tub girl","tubgirl","tushy","twat","twink","twinkie","two girls one cup","undressing","upskirt","urethra play","urophilia","vagina","venus mound","vibrator","violet blue","violet wand","vorarephilia","voyeur","vulva","wank","wetback","wet dream","white power","women rapping","wrapping men","wrinkled starfish" ,"xxx","yellow showers","yiffy","zoophilia"};
		String filler = "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
		String s3 = "";
		if(s.contains("{\"text\":")) {
			int index = s.indexOf("{\"text\":");
			index = s.indexOf(":", "{\"text\":".length());
			index = s.indexOf(":", index + 1);
			if(index >= 0) {
				s3 = s.substring(0, index);
				s = s.substring(index);
			}
		}
		String lowercase = s.toLowerCase();
		for(String s2 : cusswords) {
			if(lowercase.contains(s2))
				lowercase = lowercase.replaceAll(s2, filler.substring(0, s2.length()));
		}
		if(!lowercase.equals(s.toLowerCase()))
			s = lowercase;
		return s3 + s;
	}
	
	public static String getRankName(int rank) {
		switch(rank) {
			case Values.RANK_MEMBER:
				return "Member";
			case Values.RANK_KNIGHT:
				return "Knight";
			case Values.RANK_NOBLE:
				return "Noble";
			case Values.RANK_ROYAL:
				return "Royal";
			case Values.RANK_ALPHA:
				return "Alpha";
			case Values.RANK_WRITER:
				return "Writer";
			case Values.RANK_GFX:
				return "GFX Artist";
			case Values.RANK_HELPER:
				return "Helper";
			case Values.RANK_VIDEO:
				return "Youtuber";
			case Values.RANK_BUILDER:
				return "Builder";
			case Values.RANK_MOD:
				return "Moderator";
			case Values.RANK_ADMIN:
				return "Administrator";
			case Values.RANK_OWNER:
				return "Owner";
		}
		return "Member";
	}

	public static String getChatPrefix(int rank) {
		String pre = ChatColor.RESET + "[";
		String mid = "";
		String end = ChatColor.RESET + "] ";
		switch(rank) {
			case Values.RANK_MEMBER:
				return "";
			case Values.RANK_KNIGHT:
				mid = ChatColor.GOLD + "Knight";
				break;
			case Values.RANK_NOBLE:
				mid = ChatColor.GOLD + "Noble";
				break;
			case Values.RANK_ROYAL:
				mid = ChatColor.GOLD + "Royal";
				break;
			case Values.RANK_ALPHA:
				mid = ChatColor.RED + "Alpha";
				break;
			case Values.RANK_WRITER:
				mid = ChatColor.DARK_BLUE + "Writer";
				break;
			case Values.RANK_GFX:
				mid = ChatColor.DARK_PURPLE + "GFX";
				break;
			case Values.RANK_HELPER:
				mid = ChatColor.BLUE + "Helper";
				break;
			case Values.RANK_VIDEO:
				mid = ChatColor.GOLD + "Youtube";
				break;
			case Values.RANK_BUILDER:
				mid = ChatColor.AQUA + "Builder";
				break;
			case Values.RANK_MOD:
				mid = ChatColor.GREEN + "Mod";
				break;
			case Values.RANK_ADMIN:
				mid = ChatColor.LIGHT_PURPLE + "Admin";
				break;
			case Values.RANK_OWNER:
				mid = ChatColor.YELLOW + "Owner";
				break;
		}
		return pre + mid + end;
	}
	
	public static String getSuffix(int rank) {
		switch(rank) {
			case Values.RANK_MEMBER:
				return ChatColor.WHITE + "Member";
			case Values.RANK_KNIGHT:
				return ChatColor.GOLD + "Knight";
			case Values.RANK_NOBLE:
				return ChatColor.GOLD + "Noble";
			case Values.RANK_ROYAL:
				return ChatColor.GOLD + "Royal";
			case Values.RANK_ALPHA:
				return ChatColor.RED + "Alpha";
			case Values.RANK_WRITER:
				return ChatColor.DARK_BLUE + "Writer";
			case Values.RANK_GFX:
				return ChatColor.DARK_PURPLE + "GFX";
			case Values.RANK_HELPER:
				return ChatColor.BLUE + "Helper";
			case Values.RANK_VIDEO:
				return ChatColor.GOLD + "Youtube";
			case Values.RANK_BUILDER:
				return ChatColor.AQUA + "Builder";
			case Values.RANK_MOD:
				return  ChatColor.GREEN + "Mod";
			case Values.RANK_ADMIN:
				return ChatColor.LIGHT_PURPLE + "Admin";
			case Values.RANK_OWNER:
				return ChatColor.YELLOW + "Owner";
		}
		return "";
	}

	public static int getRankFromString(String rankString) {
		int rank = 1;
		if(rankString == null) {
			rank = 1;
		} else {
			try {
				rank = 1;
				rank = (int)Values.class.getField("RANK_" + rankString.toUpperCase()).get(Values.values);
			} catch (Exception e) {
				rank = 1;
			}
		}
		return rank;
	}
	
	public String rankFormat(int rank, String message) {
		StringBuilder sb = new StringBuilder("");
		ChatColor color = ChatColor.GRAY;
		if(rank >= Values.RANK_KNIGHT)
			color = ChatColor.WHITE;
		if(rank == Values.RANK_MOD)
			color = ChatColor.GREEN;
		if(rank == Values.RANK_ADMIN)
			color = ChatColor.LIGHT_PURPLE;
		if(rank == Values.RANK_OWNER)
			color = ChatColor.AQUA;
		for(String s : message.split(" "))
			sb.append(color + s + " ");
		return sb.toString();
	}
	
	@EventHandler
	public void onPlayerChat(PlayerChatEvent event) {
		Player p = event.getPlayer();
		String name =  p.getName();
		if(name.equals("xRonbo"))
			name = ChatColor.GOLD + p.getName();
		String s = getChatPrefix(plugin.getRank(p)) + name + ChatColor.WHITE + ": " + rankFormat(plugin.getRank(p), filter(event.getMessage()));
		event.setCancelled(true);
		for(Player p2 : plugin.getServer().getOnlinePlayers())
			p2.sendMessage(s);
		System.out.print(ChatColor.stripColor(s));
	}
	
	public static RonboShrek plugin;
	public ChatManager(RonboShrek plugin) {
		ChatManager.plugin = plugin;
	}
}
