package xronbo.common.games;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import net.minecraft.util.org.apache.commons.io.FileUtils;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import xronbo.common.Values;
import xronbo.ronboshrek.RonboShrek;

public abstract class Game implements Listener {

	protected int id;
	protected Scoreboard board;
	protected Objective side;
	protected ArrayList<String> players = new ArrayList<String>();
	protected boolean inProgress = false;
	protected boolean joinable = true;
	protected volatile String currentMapDisplayName = "";
	protected volatile String currentMapWorldTemplateName = "";
	protected volatile int currentId = 0;
	
	protected static int worldId = (int)(Math.random() * 33);
	
	protected abstract double[] getSpawnLoc(Player p);
	
	private World world = null;
	protected World getWorld() {
		return world;
	}
	
	private synchronized void createNewWorld() { //must be called within async thread!
		currentId = worldId += (int)(Math.random() * 33);
		File from = new File(currentMapWorldTemplateName + "_template");
		File to = new File(currentMapWorldTemplateName + "_" + currentId);
		try {
			FileUtils.copyDirectory(from, to);
			for(File f : to.listFiles())
				if(f.getName().contains("uid.dat"))
					f.delete();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteWorld() {
		deleteWorld(false);
	}
	
	public void deleteWorld(boolean forced) {
		if(world == null) {
			return;
		}
		for(Entity e : world.getEntities()) {
			if(e instanceof Player) {
				e.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
			}
		}
		plugin.getServer().unloadWorld(world, false);
		final File toDelete = new File(currentMapWorldTemplateName + "_" + currentId);
		if(forced) {
			FileUtils.deleteQuietly(toDelete);
		} else {
			plugin.getServer().getScheduler().runTaskLaterAsynchronously(plugin, new Runnable() {
				public void run() {
					FileUtils.deleteQuietly(toDelete);
				}
			}, 100);
		}
	}
	
	protected abstract void postWorldLoad();
	
	protected volatile boolean beginning = false;
	
	protected void begin() {
		if(beginning)
			return;
		beginning = true;
		deleteWorld();
		message(ChatColor.GREEN + "Preparing game world...");
		System.out.println("Game " + id + " is beginning.");
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				createNewWorld();
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public void run() {
						world = plugin.getServer().createWorld(new WorldCreator(currentMapWorldTemplateName + "_" + currentId));
						world.setAutoSave(false);
						world.setKeepSpawnInMemory(false);
						world.setTime(0);
						System.out.println("Loaded world " + world.getName() + " for Game " + id + ".");
						postWorldLoad();
						for(Entity e : getWorld().getEntities()) {
							if(e instanceof Item || (e instanceof LivingEntity && !(e instanceof Player)))
								e.remove();
						}
						checkPlayers();
						inProgress = true;
						joinable = GameManager.JOINABLE_AFTER_START;
						for(String s : players) {
							Player p = plugin.getServer().getPlayerExact(s);
							enterGame(p);
						}
						message(ChatColor.GOLD + GameManager.GAME_NAME + " has begun!!!");
						beginning = false;
						postAllEnter();
					}
				});
			}
		});
		
	}
	
	protected abstract void postAllEnter();
	
	protected Location doubleArrayToLoc(double[] d) {
		return new Location(getWorld(), d[0], d[1], d[2], (float)d[3], (float)d[4]);
	}
	
	protected double[] locToDoubleArray(Location loc) {
		return new double[] {loc.getX(), loc.getY(), loc.getZ(), loc.getPitch(), loc.getYaw()};
	}
	
	protected void enterGame(Player p) {
		Location loc = doubleArrayToLoc(getSpawnLoc(p));
		p.teleport(loc);
		p.getInventory().clear();
		p.getInventory().setArmorContents(new ItemStack[p.getInventory().getArmorContents().length]);
		for(PotionEffect pe : p.getActivePotionEffects())
			p.removePotionEffect(pe.getType());
		p.setGameMode(GameMode.SURVIVAL);
		p.setAllowFlight(false);
		p.setHealth(20.0);
		p.setMaxHealth(20.0);
		p.setFoodLevel(19);
		p.setFallDistance(0);
		postEnter(p);
	}
	
	protected abstract void postEnter(Player p);
	
	protected void checkPlayers() {
		ArrayList<String> toRemove = new ArrayList<String>();
		for(String s : players) {
			Player p = plugin.getServer().getPlayerExact(s);
			if(p == null) {
				toRemove.add(s);
			}
		}
		players.remove(toRemove);
	}
	
	private boolean counting = false;
	protected void scheduleStart() {
		if(counting)
			return;
		counting = true;
		String[] s = GameManager.WORLD_NAMES[(int)(Math.random() * GameManager.WORLD_NAMES.length)];
		currentMapWorldTemplateName = s[0];
		currentMapDisplayName = s[1];
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public int countdown = GameManager.COUNTDOWN_LENGTH;
			public void run() {
				checkPlayers();
				if(countdown <= 0) {
					begin();
					counting = false;
				} else {
					if(players.size() >= GameManager.PLAYERS_TO_START) {
						if(countdown % 5 == 0 || countdown <= 5)
							message(ChatColor.GREEN + GameManager.GAME_NAME + " is starting in " + countdown + " seconds!");
						countdown--;
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 20);
					} else {
						int needed = (GameManager.PLAYERS_TO_START - players.size()) ;
						counting = false;
						message(ChatColor.RED + "Countdown canceled. " + needed + " more player" + (needed > 1 ? "s are" : " is") + " needed to begin!");
					}
				}
			}
		});
	}
	
	public void end() {
		inProgress = false;
		joinable = true;
		players.clear();
		if(getWorld() != null) {
			for(Entity e : getWorld().getEntities()) {
				if(e instanceof Player) {
					Player p = (Player)e;
					p.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
					p.getInventory().clear();
					giveHub(p);
				}
			}
		}
		deleteWorld();
	}
	
	protected void message(String s) {
		for(String s2 : players) {
			Player p = plugin.getServer().getPlayerExact(s2);
			if(p != null && GameManager.getGame(p) == this) {
				p.sendMessage(s);
			}
		}
	}
	
	protected void join(Player p) {
		players.add(p.getName());
		p.setScoreboard(board);
		for(PotionEffect pe : p.getActivePotionEffects())
			p.removePotionEffect(pe.getType());
		p.setGameMode(GameMode.SURVIVAL);
		p.setAllowFlight(false);
		p.setHealth(20.0);
		p.setFoodLevel(19);
		if(!inProgress) {
			if(players.size() >= GameManager.PLAYERS_TO_START) {
				scheduleStart();
			} else {
				int needed = (GameManager.PLAYERS_TO_START - players.size());
				message(ChatColor.YELLOW + "Waiting for " + needed  + " more player" + (needed > 1 ? "s" : "") + " to begin " + ChatColor.BOLD + GameManager.GAME_NAME + ChatColor.YELLOW + "...");
			}
		} else {
			enterGame(p);
		}
	}
	
	@EventHandler
	public void opq(PlayerQuitEvent event) {
		for(Game g : GameManager.games.values())
			g.leave(event.getPlayer());
	}
	
	@EventHandler
	public void opd(PlayerDeathEvent event) {
		if(GameManager.SHOW_DEATH_MESSAGE) {
			if(GameManager.getGame(event.getEntity()) != null) {
				GameManager.getGame(event.getEntity()).message(event.getDeathMessage());
			}
		}
		if(GameManager.LEAVE_ON_DEATH)
			for(Game g : GameManager.games.values())
				g.leave(event.getEntity());
		event.setDeathMessage("");
	}
	
	@EventHandler
	public void or(PlayerRespawnEvent event) {
		if(!GameManager.LEAVE_ON_DEATH) {
			if(GameManager.getGame(event.getPlayer()) != null) {
				Location loc = doubleArrayToLoc(GameManager.getGame(event.getPlayer()).getSpawnLoc(event.getPlayer()));
				event.setRespawnLocation(loc);
			}
		} else {
			event.setRespawnLocation(plugin.getServer().getWorld("world").getSpawnLocation());
		}
	}

	@EventHandler
	public void oed(EntityDamageEvent event) {
		if(event.getEntity().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(event.getEntity().hasMetadata("invincible"))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void obbe(BlockBreakEvent event) {
		if(event.getBlock().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(!GameManager.TERRAIN_CHANGEABLE)
			event.setCancelled(true);
		if(event.getPlayer().getGameMode() == GameMode.CREATIVE && plugin.getRank(event.getPlayer()) >= Values.RANK_ADMIN)
			event.setCancelled(false);
	}
	
	@EventHandler
	public void obpe(BlockPlaceEvent event) {
		if(event.getBlock().getWorld().getName().equals("world"))
			event.setCancelled(true);
		if(!GameManager.TERRAIN_CHANGEABLE)
			event.setCancelled(true);
		if(event.getPlayer().getGameMode() == GameMode.CREATIVE && plugin.getRank(event.getPlayer()) >= Values.RANK_ADMIN)
			event.setCancelled(false);
	}
	
	@EventHandler
	public void odie(PlayerDropItemEvent event) {
		if(event.getPlayer().getWorld().getName().equals("world"))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void opi(PlayerInteractEvent event) {
		ItemStack item = event.getPlayer().getItemInHand();
		if(hub != null && item != null && item.equals(hub)) {
			ByteArrayOutputStream b = new ByteArrayOutputStream();
			DataOutputStream out = new DataOutputStream(b);
			try {
				out.writeUTF("Connect");
				out.writeUTF("hub");
			} catch (IOException e) {
				e.printStackTrace();
			}
			event.getPlayer().sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
		}
	}
	
	private ItemStack hub = null;
	private ArrayList<String> hubreturn = new ArrayList<String>();
	protected void giveHub(Player p) {
		if(hub == null) {
			hub = new ItemStack(Material.COMPASS);
			ItemMeta im = hub.getItemMeta();
			im.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Return to Hub");
			hub.setItemMeta(im);
		}
		p.getInventory().clear();
		p.getInventory().addItem(hub);
		if(!hubreturn.contains(p.getName())) {
			final String name = p.getName();
			hubreturn.add(name);
			plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
				public int count = 0;
				public void run() {
					if(plugin.getServer().getPlayerExact(name) != null) {
						if(count++ % 10 == 0) {
							plugin.getServer().getPlayerExact(name).getInventory().clear();
							plugin.getServer().getPlayerExact(name).getInventory().addItem(hub);
							plugin.getServer().getPlayerExact(name).sendMessage(ChatColor.AQUA + "Click while holding your " + ChatColor.GOLD + "Compass" + ChatColor.AQUA + " to return to Hub!");	
						}
						if(count < 30)
							plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
						else
							hubreturn.remove(name);
					} else {
						hubreturn.remove(name);
					}
				}
			});
		}
	}
	
	protected void leave(Player p) {
		if(players.contains(p.getName())) {
			p.teleport(plugin.getServer().getWorld("world").getSpawnLocation());
			players.remove(p.getName());
			p.removeMetadata("id", plugin);
			p.getInventory().clear();
			giveHub(p);
		}
		if(inProgress && checkEndCondition()) {
			end();
		}
	}
	
	protected abstract boolean checkEndCondition();
	protected abstract void objectiveTask();
	
	protected static RonboShrek plugin;
	protected Game(int id) {
		this.id = id;
		board = plugin.getServer().getScoreboardManager().getNewScoreboard();
		objectiveTask();
		String[] s = GameManager.WORLD_NAMES[(int)(Math.random() * GameManager.WORLD_NAMES.length)];
		currentMapWorldTemplateName = s[0];
		currentMapDisplayName = s[1];
	}
	
}
