package xronbo.common.games;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.messaging.PluginMessageListener;

import xronbo.ronboshrek.RonboShrek;
import xronbo.ronboshrek.ShrekGame;

public class GameManager implements Listener, PluginMessageListener {
	
	/*
	 * Things that need to be changed every minigame
	 */

	public static final String GAME_NAME = "Shrekt";
	public static final String[][] WORLD_NAMES = {
		{"maze", "Maze"},
	};
	public static final int PLAYERS_TO_START = 2;
	public static final int COUNTDOWN_LENGTH = 60;
	public static final boolean JOINABLE_AFTER_START = false;
	public static final int GAME_COUNT = 3;
	public static final int MAX_PLAYERS = 24;
	public static final boolean TERRAIN_CHANGEABLE = false;
	public static final boolean LEAVE_ON_DEATH = true;
	public static final boolean SHOW_DEATH_MESSAGE = false;
	private static final Class<? extends Game> GAME_CLASS = ShrekGame.class;
	
	public static void sendInfo() {
		if(plugin.getServer().getOnlinePlayers().length > 0) {
			Player p = Bukkit.getOnlinePlayers()[0];
			ByteArrayOutputStream b = new ByteArrayOutputStream();
			DataOutputStream out = new DataOutputStream(b);
			try {
				for(Game g : games.values()) {
					out.writeInt(g.players.size());
					out.writeBoolean(g.inProgress);
					out.writeBoolean(g.joinable);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			p.sendPluginMessage(plugin, "MinigameInfo", b.toByteArray());
		}
	}
	
	/*
	 * Use as-is
	 */
	
	private static int ID = 0;
	public static HashMap<Integer, Game> games = new HashMap<Integer, Game>();
	private static boolean registeredListener = false;
	public static volatile int lastWorldIndex = 0;
	
	private static void load() {
		Game.plugin = plugin;
		for(int k = 0; k < GAME_COUNT; k++) {
			int id = ID++;
			try {
				Game g = GAME_CLASS.getConstructor(int.class).newInstance(id);
				if(!registeredListener) {
					registeredListener = true;
					plugin.getServer().getPluginManager().registerEvents(g, plugin);
				}
				games.put(id, g);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Loaded " + games.size() + " game instances.");
		infoTask();
	}
	
	public static void infoTask() {
		plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
			public void run() {
				sendInfo();
			}
		}, 20, 20);
	}
	
	public static void add(Player p, int id, boolean vip) {
		p.setMetadata("id", new FixedMetadataValue(plugin, id));
		Game g = getGame(p);
		boolean join = false;
		if(g.joinable) {
			if(g.players.size() < MAX_PLAYERS || vip) {
				join = true;
				g.join(p);
			} else {
				g.joinable = false;
				for(Game g2 : games.values()) {
					if(g2.joinable) {
						join = true;
						g2.join(p);
						p.sendMessage(ChatColor.RED + "The game number you wanted to join was full :(");
						p.sendMessage(ChatColor.RED + "So, we moved you to an open one!");
						p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/hub" + ChatColor.GREEN + " if you wish to return to the Kastia Lobby.");
						break;
					}
				}
			}
		} else {
			for(Game g2 : games.values()) {
				if(g2.joinable) {
					join = true;
					g2.join(p);
					p.sendMessage(ChatColor.RED + "The game number you wanted to join could not be joined :(");
					p.sendMessage(ChatColor.RED + "So, we moved you to an joinable one!");
					p.sendMessage(ChatColor.GREEN + "Use " + ChatColor.YELLOW + "/hub" + ChatColor.GREEN + " if you wish to return to the Kastia Lobby.");
					break;
				}
			}
		}
		if(!join) {
			p.removeMetadata("id", plugin);
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage("");
			p.sendMessage(ChatColor.RED + "Sorry! It looks like the game you wanted to join is now un-joinable. Please try again.");
			p.sendMessage(ChatColor.RED + "Sending you back to the Kastia Lobby...");
			ByteArrayOutputStream b = new ByteArrayOutputStream();
			DataOutputStream out = new DataOutputStream(b);
			try {
				out.writeUTF("Connect");
				out.writeUTF("hub");
			} catch (IOException e) {
				e.printStackTrace();
			}
			p.sendPluginMessage(plugin, "BungeeCord", b.toByteArray());
		}
	}
	
	public static Game getGame(Player p) {
		int id = getGameId(p);
		if(id > -1 && games.containsKey(id))
			return games.get(id);
		return null;
	}
	
	public static int getGameId(Player p) {
		if(p.hasMetadata("id"))
			return p.getMetadata("id").get(0).asInt();
		return -1;
	}
	
	@Override
	public void onPluginMessageReceived(String channel, Player player, byte[] message) {
		if(channel.equals("MinigameTransfer")) {
			DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
			try {
				final String name = in.readUTF();
				final int id = in.readInt();
				final boolean vip = in.readBoolean();
				System.out.println("Recieved minigame transfer (" + name + "->" + id + ") VIP?" + vip);
				plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
					public int count = 0;
					public void run() {
						if(plugin.getServer().getPlayerExact(name) != null) {
							add(plugin.getServer().getPlayerExact(name), id, vip);
						} else {
							if(count < 10) {
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 10);
							}
							count++;
						}
					}
				});
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static RonboShrek plugin;
	public GameManager(RonboShrek plugin) {
		GameManager.plugin = plugin;
		load();
	}
	
}
