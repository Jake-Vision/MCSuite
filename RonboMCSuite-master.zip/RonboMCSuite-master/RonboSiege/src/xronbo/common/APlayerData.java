package xronbo.common;

import java.util.HashMap;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import xronbo.common.hpbar.HPBar;
import xronbo.ronbosiege.PlayerData;
import xronbo.ronbosiege.RonboSiege;

public abstract class APlayerData  {
	
	public static HashMap<String, PlayerData> players = new HashMap<String, PlayerData>();	
	public static Scoreboard board = null;
	public static Objective objectiveHP = null;

	public String playerName;
	public int health;
	public long lastDamaged = 0;
	
	public static APlayerData getPD(Object p) {
		if(p instanceof Player)
			return players.get(((Player)p).getName());
		else
			return players.get(p.toString());
	}
	
	public void damage(int i, boolean isSpell) {
		if(!isSpell) {
			if(System.currentTimeMillis() - lastDamaged < 1000)
				return;
		}
		health -= i;
		if(health <= 0) {
			die();
		}
		updateHP();
		getPlayer().damage(0);
	}
	
	public int getMaxHP() {
		return 100;
	}
	
	public void updateHP() {
		objectiveHP.getScore(getPlayer()).setScore(health);
		HPBar.setMessage(getPlayer(), ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "HP: " + ChatColor.RESET + "" + ChatColor.LIGHT_PURPLE + (health > 0 ? health : 0) + "/" + (getMaxHP()), ((float) health / (getMaxHP())) * 100);
		double hearts = ((double)health) / (getMaxHP()) * 20;
		if(hearts <= 1 && health > 0)
			hearts = 1;
		if(hearts > 20)
			hearts = 20;
		if(hearts <= 1)
			hearts = 1;
		getPlayer().setHealth(hearts);
	}
	
	public void die() {
		getPlayer().getInventory().clear();
		health = getMaxHP();
		postDeath();
	}
	
	public abstract void postDeath();
	
	public Player getPlayer() {
		return plugin.getServer().getPlayerExact(playerName);
	}
	
	public static RonboSiege plugin;
	
	public abstract Team getTeam(Player p);
	
	public APlayerData(Player p) {
		if(board == null) {
			board = plugin.getServer().getScoreboardManager().getNewScoreboard();
			objectiveHP = board.registerNewObjective("hpdisplay", "dummy");
			objectiveHP.setDisplaySlot(DisplaySlot.BELOW_NAME);
			objectiveHP.setDisplayName(ChatColor.RED + "\u2764");
		}
		playerName = p.getName();
		health = getMaxHP();
		objectiveHP.getScore(getPlayer()).setScore(health);
		double hearts = ((double)health) / (getMaxHP()) * 20;
		if(hearts <= 1 && health > 0)
			hearts = 1;
		if(hearts > 20)
			hearts = 20;
		if(health <= 0) {
			hearts = 1;
		}
		final PlayerData me = (PlayerData)this;
		getPlayer().setHealth(hearts);
		HPBar.setMessage(getPlayer(), ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "HP: " + ChatColor.RESET + "" + ChatColor.LIGHT_PURPLE + (health > 0 ? health : 0) + "/" + (getMaxHP()), ((float) health / (getMaxHP())) * 100);
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				players.put(playerName, me);
			}
		}, 1);
	}
	
}
