package xronbo.common;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

import xronbo.ronbosiege.GrandmasterManager;
import xronbo.ronbosiege.RonboSiege;

public class CombatManager implements Listener {

	@EventHandler
	public void onEntityDamageEvent(EntityDamageEvent event) {
		if(event instanceof EntityDamageByEntityEvent) {
			EntityDamageByEntityEvent e = (EntityDamageByEntityEvent)event;
			if(e.getDamager() instanceof Player) {
				combat(e.getDamager(), e.getEntity(), getDamage((Player)e.getDamager()), false);
			} else if(e.getDamager() instanceof Projectile) {
				combat(e.getDamager(), e.getEntity(), 0, false);
				e.getDamager().remove();
			}
		}
		event.setCancelled(true);
	}
	
	public static void combat(Entity attacker, Entity damaged, int damage, boolean isSpell) {
		if(attacker instanceof Projectile) {
			Projectile proj = (Projectile)attacker;
			if(proj.getShooter() instanceof Player)
				attacker = proj.getShooter();
			isSpell = true;
		}
		if(attacker == damaged)
			return;
		if(attacker.hasMetadata("spectator") && attacker.getMetadata("spectator").get(0).asBoolean())
			return;
		if(attacker.hasMetadata("team") && damaged.hasMetadata("team") && attacker.getMetadata("team").get(0).asString().equals(damaged.getMetadata("team").get(0).asString()))
			return;
		if(attacker instanceof Player) {
			if(damage == 0)
				damage = getDamage((Player)attacker);
			if(damaged instanceof Player) {
				APlayerData.getPD(damaged).damage(damage, isSpell);
			} else if(damaged.getUniqueId().equals(GrandmasterManager.grandmaster) && !attacker.getMetadata("team").get(0).asString().equals("defender")) {
				GrandmasterManager.damageGrandmaster((LivingEntity)damaged, damage, isSpell);
			}
		}
	}
	
	public static int getDamage(Player p) {
		ItemStack item = p.getItemInHand();
		int damage = 1;
		if(item != null && item.hasItemMeta() && item.getItemMeta().hasLore()) {
			try {
				String s = item.getItemMeta().getLore().get(0);
				damage = Integer.parseInt(ChatColor.stripColor(s).substring("Damage: ".length()));
			} catch(Exception e) {
				
			}
		}
		return damage;
	}
	
	public static RonboSiege plugin;
	public CombatManager(RonboSiege plugin) {
		CombatManager.plugin = plugin;
		APlayerData.plugin = plugin;
	}
}
