package xronbo.common;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import net.minecraft.server.v1_7_R3.EntityWitherSkull;
import net.minecraft.server.v1_7_R3.World;

import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_7_R3.CraftWorld;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import xronbo.common.effects.EffectCreator;
import xronbo.common.effects.EffectHolder;
import xronbo.common.effects.ParticleDetails;
import xronbo.common.effects.ParticleType;
import xronbo.ronbosiege.RonboSiege;

public class ItemManager implements Listener {
	
	public static ItemStack wandammo = new ItemStack(Material.GLOWSTONE_DUST);
	public static ItemStack bowammo = new ItemStack(Material.REDSTONE_TORCH_ON);
	
	public enum Weapon {
		BONE(ChatColor.RED + "Heavy Bone", 12, SpellSet.BONE, new ItemStack(Material.BONE, 1)),
		DAGGER(ChatColor.RED + "Sharp Dagger", 11, SpellSet.DAGGER, new ItemStack(Material.SHEARS, 1)),
		SWORD(ChatColor.AQUA + "Curtana", 15, SpellSet.SWORD, new ItemStack(Material.IRON_SWORD, 1)),
		BOW(ChatColor.AQUA + "Ronbow", 13, SpellSet.BOW, new ItemStack(Material.BOW, 1)),
		FIREBOW(ChatColor.RED + "Flaming Ronbow", 15, SpellSet.BOW, new ItemStack(Material.BOW, 1)),
		MACE(ChatColor.RED + "Spiky Mace", 14, SpellSet.MACE, new ItemStack(Material.STONE_SPADE, 1)),
		WAND(ChatColor.GOLD + "Royal Wand", 17, SpellSet.WAND, new ItemStack(Material.GOLD_HOE, 1)),
		STAVE(ChatColor.GOLD + "Heaven Canceller", 10, SpellSet.STAVE, new ItemStack(Material.STICK, 1)),
		;
		public ItemStack getItem() {
			ItemStack clone = item.clone();
			ItemMeta im = clone.getItemMeta();
			im.setDisplayName(name);
			im.setLore(Arrays.asList(new String[] {ChatColor.GOLD + "Damage: " + ChatColor.YELLOW + damage, ChatColor.DARK_AQUA + "Spell: " + ChatColor.AQUA + getSpell()}));
			clone.setItemMeta(im);
			return removeAttributes(clone);
		}
		public String getSpell() {
			return spellset.spells[(int)(Math.random() * spellset.spells.length)].name;
		}
		public ItemStack item;
		public String name;
		public int damage;
		public SpellSet spellset;
		Weapon(String name, int damage, SpellSet spells, ItemStack item) {
			this.name = name;
			this.item = item;
			this.damage = damage;
			this.spellset = spells;
		}
	}
	
	@EventHandler
	public void onph(final ProjectileHitEvent event) {
		plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				event.getEntity().remove();
			}
		}, 10);
	}
	
	@EventHandler
	public void onpp(PlayerPickupItemEvent event) {
		if(event.getItem().getItemStack().getType() == Material.ARROW) {
			event.setCancelled(true);
			event.getItem().remove();
		}
	}
	
	@EventHandler
	public void onpi(final PlayerInteractEvent event) {
		try {
			if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
				ItemStack item = event.getPlayer().getItemInHand();
				String spellName = item.getItemMeta().getLore().get(1);
				spellName = ChatColor.stripColor(spellName).substring("Spell: ".length());
				boolean shot = false;
				for(SpellSet ss : SpellSet.values()) {
					for(Spell s : ss.spells) {
						if(s.name.equals(spellName)) {
							s.cast(event.getPlayer());
							shot = true;
							break;
						}
					}
					if(shot)
						break;
				}
				event.setCancelled(true);
			} else if(event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
				ItemStack item = event.getPlayer().getItemInHand();
				Material m = item.getType();
				if(m == Material.WOOD_HOE || m == Material.STONE_HOE || m == Material.IRON_HOE || m == Material.GOLD_HOE || m == Material.DIAMOND_HOE) {
					event.setCancelled(true);
					Player p = event.getPlayer();
					if(p.getInventory().contains(Material.GLOWSTONE_DUST)) {
						int slot = p.getInventory().first(Material.GLOWSTONE_DUST);
						if(p.getInventory().getItem(slot).getAmount() > 1)
							p.getInventory().getItem(slot).setAmount(p.getInventory().getItem(slot).getAmount() - 1);
						else
							p.getInventory().setItem(slot, new ItemStack(Material.AIR));
						final ArrayList<Location> boltLocs = new ArrayList<Location>();
						final ArrayList<Integer> tasks = new ArrayList<Integer>();
						final Player player = p;
						final int damage = CombatManager.getDamage(p);
						Vector v = p.getEyeLocation().getDirection().normalize();
						Location loc = p.getEyeLocation();
						for(int k = 0; k < 10; k++) {
							loc.add(v.toLocation(loc.getWorld()));
							if(isAirlike(loc.getBlock().getType()))
								boltLocs.add(loc.clone());
							else
								break;
						}
						SoundHandler.playSound(p, Sound.FIREWORK_LAUNCH);
						for(int k = 0; k < boltLocs.size(); k+=2) {
							final int current = k;
							tasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
								public void run() {
									Location loc = boltLocs.get(current);
									HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
									particles.add(new ParticleDetails(ParticleType.RAINBOWSWIRL));
									EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
									holder.setRunning(true);
									holder.update();
									holder.setRunning(false);
									Entity e = loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
									Entity e3 = null;
									if(current + 1 < boltLocs.size())
										e3 = loc.getWorld().spawnEntity(boltLocs.get(current + 1), EntityType.FIREWORK);
									List<Entity> toHit = (e3 != null ? e3 : e).getNearbyEntities(0.5, 0.5, 0.5);
									for(Entity e2 : toHit) {
										if(!(e2 instanceof LivingEntity))
											continue;
										CombatManager.combat(player, e2, damage, true);
										for(Integer i : tasks)
											plugin.getServer().getScheduler().cancelTask(i);
										break;
									}
									e.remove();
									if(e3 != null)
										e3.remove();
								}
							}, k * 1));
						}
					} else {
						p.sendMessage(ChatColor.RED + "You are out of Magical Energy!");
					}
				} else if(m == Material.BOW) {
					event.setCancelled(true);
					Player p = event.getPlayer();
					if(p.getInventory().contains(Material.REDSTONE_TORCH_ON)) {
						int slot = p.getInventory().first(Material.REDSTONE_TORCH_ON);
						if(p.getInventory().getItem(slot).getAmount() > 1)
							p.getInventory().getItem(slot).setAmount(p.getInventory().getItem(slot).getAmount() - 1);
						else
							p.getInventory().setItem(slot, new ItemStack(Material.AIR));
						Arrow arrow = p.launchProjectile(Arrow.class);
						arrow.setVelocity(arrow.getVelocity().multiply(1.5));
						arrow.setBounce(false);
						arrow.setShooter(p);
						arrow.setMetadata("damage", new FixedMetadataValue(plugin, CombatManager.getDamage(p)));
						if(item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().contains("Flaming"))
							arrow.setFireTicks(1000);
						p.playSound(p.getLocation(), Sound.SHOOT_ARROW, 10, 1);
					} else {
						p.sendMessage(ChatColor.RED + "You are out of Ronbow Arrows!");
					}
				}
			}
		} catch(Exception e) {
//			e.printStackTrace();
		}
	}
	
	public static boolean isAirlike(Material m) {
		switch(m.getId()) {
			case 0: //air
			case 78: //snow layer
			case 51: //fire
			case 50: //torch
			case 59: //wheat
			case 39: //mushroom
			case 40: //mushroom
			case 55: //redstone wire
			case 70: //stone pressure
			case 72: //wood pressure
			case 106: //vines
			case 141: //carrots
			case 142: //potatoes
			case 175: //flowers
			case 31: //grasses
			case 32: //dead shrub
				return true;
			default:
				return false;
		}
	}
	
	public enum SpellSet {
		BOW(new Spell[]{
			new Spell("Triple Shot", "You quickly shoot out three arrows at once.") {
				public void effect(Player p) {
					for(int k = 0; k < 3; k++) {
						Arrow arrow = p.launchProjectile(Arrow.class);
						arrow.setVelocity(arrow.getVelocity().multiply(1.5));
						arrow.setShooter(p);
						arrow.setBounce(false);
						arrow.setCritical(true);
						arrow.setMetadata("damage", new FixedMetadataValue(plugin, CombatManager.getDamage(p)));
						SoundHandler.playSound(p, Sound.SHOOT_ARROW);
					}
				}
			},
			new Spell("Arrow Rain", "A shower of arrows rains down at your target.") {
				public void effect(Player p) {
					Location loc = p.getTargetBlock(null, 0).getLocation();
					SoundHandler.playSound(p, Sound.PISTON_EXTEND);
					for(int x = -3; x <= 3; x++) {
						for(int z = -3; z <= 3; z++) {
							Location currentLoc = loc.clone();
							currentLoc.setX(loc.getX() + x - 1);
							currentLoc.setZ(loc.getZ() + z);
							currentLoc.setY(loc.getY() + 6);
							Projectile arrow = ((Projectile)(loc.getWorld().spawnEntity(currentLoc, EntityType.ARROW)));
							Location loc2 = loc.clone();
							loc2.setX(loc.getX() + x);
							loc2.setZ(loc.getZ() + z);
							Vector v = loc2.toVector().subtract(currentLoc.toVector()).normalize();
							arrow.setVelocity(v);
							arrow.setShooter(p);
							arrow.setMetadata("damage", new FixedMetadataValue(plugin, CombatManager.getDamage(p)));
						}
					}
				}
			},
		}),
		DAGGER(new Spell[]{
				new Spell("Displace", "You warp yourself to a nearby player.") {
					public void effect(Player p) {
						Entity closest = null;
						double distance = Integer.MAX_VALUE;
						for(Entity e : p.getNearbyEntities(30, 30, 30)) {
							if(!(e instanceof LivingEntity))
								continue;
							if(e.getLocation().distanceSquared(p.getLocation()) < distance) {
								closest = e;
								distance = e.getLocation().distanceSquared(p.getLocation());
							}
						}
						if(closest != null) {
							p.teleport(closest.getLocation());
							p.getLocation().getWorld().playEffect(p.getLocation(), Effect.SMOKE, 4);
							p.getLocation().getWorld().playSound(p.getLocation(), Sound.PORTAL_TRAVEL, 1, 1);
						}
						p.sendMessage(ChatColor.RED + "There was no one nearby...");
					}
				},
				new Spell("Acrobat", "You feel your strength and energy renewed.") {
					public void effect(Player p) {
						p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 20 * 5, 1));
						p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 5, 1));
						SoundHandler.playSound(p, Sound.CAT_HISS);
					}
				},
			}),
		MACE(new Spell[]{
				new Spell("Smash", "You smash the ground with a powerful blow.") {
					public void effect(Player p) {
						Location loc = p.getLocation();
						loc.getWorld().createExplosion(loc.getX(), loc.getY(), loc.getZ(), 4, false, false);
						for(Entity e : p.getNearbyEntities(5, 5, 5)) {
							if(e instanceof LivingEntity) {
								CombatManager.combat(p, e, CombatManager.getDamage(p), true);
							}
						}
					}
				},
				new Spell("Gravity", "You force those nearby to be drawn closer to you.") {
					public void effect(Player p) {
						for(Entity e : p.getNearbyEntities(5, 3, 5)) {
							e.setVelocity(p.getLocation().subtract(e.getLocation()).toVector().multiply(2).normalize());
						}
					}
				},
			}),
		SWORD(new Spell[]{
				new Spell("Judgement", "You summon a powerful bolt of lightning.") {
					public void effect(Player p) {
						p.playSound(p.getLocation(), Sound.EXPLODE, 20, 1);
						p.getWorld().strikeLightningEffect(p.getLocation());
						for(Entity e : p.getNearbyEntities(5, 3, 5)) {
							if(e instanceof LivingEntity) {
								CombatManager.combat(p, e, CombatManager.getDamage(p), true);
							}
						}
					}
				},
				new Spell("Charge", "You charge forward, ready for battle.") {
					public void effect(Player p) {
						p.setVelocity(p.getEyeLocation().getDirection().normalize().multiply(2).setY(0).add(new Vector(0, 0.5, 0)));
						SoundHandler.playSound(p, Sound.WITHER_SHOOT);
					}
				},
			}),
		WAND(new Spell[]{
				new Spell("Fire Bolt", "You shoot a super hot bolt of fire.") {
					public void effect(Player p) {
						final ArrayList<Location> boltLocs = new ArrayList<Location>();
						final ArrayList<Integer> tasks = new ArrayList<Integer>();
						final Player player = p;
						final int damage = CombatManager.getDamage(p);
						Vector v = p.getEyeLocation().getDirection().normalize();
						Location loc = p.getEyeLocation();
						for(int k = 0; k < 10; k++) {
							loc.add(v.toLocation(loc.getWorld()));
							if(isAirlike(loc.getBlock().getType()))
								boltLocs.add(loc.clone());
							else
								break;
						}
						SoundHandler.playSound(p, Sound.FIREWORK_LAUNCH);
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public int count = 0;
							public void run() {
								for(int k = 0; k < boltLocs.size(); k+=2) {
									final int current = k;
									tasks.add(plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
										public void run() {
											Location loc = boltLocs.get(current);
											HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
											particles.add(new ParticleDetails(ParticleType.FIRE));
											EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
											holder.setRunning(true);
											holder.update();
											holder.setRunning(false);
											Entity e = loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
											Entity e3 = null;
											if(current + 1 < boltLocs.size())
												e3 = loc.getWorld().spawnEntity(boltLocs.get(current + 1), EntityType.FIREWORK);
											List<Entity> toHit = (e3 != null ? e3 : e).getNearbyEntities(0.5, 0.5, 0.5);
											for(Entity e2 : toHit) {
												if(!(e2 instanceof LivingEntity))
													continue;
											    World world = ((CraftWorld)player.getWorld()).getHandle();
											    net.minecraft.server.v1_7_R3.Entity launch = new EntityWitherSkull(world);
											    Projectile proj = (Projectile) launch.getBukkitEntity();
												Player shooter = (Player) player;
												proj.setBounce(false);
												proj.setShooter(shooter);
												CombatManager.combat(player, e2, damage, true);
												proj.remove();
												for(Integer i : tasks)
													plugin.getServer().getScheduler().cancelTask(i);
												break;
											}
											e.remove();
											if(e3 != null)
												e3.remove();
										}
									}, k * 1));
								}
								if(count++ < 8)
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 5);
							}
						});
					}
				},
				new Spell("Fire Aura", "You summon an aura of fire around you.") {
					public void effect(final Player p) {
						final int damage = CombatManager.getDamage(p);
						plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
							public int count;
							public void run() {
								final ArrayList<Location> locs = new ArrayList<Location>();
								for(int dx = -1; dx <= 1; dx++) {
									for(int dy = 0; dy <= 2; dy++) {
										for(int dz = -1; dz <= 1; dz++) {
											if(!(dx == 0 && (dy == 0 || dy == 1) && dz == 0))
											locs.add(p.getLocation().clone().add(dx,dy,dz));
										}
									}
								}
								for(Location loc : locs) {
									if(Math.random() < 0.2) {
										HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
										particles.add(new ParticleDetails(ParticleType.FIRE));
										EffectHolder holder = EffectCreator.createLocHolder(particles, loc);
										holder.setRunning(true);
										holder.update();
										holder.setRunning(false);
									}
									Entity e = loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
									for(Entity e2 : e.getNearbyEntities(1,1,1)) {
										if(!(e2 instanceof LivingEntity))
											continue;
									    World world = ((CraftWorld)p.getWorld()).getHandle();
									    net.minecraft.server.v1_7_R3.Entity launch = new EntityWitherSkull(world);
									    Projectile proj = (Projectile) launch.getBukkitEntity();
										Player shooter = (Player) p;
										proj.setBounce(false);
										proj.setShooter(shooter);
										CombatManager.combat(p, e2, damage, true);
										proj.remove();
										break;
									}
								}
								if(count++ < 4)
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 5);
							}
						});
					}
				},
			}),
			STAVE(new Spell[]{
					new Spell("Heal", "You quickly heal yourself for 20 HP.") {
						public void effect(Player p) {
							p.playSound(p.getLocation(), Sound.ORB_PICKUP, 10, 1);
							HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
							particles.add(new ParticleDetails(ParticleType.HEART));
							EffectHolder holder = EffectCreator.createLocHolder(particles, p.getLocation());
							holder.setRunning(true);
							holder.update();
							holder.setRunning(false);
							APlayerData pd = APlayerData.getPD(p);
							pd.health += 20;
							if(pd.health > 100)
								pd.health = 100;
							pd.updateHP();
						}
					},
					new Spell("Group Heal", "You quickly heal those around you for 10 HP.") {
						public void effect(Player p2) {
							p2.playSound(p2.getLocation(), Sound.ORB_PICKUP, 10, 1);
							HashSet<ParticleDetails> particles = new HashSet<ParticleDetails>();
							particles.add(new ParticleDetails(ParticleType.HEART));
							EffectHolder holder = EffectCreator.createLocHolder(particles, p2.getLocation());
							holder.setRunning(true);
							holder.update();
							holder.setRunning(false);
							APlayerData pd = APlayerData.getPD(p2);
							pd.health += 10;
							if(pd.health > 100)
								pd.health = 100;
							pd.updateHP();
							for(Entity e : p2.getNearbyEntities(7,7,7)) {
								if(!(e instanceof Player))
									continue;
								Player p = (Player)e;
								if(p.hasMetadata("team") && p2.hasMetadata("team") && p.getMetadata("team").get(0).asString().equals(p2.getMetadata("team").get(0).asString())) {
									p.playSound(p.getLocation(), Sound.ORB_PICKUP, 10, 1);
									particles = new HashSet<ParticleDetails>();
									particles.add(new ParticleDetails(ParticleType.HEART));
									holder = EffectCreator.createLocHolder(particles, p.getLocation());
									holder.setRunning(true);
									holder.update();
									holder.setRunning(false);
									pd = APlayerData.getPD(p);
									pd.health += 10;
									if(pd.health > 100)
										pd.health = 100;
									pd.updateHP();
								}
							}
						}
					},
				}),
				BONE(new Spell[]{
						new Spell("MMBLARG", "MMBLARG!!!") {
							public void effect(final Player p) {
								Location loc = p.getLocation();
								ArrayList<int[]> coords = new ArrayList<int[]>();
								SoundHandler.playSound(p, Sound.EXPLODE);
								for(int k = 0; k < 10; k++) {
									coords.add(new int[] {(int)(Math.random() * 7 - 3), (int)(Math.random() * 7 - 3)});
								}
								final ArrayList<UUID> damaged = new ArrayList<UUID>();
								Material[] materials = {Material.DIRT, Material.STONE, Material.COBBLESTONE};
								for(int[] i : coords) {
									int x = i[0];
									int z = i[1];
									Location currentLoc = loc.clone();
									currentLoc.setX(loc.getX() + x);
									currentLoc.setZ(loc.getZ() + z);
									currentLoc.setY(loc.getY() + 4);
									final FallingBlock fb = currentLoc.getWorld().spawnFallingBlock(currentLoc, materials[(int)(Math.random() * materials.length)], (byte) 1);
									fallingBlocks.add(fb.getUniqueId().toString());
									fb.setDropItem(false);
									final int damageValue = CombatManager.getDamage(p);
									plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
										public void run() {
											boolean hit = false;
											if(fb == null || !fb.isValid() || fb.isDead())
												return;
											for(Entity e2 : fb.getNearbyEntities(1, 1, 1)) {
												if(!(e2 instanceof LivingEntity))
													continue;
												if(damaged.contains(e2.getUniqueId()))
													continue;
												damaged.add(e2.getUniqueId());
												CombatManager.combat(p, e2, damageValue, true);
											}
											if(!hit)
												plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, this, 2);
										}
									}, 2);
								}
							}
						},
						new Spell("UNNHG", "UNNHG!!!") {
							public void effect(final Player p) {
								p.setVelocity(new Vector(0,0.7,0));
								final int damageValue = CombatManager.getDamage(p);
								plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
									public void run() {
										if(p == null || p.isDead() || !p.isOnline())
											return;
										Location loc = p.getLocation();
										loc.getWorld().createExplosion(loc.getX(),loc.getY(),loc.getZ(),4.0f,false,false);
										for(Entity e2 : p.getNearbyEntities(5, 5, 5)) {
											if(!(e2 instanceof LivingEntity))
												continue;
											CombatManager.combat(p, e2, damageValue, true);
										}
									}
								}, 15);
							}
						},
					}),
			;
		public Spell[] spells;
		SpellSet(Spell[] spells) {
			this.spells = spells;
		}
	}
	
	public abstract static class Spell {
		public static HashMap<String, Long> lastCast = new HashMap<String, Long>();
		public void cast(Player p) {
			if(lastCast.containsKey(p.getName())) {
				long last = lastCast.get(p.getName());
				if(System.currentTimeMillis() - last < 5000) {
					p.sendMessage(ChatColor.RED + "You can only cast a spell once every 5 seconds. (" + String.format("%.1f", 5.0 - (System.currentTimeMillis() - last)/1000.0) + "s left)");
					return;
				}
			}
			lastCast.put(p.getName(), System.currentTimeMillis());
			p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + activation);
			effect(p);
		}
		public abstract void effect(Player p);
		public String name, activation;
		public Spell(String name, String activation) {
			this.name = name;
			this.activation = activation;
		}
	}
	
	public static ArrayList<String> fallingBlocks = new ArrayList<String>();
	
	@EventHandler
	public void onEntityChangeBlock(EntityChangeBlockEvent event) {
		if(fallingBlocks.contains(event.getEntity().getUniqueId().toString())) {
			event.setCancelled(true);
			fallingBlocks.remove(event.getEntity().getUniqueId().toString());
		}
	}
	
    public static ItemStack removeAttributes(ItemStack item){
		try {
		  Object nmsItem = NMSStuff.getNMSItem(item);
		  if(nmsItem == null)
			  return item;
		  Object modifiers = NMSStuff.getNMSClass("NBTTagList").newInstance();
		  Object tag = NMSStuff.getNMSValue("ItemStack", "tag", nmsItem);
		  if(tag == null) {
		      tag = NMSStuff.getNMSClass("NBTTagCompound").newInstance();
		      NMSStuff.setNMSValue("ItemStack", "tag", nmsItem, tag);
		  }
		  Method meth = NMSStuff.getNMSClass("NBTTagCompound").getDeclaredMethod("set", String.class, NMSStuff.getNMSClass("NBTBase"));
		  meth.invoke(tag, "AttributeModifiers", modifiers);
		  NMSStuff.setNMSValue("ItemStack", "tag", nmsItem, tag);
		  return NMSStuff.getBukkitItem(nmsItem);
		} catch (Exception e) {
			
		}
        return item;
    }
	
	public static RonboSiege plugin;
	public ItemManager(RonboSiege plugin) {
		ItemManager.plugin = plugin;
		ItemMeta im = wandammo.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Magical Energy");
		im.setLore(Arrays.asList(ChatColor.AQUA + "Ammo for wands!"));
		wandammo.setItemMeta(im);
		im = bowammo.getItemMeta();
		im.setDisplayName(ChatColor.GOLD + "Ronbow Arrow");
		im.setLore(Arrays.asList(ChatColor.AQUA + "Ammo for bows!"));
		bowammo.setItemMeta(im);
	}
	
}
