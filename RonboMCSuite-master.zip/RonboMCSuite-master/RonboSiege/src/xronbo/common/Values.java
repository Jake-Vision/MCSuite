package xronbo.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.bukkit.ChatColor;

public final class Values {
	
	public static final int RANK_MEMBER = 1;
	public static final int RANK_VIP = 2;
	public static final int RANK_ALPHA = 3;
	public static final int RANK_WRITER = 4;
	public static final int RANK_GFX = 5;
	public static final int RANK_HELPER = 6;
	public static final int RANK_VIDEO = 7;
	public static final int RANK_BUILDER = 8;
	public static final int RANK_MOD = 9;
	public static final int RANK_ADMIN = 10;
	public static final int RANK_OWNER = 11;
	
	public static final Values values = new Values();
	
	public static String capitalize(String s) {
		StringBuilder sb = new StringBuilder("");
		boolean capitalize = true;
		for(int k = 0; k < s.length(); k++) {
			String s2 = s.substring(k, k+1);
			if(capitalize) {
				capitalize = false;
				s2 = s2.toUpperCase();
			}
			if(!s2.matches("[a-zA-z]{1}")) {
				capitalize = true;
			}
			sb.append(s2);
		}
		return sb.toString();
	}

	public static ArrayList<String> longStringToLoreList(ChatColor color, String... strings) {
		ArrayList<String> lore = new ArrayList<String>();
		for(String s : strings) {
			lore.addAll(Arrays.asList(stringToLore(s, color)));
			lore.add("");
		}
		if(lore.size() > 0) {
			if(lore.get(lore.size() - 1).equals(""))
				lore.remove(lore.size() - 1);
		}
		return lore;
	}
	
	public static String[] stringToLore(String s) {
		return stringToLore(s, ChatColor.AQUA);
	}
	
	public static String[] stringToLore(String s, ChatColor color) {
		ArrayList<String> lines = new ArrayList<String>();
		Scanner scan = new Scanner(s);
		StringBuilder temp = new StringBuilder("");
		while(scan.hasNext()) {
			String toAppend = scan.next();
			if(temp.length() + (toAppend + " ").length() > 35) {
				lines.add(color + temp.toString());
				temp.setLength(0);
				temp.append(toAppend + " ");
			} else {
				temp.append(toAppend + " ");
			}
		}
		if(temp.length() > 0)
			lines.add(color + temp.toString());
		scan.close();
		return lines.toArray(new String[lines.size()]);
	}
	
	public static int randInt(int min, int max) {
		return ((int)(Math.random() * (max - min + 1))) + min;
	}
	
	public static double randDouble(double min, double max) {
		return Math.random()*(max - min) + min;
	}
	
	private Values() {
		
	}
}