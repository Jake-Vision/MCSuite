package xronbo.common;

import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.WorldLoadEvent;

import xronbo.ronbosiege.RonboSiege;

public class GeneralManager implements Listener {

	@EventHandler
	public void onRegenHealth(EntityRegainHealthEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onCreatureSpawn(CreatureSpawnEvent event) {
		if(event.getSpawnReason() != SpawnReason.CUSTOM) {
			event.setCancelled(true);
			event.getEntity().remove();
		}
	}
	
	@EventHandler
	public void onItemDrop(PlayerDropItemEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onEntityCombust(EntityCombustEvent event) {
		event.getEntity().setFireTicks(0);
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onWeatherChange(WeatherChangeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onThunderChange(ThunderChangeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onWorldLoad(WorldLoadEvent event) {
		World w = event.getWorld();
		if(w.hasStorm())
			w.setStorm(false);
		if(w.isThundering())
			w.setThundering(false);
	}
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent event) {
		if(event.getPlayer().getGameMode() != GameMode.CREATIVE)
			event.setCancelled(true);
		if(!(event.getPlayer().getName().equals("xRonbo") || event.getPlayer().getName().equals("Edasaki") || event.getPlayer().getName().equals("Brackers10")))
			event.setCancelled(true);
	}

	@EventHandler
	public void onBlockPlace(BlockPlaceEvent event) {
		if(event.getPlayer().getGameMode() != GameMode.CREATIVE)
			event.setCancelled(true);
		if(!(event.getPlayer().getName().equals("xRonbo") || event.getPlayer().getName().equals("Edasaki") || event.getPlayer().getName().equals("Brackers10")))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onLeafDecay(LeavesDecayEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockFade(BlockFadeEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void onBlockForm(BlockFormEvent event) {
		event.setCancelled(true);
	}
	
	@EventHandler
	public void hungerDecay(FoodLevelChangeEvent event) {
		((Player)event.getEntity()).setFoodLevel(20);
		event.setCancelled(true);
	}
	
	public static RonboSiege plugin;
	public GeneralManager(RonboSiege plugin) {
		GeneralManager.plugin = plugin;
	}
}
