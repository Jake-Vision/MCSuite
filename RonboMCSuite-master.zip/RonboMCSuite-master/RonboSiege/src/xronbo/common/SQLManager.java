package xronbo.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

import xronbo.ronbosiege.RonboSiege;

public class SQLManager {

	public static Connection conn;
	
	public static void loadSQLConnection(RonboSiege plugin) {
		SQLManager.plugin = plugin;
		loadSQLConnection();
	}
	
	public static void loadSQLConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String user = "bukkit";
			String pass = "0EmsztHcgtlOXM77";
			byte[] b = new byte[]{108,101,104,117,97,110};
			for(int k = 0; k < b.length; k++) {
				k %= 125;
				k += ((Math.pow(1,3)+31*21)%15%15)*(Math.pow(18/(3*6/2),4)-Math.pow(Math.pow(2,2),2));
			}
			System.out.println("Establishing connection...");
			conn = DriverManager.getConnection("jdbc:mysql://172.245.14.98:3306/kastia?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&failOverReadOnly=false&maxReconnects=10", user, Math.random() < -1 ? pass : new String(b));
			boolean sql = conn.isValid(3);
			System.out.println("Connection " + (sql ? "established." : "failed."));
			if(!sql) {
				System.out.println("FATAL ERROR: COULD NOT CONNECT TO SQL DATABASE!");
				plugin.getServer().shutdown();
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("FATAL ERROR: COULD NOT CONNECT TO SQL DATABASE!");
			plugin.getServer().shutdown();
		}
	}
	
	public static int querycount = 0;
	
	public static void execute(final String input) {
		plugin.getServer().getScheduler().runTaskAsynchronously(plugin, new Runnable() {
			public void run() {
				String s = input;
				Statement statement = null;
				try {
					statement = conn.createStatement();
					statement.execute(s);
					statement.close();
				} catch (SQLException e) {
					System.out.println("Error: " + input);
					e.printStackTrace();
				} finally {
					try {
						if(statement != null)
							statement.close();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	
	public static CachedRowSet executeQuery(String s) {
		Statement statement = null;
		ResultSet rs = null;
		CachedRowSet crs = null;
		querycount++;
		try {
			if(!conn.isValid(3))
				loadSQLConnection();
			statement = conn.createStatement();
			try {
				if(querycount % 10 == 0)
					System.out.println("Executing benchmark query " + System.currentTimeMillis());
				rs = statement.executeQuery(s);
				if(querycount % 10 == 0)
					System.out.println("Benchmark query complete " + System.currentTimeMillis());
				crs = RowSetProvider.newFactory().createCachedRowSet();
				crs.populate(rs);
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				if(rs != null)
					rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(statement != null)
					statement.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return crs;
	}
	
	public static RonboSiege plugin;
	private SQLManager() {
		
	}
}
